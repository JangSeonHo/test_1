require('app-module-path').addPath(`${__dirname}`);

// import server, {serverExtNet} from 'server';
import server from 'server';

server.listen(4000);
// serverExtNet.listen(5000);
