import UserWorkingStatus from '../../models/account/user_working_status';

export const cleanupWorkingStatus = async (companyCode: string, tenantFlag: string): Promise<number> => {
  try {
    const WorkingStatusModel = UserWorkingStatus({ tenantFlag });
    const result = await WorkingStatusModel.deleteMany({
      company_code: companyCode
    });
    return result.deletedCount || 0;
  } catch (error) {
    console.error('Error in cleanupWorkingStatus:', error);
    throw error;
  }
}; 
