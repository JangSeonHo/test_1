/* eslint-disable max-len */
/* eslint-disable indent */
// import fs from 'fs';

import Koa from 'koa';
import Router from '@koa/router';
import cors from '@koa/cors';
import {koaBody} from 'koa-body';

import mongoose from 'mongoose';

import api from 'routes';
import checkTenantInfo from 'middlewares/checkTenantInfo';

import admin from 'firebase-admin';

import serviceAccount from './firebase.json';

import './scheduler/executeScheduler';

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount as admin.ServiceAccount),
});

import dotenv from 'dotenv';
dotenv.config();

import {dbUrl, dbUrlPrimaryOnly} from 'configs/database';

mongoose.connect(dbUrl, {maxPoolSize: 5000})
  .then(async () => {
    console.log('connect to mongoose');
  }).catch((err) => {
    console.log('failed to connect to mongoose.');
  });

export const dbPrimaryOnly = mongoose.createConnection(dbUrlPrimaryOnly);

const app = new Koa();
const router = new Router();

router.use('/api', api.routes());

app.proxy = true;
app.use(cors())
  .use(checkTenantInfo)
  .use(koaBody({
    formLimit: '100mb', // form data limit
    jsonLimit: '100mb', // json data limit
    textLimit: '100mb', // text data limit
    multipart: true,
  }))
  .use(router.routes())
  .use(router.allowedMethods())
  .use((ctx) => {
    ctx.status = 404;
    ctx.body = {'success': 'false'};
  });

import {Server, Socket} from 'socket.io';

import http from 'http';
const server = http.createServer(app.callback());

export const io = new Server(server, {});

import userInfoListener from 'sockets/dbStreamListeners/userInfo';
import userBadgeListener from 'sockets/dbStreamListeners/userBadge';
import userAlarmListener from 'sockets/dbStreamListeners/userAlarm';
import noteMemberListener from 'sockets/dbStreamListeners/noteMember';
import userSignInfoListener from 'sockets/dbStreamListeners/userSignInfo';
import userGroupInfoListener from 'sockets/dbStreamListeners/userGroupInfo';
import userInfoStatusListener from 'sockets/dbStreamListeners/userInfoStatus';
import chattingRoomInfoListener from 'sockets/dbStreamListeners/chattingRoomInfo';
import chattingRoomMemberListener from 'sockets/dbStreamListeners/chattingRoomMember';
import chattingRoomMessageListener from 'sockets/dbStreamListeners/chattingRoomMessage';
import chattingRoomMessageEgListener from 'sockets/dbStreamListeners/chattingRoomMessageEg';
import chattingRoomMessageVoteListener from 'sockets/dbStreamListeners/chattingRoomMessageVote';
import chattingRoomMessageNoticeListener from 'sockets/dbStreamListeners/chattingRoomMessageNotice';

import chattingRoomMember, {roomMemberModelPrimaryOnly} from 'models/message/chatting_room_member';
import chattingRoomInfo, {roomInfoModelPrimaryOnly} from 'models/message/chatting_room_info';
import userInfo, {userInfoModelPrimaryOnly} from 'models/account/user_info';
import departmentInfo, {deptModelPrimaryOnly} from 'models/company/company_department_info';
import companyInfo, {companyModelPrimaryOnly} from 'models/company/company_company_info';
import chatMessage, {chatRoomMsgModelPrimaryOnly} from 'models/message/chatting_room_message';
import chatNotice, {chatRoomMsgNoticeModelPrimaryOnly} from 'models/message/chatting_room_message_notice';
import noteMember, {noteMemberModelPrimaryOnly} from 'models/note/note_member';
import blockedIpRangeFileTransmit from 'models/system/blocked_ip_range_file_transmit';

const tenantLists = ['nmp'];
tenantLists.forEach((tenantFlag: string) => {
  chattingRoomInfo({tenantFlag});
  userInfo({tenantFlag});
  departmentInfo({tenantFlag});
  companyInfo({tenantFlag});
  chattingRoomMember({tenantFlag});
  chatMessage({tenantFlag});
  chatNotice({tenantFlag});
  noteMember({tenantFlag});
  blockedIpRangeFileTransmit({tenantFlag});

  roomMemberModelPrimaryOnly({tenantFlag});
  roomInfoModelPrimaryOnly({tenantFlag});
  userInfoModelPrimaryOnly({tenantFlag});
  deptModelPrimaryOnly({tenantFlag});
  companyModelPrimaryOnly({tenantFlag});
  chatRoomMsgNoticeModelPrimaryOnly({tenantFlag});
  chatRoomMsgModelPrimaryOnly({tenantFlag});
  noteMemberModelPrimaryOnly({tenantFlag});

  userInfoListener(tenantFlag, io);
  userBadgeListener(tenantFlag, io);
  userAlarmListener(tenantFlag, io);
  noteMemberListener(tenantFlag, io);
  userSignInfoListener(tenantFlag, io);
  userGroupInfoListener(tenantFlag, io);
  userInfoStatusListener(tenantFlag, io);
  chattingRoomInfoListener(tenantFlag, io);
  chattingRoomMemberListener(tenantFlag, io);
  chattingRoomMessageListener(tenantFlag, io);
  chattingRoomMessageEgListener(tenantFlag, io);
  chattingRoomMessageVoteListener(tenantFlag, io);
  chattingRoomMessageNoticeListener(tenantFlag, io);
});

import connection from 'sockets/listeners/connection';
import isLoggedIn from 'sockets/middlewares/isLoggedIn';

io.use(isLoggedIn);
io.on('connection', (socket: Socket) => connection(socket, io));

import process from 'process';

process
  .on('unhandledRejection', (reason, p) => {
    console.error(reason, 'Unhandled Rejection at Promise', p);
  })
  .on('uncaughtException', (err) => {
    console.error(err, 'Uncaught Exception thrown');
  });

export default server;
