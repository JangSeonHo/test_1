/* eslint-disable max-len */
import Koa from 'koa';
import admin from 'firebase-admin';

// @ts-ignore
import Pushy from 'pushy';
const { ObjectId } = require('mongodb');

import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';

const TENANT_FLAG = "nmp";
const SEND_TYPE_PUSHYME = "PUSHY.ME";

//pushy.me - api key
const pushyAPI = new Pushy('431b11499e3ade8f0df11896c8d8c4a1cfabd60c7f77241ac24fd80fde32fc68');

// client package
// ===>>> com.lgcns.mtalk

const pushIntegration = async(msg: any) => {
  console.log("");
  console.log('[pushIntegration] --- Received mst :', msg);
  console.log('[pushIntegration] --- Received mst [msg.data.body] :', msg.data.body);

  console.log("");

  const targetUserInfo = userInfoModel({tenantFlag: TENANT_FLAG});
  const targetUserSignInfo = userSignInfoModel({tenantFlag: TENANT_FLAG});

  let isChina = false;

  try{
    //nmp_user_sign_infos에 해당 모바일(aos, ios)에 해당하는 정보가 중국내 사용이면(isChina === true) pushy.me토큰으로 발송한다.
    const signData = await targetUserSignInfo.findOne({pushToken: msg.token}).select('_id isChina');
    console.log("signData >>>>>>>>>>>>>>>>>>>>>>>>> ", signData);

    if (signData && signData.isChina !== undefined) {
      isChina = signData.isChina;
    }

    if(!isChina){
      admin.messaging().send(msg);
    }else if(isChina){
      //일단 샘플형태로 제공해서 테스트해 본다. 2025.02.05
      // Set push payload data to deliver to device(s)
      const now = new Date();
      const unixTimestamp = now.getTime();

      // 1차 우선적으로 채팅방_공지사항 등록에 대한 설정정보를 토대로 진행함.
      const data = {
        message: msg.data.body,
        title: msg.data.title,
        body: msg.data.body,
        type: msg.data.type,
        id: msg.data.id, //채팅방 - 공지사항 등록시 발생되는 push로 테스트 할것이다. 2025.02.05
        badge:  msg.data.badge,
        content: msg.data.body,
        createdAt: new Date(),
      };

      // Insert target device token(s) here
      const toToken = [msg.token];

      // Set optional push notification options (such as iOS notification fields)
      const options = {
        notification: {
          badge: 0,
          sound: 'default',
          title: msg.data.title,
          body: msg.data.body,
          category: '',           // Optional
          loc_key: '',            // Optional
          loc_args: [],           // Optional
          title_loc_key: '',      // Optional
          title_loc_args: [],     // Optional
          interruption_level: 'active', // Must be one of: "passive", "active", "time-sensitive", "critical"
        },
      };

      const pushPromise = new Promise((resolve, reject) => {
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[pushIntegration] data ::: ${JSON.stringify(data, null, 2)}`);
          console.log(`[pushIntegration] options ::: ${JSON.stringify(options, null, 2)}`);
          console.log(`[pushIntegration] token ::: ${toToken}`);
        }
        pushyAPI.sendPushNotification(data, toToken, options, function (err, id) {
          if (err) {
            reject(err);
          } else {
            resolve(id);
          }
        });
      });

    }
  }catch(e){
    console.error(e);
  }
}

export default pushIntegration;