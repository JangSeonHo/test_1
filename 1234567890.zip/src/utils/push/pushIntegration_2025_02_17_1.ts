/* eslint-disable max-len */
import admin from 'firebase-admin';
import Pushy from 'pushy';

import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';

const TENANT_FLAG = "nmp";

//pushy.me - api key
const pushyAPI = new Pushy('431b11499e3ade8f0df11896c8d8c4a1cfabd60c7f77241ac24fd80fde32fc68');

// client package
// ===>>> com.lgcns.mtalk

const pushIntegration = async (msg: any, isBatch: boolean = false) => {
  const targetUserInfo = userInfoModel({tenantFlag: TENANT_FLAG});
  const targetUserSignInfo = userSignInfoModel({tenantFlag: TENANT_FLAG});

  let isChina = false;

  try{
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("[pushIntegration][isBatch] >>>>>>>>>>>>>>>>>>>>>>>>>>> ", isBatch);
      console.log("[pushIntegration][signData] >>>>>>>>>>>>>>>>>>>>>>>>>>> ", msg);
    }

    //---------------------------------------------------------------------------------------------------------------------------------
    //배치 처리(미지니스 로직에서 맵으로 생성한 데이타를 파라미터로 전달받음.)
    //---------------------------------------------------------------------------------------------------------------------------------
    if(isBatch){
      const batchSize = 100;
      for (let i = 0; i < msg.length; i += batchSize) {
        const batch = msg.slice(i, i + batchSize);

        try {
          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log("[pushIntegration][푸쉬 배치로 전송됩니다.][batch] >>>>>>>>>>>>>>>>>>>>>>>>>>> ", batch[i].token);
          }
              //nmp_user_sign_infos에 해당 모바일(aos, ios)에 해당하는 정보가 중국내 사용이면(isChina === true) pushy.me토큰으로 발송한다.
          const signData = await targetUserSignInfo.findOne({pushToken: batch[i].token}).select('_id isChina pushType');

          if (signData && signData.isChina !== undefined) {
            isChina = signData.isChina;
          }

          // 배치 - pushy.me
          if(isChina){
            // Set push payload data to deliver to device(s)
            const now = new Date();
            const unixTimestamp = now.getTime();

            // 1차 우선적으로 채팅방_공지사항 등록에 대한 설정정보를 토대로 진행함.
            const data = {
              message: batch[i].data.body,
              title: batch[i].data.title,
              body: batch[i].data.body,
              type: batch[i].data.type,
              id: batch[i].data.id,
              badge:  batch[i].data.badge.toString(),
              content: batch[i].data.body,
              createdAt: new Date(),
            };

            // Insert target device token(s) here
            const toToken = [batch[i].token];

            // Set optional push notification options (such as iOS notification fields)
            const options = {
              notification: {
                badge: Number(batch[i].data.badge),
                sound: 'default',
                title: batch[i].data.title,
                body: batch[i].data.body,
                category: '',           // Optional
                loc_key: '',            // Optional
                loc_args: [],           // Optional
                title_loc_key: '',      // Optional
                title_loc_args: [],     // Optional
                interruption_level: 'active', // Must be one of: "passive", "active", "time-sensitive", "critical"
              },
            };

            const pushPromise = new Promise((resolve, reject) => {
              pushyAPI.sendPushNotification(data, toToken, options, function (err, id) {
                if (err) {
                  console.error("[pushIntegration][batch - pushy.me][푸쉬 전송 실패] >>>>>>>>>>> ", err);
                  reject(err);
                } else {
                  resolve(id);
                }
              });
            });
          }else
          //배치 - FCM
          {
            const response = await admin.messaging().sendEach(batch);

            if (response.failureCount > 0) {
              response.responses.forEach((res, index) => {
                if (!res.success) {
                  const error = res.error;
                  if (error) {
                    if (error.code === 'messaging/registration-token-not-registered') {
                      console.error('[pushIntegration][batch] Token not registered - token : ', batch[index].token);
                    } else {
                      console.error('[pushIntegration][batch - fcm] 푸쉬 전송 실패 >>> : ', error);
                    }
                  }
                }
              });
            }
          }
        } catch (error) {
          console.error('[pushIntegration][batch][fail_2] 푸쉬 배치 전송 중 오류 발생 >>>>>>> :', error);
        }
      }
    }

    //---------------------------------------------------------------------------------------------------------------------------------
    //단건처리(비지니스 로직단에서 loop 실행하면서 한건씩 전송함.)
    //---------------------------------------------------------------------------------------------------------------------------------
    else{
      //nmp_user_sign_infos에 해당 모바일(aos, ios)에 해당하는 정보가 중국내 사용이면(isChina === true) pushy.me토큰으로 발송한다.
      const signData = await targetUserSignInfo.findOne({pushToken: msg.token}).select('_id isChina pushType');
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("[pushIntegration][signData] >>>>>>>>>>>>>>>>>>>>>>>>>>> ", signData);
      }

      if (signData && signData.isChina !== undefined) {
        isChina = signData.isChina;
      }

      if(!isChina){
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log("[pushIntegration][푸쉬 단건 전송] >>>>>>>>>>> ", msg.token);
        }
        await admin.messaging().send(msg);
      }else if(isChina){
        // Set push payload data to deliver to device(s)
        const now = new Date();
        const unixTimestamp = now.getTime();

        // 1차 우선적으로 채팅방_공지사항 등록에 대한 설정정보를 토대로 진행함.
        const data = {
          message: msg.data.body,
          title: msg.data.title,
          body: msg.data.body,
          type: msg.data.type,
          id: msg.data.id,
          badge:  msg.data.badge.toString(),
          content: msg.data.body,
          createdAt: new Date(),
        };

        // Insert target device token(s) here
        const toToken = [msg.token];

        // Set optional push notification options (such as iOS notification fields)
        const options = {
          notification: {
            badge: Number(msg.data.badge),
            sound: 'default',
            title: msg.data.title,
            body: msg.data.body,
            category: '',           // Optional
            loc_key: '',            // Optional
            loc_args: [],           // Optional
            title_loc_key: '',      // Optional
            title_loc_args: [],     // Optional
            interruption_level: 'active', // Must be one of: "passive", "active", "time-sensitive", "critical"
          },
        };

        const pushPromise = new Promise((resolve, reject) => {
          pushyAPI.sendPushNotification(data, toToken, options, function (err, id) {
            if (err) {
              if (process.env.DEVELOPMENT_MODE === 'local') {
                console.log("[pushIntegration][pushy.me][에러] >>>>>>>>>>> ", err);
              }
              reject(err);
            } else {
              resolve(id);
            }
          });
        });

      }
    }

  }catch(e){
    console.error(e);
  }
}


export default pushIntegration;