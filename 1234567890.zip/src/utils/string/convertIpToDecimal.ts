const convertIpToDecimal = (ip: string) => {
  let ipVal = ip.trim();
  ipVal = ipVal.replace(/^.*:/, '');
  const arrIP = ipVal.split('.');
  return ((((((+arrIP[0])*256)+(+arrIP[1]))*256)+(+arrIP[2]))*256)+(+arrIP[3]);
};

export default convertIpToDecimal;
