const convertDateToMsgLogTime = (timestamp: any) => {
  const date = new Date(timestamp);

  const formatter = new Intl.DateTimeFormat("ko-KR", {
    timeZone: "Asia/Seoul",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false, // 24시간 형식
  });
  const milliseconds = date.getMilliseconds();
  const fractionalSecond = (milliseconds / 1000).toFixed(1).substring(1);

  return formatter.format(date)
    .replace(/\. /g, "-") // 년. 월. 일을 "-"로 변환
    .replace(/오전 |오후 /g, "") + fractionalSecond;
};

export default convertDateToMsgLogTime;
