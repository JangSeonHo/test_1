import nodemailer from 'nodemailer';

const sendEmail = async ({
  to,
  subject,
  text,
}: {
  to: string,
  subject: string,
  text: string,
}) => {
  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'newucap@gmail.com', // generated ethereal user
        pass: 'txpdiwfudsnxcncl',
      },
    });

    await transporter.sendMail({
      from: '<newucap@gmail.com>',
      to,
      subject,
      text,
    });
  } catch (err) {
    console.log(err);
  }
};

export default sendEmail;
