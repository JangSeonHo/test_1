import nodemailer from 'nodemailer';

const sendEmail = async ({
  to,
  subject,
  text,
}: {
  to: string;
  subject: string;
  text: string;
}) => {
  try {
    const transporter = nodemailer.createTransport({
      host: 'mrelay.lgcns.com',
      port: 25,
      secure: false,
      tls: {
        rejectUnauthorized: false,
      },
    });

    await transporter.sendMail({
      from: 'mtalk@lgcns.com',
      to,
      subject,
      text,
    });
  } catch (err) {
    console.log(err);
  }
};

export default sendEmail;
