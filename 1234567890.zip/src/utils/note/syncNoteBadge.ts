import userBadgeModel from 'models/account/user_badge';
import noteMemberModel from 'models/note/note_member';

const syncNoteBadge = async (tenantFlag: string, userId: string) => {
  const TUserBadgeModel = userBadgeModel({tenantFlag});
  const TNoteMemberModel = noteMemberModel({tenantFlag});

  const notes = await TNoteMemberModel
    .find({parentUser: userId, isRead: false}).select('_id');

  TUserBadgeModel.updateOne({parentUser: userId, unreadNotes: notes.length});
};

export default syncNoteBadge;
