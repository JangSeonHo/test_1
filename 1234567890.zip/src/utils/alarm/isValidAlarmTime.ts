// eslint-disable-next-line max-len
const isValidAlarmTime = (timezoneOffset: number, startTime: number, endTime: number) => {
  // eslint-disable-next-line max-len
  const currentTime = new Date().getTime() + ((timezoneOffset + 9) * 60 * 60 * 1000);
  // timezoneOffset 값 0은 +9 시간대를 의미하므로 +9는 그에 대한 보정값
  const currentHour = new Date(currentTime).getHours();

  const isDayOver = startTime > endTime;
  // eslint-disable-next-line max-len
  if (isDayOver) {
    return currentHour >= endTime && currentHour < startTime;
  }

  return currentHour >= endTime || currentHour < startTime;
};

export default isValidAlarmTime;
