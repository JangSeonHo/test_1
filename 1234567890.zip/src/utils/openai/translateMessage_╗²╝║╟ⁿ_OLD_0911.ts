/* eslint-disable max-len */
const translateMessage = async (message: string, translateLocaleText: string, translateLocale: string) => {
  let url = 'https://lgcns-ms-openai.openai.azure.com/openai/deployments/trans-gpt-4o/chat/completions?api-version=2024-02-15-preview';
  let key = '1af8e64c8d50470da181e208cd734b94';

  try {
    const res = await fetch(url, {
      method: 'post',
      headers: {
        'api-key': key,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(
        {
          messages: [
            {role:"system",content:"You are an AI assistant that helps people find information."},
            {role:"user",content:""},
            {role:"assistant",content:`"${message}"을(를) ${translateLocaleText}로 번역한 결과값만 리턴해줘.`}
          ],
          max_tokens: 1024,
          temperature: 0.2,
          frequency_penalty: 0,
          presence_penalty: 0,
          top_p: 0.95,
          stop: null
        }
      ),
    });

    const {choices} = await res.json();

    let returnText = "";

    if(choices[0]['message']['content']){
      returnText = (!choices[0]['message']['content'] || choices[0]['message']['content'] === '') ? 'Translation could not be completed.(C)' : choices[0]['message']['content'];
    }else{
      returnText = 'Translation could not be completed.(A) >>>>>> '+message;
    }

    return returnText;
  } catch (err) {
    console.log(err);
    return 'Translation could not be completed.[E]';
  }
};

export default translateMessage;
