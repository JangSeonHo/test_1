/* eslint-disable max-len */
const translateMessage = async (message: string, translateLocaleText: string) => {
  try {
    const res = await fetch(`https://lgcns-ms-openai.openai.azure.com/openai/deployments/lgcns-davinci-003/completions?api-version=2022-12-01`, {
      method: 'post',
      headers: {
        'api-key': '1af8e64c8d50470da181e208cd734b94',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: `문장 "${message}"를 ${translateLocaleText}로 번역하면?`,
        max_tokens: 1024,
        temperature: 0.2,
      }),
    });

    const {choices} = await res.json();

    const returnText = (!choices[0]['text'] || choices[0]['text'] === '') ? '번역이 불가능한 문장입니다' : choices[0]['text'];
    return returnText;
  } catch (err) {
    return '번역이 불가능한 문장입니다';

    console.log(err);
  }
};

export default translateMessage;
