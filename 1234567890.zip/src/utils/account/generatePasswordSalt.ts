/* eslint-disable max-len */
import crypto from 'crypto';

const generatePasswordSalt: Function = (): string => {
  const buf = crypto.randomBytes(64);
  const salt = buf.toString('base64');

  return salt;
};

export default generatePasswordSalt;
