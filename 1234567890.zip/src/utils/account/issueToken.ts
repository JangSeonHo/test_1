import jwt from 'jsonwebtoken';
import userSignModel from 'models/account/user_sign_info';
import userInfoModel from 'models/account/user_info';
import mongoose from 'mongoose';

const issueToken: Function = async (
  {
    tenantFlag,
    userId,
    deviceId,
    deviceType,
    versionInfo,
    isRefresh = false,
    role = 'user',
  }: {
    tenantFlag: string,
    userId: string,
    deviceId: string,
    deviceType: string,
    versionInfo: string,
    isRefresh: boolean,
    role: string,
  },
): Promise<{accessToken: string, refreshToken: string}> => {
  const expiresIn8Hours = 60 * 60 * 8;
  const expiresIn1Day = 60 * 60 * 24;
  const expiresIn1Month = expiresIn1Day * 30;
  const expiresIn3Month = expiresIn1Month * 3;
  const createdAt = new Date().getTime();

  const userInfo = await userInfoModel({tenantFlag}).findOne({_id: userId})
    .select('useAlarmWhenPCIsUnfocused parentComapny')
    .populate({
      path: 'parentCompany',
      select: 'companyCode',
    });

  const companyCode = userInfo.parentCompany?.companyCode;
  // 유플러스 윈도 클라이언트 외부망 접근 차단을 위해 토큰에 companyCode 추가

  // 우선 임시로 accessToken 만료기간을 한달로 설정한다.2024.07.03 by shjang7405
  // accessToken의 payload에 deviceType항목을 추가한다. 2025.01.15 by JangSeonHo
  const accessToken = jwt.sign({tenantFlag, userId, role, deviceType, companyCode},
    process.env.DEV_JWT_SECRET as string,
    {expiresIn: expiresIn8Hours},
  );

  const refreshToken = jwt.sign({tenantFlag, userId, deviceType, companyCode},
    process.env.DEV_JWT_SECRET as string,
    {expiresIn: expiresIn1Day * 7},
  );

  const TargetUserSignModel = userSignModel({tenantFlag});

  if (isRefresh) {
    await TargetUserSignModel.updateOne({
      'parentUser': userId,
      'deviceId': deviceId,
      'deviceType': deviceType,
    }, {
      'accessToken': accessToken,
      'refreshToken': refreshToken,
      'lastRefreshedAt': createdAt,
    });
  } else {
    if (deviceType === 'android' || deviceType === 'ios') {
      await TargetUserSignModel.deleteMany({
        $and: [
          {
            'parentUser': new mongoose.mongo.ObjectId(userId),
          },
          {
            $or: [
              {deviceType: 'android'},
              {deviceType: 'ios'},
            ],
          },
        ],
      });
    }

    if (deviceType === 'win32' || deviceType === 'macos') {
      await TargetUserSignModel.deleteMany({
        $and: [
          {
            'parentUser': new mongoose.mongo.ObjectId(userId),
          },
          {
            $or: [
              {deviceType: 'win32'},
              {deviceType: 'macos'},
            ],
          },
        ],
      });
    }

    if (deviceType === 'iPad') {
      await TargetUserSignModel.deleteMany({
        $and: [
          {
            'parentUser': new mongoose.mongo.ObjectId(userId),
          },
          {
            $or: [
              {deviceType: 'iPad'},
            ],
          },
        ],
      });
    }

    if (deviceId === 'web' || deviceType === 'web') {
      await TargetUserSignModel.deleteMany({
        'parentUser': new mongoose.mongo.ObjectId(userId),
        '$or': [
          {deviceId: 'web'},
          {deviceType: 'web'},
        ],
      });
    }

    // [성능튜닝] JMeter 호출 시 deviceType이 존재하지 않아 user_sign_infos collection에 불필요한 document 계속 증가
    // 이부분 삭제 처리를 위해 로직 추가
    if (deviceType.trim().length === 0 || deviceType === '' || deviceType === null) {
      // deviceType이 없는 document 삭제
      await TargetUserSignModel.deleteMany({ parentUser: userId, deviceType: '' });
    }

    const newUserSignInfo = new TargetUserSignModel({
      'parentUser': userId,
      'accessToken': accessToken,
      'refreshToken': refreshToken,
      'deviceId': deviceId,
      'deviceType': deviceType,
      'versionInfo': versionInfo,
      'pushType': 'fcm',
      'pushToken': '',
      'isChina': false,
      'initialSignedAt': createdAt,
      'lastRefreshedAt': createdAt,
      'onlyAlarmWhenPCIsAbsence': userInfo.useAlarmWhenPCIsUnfocused || false,
    });

    await newUserSignInfo.save();

    const targetUserModel = userInfoModel({tenantFlag});
    const uv: any = {$push: {childSignInfos: newUserSignInfo._id}};
    if (deviceType === 'android' || deviceType === 'ios') {
      uv.lastSignedMobileId = deviceId;
    }
    await targetUserModel.updateOne({_id: userId}, uv);
  }

  return {
    accessToken,
    refreshToken,
  };
};

export default issueToken;
