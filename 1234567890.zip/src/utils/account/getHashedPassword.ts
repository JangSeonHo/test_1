/* eslint-disable max-len */
import crypto from 'crypto';

const getHashedPassword: Function = (plainPassword: string, salt: string): string => {
  const hashedPassword = crypto.pbkdf2Sync(plainPassword, salt, 9999, 64, 'sha512').toString('base64');
  return hashedPassword;
};

export default getHashedPassword;
