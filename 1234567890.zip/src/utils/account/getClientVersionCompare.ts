// utils/account/getClientVersionCompare.ts

export function isNewerOrEqualVersion(current: string, base: string): boolean {
  const currentParts = current.split('.').map(Number);
  const baseParts = base.split('.').map(Number);

  for (let i = 0; i < Math.max(currentParts.length, baseParts.length); i++) {
    const curr = currentParts[i] || 0;
    const baseV = baseParts[i] || 0;

    if (curr > baseV) return true;
    if (curr < baseV) return false;
  }

  return true;
}

export default isNewerOrEqualVersion