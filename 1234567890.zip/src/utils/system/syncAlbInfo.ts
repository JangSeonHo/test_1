import {albUrl, syncInterval} from 'configs/awsALB';
const {lookup} = require('dns-lookup-cache');
import {internalLBIP} from 'server';

import {schedulerLockModelPrimaryOnly} from 'models/sync/scheduler_lock';
import {lbipModelPrimaryOnly} from 'models/system/loadbalancer_ip';
import convertIpToDecimal from 'utils/string/convertIpToDecimal';
import convertDateToKoreanTime from 'utils/string/convertDateToKoreanTime';

// eslint-disable-next-line require-jsdoc
async function acquireLock() {
  try {
    const lockModel: any = schedulerLockModelPrimaryOnly({tenantFlag: 'nmp'});
    const lbLock = await lockModel.findOne({
      _id: 'syncLoadBalancerLock',
    });
    const now = new Date().getTime();

    if (!lbLock) {
      const nm: any = lockModel({
        _id: 'syncLoadBalancerLock',
        createdAt: now,
      });
      await nm.save();
      return true;
    } else if (new Date(lbLock.createdAt).getTime() + 1000 < now) {
      await lockModel.updateOne({
        _id: 'syncLoadBalancerLock',
      }, {
        $set: {createdAt: now},
      });
      return true;
    }
    return false;
  } catch (err) {
    console.log(err);
  }
}

const syncAlbInfo = ({
}: {
}) => {
  try {
    setInterval(async () => {
      if (await acquireLock()) {
        lookup(albUrl, {family: 4, all: true}, (async (error: any, addresses: any) => {
          if (error) {
            console.log('[syncAlbInfo] ALB DNS lookup error :', error);
          } else {
            const lbipModel: any = lbipModelPrimaryOnly({tenantFlag: 'nmp'});
            const oldIPs = await lbipModel.findOne({enable: true, isExt: false})
              .select('ip1 ip2');
            const oldIPArr = [oldIPs.ip1, oldIPs.ip2];

            let newIPArr = addresses.map((info: any) => convertIpToDecimal(info.address));
            newIPArr.sort((a: number, b: number) => a - b);
            newIPArr = newIPArr.map((ipVal: any) => {
              return typeof(ipVal) == 'number' ? ipVal : 0;
            });
            internalLBIP.ip1 = newIPArr[0];
            internalLBIP.ip2 = newIPArr[1];

            if (oldIPArr[0] != newIPArr[0] || oldIPArr[1] != newIPArr[1]) {
              await lbipModel.updateOne({_id: oldIPs._id}, {
                ip1: newIPArr[0],
                ip2: newIPArr[1],
                updatedAt: new Date().getTime(),
              });
              console.log('[syncAlbInfo] Old ALB IP : ', oldIPArr[0], ' / ', oldIPArr[1]);
              console.log('[syncAlbInfo] New ALB IP : ', newIPArr[0], ' / ', newIPArr[1]);
              console.log('[syncAlbInfo] ALB IP Update Time :', convertDateToKoreanTime(new Date()));
            }
          }
        }));
      } else {
        const lbipModel: any = lbipModelPrimaryOnly({tenantFlag: 'nmp'});
        const oldIPs = await lbipModel.findOne({enable: true, isExt: false})
          .select('ip1 ip2');
        internalLBIP.ip1 = oldIPs.ip1;
        internalLBIP.ip2 = oldIPs.ip2;
      }
    }, syncInterval * 1000);
  } catch (err) {
    console.log(err);
  }
};

export default syncAlbInfo;
