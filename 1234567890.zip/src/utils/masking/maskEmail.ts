const maskEmail: Function = (email: string): string => {
  try {
    const id = email.split('@')[0];
    const domain = email.split('@')[1];

    const idMask = `${id.substring(0, 3)}****`;

    return `${idMask}@${domain}`;
  } catch (err) {
    return '';
  }
};

export default maskEmail;
