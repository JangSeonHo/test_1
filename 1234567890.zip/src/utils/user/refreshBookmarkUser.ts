/* eslint-disable max-len */
import {userInfoModelPrimaryOnly as userInfoModel} from 'models/account/user_info';
import {userGroupInfoModelPrimaryOnly as userGroupInfoModel} from 'models/account/user_group_info';

const refreshBookmarkUsers = async (tenantFlag: string, userId: string) => {
  const targetUserModel = userInfoModel({tenantFlag});
  const targetUserGroupModel = userGroupInfoModel({tenantFlag});

  const userInfo = await targetUserModel.findOne({_id: userId})
    .select('childPrivateContacts childBookmarkUsers childUserGroups');

  const groups = await Promise.all(userInfo.childUserGroups.map(async (group: string) => {
    const v = await targetUserGroupModel.findOne({_id: group}).select('childGroupUsers');
    return v.childGroupUsers.map((v: any) => v.toString());
  }));

  const pus = userInfo.childPrivateContacts.map((v: any) => v.toString());
  const bus = userInfo.childBookmarkUsers.map((v: any) => v.toString());

  const newBookmark = bus.filter((u: string) => {
    if (pus.includes(u)) {
      return true;
    }

    let inGroup = false;
    groups.forEach((arr: Array<String>) => {
      if (arr.includes(u)) {
        inGroup = true;
      }
    });

    return inGroup;
  });

  await targetUserModel.updateOne({_id: userId}, {
    childBookmarkUsers: newBookmark,
  });
};

export default refreshBookmarkUsers;
