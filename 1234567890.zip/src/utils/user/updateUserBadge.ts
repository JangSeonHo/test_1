/* eslint-disable max-len */
import userBadgeModel from 'models/account/user_badge';
import {roomMemberModelPrimaryOnly} from 'models/message/chatting_room_member';


const updateUserBadge = async (tenantFlag: string, userId: string) => {
  const chattingRooms = await roomMemberModelPrimaryOnly({tenantFlag}).find({
    parentUser: userId,
    isDeleted: false,
  }).select('parentChattingRoom lastCheckedMessageSeq').populate({
    path: 'parentChattingRoom',
    select: 'childLastMessage isMyChat',
    populate: [
      {
        path: 'childLastMessage',
        select: 'messageSeq',
      },
    ],
  });


  let count = 0;
  chattingRooms.forEach((room: any) => {
    // console.log(`update userbadge : ${room}`);
    // console.log(`update userbadge parentChattingRoom : ${room.parentChattingRoom}`);
    if (!room.parentChattingRoom) {
      return;
    }
    if (!room.parentChattingRoom.isMyChat && room.parentChattingRoom.childLastMessage && room.parentChattingRoom.childLastMessage.messageSeq > 0) {
      if (room.parentChattingRoom.childLastMessage.messageSeq - room.lastCheckedMessageSeq > 0) {
        count += (room.parentChattingRoom.childLastMessage.messageSeq - room.lastCheckedMessageSeq);
      }
    }
  });

  await userBadgeModel({tenantFlag}).updateOne({parentUser: userId}, {
    unreadChatMessages: Math.trunc(count) < 0 ? 0 : Math.trunc(count),
  });
};

export default updateUserBadge;
