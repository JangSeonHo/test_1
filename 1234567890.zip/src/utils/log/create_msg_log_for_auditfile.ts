import messageLogForAuditfile from 'models/log/message_log_for_auditfile';
import companyInfoModel from 'models/company/company_company_info';
import departmentModel from 'models/company/company_department_info';
import convertDateToMsgLogTime from '../string/convertDateToMsgLogTime';

export declare type LogType = 'chat' | 'chatUser' | 'note' | 'noteUser';
export declare type MsgLogInfo = {
  roomId?: string,
  noteId?: string,
  userId: string,
  content: string,
  eventSeq?: number,
  regDate: number,
  userName: string,
  jobTitle: string,
  emailId: string,
  email?: string,
  empNo: string,
  parentCompany: string,
  parentDepartment?: string,
  deptName?: string,
};

const tenantFlag = 'nmp';
const createMsgLogForAuditfile = async ({logType, data}: {
  logType: LogType,
  data: MsgLogInfo,
}) => {
  let text = '';
  const companyInfo = await companyInfoModel({tenantFlag})
    .findById(data.parentCompany)
    .select('companyCode').lean();
  // @ts-ignore
  const companyCode = companyInfo['companyCode'];
  let logTypeId: string | undefined = '';
  const regDate = companyCode != 'GUC054' ? convertDateToMsgLogTime(data.regDate) : convertDateToMsgLogTime(data.regDate).slice(0, -2);

  switch (logType) {
    case 'chat':
      logTypeId = data.roomId;
      data.email = data.email ?? '';
      let deptName = '';
      if (companyCode == 'GUC007' || companyCode == 'GUC054') { // 디스플레이 or 서브원
        const deptInfo = await departmentModel({tenantFlag}).findOne({
          _id: data.parentDepartment,
        }).select('departmentName')
          .lean();
        if (!!deptInfo) {
          // @ts-ignore
          deptName = deptInfo['departmentName'].ko ?? '';
        }
      }

      switch (companyCode) {
        // case 'GUC100': // 유캡
        case 'GUC057': // 엔솔
        case 'GUC005': // 화학
          text = `${logTypeId}${data.eventSeq}대화전송${regDate}${data.emailId}${data.empNo}${data.userName}${companyCode}${data.email.split('@')[1] ?? ''}${data.content}\b`;
          break;
        case 'GUC007': // 디스플레이
          text = `ROOM_SEQ="${logTypeId}"\bEVENT_SEQ="${data.eventSeq}"\bCHAT_TYPE="대화전송"\bREG_DATE="${regDate}"\bCONTENT="${data.content}"\bEMP_NO="${data.empNo}"\bUSER_NAME="${data.userName}"\bGRADE="${data.jobTitle}"\bDEPT_NAME="${deptName}"^`;
          break;
        case 'GUC054': // 서브원
          text = `ROOM_SEQ="${logTypeId}"\bEVENT_SEQ="${data.eventSeq}"\bCHAT_TYPE="대화전송"\bREG_DATE="${regDate}"\bCONTENT="${data.content}"\bEMP_NO="${data.empNo}"\bUSER_NAME="${data.userName}"\bGRADE="${data.jobTitle}"\bCOMPANY_NAME="GUC054"\bDEPT_NAME="${deptName}"^`;
          break;
      }
      break;
    case 'note':
      logTypeId = data.noteId;
      switch (companyCode) {
        // case 'GUC100': // 유캡
        case 'GUC057': // 엔솔
        case 'GUC005': // 화학
        case 'GUC007': // 디스플레이
          text = `MSG_SEQ="${logTypeId}"\bRES_SEQ=""\bRES_TYPE="T"\bREG_DATE="${regDate}"\bRES_CONTENT="${data.content}"\bEMP_NO="${data.empNo}"\bUSER_NAME="${data.userName}"\bGRADE="${data.jobTitle}"\bDEPT_NAME="${data.deptName}"^`;
          break;
      }
      break;
  }
  // console.log(`$$$ audit : ${text}`);
  if (text.length === 0) {
    return;
  }
  const AuditLogModel = messageLogForAuditfile({tenantFlag});
  const newLog = new AuditLogModel({companyCode: companyCode, logType, logTypeId, text});
  await newLog.save();
};

export default createMsgLogForAuditfile;
