import crypto from 'crypto';
import getEncryptionKey from 'middlewares/getEncryptionKey';

const ENCRYPTION_KEY = "S7E5R3KJTKTKDLXTBE1MK25AY3IRJTD9";
const IV = ENCRYPTION_KEY.substring(0, 16);

export const encrypt = (value: string): string => {
  try {
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), Buffer.from(IV));
    let encrypted = cipher.update(value);
    encrypted = Buffer.concat([encrypted, cipher.final()]);

    return encrypted.toString('base64');
  } catch (err) {
    console.error('Encryption failed', err);
    throw new Error('Encryption failed');
  }
};

export const decrypt = (value: string): string => {
  try {
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), Buffer.from(IV));
    let decrypted = decipher.update(value, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted.toString();
  } catch (err) {
    console.error('Decryption failed', err);
    throw new Error('Decryption failed');
  }
};
