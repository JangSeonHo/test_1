// @ts-ignore
import aligoapi from 'aligoapi';

import axios from 'axios';
const SEND_TYPE_SMS = "SMS";
const SEND_TYPE_LMS = "LMS";
const SMS_URL = "https://talkapi.lgcns.com/request/sms.json";
const LMS_URL = "https://talkapi.lgcns.com/request/lms.json";
const TALK_SERVICE_ID = "2400105696";
const SEDNDER_PHONE_NUMBER_NO = "1661-9066";

const sendSMS = async ({
  to,
  text,
}: {
  to: string,
  text: string,
}) => {
  try {
    // const authInfo = {
    //   key: '073popxhra4lyiyfkd6hmpnl9bgf6pef',
    //   user_id: 'm365helpdesk',
    // };

    // const sendData = {
    //   'headers': {
    //     'Content-Type': 'application/json',
    //   },
    //   'body': {
    //     sender: '1670-3577',
    //     receiver: to,
    //     msg: text,
    //   },
    // };

    // console.log("sendData >>>>>> ",sendData);
    // console.log("authInfo >>>>>> ",authInfo);
    // await aligoapi.send(sendData, authInfo);

    let url = SMS_URL;
    let userMobile = to;

    // 요청 바디 생성 (LMS일 때만 subject 포함)
    const requestBody: any = {
      service: TALK_SERVICE_ID,
      message: text,
      mobile: userMobile,
      callbackNo: SEDNDER_PHONE_NUMBER_NO,
    };

    console.log("url >>>> ", url);
    console.log("requestBody >>>> ", requestBody);

    const response = await axios.post(url, requestBody, {
      headers: {
        "Content-Type": "application/json",
        "authToken": "5I0uE5LbZ7aTY4WDw08LeA==",
        "serverName": "mTalk",
      },
    });

    if (response.status === 200) {
      console.log("---------------------------------------------------- OK");
    }else{
      console.log("---------------------------------------------------- FAIL");
    }

  } catch (err) {
    console.log(err);
  }
};

export default sendSMS;
