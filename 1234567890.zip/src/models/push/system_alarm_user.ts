/* eslint-disable max-len */
import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  SYSTEM_ALARM_USER,
  SYSTEM_ALARM_INFO,
  USER_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'parentSystemAlarm': {type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${SYSTEM_ALARM_INFO}`},
  'parentUser': {type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${USER_INFO}`},
  'title': {type: String, default: ""},
  'createdAt': {type: Number},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYSTEM_ALARM_USER}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYSTEM_ALARM_USER}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const systemAlarmUserModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYSTEM_ALARM_USER}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};
export default getModel;
