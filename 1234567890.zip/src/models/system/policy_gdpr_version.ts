import mongoose from 'mongoose';

const {Schema, model} = require('mongoose');

import {
  POLICY_GDPR_VERSION,
 } from 'models/collection_names';

 const getSchema = ({tenantFlag}: {tenantFlag: string}) => new Schema({
  'ver': {type: String},
}, { timestamps: true} );

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${POLICY_GDPR_VERSION}`;

  return mongoose.models[modelName] ||
    model(modelName, getSchema({tenantFlag}));
};

export default getModel;
