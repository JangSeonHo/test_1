import mongoose from 'mongoose';

import {
  COMPANY_DISTRIBUTION_MANAGEMENT,
  COMPANY_GROUP_INFO,
  COMPANY_COMPANY_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema(
  {
    device: {
      type: String,
      required: false,
    },
    version: {
      type: String,
      required: false,
    },
    distributionDate: {
      type: Date,
      required: false,
    },
    // type: {
    //   type: String,
    //   required: false,
    // },
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`,
    },
    companyGroup: {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${COMPANY_GROUP_INFO}`,
    },
  },
  {
    timestamps: true,
  },
);

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${COMPANY_DISTRIBUTION_MANAGEMENT}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
