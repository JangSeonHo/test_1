import mongoose from 'mongoose';

import {
  POLICY_VERSION,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'version': {type: String, default: '0.0'},
  'createdAt': {type: Number},
});


  const getModel = ({tenantFlag}: {tenantFlag: string}) => {
    const modelName = `${tenantFlag}_${POLICY_VERSION}`;
    
      return mongoose.models[modelName] ||
        mongoose.model(modelName, getSchema({tenantFlag}));
    
  };

export default getModel;
