import mongoose from 'mongoose';

import {
  UPLUS_ALLOWED_LOGIN_IP,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'ipRangeStart': {type: Number},
  'ipRangeEnd': {type: Number},
  'isInternal': {type: Boolean},
  'isEnable': {type: Boolean},
  'creator': {type: String},
  'description': {type: String},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${UPLUS_ALLOWED_LOGIN_IP}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
