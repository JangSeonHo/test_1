import mongoose from 'mongoose';

import {
  DOWNLOAD_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'ipAddr': {type: String},
  'creator': {type: String},
  'updater': {type: String},
  'description': {type: String},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${DOWNLOAD_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
