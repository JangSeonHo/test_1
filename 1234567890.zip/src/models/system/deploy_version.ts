import mongoose from 'mongoose';

import {
  DEPLOY_VERSION,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'androidVersion': {type: String},
  'iosVersion': {type: String},
  'windowsVersion': {type: String},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${DEPLOY_VERSION}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
