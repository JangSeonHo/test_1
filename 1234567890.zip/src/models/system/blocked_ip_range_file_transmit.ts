import mongoose from 'mongoose';

import {
  BLOCKED_IP_RANGE_FILE,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'parentCompanyCode': {type: String},
  'ipRangeStart': {type: Number},
  'ipRangeEnd': {type: Number},
  'download': {type: Boolean},
  'upload': {type: Boolean},
  'creator': {type: String},
  'description': {type: String},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${BLOCKED_IP_RANGE_FILE}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
