import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  SCHEDULER_INFO,
} from 'models/collection_names';


const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  _id: {type: String, required: true,},
  cron: {type: String,},
  enabled: {type: Boolean, required: true, default: false},
  lastedRunAt: {type: Number,},
  description: {type: String,},
  immediateRun: {type: Boolean, required: true, default: false},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SCHEDULER_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const syncSummaryLogModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SCHEDULER_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;