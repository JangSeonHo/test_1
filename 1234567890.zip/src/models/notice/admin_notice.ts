import mongoose from 'mongoose';

import {
  ADMIN_NOTIFICATION,
  COMPANY_GROUP_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
    'title': {type: String},
    'content': {type: String},
    'type': {type: String},
    'status': {type: String},
    'notiGroupTarget': {type: Array, default: []},
    'views': {type: Number},
    'image': {type: Array, default: []},
    'files': {type: Array, default: []},
    'creator': {
        'email': {type: String, default: ''},
        'name': {type: String, default: ''},
    },
    'notiGroup': {
        type: mongoose.Schema.Types.ObjectId,
        ref: `${tenantFlag}_${COMPANY_GROUP_INFO}`,
    },
    'startDate': {type: Date, default: null},
    'endDate': {type: Date, default: null},
    'createdAt': {type: Date, default: null},
    'updatedAt': {type: Date, default: null},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${ADMIN_NOTIFICATION}`;

  return mongoose.models[modelName] || mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
