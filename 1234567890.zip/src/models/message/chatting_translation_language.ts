import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  CHATTING_TRANSLATION_LANGUAGE,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema(
  {
    langCd: {
      type: String,
      required: true,
    },
    langNmKo: {
      type: String,
      required: true,
    },
    langNmEn: {
      type: String,
      required: true,
    },
    langNmCn: {
      type: String,
      required: true,
    },
    langNmJp: {
      type: String,
      required: true,
    },
    useYn: {
      type: String,
      required: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
    updatedAt: {
      type: Date,
      default: Date.now,
    }
  }
);

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_TRANSLATION_LANGUAGE}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const companyModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_TRANSLATION_LANGUAGE}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;