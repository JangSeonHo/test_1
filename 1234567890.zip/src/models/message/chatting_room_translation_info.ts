import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  CHATTING_ROOM_TRANSLATION_INFO,
  USER_INFO,
  CHATTING_ROOM_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  parentUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
    required: true,
  },
  parentChattingRoom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_INFO}`,
    required: true,
  },
  sendLocale: {
    type: String,
  },
  isSendEnable: {
    type: Boolean,
  },
  recvLocale: {
    type: String,
  },
  isRecvEnable: {
    type: Boolean,
  },
  lastMessageSeq: {
    type: Number,
  },
  createdAt: {
    type: Number,
    required: true,
  },
  updatedAt: {
    type: Number,
    required: true,
  }
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_TRANSLATION_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const companyModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_TRANSLATION_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;