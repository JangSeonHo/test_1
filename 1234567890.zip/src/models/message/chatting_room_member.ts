import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  CHATTING_ROOM_INFO,
  CHATTING_ROOM_MEMBER,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  roomName: {type: String, default: ''},
  parentUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  },
  parentChattingRoom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_INFO}`,
  },
  isGroupChat: {type: Boolean},
  isMyChat: {type: Boolean},
  isDeleted: {type: Boolean, default: false},
  lastCheckedMessageSeq: {type: Number, default: 0},
  lastCheckedMessageEventSeq: {type: Number, default: 0},
  joinedAt: {type: Number},
  isMyGptChat: {type: Boolean, default: false},
  deletedMessages: [],
  deletedMessageSeq: {type: Number, default: 0},
  deletedLastCheckedMessageSeq: {type: Number, default: 0},
  isEntered: {type: Boolean, default: false},
  ucapRoomId: {type: String, default: ''},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MEMBER}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MEMBER}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const roomMemberModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MEMBER}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
