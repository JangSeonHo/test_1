import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  CHATTING_ROOM_INFO,
  CHATTING_ROOM_MESSAGE,
  CHATTING_ROOM_MESSAGE_EG,
  CHATTING_ROOM_MESSAGE_VOTE,
  CHATTING_ROOM_MESSAGE_NOTICE,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  parentUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  },
  parentChattingRoom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_INFO}`,
  },
  mentionedUsers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  }],
  messageSeq: {type: Number},
  content: {type: String, default: ''},
  isGptMessage: {type: Boolean},
  isSystemMessage: {type: Boolean, default: false},
  systemMessageType: {type: String},
  systemMessegeTargetId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_MESSAGE}`,
  },
  isDeleted: {type: Boolean, default: false},
  isExpired: {type: Boolean, default: false},
  isEmoticon: {type: Boolean, default: false},
  isImportant: {type: Boolean, default: false},
  isReply: {type: Boolean, default: false},
  replyOrigin: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_MESSAGE}`,
  },
  isNotice: {type: Boolean, default: false},
  isVote: {type: Boolean, default: false},
  childVote: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_MESSAGE_VOTE}`,
  },
  childNotice: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_MESSAGE_NOTICE}`,
  },
  hasFiles: {type: Boolean, default: false},
  files: [{
    url: {type: String},
    fileName: {type: String},
    size: {type: Number},
    mimeType: {type: String},
    duration: {type: String},
    isMultiRecord: {type: Boolean, default: false},
  }],
  createdAt: {type: Number},
  updatedAt: {type: Number},
  totalEngagements: {
    'R1': {type: Number, default: 0},
    'R2': {type: Number, default: 0},
    'R3': {type: Number, default: 0},
    'R4': {type: Number, default: 0},
    'R5': {type: Number, default: 0},
    'R6': {type: Number, default: 0},
    'R7': {type: Number, default: 0},
    'R8': {type: Number, default: 0},
    'R9': {type: Number, default: 0},
  },
  childEngagement: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_MESSAGE_EG}`,
  },
  translate: [
    {
      locale: {type: String},
      text: {type: String},
      _id: false,
    },
  ],
  recvTranslate: [
    {
      locale: {type: String},
      text: {type: String},
      _id: false,
    },
  ],
  uuid: {type: String}, //
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const chatRoomMsgModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
