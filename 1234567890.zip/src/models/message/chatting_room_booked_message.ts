import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  CHATTING_ROOM_INFO,
  CHATTING_ROOM_BOOKED_MESSAGE,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  parentUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  },
  parentChattingRoom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_INFO}`,
  },
  mentionedUsers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  }],
  messageSeq: {type: Number},
  content: {type: String, default: ''},
  isSystemMessage: {type: Boolean, default: false},
  systemMessageType: {type: String},
  isDeleted: {type: Boolean, default: false},
  isEmoticon: {type: Boolean, default: false},
  isImportant: {type: Boolean, default: false},
  isReply: {type: Boolean, default: false},
  replyOrigin: {type: String},
  isNotice: {type: Boolean, default: false},
  hasFiles: {type: Boolean, default: false},
  files: [{
    url: {type: String},
    fileName: {type: String},
    size: {type: Number},
    mimeType: {type: String},
  }],
  createdAt: {type: Number},
  updatedAt: {type: Number},
  bookedAt: {type: Number},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_BOOKED_MESSAGE}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_BOOKED_MESSAGE}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const chatRoomBookMsgModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_BOOKED_MESSAGE}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
