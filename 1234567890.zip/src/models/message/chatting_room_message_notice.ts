import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  CHATTING_ROOM_INFO,
  CHATTING_ROOM_MESSAGE,
  CHATTING_ROOM_MESSAGE_NOTICE,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  parentUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  },
  parentChattingRoom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_INFO}`,
  },
  parentChattingMessage: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_MESSAGE}`,
  },
  title: {type: String},
  content: {type: String},
  fileFolderId: {type: String},
  files: [{
    url: {type: String},
    fileName: {type: String},
    size: {type: Number},
    mimeType: {type: String},
  }],
  createdAt: {type: Number},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE_NOTICE}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE_NOTICE}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const chatRoomMsgNoticeModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE_NOTICE}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
