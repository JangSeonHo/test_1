import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  COMPANY_COMPANY_INFO,
  STATISTICS_COMPANY_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema(
  {
    parentCompany: {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`,
      required: true,
    },
    useYn: {
      type: String,
      required: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    }
  }
);

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${STATISTICS_COMPANY_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const companyModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${STATISTICS_COMPANY_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
