import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  COMPANY_GROUP_INFO,
  COMPANY_COMPANY_INFO,
  COMPANY_DEPARTMENT_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'companyName': {
    'ko': {type: String, default: ''},
    'en': {type: String, default: ''},
  },
  'companyDomain': {type: String},
  'parentGroup': {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${COMPANY_GROUP_INFO}`,
  },
  'childDepartments': [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${COMPANY_DEPARTMENT_INFO}`,
    },
  ],
  'totalChildDepartments': {type: Number},
  'totalChildUsers': {type: Number},
  'originCode': {type: String},
  'lastModifiedAt': {type: Number},
  'fileAllowedCompanies': [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`,
    },
  ],
  'useYn': {type: String, default: 'Y'},
  'companyCode': {type: String},
  'sortNo': {type: Number},
  'useCompanyOnlyYn': {type: String, default: 'N'},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${COMPANY_COMPANY_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const companyModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${COMPANY_COMPANY_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
