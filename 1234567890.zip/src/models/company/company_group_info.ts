import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  COMPANY_GROUP_INFO,
  COMPANY_COMPANY_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'groupName': {
    'ko': {type: String, default: ''},
    'en': {type: String, default: ''},
  },
  'childCompanies': [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`,
    },
  ],
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${COMPANY_GROUP_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const companyGroupInfoModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${COMPANY_GROUP_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
