import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  NOTE,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'sender': {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  },
  'receivers': [{
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  }],
  'senderUserName': {
    ko: {type: String},
    en: {type: String},
  },
  'receiverUserNames': {
    ko: {type: String},
    en: {type: String},
  },
  'title': {type: String},
  'content': {type: String},
  'fileFolderId': {type: String},
  'attachedImages': [{
    url: {type: String},
    fileName: {type: String},
    size: {type: Number},
    mimeType: {type: String},
  }],
  'attachedFiles': [{
    url: {type: String},
    fileName: {type: String},
    size: {type: Number},
    mimeType: {type: String},
  }],
  'createdAt': {type: Number},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${NOTE}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${NOTE}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const noteInfoModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${NOTE}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
