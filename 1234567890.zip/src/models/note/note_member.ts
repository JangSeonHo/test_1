import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  NOTE_MEMBER,
  NOTE,
  USER_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'parentNote': {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${NOTE}`,
  },
  'type': {type: String}, // S(send), R(receive)
  'parentUser': {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  },
  'createdAt': {type: Number},
  'isCanceled': {type: Boolean, default: false},
  'isDeleted': {type: Boolean, default: false},
  'isRead': {type: Boolean, default: false},
  'readAt': {type: Number},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${NOTE_MEMBER}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${NOTE_MEMBER}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const noteMemberModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${NOTE_MEMBER}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
