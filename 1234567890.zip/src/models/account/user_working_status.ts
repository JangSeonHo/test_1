import mongoose, { Schema, Document } from 'mongoose';
import { USER_WORKING_STATUS } from '../../models/collection_names';
import { UTC_9 } from '../../constants/commonConstants';

export interface IUserWorkingStatus extends Document {
  user_id: string;
  date: string;
  attend_code?: string;
  attend: string;
  company_code: string;
  created_at: Date;
  updated_at: Date;
}

const getSchema = ({tenantFlag}: {tenantFlag: string}) => {
  const schema = new Schema({
    user_id: { type: String, required: true },
    date: { type: String, required: true },
    attend_code: { type: String, required: false },
    attend: { type: String, required: true },
    company_code: { type: String, required: true },
    created_at: { 
      type: Date, 
      default: () => new Date(new Date().getTime() + UTC_9)
    },
    updated_at: { 
      type: Date, 
      default: () => new Date(new Date().getTime() + UTC_9)
    }
  }, {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
  });

  schema.index({ user_id: 1, date: -1 });
  schema.index({ company_code: 1 });

  return schema;
};

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_WORKING_STATUS}`;
  return mongoose.models[modelName] || mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel; 
