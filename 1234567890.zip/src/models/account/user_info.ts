/* eslint-disable max-len */
import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  USER_GROUP_INFO,
  USER_SIGN_INFO,
  USER_STATUS_INFO,
  COMPANY_COMPANY_INFO,
  COMPANY_DEPARTMENT_INFO,
  COMPANY_GROUP_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'originCode': {type: String},
  'role': {type: String, default: 'user'}, // centerAdmin, companyAdmin, user
  'userName': {
    'ko': {type: String, default: ''},
    'en': {type: String, default: ''},
  },
  'jobTitle': {
    'ko': {type: String, default: ''},
    'en': {type: String, default: ''},
  },
  'email': {type: String},
  'emailId': {type: String},
  'hashedPassword': {type: String},
  'passwordSalt': {type: String},
  'personalPhoneNumber': {type: String},
  'officePhoneNumber': {type: String},
  'baseContactNumber': {type: String, default: 'personalPhoneNumber'}, // personalPhoneNumber, officePhoneNumber
  'parentGroup': {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${COMPANY_GROUP_INFO}`,
  },
  'parentCompany': {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`,
  },
  'parentDepartment': {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${COMPANY_DEPARTMENT_INFO}`,
  },
  'profileImage': {type: String},
  'childStatusInfo': {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_STATUS_INFO}`,
  },
  'childSignInfos': [{
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_SIGN_INFO}`,
  }],
  'childUserGroups': [{
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_GROUP_INFO}`,
  }],
  'childBookmarkUsers': [{
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  }],
  'childPrivateContacts': [{
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  }],
  'useMessenger': {type: Boolean, default: false},
  'mfa': {
    type: {type: String}, // email || sms
    code: {type: String},
    validateTime: {type: Number},
    isVerified: {type: Boolean},
    isPasswordVerified: {type: Boolean, default: false},
    failCount: {type: Number, default: 0},
    lockUntil: {type: Number, default: 0},
  },
  'isPCFocused': {type: Boolean, default: false},
  'useAlarmWhenPCIsUnfocused': {type: Boolean, default: false},
  'isDeleted': {type: Boolean, default: false},
  'lastSignedMobileId': {type: String},
  'agreePrivacyPolicy': {type: Boolean, default: true},
  'agreePrivacyPolicyVersion': {type: String, default: '1.0'},
  'agreePrivacyPolicyDate': {type: Number, default: () => Date.now() },
  'agreeMandatoryPrivacyPolicy': {type: Boolean, default: true},
  'agreeProfileImagePolicy': {type: Boolean, default: true},
  'loginFailCount': {type: Number, default: 0},
  'changePasswordDate': {type: Number},
  'siblingOrders': {type: String, default: ''},
  'lastLoginDate': {type: Number},
  'listOrder': {type: String, default: ''},
  'userType': {type: String, default: ''},
  'europeCorp': {type: Boolean, default: false},
  'agreeGDPRVersion': {type: String, default: ''},
  'agreeGDPRDate': {type: Number},
  'inWorkYn': {type: String, default: ''},
  'realDeleted': {type: Boolean, default: false},
  'authKey': {type: String, default: ''},
  'policyOrgAuthMobile': { type: String, default: 'N' },
  'policyOrgAuthPc': { type: String, default: 'N' },
  'empNo': {type: String, default: ''},
  'isChina': {type: Boolean, default: false},
  'policyOrgViewYn': { type: String, default: 'Y' },
	'lineNumberC': {type: String, default : ''},
	'hpNumberC': {type: String, default : ''},
	'policyConfAuth': {type: String, default : ''},
	'policyMadnAuth': {type: String, default : ''},
	'policyPstnAuth': {type: String, default : ''},
	'inKoreaYn': {type: String, default : ''},
	'extEmail': {type: String, default : ''},
	'vacationYn': {type: String, default : ''},
	'mobileUseYn': {type: String, default : ''},
	'empCategory': {type: String, default : ''},
	'policyMsgBoxAuth': {type: String, default : ''},
	'policyFileAuthPc': {type: String, default : ''},
	'policyFileAuthMobile': {type: String, default : ''},
	'policyFileAuthWeb': {type: String, default : ''},
	'location': {type: String, default : ''},
	'locationCode': {type: String, default : ''},
	'policyCodeAuth': {type: String, default : ''},
	'usageStartDate': {type: String, default : ''},
	'usageEndDate': {type: String, default : ''},
	'deptName': {type: String, default : ''},
	'locationCd': {type: String, default : ''},
	'subsidiary': {type: String, default : ''},
	'userNameCn': {type: String, default : ''},
  'createdAt': {type: Number, default: () => Date.now() },
  'updatedAt': {type: Number, default: () => Date.now() },
  'deletedAt': {type: Number, default: () => Date.now() },
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_INFO}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const userInfoModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
