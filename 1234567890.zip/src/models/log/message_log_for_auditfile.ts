import mongoose from 'mongoose';

import {
  MESSAGE_LOG_FOR_AUDITFILE,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'companyCode': {type: String},
  'logType': {type: String},
  'logTypeId': {type: String},
  'text': {type: String},
  'createdAt': {type: Number},
});

// eslint-disable-next-line require-jsdoc
function getCollectionName(minusDay = 0) {
  const formatter = new Intl.DateTimeFormat('ko-KR', {
    timeZone: 'Asia/Seoul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  const date = new Date();
  date.setDate(date.getDate() - minusDay);
  const [{value: year}, , {value: month}, , {value: day}] = formatter.formatToParts(date);
  return `${year}${month}${day}`;
}

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${MESSAGE_LOG_FOR_AUDITFILE}_${getCollectionName()}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const getMinusDayLogModel = ({tenantFlag, minusDays}: {tenantFlag: string, minusDays: number}) => {
  const modelName = `${tenantFlag}_${MESSAGE_LOG_FOR_AUDITFILE}_${getCollectionName(minusDays)}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
