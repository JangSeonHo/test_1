import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  SYNC_SUMMARY_SYNCDATA_LOG,
  SYNC_SUMMARY_LOG
} from 'models/collection_names';


const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  parentSummary: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${SYNC_SUMMARY_LOG}`,
  },
  syncEncData: {type: String},
  syncDecData: {type: String},
  transDivision: {type: String},
  totalCount: {type: Number},
  processDivision: {type: String},
  companyCode: {type: String},
  syncFileName: {type: String},
  createdAt: {type: Number},
  updatedAt: {type: Number},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYNC_SUMMARY_SYNCDATA_LOG}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const syncSummaryLogModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYNC_SUMMARY_SYNCDATA_LOG}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;