import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  SYNC_SUMMARY_LOG,
} from 'models/collection_names';


const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  syncFileName: {type: String},
  startedAt: {type: Number},
  endedAt: {type: Number},
  totalCounts: {type: Number},
  successCounts: {
    create: {type: Number, default: 0},
    update: {type: Number, default: 0},
    delete: {type: Number, default: 0},
  },
  errorCounts: {
    create: {type: Number, default: 0},
    update: {type: Number, default: 0},
    delete: {type: Number, default: 0},
  },
  transDivision: {type: String},
  duration: {type: Number, default: 0},
  ecsTaskId: {type: String, default: ""},
  executionDivision: {type: String, default: ""},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYNC_SUMMARY_LOG}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const syncSummaryLogModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYNC_SUMMARY_LOG}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;