import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  SYNC_SUMMARY_LOG,
  SYNC_ERROR_LOG
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  parentLog: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${SYNC_SUMMARY_LOG}`,
  },
  originData: {type: Object},
  error: {type: String},
  createdAt: {type: Number},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYNC_ERROR_LOG}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const syncErrorModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYNC_ERROR_LOG}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;