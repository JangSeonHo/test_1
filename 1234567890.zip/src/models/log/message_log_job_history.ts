import mongoose from 'mongoose';
import streamMongoose from 'configs/streamMongoose';
import {dbPrimaryOnly} from '../../server';

import {
  MESSAGE_LOG_JOB_HISTORY,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'logDate': {type: String},
  'userDataStatus': {type: String}, // NOT_STARTED / PROCESSING / COMPLETE / ERROR
  'userDataJobStartTime': {type: Number},
  'userDataJobEndTime': {type: Number},
  'logFileStatus': {type: String}, // NOT_STARTED / PROCESSING / COMPLETE / ERROR
  'logFileJobStartTime': {type: Number},
  'logFileJobEndTime': {type: Number},
  'createdAt': {type: Number},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${MESSAGE_LOG_JOB_HISTORY}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${MESSAGE_LOG_JOB_HISTORY}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

// eslint-disable-next-line max-len
export const msgLogJobHistoryModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${MESSAGE_LOG_JOB_HISTORY}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
