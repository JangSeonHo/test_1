import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  SYNC_HEADER_INFO,
} from 'models/collection_names';


const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  companyCode: {type: String},
  companyId: {type: Number},
  orgHeader:  {type: String},
  userHeader: {type: String},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYNC_HEADER_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const syncSummaryLogModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYNC_HEADER_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;