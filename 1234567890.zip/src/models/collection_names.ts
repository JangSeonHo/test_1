/* eslint-disable max-len */
// purpose: collection name 분류
// desc:

// 플랫폼 버전
export const PLATFORM_VERSION = 'platform_version';
export const PLATFORM_ADMIN = 'platform_admin';

// 회사별 설정

// 회사 상위 그룹 정보 ex)LG
export const COMPANY_GROUP_INFO = 'company_group_info';
// 회사정보 ex) LG CNS
export const COMPANY_COMPANY_INFO = 'company_company_info';
// 회사상세 정보
export const COMPANY_DETAIL = 'company_company_detail';
// 회사 부서 정보 ex) MS Teams 팀
export const COMPANY_DEPARTMENT_INFO = 'company_department_info';

// 유저 정보
export const USER_INFO = 'user_info';
export const USER_SIGN_INFO = 'user_sign_info';
export const USER_GROUP_INFO = 'user_group_info';
export const USER_STATUS_INFO = 'user_status_info';
export const USER_ALARM = 'user_alarm';
export const USER_BADGE = 'user_badge';
export const USER_SETTING_INFO = 'user_setting_info';
export const USER_SETTING_DIVICE_INFO = 'ser_setting_divice_info';
export const USER_WORKING_STATUS = 'user_working_status';

// 채팅 관련 collection
export const CHATTING_COUNTER = 'chatting_counter';
export const CHATTING_ROOM_INFO = 'chatting_room_info';
export const CHATTING_ROOM_MEMBER = 'chatting_room_member';
export const CHATTING_ROOM_MESSAGE = 'chatting_room_message';
export const CHATTING_ROOM_BOOKED_MESSAGE = 'chatting_room_booked_message';
export const CHATTING_ROOM_MESSAGE_SP = 'chatting_room_message_sp'; // reminder, bookmark
export const CHATTING_ROOM_MESSAGE_EG = 'chatting_room_message_eg'; // engagement
export const CHATTING_ROOM_MESSAGE_VOTE = 'chatting_room_message_vote';
export const CHATTING_ROOM_MESSAGE_NOTICE = 'chatting_room_message_notice';
export const CHATTING_TRANSLATION_LANGUAGE = 'chatting_translation_language';
export const CHATTING_ROOM_TRANSLATION_INFO = 'chatting_room_translation_info';

// 쪽지
export const NOTE = 'note';
export const BOOKED_NOTE = 'booked_note';
export const NOTE_MEMBER = 'note_member';

export const SYSTEM_NOTICE = 'system_notice';

// pocliy
export const POLICY_VERSION = 'policy_version';
export const POL_VERSION = 'pol_version';
export const POLICY_GDPR_VERSION = 'policy_gdpr_version';
export const DEPLOY_VERSION = 'deploy_version';

// api
export const LOG_API_ACCESS = 'log_api_access';
export const DOWNLOAD_HISTORY = 'download_history';
export const MESSAGE_LOG_FOR_AUDITFILE = 'message_log_for_auditfile';
export const MESSAGE_LOG_JOB_HISTORY = 'message_log_job_history';

// admin - notification
export const ADMIN_NOTIFICATION = 'notification';

// Distribution
export const DISTRIBUTION_MANAGEMENT = 'distribution_management';
export const COMPANY_DISTRIBUTION_MANAGEMENT = 'company_distribution_management';

// org/user sync log
export const SYNC_SUMMARY_LOG = 'sync_summary_log';
export const SYNC_SUMMARY_SYNCDATA_LOG = 'sync_summary_syncdata_log';
export const SYNC_ERROR_LOG = 'sync_error_log';

// org/user sync headers info
export const SYNC_HEADER_INFO = 'sync_header_info';

export const USER_CANCEL = 'user_cancel';

export const ENCRYPTION_KEY = 'encryption_key';

export const DOWNLOAD_INFO = 'download_info';

export const LOADBALANCER_IP = 'loadbalancer_ip';
export const BLOCKED_IP_RANGE_FILE = 'blocked_ip_range_file_transmit';
export const WHITELIST_IP_FILE = 'whitelist_ip_file_transmit';

export const UPLUS_ALLOWED_LOGIN_IP = 'uplus_allowed_login_ip';
export const FILESHARE_GROUP_EMAIL = 'fileshare_group_email';
export const FILESHARE_GROUP_IP = 'fileshare_group_ip_range';

// alarm push
export const PUSH_AUTH_TOKEN_INFO = 'push_auth_token_info';
export const SYSTEM_ALARM_INFO = 'system_alarm_info';
export const SYSTEM_ALARM_USER = 'system_alarm_user';

//sync
export const SCHEDULER_LOCK = 'scheduler_lock';
export const SCHEDULER_INFO = 'scheduler_info';

// onchange stream
export const ONCHANGE_INFO = 'onchange_info';

// report - dashboard
export const DASHBOARD_DAILY_RECORD = 'dashboard_daily_record';
export const STATISTICS_DAILY_RECORD = 'statistics_daily_record';
export const STATISTICS_COMPANY_INFO = 'statistics_company_info';

export const USER_VERIFY_CODE_CHECK = 'user_verify_code_check';