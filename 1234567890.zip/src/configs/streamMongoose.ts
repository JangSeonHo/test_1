import {Mongoose} from 'mongoose';
import {dbUrlForStream} from './database';
import mainListener from 'sockets/dbStreamListeners/mainListener';
import {io} from '../server';

const m = new Mongoose();

m.connect(dbUrlForStream, {
  // serverSelectionTimeoutMS: 20000,
}).then(() => {
  console.log('stream db connect');
  mainListener(io);
});

export default m;
