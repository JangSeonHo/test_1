import dotenv from 'dotenv';
dotenv.config();

export const synapHost = process.env.STATE_ENV === 'dev' ?
   `https://dev-docviewer.lgmtalk.com/SynapDocViewServer` :
   process.env.STAGE_ENV === 'stg' ?
    `https://stg-docviewer.lgmtalk.com/SynapDocViewServer` :
    `https://docviewer.lgmtalk.com/SynapDocViewServer`;
