import dotenv from 'dotenv';

dotenv.config();

export const syncInterval = 1; // 갱신 초 단위
export const albUrl = process.env.STATE_ENV === 'dev' ?
   `internal-NMP-ALB-DEV-INT-AN2-503148719.ap-northeast-2.elb.amazonaws.com` :
   process.env.STAGE_ENV === 'stg' ?
    `internal-NMP-ALB-STG-INT-AN2-836559186.ap-northeast-2.elb.amazonaws.com` :
    `internal-NMP-ALB-PRD-INT-AN2-1149533573.ap-northeast-2.elb.amazonaws.com`;
