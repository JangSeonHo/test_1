import dotenv from 'dotenv';
dotenv.config();

export const cdnHost = process.env.STATE_ENV === 'dev' ?
   'https://dev-file.lgmtalk.com' :
   process.env.STAGE_ENV === 'stg' ?
    'https://stg-file.lgmtalk.com' :
    'https://file.lgmtalk.com';

export const albIP = process.env.STATE_ENV === 'dev' ?
  'internal-NMP-ALB-DEV-INT-AN2-503148719.ap-northeast-2.elb.amazonaws.com' :
  'internal-NMP-ALB-PRD-INT-AN2-1149533573.ap-northeast-2.elb.amazonaws.com';

export const debugMode = {
  any: false,
  socket: false,
  default: false,
};
