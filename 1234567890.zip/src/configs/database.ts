import dotenv from 'dotenv';

dotenv.config();

console.log("process.env.STATE_ENV >>>>>>>>>>>>>>> ", process.env.STATE_ENV);

export const dbUrl = process.env.STATE_ENV === 'dev' ?
  `mongodb://nmpadm:${process.env.DB_PWD}@nmp-db-dev.cluster-cpno80tqzbpe.ap-northeast-2.docdb.amazonaws.com:27017/lg?authMechanism=SCRAM-SHA-1&tls=true&tlsCAFile=/svc/engn001/nmp/global-bundle.pem&replicaSet=rs0&retryWrites=false&readPreference=secondaryPreferred` :
  process.env.STAGE_ENV === 'stg' ?
    `mongodb://nmpadm:${process.env.DB_PWD}@nmp-db-stg.cluster-cgrkzrvssg7p.ap-northeast-2.docdb.amazonaws.com:27017/lg?authMechanism=SCRAM-SHA-1&tls=true&tlsCAFile=/svc/engn001/nmp/global-bundle.pem&replicaSet=rs0&retryWrites=false&readPreference=secondaryPreferred` :
    `mongodb://nmpadm:${process.env.DB_PWD}@nmp-db-prd.cluster-cjksgswzxbdp.ap-northeast-2.docdb.amazonaws.com:27017/lg?authMechanism=SCRAM-SHA-1&tls=true&tlsCAFile=/svc/engn001/nmp/global-bundle.pem&replicaSet=rs0&retryWrites=false&readPreference=secondaryPreferred`;

export const dbUrlPrimaryOnly = process.env.STATE_ENV === 'dev' ?
  `mongodb://nmpadm:${process.env.DB_PWD}@nmp-db-dev.cluster-cpno80tqzbpe.ap-northeast-2.docdb.amazonaws.com:27017/lg?authMechanism=SCRAM-SHA-1&tls=true&tlsCAFile=/svc/engn001/nmp/global-bundle.pem&replicaSet=rs0&retryWrites=false&readPreference=primary` :
  process.env.STAGE_ENV === 'stg' ?
    `mongodb://nmpadm:${process.env.DB_PWD}@nmp-db-stg.cluster-cgrkzrvssg7p.ap-northeast-2.docdb.amazonaws.com:27017/lg?authMechanism=SCRAM-SHA-1&tls=true&tlsCAFile=/svc/engn001/nmp/global-bundle.pem&replicaSet=rs0&retryWrites=false&readPreference=primary` :
    `mongodb://nmpadm:${process.env.DB_PWD}@nmp-db-prd.cluster-cjksgswzxbdp.ap-northeast-2.docdb.amazonaws.com:27017/lg?authMechanism=SCRAM-SHA-1&tls=true&tlsCAFile=/svc/engn001/nmp/global-bundle.pem&replicaSet=rs0&retryWrites=false&readPreference=primary`;

export const dbUrlForStream = process.env.STATE_ENV === 'dev' ?
  `mongodb://nmpadm:${process.env.DB_PWD}@nmp-db-dev.cluster-cpno80tqzbpe.ap-northeast-2.docdb.amazonaws.com:27017/lg?authMechanism=SCRAM-SHA-1&tls=true&tlsCAFile=/svc/engn001/nmp/global-bundle.pem&replicaSet=rs0&retryWrites=false` :
  process.env.STAGE_ENV === 'stg' ?
    `mongodb://nmpadm:${process.env.DB_PWD}@nmp-db-stg.cluster-cgrkzrvssg7p.ap-northeast-2.docdb.amazonaws.com:27017/lg?authMechanism=SCRAM-SHA-1&tls=true&tlsCAFile=/svc/engn001/nmp/global-bundle.pem&replicaSet=rs0&retryWrites=false` :
    `mongodb://nmpadm:${process.env.DB_PWD}@nmp-db-prd.cluster-cjksgswzxbdp.ap-northeast-2.docdb.amazonaws.com:27017/lg?authMechanism=SCRAM-SHA-1&tls=true&tlsCAFile=/svc/engn001/nmp/global-bundle.pem&replicaSet=rs0&retryWrites=false`;
