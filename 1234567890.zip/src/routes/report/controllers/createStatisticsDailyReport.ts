import Koa from 'koa';

const { ObjectId } = require("mongodb");
import userInfoModel from 'models/account/user_info';
import chattingRoomMessageModel from 'models/message/chatting_room_message';
import noteModel from 'models/note/note_info';
import statisticsDailyRecordModel from 'models/report/statistics_daily_record';
import statisticCompanyInfoModel from 'models/report/statistics_company_info';
import {USER_SIGN_INFO, USER_INFO} from 'models/collection_names';

const createStatisticsDailyReport = async (tenantFlag: string) => {

  try {
    const now = new Date();
    const ONE_DAY_IN_MS = 24 * 60 * 60 * 1000;
    const koreaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));
    const toDate = new Date(koreaTime.getFullYear(), koreaTime.getMonth(), koreaTime.getDate()).getTime();
    const fromDate = toDate - (ONE_DAY_IN_MS);
    const year = new Date(fromDate).getFullYear().toString();
    const month = (new Date(fromDate).getMonth() + 1).toString().padStart(2, '0');
    const day = new Date(fromDate).getDate().toString().padStart(2, '0');

    const UserInfoModel = userInfoModel({ tenantFlag });
    const ChattingRoomMessageModel = chattingRoomMessageModel({ tenantFlag });
    const NoteModel = noteModel({ tenantFlag });
    const StatisticsDailyRecordModel = statisticsDailyRecordModel({ tenantFlag });
    const StatisticsCompanyModel = statisticCompanyInfoModel({ tenantFlag });

    const companyList = await StatisticsCompanyModel.find({
        useYn: 'Y'
    })
    .populate('parentCompany');

    for (const company of companyList) {
      const companyId = company.parentCompany._id;

      const alreadyCreatedRecord = await StatisticsDailyRecordModel.findOne({
        parentCompany: new ObjectId(companyId),
        year,
        month,
        day
      });

      if(alreadyCreatedRecord) {
        continue;
      }

      // 회사 전체 인원 정보 조회
      const userInfos = await UserInfoModel.aggregate([
        {
          $match: {
            "parentCompany": new ObjectId(companyId)
          }
        },
        {
          $sort: {
            "_id": 1
          }
        },
        {
          $project: {
            _id: 1,
            registeredYn: { $cond: { if: { $ifNull: ["$changePasswordDate", false] }, then: 'Y', else: 'N' } },
            deletedYn: { $cond: { if: { $eq: ["$isDeleted", true] }, then: 'Y', else: 'N' } }
          }
        }
      ]);

      // 사용여부 조회
      const useYnInfo = await UserInfoModel.aggregate([
        {
          $match: {
            "parentCompany": new ObjectId(companyId)
          }
        },
        {
          $lookup: {
            from: `${tenantFlag}_${USER_SIGN_INFO}s`,
            localField: "_id",
            foreignField: "parentUser",
            as: "userSignInfo"
          }
        },
        {
          $unwind: "$userSignInfo"
        },
        {
          $match: {
            "userSignInfo.lastRefreshedAt": { $gte: fromDate }
          }
        },
        {
          $group: {
            _id: "$_id",
            pcCnt: {
              $sum: {
                $cond: [{ $eq: ['$userSignInfo.deviceType', 'win32'] }, 1, 0]
              }
            },
            mobileCnt: {
              $sum: {
                $cond: [
                  { $in: ['$userSignInfo.deviceType', ['android', 'ios']] },
                  1,
                  0
                ]
              }
            }
          }
        },
        {
          $sort: { '_id._id': 1 }
        },
        {
          $project: {
            _id: 1,
            pcYn: {
              $cond: [{ $eq: ['$pcCnt', 0] }, 'N', 'Y']
            },
            mobileYn: {
              $cond: [{ $eq: ['$mobileCnt', 0] }, 'N', 'Y']
            }
          }
        }
      ]);

      const useYnMap = useYnInfo.reduce((acc, cur) => {
        acc[cur._id] = cur;
        return acc;
      }, {});

      // 채팅건수 조회
      const userChatCountInfo = await ChattingRoomMessageModel.aggregate([
        {
          $match: {
            "createdAt": { "$gte": fromDate, "$lt": toDate },
            "isSystemMessage": false
          }
        },
        {
          $lookup: {
            from: `${tenantFlag}_${USER_INFO}s`,
            localField: "parentUser",
            foreignField: "_id",
            as: "userInfo"
          }
        },
        {
          $unwind: "$userInfo"
        },
        {
          $match: {
            "userInfo.parentCompany": new ObjectId(companyId)
          }
        },
        {
          $group: {
            _id: "$parentUser",
            chatCounts: { $sum: 1 }
          }
        },
        {
          $project: {
            _id: 0,
            parentUser: "$_id",
            chatCounts: 1
          }
        }
      ]);

      const chatCountMap = userChatCountInfo.reduce((acc, cur) => {
        acc[cur.parentUser] = cur;
        return acc;
      }, {});

      // 쪽지건수 조회
      const userNoteCountInfo = await NoteModel.aggregate([
        {
          $match: {
            "createdAt": { "$gte": fromDate, "$lt": toDate }
          }
        },
        {
          $lookup: {
            from: `${tenantFlag}_${USER_INFO}s`,
            localField: "sender",
            foreignField: "_id",
            as: "userInfo"
          }
        },
        {
          $unwind: "$userInfo"
        },
        {
          $match: {
            "userInfo.parentCompany": new ObjectId(companyId)
          }
        },
        {
          $group: {
            _id: "$sender",
            noteCounts: { $sum: 1 }
          }
        },
        {
          $project: {
            _id: 0,
            parentUser: "$_id",
            noteCounts: 1
          }
        }
      ]);

      const noteCountMap = userNoteCountInfo.reduce((acc, cur) => {
        acc[cur.parentUser] = cur;
        return acc;
      }, {});

      const createdAt = new Date().getTime();

      // 위 데이터들을 통합하여 저장
      const records = userInfos.map((userInfo, index) => {
        const userSignInfo = useYnMap[userInfo._id];
        const chatInfo = chatCountMap[userInfo._id];
        const noteInfo = noteCountMap[userInfo._id];

        return {
          parentCompany: companyId,
          parentUser: userInfo._id,
          year,
          month,
          day,
          registeredYn: userInfo.registeredYn,
          deletedYn: userInfo.deletedYn,
          usePcYn: userSignInfo?.pcYn?? 'N',
          useMobileYn: userSignInfo?.mobileYn ?? 'N',
          chatCounts: chatInfo?.chatCounts ?? 0,
          noteCounts: noteInfo?.noteCounts ?? 0,
          createdAt,
        };
      });

      await StatisticsDailyRecordModel.insertMany(records);
    }

    return {
      success: true,
      message: "success",
    };
  } catch (err) {
    throw err;
  }
};

export default createStatisticsDailyReport;
