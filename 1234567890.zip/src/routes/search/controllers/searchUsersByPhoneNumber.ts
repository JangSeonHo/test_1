/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyCompanyModel from 'models/company/company_company_info';
import departmentModel from 'models/company/company_department_info';

const searchUserByPhoneNumber = async (ctx: Koa.Context) => {
  try {
    const {phoneNumber} = ctx.query;

    if (!phoneNumber || phoneNumber.length === 0) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Bad Request',
      };
    }

    const tenantFlag = ctx.response.get('tenantFlag');

    // compile before populate
    companyCompanyModel({tenantFlag});
    departmentModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    //

    const targetModel = userInfoModel({tenantFlag});

    const query: any = {
      'isDeleted': false,
      '$or': [
        {
          'personalPhoneNumber': phoneNumber,
        },
        {
          'officePhoneNumber': phoneNumber,
        },
      ],
    };

    const user = await targetModel.findOne(query)
      .select('userName jobTitle');

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        user: {
          ko: `${user.userName['ko']} ${user.jobTitle['ko']}`,
          en: `${user.userName['en']} ${user.jobTitle['en']}`,
        },
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default searchUserByPhoneNumber;
