/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyCompanyModel from 'models/company/company_company_info';
import departmentModel from 'models/company/company_department_info';
import pushAuthTokenInfoModel from 'models/push/push_auth_token_info';

import { Types } from "mongoose";

const searchUserByKeywordForSMS = async (ctx: Koa.Context) => {
  try {
    const {keyword, page = 1, itemsPerPage = 999, includeMe = 'Y', includeOtherCompanies = 'Y'} = ctx.query;
    const {companyCode } = ctx.request.body;

    if (!keyword || keyword.length === 0) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Bad Request',
      };
    }

    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    const authToken = ctx.headers['auth-token'] ?? ctx.query.authToken;

    // AuthToken 정보 확인
    const targetPushAuthTokenInfoModel = pushAuthTokenInfoModel({ tenantFlag });
    const resultAuthToken = await targetPushAuthTokenInfoModel.findOne({
      tenantFlag: tenantFlag,
      companyCode: { $eq: companyCode },
      authToken: authToken,
    });

    let paramAuthToken;
    if (resultAuthToken && resultAuthToken.authToken) {
      paramAuthToken = resultAuthToken.authToken;
    } else {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0001",
        resultMsg: "authKey mismatch",
      };
      return;
    }

    // compile before populate
    userStatusInfoModel({tenantFlag});
    //

    const requestPage = Number(page);
    const requestItemsPerPage = Number(itemsPerPage);

    const targetModel = userInfoModel({tenantFlag});
    const TargetDepartmentModel = departmentModel({tenantFlag});
    const TargetCompanyModel = companyCompanyModel({tenantFlag});

    const [departmentIds, companyIds] = await Promise.all([
      TargetDepartmentModel.find({
        '$or': [
          {
            'departmentName.ko': {
              $regex: keyword, $options: 'i',
            },
          },
          {
            'departmentName.en': {
              $regex: keyword, $options: 'i',
            },
          },
        ],
      }).select('_id'),
      TargetCompanyModel.find({
        '$or': [
          {
            'companyName.ko': {
              $regex: keyword, $options: 'i',
            },
          },
          {
            'companyName.en': {
              $regex: keyword, $options: 'i',
            },
          },
        ],
      }).select('_id'),
    ]);

    const query: any = {
      '$or': [
        {
          'userName.ko': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'userName.en': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'email': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'personalPhoneNumber': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'officePhoneNumber': {
            $regex: keyword, $options: 'i',
          },
        },
      ],
    };

    departmentIds.forEach((id: string) => {
      query['$or'].push({
        'parentDepartment': id,
      });
    });

    companyIds.forEach((id: string) => {
      query['$or'].push({
        'parentCompany': id,
      });
    });

    if (includeMe !== 'Y') {
      query['_id'] = { $ne: new Types.ObjectId(userId) }; // 올바른 방식
    }

    if (includeOtherCompanies !== 'Y') {
      const myInfo = await targetModel.findOne({_id: userId}).select('parentCompany');
      query['parentCompany'] = myInfo.parentCompany;
    }

    const users = await targetModel.find(query)
      .skip((requestPage - 1) * requestItemsPerPage)
      .limit(requestItemsPerPage)
      .select('userName jobTitle email personalPhoneNumber officePhoneNumber profileImage childStatusInfo useMessenger parentCompany parentDepartment role')
      .lean()
      .populate('parentCompany', 'companyName _id')
      .populate('parentDepartment', 'departmentName _id')
      .populate('childStatusInfo', '-_id -_v');

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        users: includeMe === 'Y' ?
          users :
          users.filter((_id) => _id.toString() !== userId),
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default searchUserByKeywordForSMS;
