/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
// import companyCompanyModel from 'models/company/company_company_info';
import companyDetailModel from 'models/company/company_detail';
// import departmentModel from 'models/company/company_department_info';

const searchUserByKeyword = async (ctx: Koa.Context) => {
  try {
    const {keyword, page = 1, itemsPerPage = 999, includeMe = 'Y', includeOtherCompanies = 'Y'} = ctx.query;

    if (!keyword || keyword.length === 0) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Bad Request',
      };
    }

    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    // compile before populate
    userStatusInfoModel({tenantFlag});
    //

    const requestPage = Number(page);
    const requestItemsPerPage = Number(itemsPerPage);

    const targetModel = userInfoModel({tenantFlag});
    // const TargetDepartmentModel = departmentModel({tenantFlag});
    // const TargetCompanyModel = companyCompanyModel({tenantFlag});

    const [myInfo, onlyCompanyDetails] = await Promise.all([
      targetModel.findOne({
        _id: userId,
      }).populate('parentCompany', '_id'),
      companyDetailModel({tenantFlag}).find({
        useCompanyOnlyYn: 'Y',
      }).select('parentCompany'),
    ]);
    const myCompanyDetail = onlyCompanyDetails.filter((detail) =>
      String(detail.parentCompany) == String(myInfo.parentCompany._id));
    const isMyCompanyOnly = myCompanyDetail.length > 0;

    // 회사명, 부서명 검색 제외
    // const [departmentIds, companyIds] = await Promise.all([
    //   TargetDepartmentModel.find({
    //     '$or': [
    //       {
    //         'departmentName.ko': {
    //           $regex: keyword, $options: 'i',
    //         },
    //       },
    //       {
    //         'departmentName.en': {
    //           $regex: keyword, $options: 'i',
    //         },
    //       },
    //     ],
    //   }).select('_id'),
    //   TargetCompanyModel.find({
    //     '$or': [
    //       {
    //         'companyName.ko': {
    //           $regex: keyword, $options: 'i',
    //         },
    //       },
    //       {
    //         'companyName.en': {
    //           $regex: keyword, $options: 'i',
    //         },
    //       },
    //     ],
    //   }).select('_id'),
    // ]);

    const query: any = {
      'isDeleted': false,
      '$or': [
        {
          'userName.ko': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'userName.en': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'email': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'personalPhoneNumber': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'officePhoneNumber': {
            $regex: keyword, $options: 'i',
          },
        },
      ],
      '$nor': [],
    };

    // departmentIds.forEach((id: string) => {
    //   query['$or'].push({
    //     'parentDepartment': id,
    //   });
    // });
    //
    // companyIds.forEach((id: string) => {
    //   query['$or'].push({
    //     'parentCompany': id,
    //   });
    // });

    if (includeMe !== 'Y') {
      query['$nor'].push({_id: userId});
    }

    if (includeOtherCompanies !== 'Y' || isMyCompanyOnly) {
      // const myInfo = await targetModel.findOne({_id: userId}).select('parentCompany');
      query['parentCompany'] = myInfo.parentCompany._id;
    }

    if (!isMyCompanyOnly) {
      onlyCompanyDetails.forEach((company) => {
        query['$nor'].push({
          'parentCompany': company.parentCompany,
        });
      });
    }

    const users = await targetModel.find(query)
      .skip((requestPage - 1) * requestItemsPerPage)
      .limit(requestItemsPerPage)
      .select('userName jobTitle email personalPhoneNumber officePhoneNumber profileImage childStatusInfo useMessenger parentCompany parentDepartment role')
      .lean()
      .populate('parentCompany', 'companyName _id')
      .populate('parentDepartment', 'departmentName _id')
      .populate('childStatusInfo', '-_id -_v');

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        users: includeMe === 'Y' ?
          users :
          users.filter((_id) => _id.toString() !== userId),
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default searchUserByKeyword;
