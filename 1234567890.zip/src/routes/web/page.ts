import Router from '@koa/router';

const router = new Router();

router.get('/login', async (ctx) => {
  await ctx.render('login');
});

router.get('/chat', async (ctx) => {
  const token = ctx.cookies.get('jwt_token');
  if (!token) return ctx.redirect('/login');
  await ctx.render('chat', { token });
});

export default router;
