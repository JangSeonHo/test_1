import Koa from 'koa';

import companyCompanyModel from 'models/company/company_company_info';
import accountUserInfoModel from 'models/account/user_info';
import generatePasswordSalt from 'utils/account/generatePasswordSalt';
import getHashedPassword from 'utils/account/getHashedPassword';

const updatePasswordUser = async (ctx   : Koa.Context) => {
  try {
    const {
      companyCode,
      emailId: emailIdList,
    } = ctx.request.body as { companyCode: string; emailId: string[] };

    const tenantFlag = ctx.response.get('tenantFlag');

    const companyModel = companyCompanyModel({tenantFlag});
    const userInfoModel = accountUserInfoModel({tenantFlag});

    const company = await companyModel.findOne({ companyCode });
    if (!company || !company._id) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: 'Invalid companyCode or company not found',
      };
      return;
    }
    console.log("[updatePasswordUser][companyId] >>> ", company._id);


    const updatePromises = emailIdList.map(async (emailId) => {
      //const emailId = (email.split('@')[0] ?? '').toLowerCase();
      const passwordSalt: string = generatePasswordSalt();
      //const hashedPassword: string = getHashedPassword(emailId, passwordSalt);
      const hashedPassword: string = getHashedPassword("!!1q2w3e4r", passwordSalt);
      console.log(emailId+" , "+hashedPassword+" , "+passwordSalt);

      return userInfoModel.updateOne(
        {
          emailId,
          //parentCompany: company._id,
        },
        {
          $set: {
            hashedPassword,
            passwordSalt,
          },
        }
      );
    });

    const results = await Promise.allSettled(updatePromises);

    const successCount = results.filter(r => r.status === 'fulfilled').length;
    const failCount = results.filter(r => r.status === 'rejected').length;

    ctx.status = 200;
    ctx.body = {
      success: true,
      updated: successCount,
      failed: failCount,
    };
  } catch (err) {
    console.log(err);

    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default updatePasswordUser;
