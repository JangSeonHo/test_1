import Router from '@koa/router';

const router = new Router();

import createUser from './controllers/createUser';
router.post('/createUser', createUser);

import updatePasswordUser from './controllers/updatePasswordUser';
router.post('/updatePasswordUser', updatePasswordUser);

import getVersionUpdateYn from './controllers/getVersionUpdateYn';
router.post('/getVersionUpdateYn', getVersionUpdateYn);

export default router;
