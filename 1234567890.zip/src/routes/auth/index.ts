// middlewares
import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

import Router from '@koa/router';
const router = new Router();

import issueJWT from './controllers/jwt/issueJWT';
router.post('/jwt/issueJWT', issueJWT);

import validateJWT from './controllers/jwt/validateJWT';
router.post('/jwt/validateJWT', isLoggedIn , validateJWT);

import refreshJWT from './controllers/jwt/refreshJWT';
router.post('/jwt/refreshJWT', logApiAccess, refreshJWT);

import revokeJWT from './controllers/jwt/revokeJWT';
router.delete('/jwt/revokeJWT', isLoggedIn, logApiAccess, revokeJWT);

import activateMessenger from './controllers/activateMessenger';
router.post('/activateMessenger', activateMessenger);

import checkEmailValidation from './controllers/checkEmailValidation';
router.get('/checkEmailValidation', checkEmailValidation);

import sendVerifyCode from './controllers/sendVerifyCode';
router.post('/sendVerifyCode', logApiAccess, sendVerifyCode);

import validateVerifyCode from './controllers/validateVerifyCode';
router.post('/validateVerifyCode', logApiAccess, validateVerifyCode);

import validateVerifyCodeMobile from './controllers/validateVerifyCodeMobile';
// eslint-disable-next-line max-len
router.post('/validateVerifyCodeMobile', logApiAccess, validateVerifyCodeMobile);

import checkPassword from './controllers/checkPassword';
router.post('/checkPassword', isLoggedIn, checkPassword);

import changePassword from './controllers/changePassword';
router.post('/changePassword', isLoggedIn, logApiAccess, changePassword);

import loginMobile from './controllers/loginMobile';
router.post('/loginMobile', loginMobile);

import agreePrivacyPolicy from './controllers/agreePrivacyPolicy';
// eslint-disable-next-line max-len
router.post('/agreePrivacyPolicy', isLoggedIn, logApiAccess, agreePrivacyPolicy);

import agreeGdprPolicy from './controllers/agreeGdprPolicy';
router.post('/agreeGdprPolicy', isLoggedIn, logApiAccess, agreeGdprPolicy);

export default router;
