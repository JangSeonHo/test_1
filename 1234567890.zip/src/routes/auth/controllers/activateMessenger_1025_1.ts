/* eslint-disable max-len */
import Koa from 'koa';

import mongoose from 'mongoose';

import userInfoModel from 'models/account/user_info';
import policyVersionModel from 'models/system/policy_version';

import generatePasswordSalt from 'utils/account/generatePasswordSalt';
import getHashedPassword from 'utils/account/getHashedPassword';
import issueToken from 'utils/account/issueToken';
import companyInfoModel from 'models/company/company_company_info';
import uplusAllowedIpModel from 'models/system/uplus_allowed_login_ip';

const activateMessenger = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {userId, password, authType, code, deviceId}: {userId: string, password: string, authType: string, code: string, deviceId: string} = body;
    const headers = ctx.headers;
    const deviceType = headers['device-type'];
    const versionInfo = headers['version-info'];

    if ((authType !== 'email' && authType !== 'phone') ||
      !mongoose.Types.ObjectId.isValid(userId) || code.length !== 6 || !deviceId) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');

    const targetUserModel = userInfoModel({tenantFlag});

    const userInfo = await targetUserModel.findOne({'_id': userId, 'mfa.type': authType, 'mfa.code': code}).select('_id parentCompany');

    if (userInfo === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'permission denied',
      };

      return;
    }

    // 임시 - 유플러스(GUC001) 유저는 등록된 VDI용 라우터 IP만 허용 - 권오중
    const companyInfo = await companyInfoModel({tenantFlag})
      .findOne({companyCode: 'GUC001'})
      .select('_id').lean();
    // console.log('typeof companyOid = ', typeof companyInfo);
    if (deviceType === 'win32' && typeof companyInfo === 'object') {
      let isAllowed = false;
      if (String(userInfo.parentCompany) === String(companyInfo._id)) {
        const isAllowedIpList = await uplusAllowedIpModel({tenantFlag})
          .find({isEnable: true})
          .select('allowedIp').lean();
        if (isAllowedIpList.length > 0) {
          let tmpHeaderIp = ctx.request.headers['x-forwarded-for'] || '';
          if (tmpHeaderIp.includes(',') && typeof tmpHeaderIp === 'string') {
            tmpHeaderIp = tmpHeaderIp.split(',');
          }
          const ipArr = Array.isArray(tmpHeaderIp) ? tmpHeaderIp : [tmpHeaderIp];
          ipArr.push(ctx.request.socket.remoteAddress || '');
          ipArr.forEach((ipVal) => {
            let clientIP = ipVal.trim();
            clientIP = clientIP.replace(/^.*:/, '');
            const arrIP = clientIP.split('.');
            const decClientIP = ((((((+arrIP[0])*256)+(+arrIP[1]))*256)+(+arrIP[2]))*256)+(+arrIP[3]);
            isAllowedIpList.forEach((info: any) => {
              if (decClientIP === Number(info.allowedIp) || Number(info.allowedIp) === 0) {
                isAllowed = true;
              }
            });
          });
        }
      } else {
        isAllowed = true;
      }
      if (!isAllowed) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'error': 'permission denied',
        };
        return;
      }
    }

    const passwordSalt: string = generatePasswordSalt();
    const hashedPassword: string = getHashedPassword(password, passwordSalt);

    await targetUserModel.updateOne({_id: userId}, {
      'passwordSalt': passwordSalt,
      'hashedPassword': hashedPassword,
      'useMessenger': true,
      'loginFailCount': 0,
      'changePasswordDate': new Date().getTime(),
      'lastLoginDate': new Date().getTime(),
    });

    const {accessToken, refreshToken} = await issueToken({
      tenantFlag,
      userId,
      deviceId,
      deviceType,
      versionInfo,
    });

    const policyVersion = await policyVersionModel({tenantFlag}).findOne({});

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        userId,
        accessToken,
        refreshToken,
        policyVersion: userInfo.agreePrivacyPolicyVersion === policyVersion.version ? '' : policyVersion.version,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {'success': false, 'error': 'internal server error'};
  }
};

export default activateMessenger;
