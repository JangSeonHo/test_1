/* eslint-disable max-len */
import Koa from 'koa';

import mongoose from 'mongoose';

import userInfoModel from 'models/account/user_info';
import policyVersionModel from 'models/system/policy_version';
// import policyGDPRModel from 'models/system/policy_gdpr_version';
import policyGDPRVersionModel from 'models/system/policy_gdpr_version';

import generatePasswordSalt from 'utils/account/generatePasswordSalt';
import getHashedPassword from 'utils/account/getHashedPassword';
import issueToken from 'utils/account/issueToken';
import companyInfoModel from 'models/company/company_company_info';
import uplusAllowedIpModel from 'models/system/uplus_allowed_login_ip';
import createApiAccessLog from '../../../utils/log/create_api_access_log';
import {
  ENCKEYFORPARAM,
  UserStatusCode,
} from '../../../constants/commonConstants';
import userStatusModel from '../../../models/account/user_status_info';
import {lbipModelPrimaryOnly} from '../../../models/system/loadbalancer_ip';
import convertIpToDecimal from '../../../utils/string/convertIpToDecimal';
import validatePassword from 'utils/account/validatePassword';
import {decryptBodyParams} from '../../../utils/cipher';

const activateMessenger = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const headers = ctx.headers;
    const body: any = ctx.request.body;
    let {
      userId, password, authType, code, deviceId, deviceType, encParam,
    }: {
      userId: string, password: string, authType: string, code: string, deviceId: string, deviceType: string, encParam: string
    } = body;

    if (!!encParam) {
      const decryptRes = decryptBodyParams(encParam, ENCKEYFORPARAM, true);

      if (!decryptRes.success) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'code': '',
          'message': 'bad request',
        };
        return;
      }
      userId = decryptRes.params['userId'];
      password = decryptRes.params['password'];
      authType = decryptRes.params['authType'];
      code = decryptRes.params['code'];
      deviceId = decryptRes.params['deviceId'];
      deviceType = decryptRes.params['deviceType'];
    }

    deviceType = deviceType ?? headers['device-type'] as string ?? '';
    const versionInfo = headers['version-info'] as string ?? '';

    if ((authType !== 'email' && authType !== 'phone') ||
      !mongoose.Types.ObjectId.isValid(userId) || code.length !== 6 || !deviceId) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const targetUserModel = userInfoModel({tenantFlag});
    const targetUserStatusModel = userStatusModel({tenantFlag});

    // ToDo: agreeGDPRVersion 가 없는 사람은 어떻게 되는지 확인
    const userInfo = await targetUserModel
      .findOne({_id: userId, 'mfa.type': authType, 'mfa.code': code})
      .select('_id parentCompany agreePrivacyPolicyVersion europeCorp agreeGDPRVersion mfa');

    if (userInfo === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'permission denied',
      };

      return;
    }

    // 임시 - 유플러스(GUC001) 유저는 등록된 VDI용 라우터 IP만 허용 - 권오중
    const companyInfo = await companyInfoModel({tenantFlag})
      .findOne({companyCode: 'GUC001'})
      .select('_id');
    // console.log('typeof companyOid = ', typeof companyInfo);
    if ((deviceType === 'win32' || deviceType === 'macos') &&
      typeof companyInfo === 'object') {
      let isAllowed = false;
      if (String(userInfo.parentCompany) === String(companyInfo._id)) {
        const [lbIpInfo, isAllowedIpList] = await Promise.all([
          lbipModelPrimaryOnly({tenantFlag})
            .findOne({enable: true, isExt: false})
            .select('ip1 ip2'),
          uplusAllowedIpModel({tenantFlag})
            .find({isEnable: true})
            .select('ipRangeStart ipRangeEnd').lean(),
        ]);
        const lbIP = String(ctx.request.socket.remoteAddress || '');
        const decLBIP = convertIpToDecimal(lbIP);

        if (isAllowedIpList.length > 0 &&
          (lbIpInfo.ip1 === decLBIP || lbIpInfo.ip2 === decLBIP)) {
          console.log('U-Plus login ip - x-forwarded-for :', ctx.request.headers['x-forwarded-for']);

          let tmpHeaderIp = ctx.request.headers['x-forwarded-for'] || '';
          if (tmpHeaderIp.includes(',') && typeof tmpHeaderIp === 'string') {
            tmpHeaderIp = tmpHeaderIp.split(',');
          }
          const ipArr = Array.isArray(tmpHeaderIp) ? tmpHeaderIp : [tmpHeaderIp];
          const decIpArr: number[] = ipArr.map((ipVal) => convertIpToDecimal(ipVal));

          decIpArr.forEach((decClientIP) => {
            isAllowedIpList.forEach((range: any) => {
              if ((range.ipRangeStart <= Number(decClientIP) && range.ipRangeEnd >= Number(decClientIP)) ||
                range.ipRangeStart === 0) {
                isAllowed = true;
              }
            });
          });
        }
      } else {
        isAllowed = true;
      }
      if (!isAllowed) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'error': 'permission denied',
        };
        return;
      }
    } else if (!(deviceType === 'ios' || deviceType === 'android' || deviceType === 'iPad') &&
      typeof companyInfo === 'object') {
      // 유플러스 중에 win32 / macos / ios / android가 아닌 경우 접근제한
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': '',
        'error': 'login failure 2',
      };
      return;
    }

    // [M-2] 패스워드 정책 관리 - LG유플러스 모의해킹 결과 - 보완 조치.
    if (!validatePassword(password)) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Password must include at least two of the following: letters, numbers, special characters.',
      };
      return;
    }


    //MFA인증처리 여부 확인
    const isVerified = userInfo?.mfa?.isVerified;
    console.log("[activateMessenger][userInfo][mfa.isVerified] >>>>>>>>>>>>>>>>>> ", isVerified);
    if(!isVerified){
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'MFA authentication was not completed.', // MFA 인증이 완료되지 않았습니다.
        'data': {
          userId,
          'accessToken': '',
          'refreshToken': '',
          'policyVersion': '',
          'europeCorp': '',
          'policyGDPRVersion': ''
        },
      };
      return;
    }


    const passwordSalt: string = generatePasswordSalt();
    const hashedPassword: string = getHashedPassword(password, passwordSalt);

    await targetUserModel.updateOne({_id: userId}, {
      'passwordSalt': passwordSalt,
      'hashedPassword': hashedPassword,
      'useMessenger': true,
      'loginFailCount': 0,
      'changePasswordDate': new Date().getTime(),
      'lastLoginDate': new Date().getTime(),
    });

    const {accessToken, refreshToken} = await issueToken({
      tenantFlag,
      userId,
      deviceId,
      deviceType,
      versionInfo,
    });

    // GDPR 항목 추가 : europeCorp, policyGDPRVersion 25.2.6
    const europeCorp = userInfo.europeCorp;
    const [policyVersion, policyGDPRVersion] = await Promise.all([
      policyVersionModel({tenantFlag}).findOne({}),
      policyGDPRVersionModel({tenantFlag}).findOne({})
    ]);

    // Win / Mac 로그아웃 후 재로그인 시 stream 발생타이밍 문제로 OFFLINE 상태 표출이슈 처리
    if (deviceType === 'win32' || deviceType === 'macos') {
      await targetUserStatusModel.updateOne({
        $and: [{
          parentUser: userId,
        }, {
          $or: [{pcStatus: UserStatusCode.OFFLINE}, {pcStatus: 'offline'}, {pcStatus: UserStatusCode.AWAY}, {pcStatus: null}],
        }]}, {$set: {
          pcStatus: UserStatusCode.ONLINE,
        }});
    }

    createApiAccessLog({
      api: ctx.url,
      ip: String(ctx.request.headers['x-forwarded-for'] || ''),
      userId,
      deviceType
    });
    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        userId,
        accessToken,
        refreshToken,
        policyVersion: userInfo.agreePrivacyPolicyVersion === policyVersion.version ? '' : policyVersion.version,
        europeCorp,
        policyGDPRVersion: userInfo.agreeGDPRVersion === policyGDPRVersion.ver ? '' : policyGDPRVersion.ver,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {'success': false, 'error': 'internal server error'};
  }
};
//2024.10.25
export default activateMessenger;
