/* eslint-disable max-len */
import Koa from 'koa';
import mongoose from 'mongoose';

import userInfoModel from 'models/account/user_info';
import userVerifyCodeCheckModel from 'models/account/user_verify_code_check';
import maskEmail from 'utils/masking/maskEmail';
import maskPhoneNumber from 'utils/masking/maskPhoneNumber';

import sendEmail from 'utils/email/sendEmail';
import sendSMS from 'utils/sms/sendSMS';

const sendVerifyCode = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {authType, userId}: {authType: string, userId: string} = body;

    if ((authType !== 'email' && authType !== 'phone') ||
      !mongoose.Types.ObjectId.isValid(userId)) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');

    const targetUserModel = userInfoModel({tenantFlag});
    // eslint-disable-next-line max-len
    const userInfo = await targetUserModel.findOne({_id: userId}).select('_id personalPhoneNumber email');

    if (userInfo == null) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const targetUserVerifyCodeCheckModel = userVerifyCodeCheckModel({tenantFlag});
    const verifyCodeCount = await targetUserVerifyCodeCheckModel.countDocuments({ verifyId: userId });

    if (verifyCodeCount >= 20) {
      ctx.status = 429; // Too Many Requests
      ctx.body = {
        success: false,
        error: 'Too many SMS requests from this IP. Please try again later.',
      };
      return;
    }

    // 3. SMS 발송 기록 추가 (밀리초 기록도 같이 저장)
    await targetUserVerifyCodeCheckModel.create({
      verifyId: userId,
      createdAtMs: Date.now(),
    });

    const dateTimeString = new Date().getTime().toString();
    const code = dateTimeString.substring(dateTimeString.length - 6, dateTimeString.length);
    const validateTime =
      authType === 'email' ?
        new Date().getTime() + ((300 + 10) * 1000) :
        new Date().getTime() + ((180 + 10) * 1000); // 10초는 sever latency 보정값

    const {personalPhoneNumber, email} = userInfo;

    if (authType === 'email') {
      sendEmail({
        to: email,
        subject: 'mMessenger 로그인 인증번호입니다',
        text: `메신저 인증번호는 [${code}]입니다`,
      });
    } else if (authType === 'phone') {
      sendSMS({
        to: personalPhoneNumber,
        text: `메신저 인증번호는 [${code}]입니다`,
      });
    }

    await targetUserModel.updateOne({_id: userId}, {
      mfa: {
        'type': authType,
        'code': code,
        'validateTime': validateTime,
        'isVerified': false,
      },
    });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        'userInfo': {
          email: maskEmail(email),
          personalPhoneNumber: maskPhoneNumber(personalPhoneNumber),
          personalPhoneNumber2: personalPhoneNumber,
        },
        'authInfo': {
          validateTime,
        },
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default sendVerifyCode;
