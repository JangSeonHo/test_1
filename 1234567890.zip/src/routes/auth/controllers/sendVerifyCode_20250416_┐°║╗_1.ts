/* eslint-disable max-len */
import Koa from 'koa';
import mongoose from 'mongoose';

import userInfoModel from 'models/account/user_info';
import userVerifyCodeCheckModel from 'models/account/user_verify_code_check';
import maskEmail from 'utils/masking/maskEmail';
import maskPhoneNumber from 'utils/masking/maskPhoneNumber';

import sendEmail from 'utils/email/sendEmail';
import sendSMS from 'utils/sms/sendSMS';

const sendVerifyCode = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {authType, userId}: {authType: string, userId: string} = body;
    console.log("[sendVerifyCode][authType, userId][START] >>>>>>>>>>>>>>>>>>>>>>>> ", authType, userId);

    const headers = ctx.headers;
    const versionInfo = headers['version-info'] as string ?? '';
    const deviceType = headers['device-type'] as string ?? '';
    console.log("[sendVerifyCode][versionInfo] >>>>>>>>>>>> ",versionInfo);
    console.log("[sendVerifyCode][deviceType] >>>>>>>>>>>> ",deviceType);

    if ((authType !== 'email' && authType !== 'phone') ||
      !mongoose.Types.ObjectId.isValid(userId)) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');

    const targetUserModel = userInfoModel({tenantFlag});
    const targetUserVerifyCodeCheckModel = userVerifyCodeCheckModel({tenantFlag});
    // eslint-disable-next-line max-len
    const userInfo = await targetUserModel.findOne({_id: userId}).select('_id personalPhoneNumber email');
    console.log("[sendVerifyCode][userInfo] >>>>>>>>>>>>>>>>>>>>>>>> ", userInfo);

    if (userInfo == null) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    let errorCode: string = '';
    let errorMsg: string = '';

    // 3회이상 실패하면, 30분동안 인증번호 발생이 안된다.
    // M-11. 실패횟수에 대한 유효성 체크 로직 미리 반영. 2025.04.15
    const now = Date.now();
    const failCount = userInfo.mfa?.failCount || 0;
    const lockUntil = userInfo.mfa?.lockUntil || 0;

    if (failCount >= 3 && lockUntil && lockUntil > now) {
      console.log("[sendVerifyCode][3회이상 실패하면, 30분동안 인증번호 발생이 안된다.] >>> ", authType, userId, "[-E9991]");
      errorCode = '-E9991';
      errorMsg = 'Too many failed attempts. Please try again after 30 minutes.';

      ctx.status = 429; // Too Many Requests
      ctx.body = {
        success: false,
        errorCode: errorCode,
        errorMsg: errorMsg,
      };

      return;
    }

    // 1일 발송 제한 횟수 초과 확인 (최근 24시간 기준 최대 20회)
    const oneDayAgo = now - (24 * 60 * 60 * 1000);

    const dailySendCount = await targetUserVerifyCodeCheckModel.countDocuments({
      verifyId: userId,
      createdAtMs: { $gte: oneDayAgo },
    });

    if (dailySendCount >= 20) {
      console.log("[sendVerifyCode][1일 발송 제한 횟수 초과 확인 (최근 24시간 기준 최대 20회)] >>> ", authType, userId, "[-E9992]");
      errorCode = '-E9992';
      errorMsg = 'Exceeded daily SMS request limit. Please try again later.';

      ctx.status = 429; // Too Many Requests
      ctx.body = {
        success: false,
        errorCode: errorCode,
        errorMsg: errorMsg,
      };

      return;
    }

    // 1분내에 10번 이상 인증번호 발송함. 10번 이상 발송못함. 1분 후에 다시 발송 할 수 있음.
    const checkVerifyNow = Date.now();
    const oneMinuteAgo = checkVerifyNow - (60 * 1000);

    const verifyCodeCount = await targetUserVerifyCodeCheckModel.countDocuments({ verifyId: userId, createdAtMs: { $gte: oneMinuteAgo } });

    if (verifyCodeCount >= 10) {
      console.log("[sendVerifyCode][1분내에 10번 이상 인증번호 발송함] >>> ", authType, userId, "[-E9993]");
      errorCode = '-E9993';
      errorMsg = 'Too many SMS requests from this IP. Please try again later.';

      ctx.status = 429; // Too Many Requests
      ctx.body = {
        success: false,
        errorCode: errorCode,
        errorMsg: errorMsg,
      };
      return;
    }

    //
    if (errorCode !== '') {
      console.log("[sendVerifyCode][BLOCK] errorCode 존재 → 인증번호 발송 방지 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      ctx.status = 429;
      ctx.body = {
        success: false,
        errorCode,
        errorMsg,
      };
      return;
    }


    // SMS 발송 기록 추가 (밀리초 기록도 같이 저장)
     await targetUserVerifyCodeCheckModel.create({
      verifyId: userId,
      createdAtMs: Date.now(),
    });

    const dateTimeString = new Date().getTime().toString();
    const code = dateTimeString.substring(dateTimeString.length - 6, dateTimeString.length);
    const validateTime =
      authType === 'email' ?
        new Date().getTime() + ((300 + 10) * 1000) :
        new Date().getTime() + ((180 + 10) * 1000); // 10초는 sever latency 보정값

    const {personalPhoneNumber, email} = userInfo;

    if (authType === 'email') {
      sendEmail({
        to: email,
        subject: 'mMessenger 로그인 인증번호입니다',
        text: `메신저 인증번호는 [${code}]입니다`,
      });
    } else if (authType === 'phone') {
      sendSMS({
        to: personalPhoneNumber,
        text: `메신저 인증번호는 [${code}]입니다`,
      });
    }

    await targetUserModel.updateOne({_id: userId}, {
      mfa: {
        'type': authType,
        'code': code,
        'validateTime': validateTime,
        'isVerified': false,
      },
    });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        'userInfo': {
          email: maskEmail(email),
          personalPhoneNumber: maskPhoneNumber(personalPhoneNumber),
          personalPhoneNumber2: personalPhoneNumber,
        },
        'authInfo': {
          validateTime,
        },
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default sendVerifyCode;