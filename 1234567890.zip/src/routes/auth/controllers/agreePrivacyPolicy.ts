/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';

const agreePrivacyPolicy = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {version, agreeMandatoryPrivacyPolicy, agreeProfileImagePolicy} = ctx.request.body as any;

    const targetUserModel = userInfoModel({tenantFlag});

    if (agreeMandatoryPrivacyPolicy !== undefined) {
      if (agreeMandatoryPrivacyPolicy) {
        await targetUserModel.updateOne({_id: userId}, {
          agreePrivacyPolicyVersion: version,
          agreePrivacyPolicyDate: new Date().getTime(),
          agreeMandatoryPrivacyPolicy,
          agreeProfileImagePolicy,
        });
      }
      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          agreeMandatoryPrivacyPolicy,
          agreeProfileImagePolicy,
        },
      };
    } else { // TODO - 기존 클라이언트 호환코드. 추후 제거
      await targetUserModel.updateOne({_id: userId}, {
        agreePrivacyPolicyVersion: version,
      });
      ctx.status = 200;
      ctx.body = {
        'success': true,
      };
    }
  } catch (err) {
    ctx.status = 500;
    ctx.body = {'success': false, 'error': 'internal server error'};
  }
};

export default agreePrivacyPolicy;
