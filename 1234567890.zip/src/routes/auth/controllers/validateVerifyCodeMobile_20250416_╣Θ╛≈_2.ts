/* eslint-disable max-len */
import Koa from 'koa';
import mongoose from 'mongoose';

import userInfoModel from 'models/account/user_info';
import isNewerOrEqualVersion from 'utils/account/getClientVersionCompare';

const NEW_VERSION_INFO = '0.5.94';

const validateVerifyCodeMobile = async (ctx: Koa.Context) => {
  try {
    const headers = ctx.headers;
    const versionInfo = headers['version-info'] as string ?? '';
    const deviceType = headers['device-type'] as string ?? '';
    console.log("[validateVerifyCodeMobile][versionInfo] >>>>>>>>>>>> ",versionInfo);
    console.log("[validateVerifyCodeMobile][deviceType] >>>>>>>>>>>> ",deviceType);

    //버전 정보 비교
    const isNewVersion = isNewerOrEqualVersion(versionInfo, NEW_VERSION_INFO);

    const body: any = ctx.request.body;
    const {authType, userId, code, deviceId}: {authType: string, userId: string, code: string, deviceId: string} = body;

    if ((authType !== 'email' && authType !== 'phone') ||
      !mongoose.Types.ObjectId.isValid(userId) || code.length !== 6) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');

    const targetUserModel = userInfoModel({tenantFlag});

    const userInfo = await targetUserModel.findOne({_id: userId}).select('mfa');

    if (userInfo == null) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const {mfa} = userInfo;

    const isValidate = mfa.code === code && mfa.validateTime > new Date().getTime();

    let processResult = false;

    //[M-4] MFA 인증 우회 - LG유플러스 모의해캥결과 - 보완조치
    //클라이언트 버전 정보 비교. 0.5.94 이상부터 해당 로직 수행
    if (isNewVersion) {
      console.log('[validateVerifyCodeMobile][신-버전] 처리 중...############## ', versionInfo);
      if (isValidate) {
        console.log('[validateVerifyCodeMobile][신-버전] 처리 성공...@@@@@@@@@@@@@@@@ ', versionInfo);
        await targetUserModel.updateOne({_id: userId}, {
          'lastSignedMobileId': deviceId,
          'mfa.isVerified': true,
        });

        ctx.status = 200;
        ctx.body = {
          success: true,
          message: 'Authentication successful',
        };

        processResult = true;
      }else{
        console.log('[validateVerifyCodeMobile][신-버전] 처리 실패...!!!!!!!!!!!!!!!!!!!!!! ', versionInfo);
        ctx.status = 401;
        ctx.body = {
          success: false,
          error: 'Invalid or expired authentication code.',
        };
        return;
      }
      /*
      클라이언트에서 변경처리해야 할 부분.
      if (response.status === 200 && response.data.success) {

      } else {

      }
      */
    }
    //0.5.94 미만 버전은 아래 로직 수행.
    else{
      console.log('[validateVerifyCodeMobile][구-버전] 처리 중...############## ', versionInfo);
      await targetUserModel.updateOne({_id: userId}, {
        'lastSignedMobileId': deviceId,
        'mfa.isVerified': true,
      });
      processResult = true;

      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          isValidate,
        },
      };
    }
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default validateVerifyCodeMobile;
