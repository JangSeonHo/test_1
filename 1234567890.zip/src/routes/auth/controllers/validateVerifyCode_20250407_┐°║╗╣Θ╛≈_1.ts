/* eslint-disable max-len */
import Koa from 'koa';
import mongoose from 'mongoose';

import userInfoModel from 'models/account/user_info';

const validateVerifyCode = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {authType, userId, code}: {authType: string, userId: string, code: string} = body;

    if ((authType !== 'email' && authType !== 'phone') ||
      !mongoose.Types.ObjectId.isValid(userId) || code.length !== 6) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');

    const targetUserModel = userInfoModel({tenantFlag});

    const userInfo = await targetUserModel.findOne({_id: userId}).select('mfa');

    if (userInfo == null) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const {mfa} = userInfo;

    const isValidate = mfa.code === code && mfa.validateTime > new Date().getTime();

    await targetUserModel.updateOne({_id: userId}, {
      'mfa.isVerified': true,
    });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        isValidate,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default validateVerifyCode;
