/* eslint-disable max-len */
import Koa from 'koa';
import mongoose from 'mongoose';

import userInfoModel from 'models/account/user_info';
import isNewerOrEqualVersion from 'utils/account/getClientVersionCompare';
import {encryptVerifyCode, decryptVerifyCode} from 'utils/cipher';
import {ENCKEYFORPARAM} from 'constants/commonConstants';

const NEW_VERSION_INFO = '0.5.95';

const validateVerifyCodeMobile = async (ctx: Koa.Context) => {
  try {
    const headers = ctx.headers;
    const versionInfo = headers['version-info'] as string ?? '';
    const deviceType = headers['device-type'] as string ?? '';

    //버전 정보 비교
    const isNewVersion = isNewerOrEqualVersion(versionInfo, NEW_VERSION_INFO);

    const body: any = ctx.request.body;
    const {authType, userId, code, deviceId}: {authType: string, userId: string, code: string, deviceId: string} = body;

    if ((authType !== 'email' && authType !== 'phone') ||
      !mongoose.Types.ObjectId.isValid(userId) || code.length !== 6) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');
    const targetUserModel = userInfoModel({tenantFlag});
    const userInfo = await targetUserModel.findOne({_id: userId}).select('mfa');

    if (userInfo == null) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const {mfa} = userInfo;

    const isValidate = mfa.code === code && mfa.validateTime > new Date().getTime();
    const tempEncCode = encryptVerifyCode(mfa.code, ENCKEYFORPARAM);

    // 객체가 성공했는지 확인하고, params만 전달
    // let decrypted: { success: boolean; params?: any; error?: any } = { success: false };

    // if (tempEncCode.success) {
    //   decrypted = decryptVerifyCode(tempEncCode.params, ENCKEYFORPARAM);
    // } else {
    //   console.log("[validateVerifyCodeMobile][encryptVerifyCode][FAILED] >>>>>>>>>>>>>>>>>>>>>>>>>>>> ", tempEncCode.error);
    // }

    // - [M-4] MFA 인증 우회 - LG유플러스 모의해킹 결과 - 보완조치
    // - 클라이언트 버전 정보 비교. 0.5.95 이상부터 해당 로직 수행
    // - 신버전(0.5.95 이상)에서는 MFA인증처리 정보를 업데이트 하지 않고 넘어간다. 중간에 데이타 캐치해서 위변조해서 넘어가도
    //   최종에서는 로그인이 안된다.
    if (isNewVersion) {
      if (!isValidate) {
        await targetUserModel.updateOne({ _id: userId }, {
          'lastSignedMobileId': deviceId,
          'mfa.isVerified': false,
        });

        ctx.status = 401;
        ctx.body = {
          success: false,
          error: 'Invalid or expired authentication code.',
        };
        return;
      }
    }

    // 성공 공통 처리 (신버전 && 성공 or 구버전)
    await targetUserModel.updateOne({ _id: userId }, {
      'lastSignedMobileId': deviceId,
      'mfa.isVerified': true,
    });

    ctx.status = 200;
    ctx.body = isNewVersion
      ? {
          success: true,
          message: 'Authentication successful',
          code: tempEncCode.params, // 암호화된 코드 반환
        }
      : {
          success: true,
          code: tempEncCode.params, // 암호화된 코드 반환
          data: {
            isValidate,
          },
        };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default validateVerifyCodeMobile;
