import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import isNewerOrEqualVersion from 'utils/account/getClientVersionCompare';
// import RE2 from 're2';

const NEW_VERSION_INFO = '0.5.95';

const checkEmailValidation = async (ctx: Koa.Context) => {
  try {
    const {companyId} = ctx.query;

    const headers = ctx.headers;
    const versionInfo = headers['version-info'] as string ?? '';
    const deviceType = headers['device-type'] as string ?? '';
    console.log("[checkEmailValidation][versionInfo] >>>>>>>>>>>> ", versionInfo);
    console.log("[checkEmailValidation][deviceType] >>>>>>>>>>>> ", deviceType);

    const isNewVersion = isNewerOrEqualVersion(versionInfo, NEW_VERSION_INFO);

    const id: string = ((ctx.query.id ?? '') as String).toLowerCase();

    if (!id || !companyId) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');
    const userInfo = await userInfoModel({tenantFlag}).findOne({
      emailId: id,
      parentCompany: companyId,
      $or: [{isDeleted: false}, {isDeleted: {$exists: false}}],
    });

    const isValidate = userInfo !== null;


    //const useMessenger = isValidate ? userInfo.useMessenger : '';
    //const userId = isValidate ? userInfo._id : '';
    const useMessenger = userInfo.useMessenger ?? '';
    const userId = userInfo._id ?? '';


    //사용자 없음 처리 (버전별 메시지 다름)
    if (!isValidate) {
      ctx.status = 401;
      ctx.body = isNewVersion
        ? {
            success: false,
            data: {
              isValidate,
              data: {
                useMessenger,
                userId,
              },
            },
            error: 'User does not exist.', //사용자가 존재하지 않습니다.
          }
        : {
            success: false,
            data: {
              useMessenger,
              userId,
            },
            error: 'unauthorized', // 허가받지 않다.
          };
      return;
    }


    ctx.status = 200;
    ctx.body = isNewVersion
      ? {
          success: true,
          data: {
            useMessenger,
            userId,
          },
          message: 'This is a valid email address.', //사용가능한 이메일 입니다.
        }
      : {
          success: true,
          data: {
            isValidate,
            useMessenger,
            userId,
          },
        };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default checkEmailValidation;
