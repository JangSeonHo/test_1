import Koa from 'koa';
import userInfoModel from 'models/account/user_info';
import isNewerOrEqualVersion from 'utils/account/getClientVersionCompare';

const NEW_VERSION_INFO = '0.5.95';

// 응답 공통 함수
const makeResponse = (
  isSuccess: boolean,
  isNewVersion: boolean,
  payload: any,
  messageOrError: string
) => {
  const responsePayload = { isValidate: isSuccess, ...payload };

  if (isNewVersion) {
    return isSuccess
      ? {
          success: true,
          data: responsePayload,
          message: messageOrError,
        }
      : {
          success: false,
          data: responsePayload,
          error: messageOrError,
        };
  } else {
    return {
      success: isSuccess,
      data: responsePayload,
      ...(isSuccess ? { message: messageOrError } : { error: messageOrError }),
    };
  }
};

const checkEmailValidation = async (ctx: Koa.Context) => {
  try {
    const { companyId } = ctx.query;
    const versionInfo = (ctx.headers['version-info'] as string) ?? '';
    const deviceType = (ctx.headers['device-type'] as string) ?? '';
    const tenantFlag = ctx.response.get('tenantFlag');

    console.log('[checkEmailValidation][versionInfo] >>>>>>>>>>>>', versionInfo);
    console.log('[checkEmailValidation][deviceType] >>>>>>>>>>>>', deviceType);

    const isNewVersion = isNewerOrEqualVersion(versionInfo, NEW_VERSION_INFO);
    const id = ((ctx.query.id ?? '') as string).toLowerCase();

    if (!id || !companyId) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: 'bad request',
      };
      return;
    }

    const userInfo = await userInfoModel({ tenantFlag }).findOne({
      emailId: id,
      parentCompany: companyId,
      $or: [{ isDeleted: false }, { isDeleted: { $exists: false } }],
    });

    const useMessenger = userInfo?.useMessenger ?? '';
    const userId = userInfo?._id ?? '';
    const payload = { useMessenger, userId };

    if (!userInfo) {
      ctx.status = 401;
      ctx.body = makeResponse(false, isNewVersion, payload, isNewVersion ? 'User does not exist.' : 'unauthorized');
      return;
    }

    ctx.status = 200;
    ctx.body = makeResponse(true, isNewVersion, payload, 'This is a valid email address.');
  } catch (err) {
    console.error('[checkEmailValidation][Error] >>>>>>>>', err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default checkEmailValidation;