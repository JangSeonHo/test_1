import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
// import RE2 from 're2';

const checkEmailValidation = async (ctx: Koa.Context) => {
  try {
    const {companyId} = ctx.query;

    const id: string = ((ctx.query.id ?? '') as String).toLowerCase();

    if (!id || !companyId) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');

    // eslint-disable-next-line max-len
    const userInfo = await userInfoModel({tenantFlag}).findOne({
      emailId: id,
      parentCompany: companyId,
      $or: [{isDeleted: false}, {isDeleted: {$exists: false}}],
    });

    const isValidate = userInfo !== null;
    const useMessenger = isValidate ? userInfo.useMessenger : '';
    const userId = isValidate ? userInfo._id : '';

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        isValidate,
        useMessenger,
        userId,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.error = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default checkEmailValidation;
