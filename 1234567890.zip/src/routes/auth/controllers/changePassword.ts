/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';

import generatePasswordSalt from 'utils/account/generatePasswordSalt';
import getHashedPassword from 'utils/account/getHashedPassword';
import validatePassword from 'utils/account/validatePassword';
import { decryptBodyParams } from '../../../utils/cipher';
import { ENCKEYFORPARAM } from '../../../constants/commonConstants';

const changePassword = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const body: any = ctx.request.body;
    let { userId, password, encParam }: {
      userId: string, password: string, encParam: string
    } = body;

    if (!!encParam) {
      const decryptRes = decryptBodyParams(encParam, ENCKEYFORPARAM, true);

      if (!decryptRes.success) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'error': 'permission denied',
        };
        return;
      }
      userId = decryptRes.params['userId'];
      password = decryptRes.params['password'];
    }

    userId = userId ?? ctx.response.get('userId');
    const targetUserModel = userInfoModel({ tenantFlag });
    const userInfo = await targetUserModel.findOne({ _id: userId }).select('_id mfa');

    if (userInfo === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'permission denied',
      };
      return;
    }

    //const isVerified = userInfo?.mfa?.isVerified;
    const { isVerified, isPasswordVerified } = userInfo.mfa || {};

    // 인증처리 여부 검사 - 중간에 상태코드값, 바디 캐치해서 위변조 하더라도 암호는 저장되지 않음.
    if (!isVerified) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'MFA authentication was not completed.', // MFA 인증이 완료되지 않았습니다.
      };
      return;
    }

    // 비밀번호 검증 여부 검사
    if (!isPasswordVerified) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        error: 'Password verification was not completed.', // 비밀번호 검증이 완료되지 않았습니다.
      };
      return;
    }

    // [M-2] 패스워드 정책 관리 - LG유플러스 모의해킹 결과 - 보완 조치
    if (!validatePassword(password)) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Password must include at least two of the following: letters, numbers, special characters.',
      };
      return;
    }

    const passwordSalt: string = generatePasswordSalt();
    const hashedPassword: string = getHashedPassword(password, passwordSalt);

    await targetUserModel.updateOne({ _id: userId }, {
      'passwordSalt': passwordSalt,
      'hashedPassword': hashedPassword,
      'loginFailCount': 0,
      'changePasswordDate': new Date().getTime(),
      'mfa.isPasswordVerified': false, //정상적으로 암호 변경 후 초기화
    });

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = { 'success': false, 'error': 'internal server error' };
  }
};

export default changePassword;
