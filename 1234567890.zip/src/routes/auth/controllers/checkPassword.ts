import Koa from 'koa';

import mongoose from 'mongoose';
import userInfoModel from 'models/account/user_info';
import getHashedPassword from 'utils/account/getHashedPassword';
import validatePassword from 'utils/account/validatePassword';
import { decryptBodyParams } from '../../../utils/cipher';
import { ENCKEYFORPARAM } from '../../../constants/commonConstants';
import isNewerOrEqualVersion from 'utils/account/getClientVersionCompare';

const NEW_VERSION_INFO = '0.5.95';

const checkPassword = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const headers = ctx.headers;
    const versionInfo = (headers['version-info'] as string) ?? '';
    const deviceType = (ctx.headers['device-type'] as string) ?? '';

    const isNewVersion = isNewerOrEqualVersion(versionInfo, NEW_VERSION_INFO);

    let { userId, password, encParam }:
      { userId: string, password: string, encParam: string } = ctx.request.body;

    // encParam이 존재할 경우 복호화
    if (!!encParam) {
      const decryptRes = decryptBodyParams(encParam, ENCKEYFORPARAM, true);

      if (!decryptRes.success) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'error': 'permission denied',
        };
        return;
      }
      userId = decryptRes.params['userId'];
      password = decryptRes.params['password'];
    }

    // fallback
    userId = userId ?? ctx.response.get('userId');

    // userId 유효성 검사
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: 'invalid userId format',
      };
      return;
    }

    const targetUserModel = userInfoModel({ tenantFlag });
    const userInfo = await targetUserModel.findOne({ _id: userId }).select('_id passwordSalt hashedPassword');

    if (!userInfo) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        error: 'permission denied: user not found',
      };
      return;
    }

    // [M-2] 패스워드 정책 관리 - LG유플러스 모의해킹 결과 - 보완 조치.
    if (!validatePassword(password)) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: 'Password must include at least two of the following: letters, numbers, special characters.',
      };
      return;
    }

    const hashedPassword = getHashedPassword(password, userInfo.passwordSalt);
    const isCorrectPassword = userInfo.hashedPassword === hashedPassword;

    // 서버에서 인증 성공 여부 저장 (추후 changePassword에서 검증)
    await targetUserModel.updateOne(
      { _id: userId },
      { 'mfa.isPasswordVerified': isCorrectPassword }
    );


    // [M-4] MFA 인증 우회 - 2단계 인증 우회 - 구버전,신버전 비교 후 response 분기처리
    if (isNewVersion) {
      ctx.status = isCorrectPassword ? 200 : 401;
      ctx.body = { success: isCorrectPassword };
    } else {
      ctx.status = 200;
      ctx.body = {
        success: true,
        data: { checkPassword: isCorrectPassword },
      };
    }
  } catch (err) {
    console.error('[checkPassword][Error]', err);
    ctx.status = 500;
    ctx.body = { success: false, error: 'internal server error' };
  }
};

export default checkPassword;
