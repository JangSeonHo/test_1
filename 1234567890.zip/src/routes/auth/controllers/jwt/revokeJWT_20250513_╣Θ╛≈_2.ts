import Koa from 'koa';
import userSignModel from 'models/account/user_sign_info';
import userStatusInfoModel from 'models/account/user_status_info';
import {UserStatusCode} from '../../../../constants/commonConstants';

const revokeJWT = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const headers = ctx.headers;
    const accessToken = headers['access-token'] as string ?? '';
    const deviceType = headers['device-type'] as string ?? '';

    const targetUserSignModel = userSignModel({tenantFlag});
    // await targetUserSignModel.updateOne({
    //   accessToken,
    // }, {
    //   'sendStream': true,
    // });
    const targetUser = await targetUserSignModel.findOne({accessToken})
      .select('parentUser');

    if (deviceType === 'android' || deviceType === 'ios') {
      console.log(targetUser.parentUser, deviceType);
      await userStatusInfoModel({tenantFlag}).updateMany({
        parentUser: targetUser.parentUser,
      }, {
        mobileStatus: UserStatusCode.OFFLINE,
      });
    } else {
      const query = {
        $and: [{
          parentUser: targetUser.parentUser,
        }, {
          $or: [
            { pcStatus: UserStatusCode.ONLINE },
            { pcStatus: 'online' },
            { pcStatus: UserStatusCode.AWAY },
            { pcStatus: null },
            { pcStatus: '온라인' },
            { pcStatus: '자리비움' },
            { pcStatus: '휴가' },
            { pcStatus: '회의' },
            { pcStatus: '교육' },
            { pcStatus: '출장' },
          ],
        }],
      };

      // ********* [사전 디버깅용] 업데이트 대상 문서 출력 *********
      const targets = await userStatusInfoModel({tenantFlag}).find(query).lean();
      console.log(`[revokeJWT] 대상 userStatusInfo 문서 (${targets.length}건):`);
      console.log(targets);

      await userStatusInfoModel({tenantFlag}).updateMany(query, {
        $set: { pcStatus: UserStatusCode.OFFLINE },
      });
    }

    // ********* [성능튜닝] 아래 로직과 동일 소스 제거 *********
    await targetUserSignModel.deleteOne({
      accessToken,
    });

    ctx.status = 200;
    ctx.body = { 'success': true };
  } catch (err) {
    console.log(err);
  }
};

export default revokeJWT;
