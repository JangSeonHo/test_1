/* eslint-disable max-len */
import Koa from 'koa';

// import Re2 from 're2';

import issueToken from 'utils/account/issueToken';
import userInfoModel from 'models/account/user_info';
import userSignModel from 'models/account/user_sign_info';
import getHashedPassword from 'utils/account/getHashedPassword';
import policyVersionModel from 'models/system/policy_version';
import companyInfoModel from 'models/company/company_company_info';
import uplusAllowedIpModel from 'models/system/uplus_allowed_login_ip';

const issueJWT = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {
      password, deviceId, companyId,
    }: {
      password: string, deviceId: string, companyId: string,
    } = body;

    const tenantFlag = ctx.response.get('tenantFlag');
    const headers = ctx.headers;
    const deviceType = headers['device-type'] as string ?? '';
    const versionInfo = headers['version-info'] as string ?? '';

    const emailId: string = (body.emailId ?? '').toLowerCase();

    if (!emailId || !password || !deviceId || !companyId) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': '',
        'error': 'login failure',
      };

      return;
    }

    const targetUserModel = userInfoModel({tenantFlag});
    const userInfo = await targetUserModel
      .findOne({emailId: emailId, parentCompany: companyId})
      .select('_id passwordSalt hashedPassword role childSignInfos lastSignedMobileId loginFailCount agreePrivacyPolicyVersion mfa changePasswordDate lastLoginDate parentCompany');

    if (userInfo === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': '',
        'error': 'login failure',
      };

      return;
    }

    // 임시 - 유플러스(GUC001) 유저는 등록된 VDI용 라우터 IP만 허용 - 권오중
    const companyInfo = await companyInfoModel({tenantFlag})
      .findOne({companyCode: 'GUC001'})
      .select('_id').lean();
    // console.log('typeof companyOid = ', typeof companyInfo);
    if (deviceType === 'win32' && typeof companyInfo === 'object') {
      let isAllowed = false;
      if (String(userInfo.parentCompany) === String(companyInfo._id)) {
        const isAllowedIpList = await uplusAllowedIpModel({tenantFlag})
          .find({isEnable: true})
          .select('allowedIp').lean();
        if (isAllowedIpList.length > 0) {
          console.log('U-Plus login ip - ', emailId, ' - x-forwarded-for :', ctx.request.headers['x-forwarded-for']);
          console.log('U-Plus login ip - ', emailId, ' - socket.remoteAddress :', ctx.request.socket.remoteAddress);

          let tmpHeaderIp = ctx.request.headers['x-forwarded-for'] || '';
          if (tmpHeaderIp.includes(',') && typeof tmpHeaderIp === 'string') {
            tmpHeaderIp = tmpHeaderIp.split(',');
          }
          const ipArr = Array.isArray(tmpHeaderIp) ? tmpHeaderIp : [tmpHeaderIp];
          ipArr.push(ctx.request.socket.remoteAddress || '');
          ipArr.forEach((ipVal) => {
            let clientIP = ipVal.trim();
            clientIP = clientIP.replace(/^.*:/, '');
            const arrIP = clientIP.split('.');
            const decClientIP = ((((((+arrIP[0])*256)+(+arrIP[1]))*256)+(+arrIP[2]))*256)+(+arrIP[3]);
            isAllowedIpList.forEach((info: any) => {
              if (decClientIP === Number(info.allowedIp) || Number(info.allowedIp) === 0) {
                isAllowed = true;
              }
            });
          });
        }
      } else {
        isAllowed = true;
      }
      if (!isAllowed) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'code': '',
          'error': 'login failure',
        };
        return;
      }
    }

    if (userInfo.loginFailCount === null) {
      userInfo.loginFailCount = 0;
    }

    if (userInfo.loginFailCount > 4) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': 'PF',
        'failCount': 5,
        'error': 'login failure',
      };

      return;
    }

    // password hashing
    const hashedPassword = getHashedPassword(password, userInfo['passwordSalt']);
    if (hashedPassword !== userInfo['hashedPassword']) {
      await targetUserModel.updateOne({emailId: emailId, parentCompany: companyId}, {
        $inc: {
          loginFailCount: 1,
        },
      });

      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': 'PF',
        'failCount': userInfo.loginFailCount + 1,
        'error': 'login failure',
      };

      return;
    }

    const userId: any = userInfo['_id'];

    const currentDate = new Date().getTime();
    const lastLoginDate = userInfo.lastLoginDate || currentDate;

    if (currentDate - lastLoginDate > (90 * 24 * 60 * 60 * 1000)) {
      ctx.status = 200;
      ctx.body = {
        success: true,
        data: {
          authInfo: null,
          userId: userInfo._id,
          shouldChangePassword: true,
        },
      };

      await targetUserModel.updateOne({emailId: emailId, parentCompany: companyId}, {
        loginFailCount: 0,
      });
      return;
    } else {
      await targetUserModel.updateOne({emailId: emailId, parentCompany: companyId}, {
        loginFailCount: 0,
        lastLoginDate: currentDate,
      });
    }

    const userInfoObj = userInfo.toObject();
    if (deviceType === 'android' || deviceType === 'ios') {
      if ((userInfoObj.hasOwnProperty('lastSignedMobileId') && deviceId !== userInfoObj.lastSignedMobileId) ||
        !userInfo.mfa || !userInfo.mfa.isVerified ||
        (!!userInfo.mfa && !userInfoObj.hasOwnProperty('lastSignedMobileId')) // PC로 인증 및 로그인을 거쳤더라도 새 모바일 기기에 대해서는 본인인증 다시 함.
      ) {
        const bodyObj = {
          success: true,
          data: {
            authInfo: null,
            userId: userInfo._id,
            initChangePassword: true,
          },
        };
        if (userInfoObj.hasOwnProperty('changePasswordDate')) {
          bodyObj.data.initChangePassword = userInfoObj.changePasswordDate <= 0;
        }
        ctx.status = 200;
        ctx.body = bodyObj;

        return;
      }
    } else if (deviceType === 'win32' && (!userInfo.mfa || !userInfo.mfa.isVerified)) {
      // PC로 최초로그인 하는 경우에 본인인증 단계로 보내기위한 처리
      const bodyObj = {
        success: true,
        data: {
          authInfo: null,
          userId: userInfo._id,
          initChangePassword: true,
        },
      };
      if (userInfoObj.hasOwnProperty('changePasswordDate')) {
        bodyObj.data.initChangePassword = userInfoObj.changePasswordDate <= 0;
      }
      ctx.status = 200;
      ctx.body = bodyObj;

      return;
    }

    const [
      {
        accessToken,
        refreshToken,
      },
      policyVersion,
    ] = await Promise.all([
      issueToken({
        tenantFlag,
        userId,
        deviceId,
        deviceType,
        versionInfo,
        role: userInfo['role'] ?? 'user',
      }),
      policyVersionModel({tenantFlag}).findOne({}),
    ]);

    // [성능튜닝] 하기 소스는 성능향상을 위해 수정됨.
    const signInfos = await userSignModel({tenantFlag}).find({parentUser: userId}).select('_id');

    const originArr = JSON.stringify(userInfo.childSignInfos.sort());
    // string Object -> Object으로 변환하여 childSignInfos 저장
    const newArr = signInfos.map((si: any) => si._id).sort();
    const newArrStr = JSON.stringify(newArr);

    if (originArr !== newArrStr) {
      await targetUserModel.updateOne({_id: userId}, {
        childSignInfos: newArr,
      });
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        userId,
        accessToken,
        refreshToken,
        role: userInfo['role'] ?? 'user',
        policyVersion: userInfo.agreePrivacyPolicyVersion === policyVersion.version ? '' : policyVersion.version,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
    };
  }
};

export default issueJWT;
