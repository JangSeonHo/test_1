import Koa from 'koa';
import userSignModel from 'models/account/user_sign_info';
import userStatusInfoModel from 'models/account/user_status_info';
import {UserStatusCode} from '../../../../constants/commonConstants';

const revokeJWT = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const headers = ctx.headers;
    const accessToken = headers['access-token'] as string ?? '';
    const deviceType = headers['device-type'] as string ?? '';

    const targetUserSignModel = userSignModel({tenantFlag});
    // await targetUserSignModel.updateOne({
    //   accessToken,
    // }, {
    //   'sendStream': true,
    // });
    const targetUser = await targetUserSignModel.findOne({accessToken})
      .select('parentUser');
    if (deviceType === 'android' || deviceType === 'ios') {
      await userStatusInfoModel({tenantFlag}).updateMany({
        parentUser: targetUser.parentUser,
      }, {
        mobileStatus: UserStatusCode.OFFLINE,
      });
    } else if (deviceType === 'win32' || deviceType === 'macos') {
      await userStatusInfoModel({tenantFlag}).updateMany({
        $and: [{
          parentUser: targetUser.parentUser,
        }, {
          $or: [{pcStatus: UserStatusCode.ONLINE}, {pcStatus: 'online'}, {pcStatus: UserStatusCode.AWAY}, {pcStatus: null}],
        }]}, {
        $set: {pcStatus: UserStatusCode.OFFLINE},
      });
    } // iPad는 사용자 상태 변경과 무관함.

    // ********* [성능튜닝] 아래 로직과 동일 소스 제거 *********
    await targetUserSignModel.deleteOne({
      accessToken,
    });


    ctx.status = 200;
    ctx.body = {'success': true};
  } catch (err) {
    console.log(err);
  }
};

export default revokeJWT;
