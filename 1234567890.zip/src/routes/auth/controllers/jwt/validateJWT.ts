import Koa from 'koa';
import policyVersionModel from 'models/system/policy_version';
import userInfoModel from 'models/account/user_info';

// client에서 success인지 아닌지만 체크. policyVersion, password 등 체크 안 함 
const validateJWT = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const role = ctx.response.get('role');
    const userId = ctx.response.get('userId');

    const policyVersion = await policyVersionModel({tenantFlag}).findOne({});
    const userInfo: any = await userInfoModel({tenantFlag})
      .findOne({_id: userId})
      .select('lastLoginDate');

    const currentDate = new Date().getTime();
    let lastLoginDate = userInfo.lastLoginDate || currentDate;

    const shouldChangePassword =
      currentDate - lastLoginDate > (90 * 24 * 60 * 60 * 1000);

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        role,
        userId,
        policyVersion: policyVersion.version,
        shouldChangePassword,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default validateJWT;
