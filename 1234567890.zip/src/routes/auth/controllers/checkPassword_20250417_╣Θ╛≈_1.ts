/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';

import getHashedPassword from 'utils/account/getHashedPassword';
import validatePassword from 'utils/account/validatePassword';
import {decryptBodyParams} from '../../../utils/cipher';
import {ENCKEYFORPARAM} from '../../../constants/commonConstants';
import isNewerOrEqualVersion from 'utils/account/getClientVersionCompare';

const NEW_VERSION_INFO = '0.5.95';

const checkPassword = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const body: any = ctx.request.body;

    const versionInfo = (ctx.headers['version-info'] as string) ?? '';
    const deviceType = (ctx.headers['device-type'] as string) ?? '';
    console.log('[checkPassword][versionInfo] >>>>>>>>>>>>', versionInfo);
    console.log('[checkPassword][deviceType] >>>>>>>>>>>>', deviceType);

    const isNewVersion = isNewerOrEqualVersion(versionInfo, NEW_VERSION_INFO);
    console.log('[checkPassword][isNewVersion] >>>>>>>>>>>>', isNewVersion);

    let {userId, password, encParam}: {
      userId: string, password: string, encParam: string
    } = body;

    if (!!encParam) {
      const decryptRes = decryptBodyParams(encParam, ENCKEYFORPARAM);

      if (!decryptRes.success) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'error': 'permission denied',
        };
        return;
      }
      userId = decryptRes.params['userId'];
      password = decryptRes.params['password'];
    }

    userId = userId ?? ctx.response.get('userId');
    const targetUserModel = userInfoModel({tenantFlag});
    const userInfo = await targetUserModel.findOne({_id: userId})
      .select('_id passwordSalt hashedPassword');

    if (userInfo === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'permission denied',
      };

      return;
    }

    // [M-2] 패스워드 정책 관리 - LG유플러스 모의해킹 결과 - 보완 조치.
    if (!validatePassword(password)) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Password must include at least two of the following: letters, numbers, special characters.',
      };
      return;
    }


    const hashedPassword: string = getHashedPassword(password, userInfo.passwordSalt);
    const isCorrectPassword = userInfo.hashedPassword === hashedPassword;

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        checkPassword: isCorrectPassword,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {'success': false, 'error': 'internal server error'};
  }
};

export default checkPassword;
