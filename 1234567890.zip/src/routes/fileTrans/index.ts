/* eslint-disable max-len */
import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

import Router from '@koa/router';
const router = new Router();

import fileUpload from './controllers/fileUpload';
router.put('/fileUpload', fileUpload);

import fileStreamUpload from './controllers/fileStreamUpload';
router.put('/fileStreamUpload', isLoggedIn, fileStreamUpload);

export default router;
