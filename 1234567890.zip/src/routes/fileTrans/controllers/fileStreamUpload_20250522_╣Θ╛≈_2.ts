import Koa from 'koa';
import { s3Bucket } from 'configs/s3';
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const getRawBody = require('raw-body');

// ✅ AWS 인증 정보 직접 하드코딩
const REGION = "ap-northeast-2";
const s3Client = new S3Client({
  region: REGION,
});

const DEFAULT_LENGTH = 30 * 1024 * 1024;

const fileStreamUpload = async (ctx: Koa.Context) => {
  try {
    // ✅ key는 query → 없으면 header에서 받고 디코딩 처리 (한글 등 허용)
    let key = ctx.query.key as string;
    if (!key) {
      const rawKey = ctx.headers['key'];
      key = typeof rawKey === 'string' ? decodeURIComponent(rawKey) : '';
    }

    if (!key) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: "Missing 'key' (query or header)",
      };
      return;
    }

    console.log("[fileTrans][fileStreamUpload][key] >>>", key);

    const contentType = ctx.headers['content-type'] || 'application/octet-stream';
    const rawLength = ctx.headers['content-length'];
    const contentLength = rawLength ? parseInt(rawLength as string, 10) : DEFAULT_LENGTH;

    // ✅ binary 파일 바디 읽기 - 실제 전달되는 파일.
    const body = await getRawBody(ctx.req, {
      length: contentLength,
      limit: '100mb',
    });

    // ✅ S3 업로드
    const command = new PutObjectCommand({
      Bucket: s3Bucket,
      Key: key,
      Body: body,
      ContentType: contentType,
      ContentLength: body.length,
    });

    await s3Client.send(command);

    ctx.status = 200;
    ctx.body = {
      success: true,
      message: `fileStreamUpload - Uploaded OK...!!!`,
    };
  } catch (err) {
    console.error('[fileStreamUpload][ERROR]', err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'fileStreamUpload internal server error',
    };
  }
};

export default fileStreamUpload;
