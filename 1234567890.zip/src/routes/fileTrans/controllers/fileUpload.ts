import Koa from 'koa';
import Router from '@koa/router';
import {s3Bucket} from 'configs/s3';
const {S3Client, GetObjectCommand, PutObjectCommand} = require('@aws-sdk/client-s3');
const getRawBody = require('raw-body');

const REGION = "ap-northeast-2";
const s3Client = new S3Client({ region: REGION });

const DEFAULT_LENGTH = 30 * 1024 * 1024;

const fileUpload = async (ctx: Koa.Context) => {
  try {
    const contentType = ctx.headers['content-type'] || 'application/octet-stream';
    const rawLength = ctx.headers['content-length'];
    const contentLength = rawLength ? parseInt(rawLength as string, 10) : DEFAULT_LENGTH;

    const {key} = ctx.request.body;

    console.log("[fileTrans][fileUpload][key]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ", key);

    //const tenantFlag = ctx.response.get('tenantFlag');
    //const userId = ctx.response.get('userId');


    // const body = await getRawBody(ctx.req, {
    //   length: contentLength,
    //   limit: '100mb',
    // });

    // const command = new PutObjectCommand({
    //   Bucket: s3Bucket,
    //   Key: key,
    //   Body: body,
    //   ContentType: contentType,
    //   ContentLength: body.length,
    // });

    // await s3Client.send(command);

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'message': `fileUpload - Uploaded OK...!!!`
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default fileUpload;
