import Router from '@koa/router';
import updateWorkingStatus from '../../controllers/hrws/updateWorkingStatus';
import getToken from '../../controllers/hrws/getToken';

interface Employee {
  user_id: string;      // Login Id
  attend: string;       // 근태 정보
  attend_code?: string; // 근태 코드 (optional)
}

interface UpdateWorkingStatusRequest {
  company_code: string;     // 회사 코드 
  date: string;            // 파일 전송 시간
  employee_count: string;  // 임직원 인원 수 
  token: string;          // JWT Bearer Token
  employee: Employee[];    // 근태 임직원 리스트
}

const router = new Router();

router.use(async (ctx, next) => {
  const start = Date.now();
  console.log(`[HRWS] Request started: ${ctx.method} ${ctx.url}`);
  
  try {
    await next();
    
    const ms = Date.now() - start;
    console.log(`[HRWS] Request completed: ${ctx.method} ${ctx.url} - ${ms}ms`);
  } catch (error) {
    const ms = Date.now() - start;
    console.error(`[HRWS] Request failed: ${ctx.method} ${ctx.url} - ${ms}ms`, error);
    throw error;
  }
});

router.post<UpdateWorkingStatusRequest>('/workingStatus', updateWorkingStatus);
router.post('/getToken', getToken);

export default router; 
