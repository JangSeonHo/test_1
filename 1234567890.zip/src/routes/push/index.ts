/* eslint-disable max-len */
import Router from '@koa/router';

const router = new Router();

import sendMsg from './controllers/sendMsg';
import sendMsg2 from './controllers/sendMsg2';
import getSendResult from './controllers/getSendResult';
import getSendResultDetail from './controllers/getSendResultDetail';

router.post('/sendMsg', sendMsg);
router.post('/sendMsg2', sendMsg2);
router.post('/getSendResult', getSendResult);
router.post('/getSendResultDetail', getSendResultDetail);

export default router;
