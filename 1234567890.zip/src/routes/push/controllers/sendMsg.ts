/* eslint-disable max-len */
import Koa from 'koa';
import admin from 'firebase-admin';
import axios from 'axios';

// @ts-ignore
import Pushy from 'pushy';
const { ObjectId } = require('mongodb');

import pushAuthTokenInfoModel from 'models/push/push_auth_token_info';
import companyCompanyInfoModel from 'models/company/company_company_info';
import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';
import userAlarmModel from 'models/alarm/alarm';
import systemAlarmInfoModel from 'models/push/system_alarm_info';
import systemAlarmUserModel from 'models/push/system_alarm_user';
import userBadgeModel from 'models/account/user_badge';
import multer from '@koa/multer';
const fs = require("fs");

const mongoose = require("mongoose");

const { PutObjectCommand, S3Client } = require("@aws-sdk/client-s3");
const REGION = "ap-northeast-2";
const s3Client = new S3Client({ region: REGION });


//aws s3 Bucket info
const s3Bucket =
  process.env.STATE_ENV === "dev"
    ? "nmp-s3-file-dev"
    : process.env.STAGE_ENV === "stg"
      ? "nmp-s3-file-stg"
      : "nmp-s3-file-prd";

//aws cdn host info
const cdnHost = process.env.STATE_ENV === 'dev' ?
  'https://dev-file.lgmtalk.com/' :
  process.env.STAGE_ENV === 'stg' ?
    'https://stg-file.lgmtalk.com/' :
    'https://file.lgmtalk.com/';


/*
-------------------------------------------------------------
■ 알림톡 알림서비스 등록 정보
-------------------------------------------------------------
서비스 ID : 2400105696
API ServerName : mTalk
API 인증 토큰 :  5I0uE5LbZ7aTY4WDw08LeA==
-------------------------------------------------------------
*/

//2025.03.13 테스트 배포 로그....

// Multer 설정 (메모리에 저장)
const upload = multer({ storage: multer.memoryStorage() });

const TENANT_FLAG = "tenantFlag";
const AUTH_TOKEN = "auth-token";
const TALK_SERVICE_ID = "2400105696";
const SEND_SYSTEM_ALARM = "system_alarm";
const SEND_TYPE_FCM = "FCM";
const SEND_TYPE_SMS = "SMS";
const SEND_TYPE_LMS = "LMS";
const SEND_TYPE_PUSHYME = "PUSHYME";
const SMS_URL = "https://talkapi.lgcns.com/request/sms.json";
const LMS_URL = "https://talkapi.lgcns.com/request/lms.json";
const MSG_SUCCESS = "success";
const MSG_OK = "OK";
const MSG_FAIL = "FAIL";
const MSG_ERROR = "error";
const MSG_FCM_ERROR_INFO = "messaging/registration-token-not-registered";
const RESULT_CODE_SUCCESS = "0000";
const RESULT_CODE_SERVER_ERROR = "0500";
const RESULT_CODE_SERVER_ERROR_MSG = "internal server error";
const SEDNDER_PHONE_NUMBER_NO = "1661-9066";
const FILE_ATTACH_DESC = "[메신저 알림센터에서 첨부파일 확인]";
const LG_DISPLAY_COMPNAY_CODE = "GUC007";

//pushy.me - api key
const pushyAPI = new Pushy('431b11499e3ade8f0df11896c8d8c4a1cfabd60c7f77241ac24fd80fde32fc68');

// client package
// ===>>> com.lgcns.mtalk(사용안함)
// ===>>> 기존 쓰던것을 쓰도록 한다고 정해짐.2025.02.25, com.lgcns.newucap.demo


const sendMsg = async (ctx: Koa.Context) => {
  try {
    const reqIp: string = ctx.request.ip ?? '';
    const tenantFlag = ctx.response.get(TENANT_FLAG);
    const authToken = ctx.headers[AUTH_TOKEN] ?? ctx.query.authToken;

    const {companyCode, title, message, sender} = ctx.request.body;

    let budalMode = ctx.request.body.budalMode === "true" || ctx.request.body.budalMode === true;

    const email = Array.isArray(ctx.request.body.email)
                  ? ctx.request.body.email.map((e: string) => e.toLowerCase())
                  : [ctx.request.body.email.toLowerCase()];

    const attachedFiles = (ctx.request.files ?? {}) as unknown as { [fieldname: string]: multer.File[] };

    const senderMobile = SEDNDER_PHONE_NUMBER_NO;

    const targetSystemAlarmInfoModel = systemAlarmInfoModel({tenantFlag});
    const targetSystemAlarmUserModel = systemAlarmUserModel({tenantFlag});


    //========================================================================================================
    // 회사별 AuthToken정보가 있는지 조회한다. 존재하지 않으면 리턴한다.
    // 0001: authKey mismatch
    //========================================================================================================
    const targetPushAuthTokenInfoModel = pushAuthTokenInfoModel({tenantFlag});
    const resultAuthToken = await targetPushAuthTokenInfoModel.findOne({
      tenantFlag: tenantFlag,
      companyCode: { $eq: companyCode },
      authToken: authToken
    });

    let paramAuthToken;

    // companyCode에 해당하는 authToken 값이 있는지 확인
    if (resultAuthToken && resultAuthToken.authToken) {
      paramAuthToken = resultAuthToken.authToken;
    } else {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0001",
        resultMsg: "authKey mismatch"
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 회사코드 존재여부 조회.
    // 0002: companyCode not found
    //========================================================================================================
    const targetCompanyCompanyInfoModel = companyCompanyInfoModel({ tenantFlag }) as any;
    const company = await targetCompanyCompanyInfoModel.findOne({ companyCode: companyCode }).select("_id companyCode");

    if (!company) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0002",
        resultMsg: "companyCode not found"
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 이메일 파라미터의 값이 없는 경우
    // 0004: email is empty
    //========================================================================================================
    if (!Array.isArray(email) || email.length === 0 || email.every((num) => !num.trim())) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0004",
        resultMsg: "email is empty"
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 이메일 정보가 존재하지 않는 경우 -- 파라미터 email로 변경함. - 2024.11.01
    // 0005: user email does not exist.["이메일", "이메일1", "이메일2", ...,"이메일n"]
    //========================================================================================================
    const targetUserInfoModel = userInfoModel({ tenantFlag });

    // sender
    let actionUser;

    const isEmailFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(sender);

    if (isEmailFormat) {
      // 이메일 형식이면 email 필드로만 조회
      actionUser = await userInfoModel({ tenantFlag })
        .findOne({ email: sender })
        .select('_id email emailId');
    } else {
      // 이메일 아이디 형식이면 parentCompany, emailId로 조회
      actionUser = await userInfoModel({ tenantFlag })
        .findOne({ parentCompany: company._id, emailId: sender })
        .select('_id email emailId');
    }

    let actionUserId = actionUser ? actionUser._id : sender;


    let users: any[] = [];
    let nonExistingEmails: string[] = [];

    // LG Display (예: GUC007)만 유별나게 처리
    if (companyCode === LG_DISPLAY_COMPNAY_CODE) {
      const company = await targetCompanyCompanyInfoModel.findOne(
        { companyCode: LG_DISPLAY_COMPNAY_CODE },
        { _id: 1 }
      ).lean();

      if (company?._id) {
        users = await targetUserInfoModel.find(
          { emailId: { $in: email }, parentCompany: company._id },
          {
            _id: 1,
            email: 1,
            emailId: 1,
            userName: 1,
            personalPhoneNumber: 1,
            parentCompany: 1,
          }
        ).lean();
      } else {
        users = [];
      }

      // 이메일 아이디 기준 비교
      const existingEmails = users.map((user) => user.email || "");
      const existingEmailIds = users.map((user) => user.emailId || "");

      nonExistingEmails = email.filter(
        (e) =>
          !existingEmails.includes(e) &&
          !existingEmailIds.includes(e) &&
          !existingEmails.map((em) => em.split("@")[0]).includes(e)
      );

      // if (nonExistingEmails.length > 0) {
      //   ctx.status = 500;
      //   ctx.body = {
      //     uid: "",
      //     resultCode: "0005",
      //     resultMsg: `[LG Display] This email does not exist for that company. [${nonExistingEmails}]`,
      //   };
      //   return;
      // }
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("");
        console.log(`[push/sendMsg][LG Display (예: GUC007)만 유별나게 처리][존재하지 않는 이메일 계정 또는 이메일 아이디] >>>>>>>>>> nonExistingEmails >>>>> ${nonExistingEmails}`);
        console.log("");
      }
    }

    // 전사 공통 (기존 email 기준만 사용)
    else {
      users = await targetUserInfoModel.find(
        { email: { $in: email } },
        {
          _id: 1,
          email: 1,
          emailId: 1,
          userName: 1,
          personalPhoneNumber: 1,
          parentCompany: 1,
        }
      ).lean();

      const existingEmails = users.map((user) => user.email);

      nonExistingEmails = email.filter((e) => !existingEmails.includes(e));

      // if (nonExistingEmails.length > 0) {
      //   ctx.status = 500;
      //   ctx.body = {
      //     uid: "",
      //     resultCode: "0005",
      //     resultMsg: `This email does not exist. [${nonExistingEmails}]`,
      //   };
      //   return;
      // }
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("");
        console.log(`[push/sendMsg][(기존 email 기준만 사용)][존재하지 않는 이메일 계정 또는 이메일 아이디] >>>>>>>>>> nonExistingEmails >>>>> ${nonExistingEmails}`);
        console.log("");
      }
    }
    //========================================================================================================





    //========================================================================================================
    // 타이틀이 빈값인 경우.
    // 0006: title is empty
    //========================================================================================================
    if (typeof title !== 'string' || !title.trim()) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0006",
        resultMsg: "title is empty"
      };
      return;
    }
    //========================================================================================================




    const getByteLength = (str: string): number => Buffer.byteLength(str, 'utf8');
    //========================================================================================================
    // title 유효성 검사: 길이 제한 (50자 / 100바이트)
    // 0007: title length exceeded
    //========================================================================================================
    if (title.length > 50 || getByteLength(title) > 100) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0007",
        resultMsg: "title length exceeded"
      };
      return;
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 컨텐츠가 빈값인 경우.
    // 0008: content is empty
    //========================================================================================================
    if (typeof message !== 'string' || !message.trim()) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0008",
        resultMsg: "content is empty"
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // content 유효성 검사: 길이 제한 (50자 / 100바이트).
    // 0009: content length exceeded
    //========================================================================================================
    let messageType = "";

    if (message.length <= 40 && getByteLength(message) <= 90) {
      messageType = SEND_TYPE_SMS;
    }else if (message.length > 40 && message.length <= 1000 && getByteLength(message) <= 2000) {
      messageType = SEND_TYPE_LMS;
    }

    if (message.length > 1000 || getByteLength(message) > 2000) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0009",
        resultMsg: "content length exceeded"
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 발신자가 빈값인 경우.
    // 0010: sender is empty
    //========================================================================================================
    if (typeof sender !== 'string' || !sender.trim()) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0010",
        resultMsg: "sender is empty"
      };
      return;
    }
    //========================================================================================================



    //========================================================================================================
    // 부달기능이 true인 경우, senderMobile은 필수 항목이다.
    // 0012: sender mobile is empty
    //========================================================================================================
    if(budalMode){
      if (typeof senderMobile !== 'string' || !senderMobile.trim()) {
        ctx.status = 500;
        ctx.body = {
          uid: "",
          resultCode: "0012",
          resultMsg: "[budalMode === true], sender mobile is empty"
        };
        return;
      }
    }
    //========================================================================================================



    //========================================================================================================
    // 선택 : 첨부된 파일정보가 있을시 유효성 검사 - 사용가능한 이미지 확장자가 아닌 경우
    // 0013: invalid image file exts
    //========================================================================================================
    const allowedExts = ['png', 'jpeg', 'jpg', 'webp', 'bmp']; // 허용 확장자 목록

    if (attachedFiles && Object.keys(attachedFiles).length > 0) {
      for (const fileList of Object.values(attachedFiles)) {
        const files = Array.isArray(fileList) ? fileList : [fileList]; // 파일이 배열이 아니면 배열로 변환

        for (const file of files) {
          const originalFilename = (file as any).originalFilename || file.originalname; // `PersistentFile` 또는 `multer.File` 고려

          if (!originalFilename) {
            ctx.status = 500;
            ctx.body = {
              uid: "",
              resultCode: "0013",
              resultMsg: "invalid image file exts...1"
            };
            return;
          }

          const splits = originalFilename.split('.');
          if (splits.length < 2) {
            ctx.status = 500;
            ctx.body = {
              uid: "",
              resultCode: "0013",
              resultMsg: "invalid image file exts...2"
            };
            return;
          }

          const ext = splits[splits.length - 1].toLowerCase();
          if (!allowedExts.includes(ext)) {
            ctx.status = 500;
            ctx.body = {
              uid: "",
              resultCode: "0013",
              resultMsg: `invalid image file exts...3 (${ext})`
            };
            return;
          }
        }
      }
    }
    //========================================================================================================




    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //
    // START - FCM, Pusy.me, 문자(SMS, LMS)
    //
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

    const targetUserAlarmModel = userAlarmModel({tenantFlag});
    const targetUserSignInfoModel = userSignInfoModel({ tenantFlag });

    let finalResults: any[] = [];

    let totalCount = 0;
    let successCount = 0;
    let failCount = 0;
    let delayCount = 0;




    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // UserInfo 데이터 가져오기
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    let userinfos: any[] = [];

    //LG Display만 유별나게...
    if (companyCode === LG_DISPLAY_COMPNAY_CODE) {
      const company = await targetCompanyCompanyInfoModel.findOne({ companyCode: LG_DISPLAY_COMPNAY_CODE }, { _id: 1 }).lean();

      if (company?._id) {
        userinfos = await targetUserInfoModel.find(
          { emailId: { $in: email }, parentCompany: company._id, },
          { _id: 1, userName: 1, email: 1, emailId: 1, personalPhoneNumber: 1, jobTitle: 1,}
        ).lean();
      } else {
        userinfos = [];
      }
    }
    //기존 전사공통
    else {
      userinfos = await targetUserInfoModel.find(
        { email: { $in: email }, },
        { _id: 1, userName: 1, email: 1, emailId: 1, personalPhoneNumber: 1, jobTitle: 1, }
      ).lean();
    }
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("");
      console.log(`[push/sendMsg][budalMode === FALSE][FCM]푸시전송 >>>>>>>>>> userinfos >>>>> ${JSON.stringify(userinfos)}`);
      console.log("");
    }

    const userIds = userinfos.map(user => user._id);
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[push/sendMsg] userIds >>>> ${userIds}`);
    }

    // nmp_user_sign_info에 유효한 토큰 정보가 있는지 확인한다.
    const userSignInfos = await targetUserSignInfoModel.find({
      parentUser: { $in: userIds },
      deviceType: { $regex: /^(android|ios|ipad)$/i },
      usePushAlarm: true,
      pushToken: { $exists: true, $ne: '' }
    }).select('parentUser deviceType pushToken isChina').lean();
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("[push/sendMsg] nmp_user_sign_info에 유효한 토큰 정보가 있는지 확인한다. >>>>>>>>>>>>>>>>>>>>>> " + JSON.stringify(userSignInfos));
    }

    userinfos.forEach(user => {
      // 해당 사용자의 signInfo 데이터를 찾음
      const signInfo = userSignInfos.find(sign => String(sign.parentUser) === String(user._id));

      // signInfo가 있는 경우 deviceType과 pushToken 필드를 user에 추가
      if (signInfo) {
        user.deviceType = signInfo.deviceType;
        user.pushToken = signInfo.pushToken;
        user.isChina = signInfo.isChina;
      } else {
        user.deviceType = null;
        user.pushToken = null;
        user.isChina = null;
      }
    });
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[push/sendMsg] userinfos >>>> ${JSON.stringify(userinfos)}`);
    }

    totalCount = userinfos.length;


    // 결과를 저장할 배열
    const results: {
      mobile: string,
      status: string,
      response?: any,
      userId?: string,
      userEmail?: string,
      pushToken?: string,
      sendType?: string
    }[] = [];


    const tempInactiveUsers: {email: string}[] = [];
    const tempInactiveUserMobile: {mobileNo: string}[] = [];

    const tempSuccessUsers: {email: string}[] = [];
    const tempSuccessUserMobile: {mobileNo: string}[] = [];

    //-----------------------------------------------------------------------------------------------------
    //알림발송 컬렉션에 정보 저장 - 모든 전송 작업이 끝난 후 사용자에 대한 전송결과 업데이트 한다.
    //시스템 알림 API 결과 정보 저장.
    //-----------------------------------------------------------------------------------------------------
    const companyId = await targetCompanyCompanyInfoModel.findOne({ companyCode: companyCode }).select("_id");

    const systemDivision = await targetPushAuthTokenInfoModel.findOne({companyCode: companyCode, authToken: authToken}).select("_id systemDivision");
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[push/sendMsg] systemDivision >>>> ${systemDivision}`);
    }

    const systemAlarm = new targetSystemAlarmInfoModel({
      parentCompany: companyId._id,
      companyCode: companyCode,
      title: title,
      message: message,
      budalMode: budalMode,
      sender: sender,
      senderMobile: senderMobile,
      sendResultCode: RESULT_CODE_SUCCESS,
      createdAt: new Date().getTime(),
      updatedAt: new Date().getTime(),
      authToken: authToken,
      systemDivision: systemDivision,
    });
    await systemAlarm.save();
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[push/sendMsg][FCM] 알림발송 _id [systemAlarm._id] >>>>> ${systemAlarm._id}`);
    }
    //-----------------------------------------------------------------------------------------------------



    const fileTimestamp = Date.now();

    const generateFileList = (attachedFiles: any): any[] => {
      const basePath = cdnHost+`${companyId._id}/system_alarm/${systemAlarm._id}/images/`;

      return attachedFiles.flatMap((fileList: any) => {
        const files = Array.isArray(fileList) ? fileList : [fileList];

        return files.map((file: any) => ({
          originalName: file.originalFilename || file.originalname,
          fileName: `${file.originalFilename || file.originalname}`,
          path: `${basePath}${file.originalFilename || file.originalname}`,
          size: file.size,
          filePath: file.filepath
        }));
      });
    }


    // attachedFiles를 배열로 변환하여 처리
    const fileArray = Object.values(attachedFiles);
    const attachedFileList = generateFileList(fileArray);
    const parsedAttachedFiles = typeof attachedFileList === "string" ? JSON.parse(attachedFileList) : attachedFileList;


    //-----------------------------------------------------------------------------------------------------
    // 첨부파일 존재할 시 AWS S3 업로드
    //-----------------------------------------------------------------------------------------------------
    //개발자 환경에서는 업로드 안되게 한다. 디비정보도 업데이트 안됨.
    if (process.env.DEVELOPMENT_MODE != 'local') {
      const uploadedFiles: {
        fileName: string;
        originalName: string;
        path: string;
        size: number;
      }[] = [];

      for (const file of parsedAttachedFiles) {
        const keyPath = `${file.originalName}`;
        const key = `${company._id}/system_alarm/${systemAlarm._id}/images/${keyPath}`;

        // 파일 데이터가 없으면 파일 경로에서 직접 읽기
        const fileData = file.buffer || fs.readFileSync(file.filePath);

        const command = new PutObjectCommand({
          Bucket: s3Bucket,
          Key: key,
          Body: fileData,
        });

        await s3Client.send(command, {
          onUploadProgress: (progress: { loaded: number; total?: number }) => {
            console.log(
              `[sendMsg] System Alarm >>> Uploading file ${file.originalName}: ${progress.loaded} / ${progress.total ?? 'Unknown Total'}`
            );
          },
        });

        uploadedFiles.push({
          fileName: file.originalName,
          originalName: file.originalName,
          path: `${cdnHost}${key}`,
          size: file.size
        });
      }

      //알림발송 컬렉션에 정보 - 첨부파일 정보 업데이트
      const systemAlarmFile = await targetSystemAlarmInfoModel.updateOne(
        {_id : systemAlarm._id},
        {$set : {attachedFiles: parsedAttachedFiles}}
      );
    }
    //-----------------------------------------------------------------------------------------------------



    //--------------------------------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------------------------------
    // 각 사용자에 대해 푸시 메시지 생성 및 전송
    //--------------------------------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------------------------------------------------------

    // 전송 완료된 번호
    const sentMobileSet = new Set<string>();

    // 전송 중인 번호 → 동시에 두 명이 진입하지 않도록 잠금용
    const sendingMobileSet = new Set<string>();


    const sendPromises = userinfos.map(async (user) => {
      if(user.pushToken === null || user.pushToken === ""){
        tempInactiveUsers.push(user.emailId);

        // 중복된 전화번호가 없을 때만 추가
        if (!tempInactiveUserMobile.some(userMobile => userMobile === user.personalPhoneNumber)) {
          tempInactiveUserMobile.push(user.personalPhoneNumber);
        }
      }

      let { deviceType, pushToken, isChina, _id, email, personalPhoneNumber } = user;

      //---------------------------------------------------------------------------------
      // nmp_user_alarm 컬렉션에 정보 저장
      //---------------------------------------------------------------------------------
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[push/sendMsg][nmp_user_alarm 컬렉션에 정보 저장] >>>>>> ${email} ::: ${_id} ::: ${actionUserId} ::: ${title}`);
      }

      //시스템 알림 정보 저장.(앱에서 확인)
      const userAlarm = new targetUserAlarmModel({
        type: SEND_SYSTEM_ALARM,
        parentUser: _id,
        content: message,
        isRead: false,
        createdAt: new Date().getTime(),
        parentSystemAlarm: systemAlarm._id,
        title: title,
      });
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("[push/sendMsg][userAlarm]>>>>>>>>>>>>>>>>>> ,", userAlarm);
      }

      // actionUserId가 ObjectId이면 actionUser 필드를 추가합니다.
      if (mongoose.Types.ObjectId.isValid(actionUserId)) {
        userAlarm.actionUser = actionUserId;
      }

      //시스템 알림정보 저장시, 배지 카운트 증가한다.
      const TargetUserBadgeModel = userBadgeModel({tenantFlag});
      const [savedUserAlarm] = await Promise.all([
        userAlarm.save(),
        TargetUserBadgeModel.updateOne({parentUser: user._id}, {
          $inc: {unreadAlarms: 1},
        }),
      ]);
      //---------------------------------------------------------------------------------


      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      //FCM 전송
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      if(!isChina){
        //pushToken이 존재할때만 수행한다.
        if(user.pushToken != null && user.pushToken != ""){
          // notification 기본 설정
          const notification = {
            title: title,
            body: message,
          };

          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log("");
            console.log("[push/sendMsg][FCM] savedUserAlarm._id.toString() >>>>> ", savedUserAlarm._id.toString());
            console.log("");
          }

          // FCM 메시지 생성
          const msg: any = {
            data: {
              type: SEND_SYSTEM_ALARM,
              id: savedUserAlarm._id.toString(),
              ...notification,
              badge: "0",
              content: message,
              createdAt: savedUserAlarm.createdAt.toString(),
            },
            token: pushToken,
          };

          // Android용 메시지 설정
          if (deviceType === 'android') {
            msg.android = {
              priority: 'HIGH',
            };
          }

          // iOS용 메시지 설정
          if (['ios', 'ipad'].includes(deviceType?.toLowerCase?.())) {
            msg.notification = notification;
            msg.apns = {
              payload: {
                aps: {
                  sound: 'default',
                  badge: 0,
                  content: message,
                  createdAt: savedUserAlarm.createdAt,
                },
              },
            };
          }

          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log("");
            console.log(`[push/sendMsg][FCM][msg] >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> `, msg);
            console.log("");
          }

          try {
            const response = await admin.messaging().send(msg);
            successCount++;

            tempSuccessUsers.push({ email: user.emailId });

            // 중복되지 않는 경우만 추가
            if (!tempSuccessUserMobile.some(m => m.mobileNo === user.personalPhoneNumber)) {
              tempSuccessUserMobile.push({ mobileNo: user.personalPhoneNumber });
            }

            await targetUserAlarmModel.updateOne(
              { _id: savedUserAlarm._id },
              { $set: { systemAlarmDivision: 'fcm', systemAlarmDevice: deviceType } },
            );

            if (process.env.DEVELOPMENT_MODE === 'local') {
              console.log(`[push/sendMsg][FCM] Firebase response Send OK >>>>>> ${email} ::: ${response}`);
              console.log(`[push/sendMsg][FCM] Firebase response Send OK [pushToken] >>>>>> ${successCount} ::: ${pushToken}`);
            }

            // 전송 성공 결과 저장
            results.push({
              mobile: personalPhoneNumber,
              status: MSG_SUCCESS,
              response: response,
              userId: String(_id),
              userEmail: email,
              pushToken: pushToken,
              sendType: SEND_TYPE_FCM
            });

          } catch (err) {
            console.error(err);
            if(user.pushToken != null && user.pushToken != ""){
              failCount++;
            }
            const error = err as { errorInfo?: { code: string } };

            if (error.errorInfo?.code === MSG_FCM_ERROR_INFO) {
              if (process.env.DEVELOPMENT_MODE === 'local') {
                console.log(`[ERROR][push/sendMsg][FCM][user._id] ${email} , ${_id} ::: Invalid token: ${pushToken}, skipping...`);
              }
              // 유효하지 않은 토큰에 대한 실패 결과 저장
              if(user.pushToken != null && user.pushToken != ""){
                results.push({
                  mobile: personalPhoneNumber,
                  status: "failed",
                  response: "Invalid token",
                  userId: String(_id),
                  userEmail: email,
                  pushToken: pushToken,
                  sendType: SEND_TYPE_FCM
                });
              }
            } else {
              if (process.env.DEVELOPMENT_MODE === 'local') {
                console.log(`[ERROR][push/sendMsg][FCM][user._id] ${email} , ${_id} ::: Unexpected error >>>> `,String(err));
              }
              // 다른 오류에 대한 실패 결과 저장
              if(user.pushToken != null && user.pushToken != ""){
                results.push({
                  mobile: personalPhoneNumber,
                  status: MSG_ERROR,
                  response: String(err),
                  userId: String(_id),
                  userEmail: email,
                  pushToken: pushToken,
                  sendType: SEND_TYPE_FCM
                });
              }
            }
          }
        }
      }

      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      //pushy.me 전송
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      else if(isChina){
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log("[push/sendMsg] pushy.me 발송은 pushy.me SDK로 생성된 토큰 정보를 가지고 해야한다. 즉, 클라이언트에 라이브러리 설치되고, 해당 pushy.me 토큰을 업데이트 하는 프로세스가 필요하다.")
          console.log(`[push/sendMsg][pushy.me].......PUSHY.ME 발송을 한다.................................`);
        }

        // Insert target device token(s) here
        const toToken = [pushToken];

        // Set push payload data to deliver to device(s)
        const data = {
          message: message,
          title: title,
          body: message,
          type: SEND_SYSTEM_ALARM,
          id: savedUserAlarm._id.toString(),
          badge: "0",
          content: message,
          createdAt: savedUserAlarm.createdAt.toString(),
        };

        // Set optional push notification options (such as iOS notification fields)
        const options = {
          notification: {
            badge: 0,
            sound: 'default',
            title: title,
            body: message,
            category: '',           // Optional
            loc_key: '',            // Optional
            loc_args: [],           // Optional
            title_loc_key: '',      // Optional
            title_loc_args: [],     // Optional
            interruption_level: 'active', // Must be one of: "passive", "active", "time-sensitive", "critical"
            message: message,
            id: savedUserAlarm._id.toString(),
            content: message,
            createdAt: savedUserAlarm.createdAt.toString(),
            type: SEND_SYSTEM_ALARM,
          },
        };

        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log("[시스템알림][pushy.me][data] >>>>>>>> ", data);
          console.log("[시스템알림][pushy.me][optionsoptions] >>>>>>>> ", options);
        }

        try {
          const pushPromise = new Promise((resolve, reject) => {
            if (process.env.DEVELOPMENT_MODE === 'local') {
              console.log(`[push/sendMsg][pushy.me] data ::: ${JSON.stringify(data)}`);
              console.log(`[push/sendMsg][pushy.me] options ::: ${JSON.stringify(options)}`);
              console.log(`[push/sendMsg][pushy.me] token ::: ${toToken}`);
            }
            pushyAPI.sendPushNotification(data, toToken, options, function (err, id) {
              if (err) {
                reject(err);
              } else {
                resolve(id);
              }
            });
          });

          const pushId = await pushPromise;
          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log(`[push/sendMsg][pushy.me] Push sent successfully! (ID: ${JSON.stringify(pushId)} - ${toToken})`);
            console.log('[push/sendMsg] savedUserAlarm._id >>>> ', savedUserAlarm._id, typeof savedUserAlarm._id);
          }
          successCount++;

          tempSuccessUsers.push({ email: user.emailId });

          // 중복되지 않는 경우만 추가
          if (!tempSuccessUserMobile.some(m => m.mobileNo === user.personalPhoneNumber)) {
            tempSuccessUserMobile.push({ mobileNo: user.personalPhoneNumber });
          }


          // _id의 타입에 따라 처리
          let alarmId;
          if (typeof savedUserAlarm._id === 'string') {
            try {
              alarmId = new ObjectId(savedUserAlarm._id);
            } catch (e) {
              console.error('[ERROR][push/sendMsg][pushy.me] Invalid ObjectId format:', savedUserAlarm._id, e);
            }
          } else if (savedUserAlarm._id instanceof ObjectId) {
            alarmId = savedUserAlarm._id;
          } else {
            console.error('[ERROR][push/sendMsg][pushy.me] Unsupported _id type:', typeof savedUserAlarm._id);
          }

          const updateResult = await targetUserAlarmModel.updateOne(
            { _id: alarmId },
            { $set: { systemAlarmDivision: 'pushy.me', systemAlarmDevice: deviceType } },
          );

          // 전송 성공 결과 저장
          results.push({
            mobile: personalPhoneNumber,
            status: MSG_SUCCESS,
            response: "PUSHY.ME Success Response",
            userId: String(_id),
            userEmail: email,
            pushToken: pushToken,
            sendType: SEND_TYPE_PUSHYME
          });

        }catch(err){
          failCount++;
          console.error('[ERROR][push/sendMsg][ushy.me][catch~error] ::: ', err);

          const error = err as { code: string; error?: string };
          const errorString = `code: ${error.code}, error: ${error.error || 'N/A'}`;

          results.push({
            mobile: personalPhoneNumber,
            status: 'PUSHY.ME ERROR',
            response: errorString,
            userId: String(_id),
            userEmail: email,
            pushToken: pushToken,
            sendType: SEND_TYPE_PUSHYME
          });
        }
      }

      const byteLength = getByteLength(message);
      const charLength = message.length;

      let url = "";
      let conditionStr = "";
      let isLMS = false;
      let userMobile = user.personalPhoneNumber?.trim();


      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      // 문자발송
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      // budalMode === true 이면서, nmp_user_sign_infos에 정보가 없으면 문자(SMS, LMS)를 보낸다.
      // 현재, nmp_user_sign_infos에 정보가 없으면, 앱 미설치자로 한다.
      if(budalMode && (user.pushToken === null || user.pushToken === "")){
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[push/sendMsg][SMS/LMS]...문자 발송을 한다.......... >>>> ${JSON.stringify(user)}`);
        }

        // 전송 완료 or 전송 중이면 생략
        if (sentMobileSet.has(userMobile) || sendingMobileSet.has(userMobile)) {
          successCount++;

          tempSuccessUsers.push({ email: user.emailId });

          // 중복되지 않는 경우만 추가
          if (!tempSuccessUserMobile.some(m => m.mobileNo === user.personalPhoneNumber)) {
            tempSuccessUserMobile.push({ mobileNo: user.personalPhoneNumber });
          }

          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log(`[push/sendMsg][SMS/LMS] 중복 문자 생략 >>> ${userMobile}`);
          }
          results.push({
            mobile: userMobile,
            status: MSG_SUCCESS,
            response: "이미 발송된 번호 - 중복 문자 생략 >>>> "+userMobile,
            userId: String(user._id),
            userEmail: user.email,
            pushToken: "",
            sendType: "SKIPPED"
          });
          return;
        }

        // 전송 중으로 설정
        sendingMobileSet.add(userMobile);


        // 메시지 길이에 따라 API 구분
        if (charLength <= 40 && byteLength <= 90) {
          url = SMS_URL;
          conditionStr = SEND_TYPE_SMS;
        } else if (charLength <= 1000 && byteLength <= 2000) {
          url = LMS_URL;
          conditionStr = SEND_TYPE_LMS;
          isLMS = true; // LMS 발송 여부 플래그 설정
        } else {
          results.push({ mobile: "", status: MSG_ERROR, response: "메시지가 너무 깁니다." });
          return results;
        }


        try {
          //첨부파일이 있는 경우와 없는 경우.
          let finalMessage = attachedFiles && Object.keys(attachedFiles).length > 0
          ? `${message}\n${FILE_ATTACH_DESC}`
          : `${message}`;

          // 요청 바디 생성 (LMS일 때만 subject 포함)
          const requestBody: any = {
            service: TALK_SERVICE_ID,
            message: finalMessage,
            mobile: userMobile,
            callbackNo: senderMobile,
          };

          if (isLMS) {
            requestBody.subject = title; // LMS인 경우 subject 추가
          }
          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log(`[push/sendMsg][budalMode === true] ${requestBody}`);
          }

          const response = await axios.post(url, requestBody, {
            headers: {
              "Content-Type": "application/json",
              "authToken": "5I0uE5LbZ7aTY4WDw08LeA==",
              "serverName": "mTalk",
            },
          });

          if (response.status === 200) {
            successCount++;

            tempSuccessUsers.push({ email: user.emailId });

            // 중복되지 않는 경우만 추가
            if (!tempSuccessUserMobile.some(m => m.mobileNo === user.personalPhoneNumber)) {
              tempSuccessUserMobile.push({ mobileNo: user.personalPhoneNumber });
            }

            sentMobileSet.add(userMobile); // 전송 완료
            if (process.env.DEVELOPMENT_MODE === 'local') {
              console.log("[push/sendMsg][SMS/LMS] 문자 발송 성공 및 Set 등록 >>> ", [...sentMobileSet]);
            }

            await targetUserAlarmModel.updateOne(
              { _id: savedUserAlarm._id },
              { $set: { systemAlarmDivision: conditionStr.toLowerCase()} },
            );

            if (process.env.DEVELOPMENT_MODE === 'local') {
              console.log(`[push/sendMsg][budalMode === true] ${conditionStr} - [${userMobile}] - 문자발송 성공 >>> `, response.data);
            }

            results.push({
              mobile: userMobile,
              status: MSG_SUCCESS,
              response: response.data.uid,
              userId: String(user._id),
              userEmail: user.email,
              pushToken: "",
              sendType: conditionStr
            });

          }else{
            failCount++;
            if (process.env.DEVELOPMENT_MODE === 'local') {
              console.log(`[push/sendMsg][budalMode === true] ${conditionStr} - ${userMobile} - 발송 실패 >>>`, response);
            }

            results.push({
              mobile: userMobile,
              status: "failed",
              response: "failed",
              userId: undefined,
              userEmail: undefined,
              pushToken: "",
              sendType: conditionStr
            });
          }
        }catch(error){
          failCount++;
          console.error(`[push/sendMsg][budalMode === true] ${conditionStr} - ${userMobile} - API 호출 오류 >>>`, error);

          if (axios.isAxiosError(error)) {
            results.push({
              mobile: userMobile,
              status: MSG_ERROR,
              response: error.response?.data || error.message,
              userId: undefined,
              userEmail: undefined,
              pushToken: "",
              sendType: conditionStr
            });
          } else if (error instanceof Error) {
            results.push({
              mobile: userMobile,
              status: MSG_ERROR,
              response: error.message,
              userId: undefined,
              userEmail: undefined,
              pushToken: "",
              sendType: conditionStr
            });
          } else {
            results.push({
              mobile: userMobile,
              status: MSG_ERROR,
              response: String(error),
              userId: undefined,
              userEmail: undefined,
              pushToken: "",
              sendType: conditionStr
            });
          }
        } finally {
          // 전송 끝났으니 중복 방지용 lock 해제
          sendingMobileSet.delete(userMobile);
        }

        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[push/sendMsg][budalMode === true] ${conditionStr} - [ ${userMobile} ] - [ ${user.email} ] >>> END >>>`);
        }
      }


      // budalMode === false 이면서, nmp_user_sign_infos에 정보가 없으면 아무것도 하지 않는다.
      // 현재, nmp_user_sign_infos에 정보가 없으면, 앱 미설치자로 한다.
      if(!budalMode && (user.pushToken === null || user.pushToken === "")){
        failCount++;

        results.push({
          mobile: userMobile,
          status: '0006',
          response: "앱 미설치자(앱 설치후 한번도 로그인 하지 않은 사용자) 또는 로그아웃 한 사용자. 확인 후 budalMode === true인 경우 문자발송이 된다.",
          userId: String(user._id),
          userEmail: user.email,
          pushToken: "",
          sendType: "NON-INSTALLER"
        });
      }


      // 클라이언트와 같이 반영하기로 하자...기능구현은 다 되어 있음.
      //시스템알림 - PC알림 데이타 저장 - 리스너 - PC알림 발생.
      const systemAlarmUser = new targetSystemAlarmUserModel({
        parentSystemAlarm: systemAlarm._id,
        parentUser: _id,
        title: title,
        createdAt: new Date().getTime(),
      });
      await systemAlarmUser.save();

    });
    //--------------------------------------------------------------------------------------------------------------------------------------------

    //--------------------------------------------------------------------------------------------------------------------------------------------
    // 모든 메시지 전송 완료 대기
    //--------------------------------------------------------------------------------------------------------------------------------------------
    await Promise.all(sendPromises);
    //--------------------------------------------------------------------------------------------------------------------------------------------


    // 최종 결과 출력 및 반환
    finalResults = results.map(item => ({
      sendDivision: item.sendType,
      receiveResult: String(item.response),
      receiveUser: new ObjectId(item.userId),
      receiveResultCode: item.status === MSG_SUCCESS ? MSG_OK : MSG_FAIL
    }));
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log('[push/sendMsg][budalMode === FALSE][FCM] finalResults>>>', finalResults);
    }


    //알림발송 컬렉션에 정보 - 사용자 전송결과 정보 업데이트
    await targetSystemAlarmInfoModel.updateOne(
      {_id : systemAlarm._id},
      {$set : {receiveInfo: finalResults}}
    );


    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //
    // END - FCM, Pusy.me, 문자(SMS, LMS)
    //
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★



    let returnCount = {
      totalCount : totalCount,
      successCount : successCount,
      failCount : failCount,
    }

    ctx.status = 200;

    if(budalMode){
      ctx.body = {
        uid : systemAlarm._id,
        resultCode: RESULT_CODE_SUCCESS,
        resultMsg: MSG_SUCCESS,
        returnCount,
        successUsers: tempSuccessUsers.map(u => u.email),
        successUserMobile: tempSuccessUserMobile.map(u => u.mobileNo), //여러명이 하나의 번호를 가지고 있으면, 하나의 번호만 리턴한다.
        inactiveUsers : [],
        inactiveUserMobile : [],
        budalMode: budalMode,
        notExistEmailUsers: nonExistingEmails,
      };
    }
    else{
      ctx.body = {
        uid : systemAlarm._id,
        resultCode: RESULT_CODE_SUCCESS,
        resultMsg: MSG_SUCCESS,
        returnCount,
        successUsers: tempSuccessUsers.map(u => u.email),
        successUserMobile: tempSuccessUserMobile.map(u => u.mobileNo),
        inactiveUsers : Array.from(new Set(tempInactiveUsers)),
        inactiveUserMobile : tempInactiveUserMobile, //여러명이 하나의 번호를 가지고 있으면, 하나의 번호만 리턴한다.
        budalMode: budalMode,
        notExistEmailUsers: nonExistingEmails,
      };
    }

  } catch (err) {
    console.error(err);
    ctx.status = 500;
    ctx.body = {
      uid: "",
      resultCode: RESULT_CODE_SERVER_ERROR,
      resultMsg: RESULT_CODE_SERVER_ERROR_MSG
    };
  }

};



// 문자 메시지의 바이트 길이를 계산하는 함수
function getByteLength(message: string): number {
  let byteLength = 0;
  for (const char of message) {
    // 유니코드 값에 따라 바이트 계산 (이모지와 특수문자 고려)
    const codePoint = char.codePointAt(0) ?? 0;
    if (codePoint <= 0x007f) {
      byteLength += 1; // 아스키 문자 (영어, 숫자 등)
    } else if (codePoint <= 0x07ff) {
      byteLength += 2; // 한글 등 2바이트 문자
    } else {
      byteLength += 3; // 이모지나 복잡한 문자 (UTF-8 최대 4바이트)
    }
  }
  return byteLength;
}



export default sendMsg;