import Koa from 'koa';
import { decrypt_iv, encrypt_iv } from 'utils/cipher';
import mongoose from 'mongoose';
import pLimit from 'p-limit';
import { ecsTaskId } from '../../../server';

const ObjectId = mongoose.Types.ObjectId;

import { GetObjectCommand, DeleteObjectCommand, S3Client } from '@aws-sdk/client-s3';
import {
  getSignedUrl,
} from '@aws-sdk/s3-request-presigner';

import {s3Bucket} from 'configs/s3';

const s3UrlPrefix = process.env.STAGE_ENV === 'dev' ?
  'https://dev-file.lgmtalk.com/' :
  process.env.STAGE_ENV === 'stg' ?
  'https://stg-file.lgmtalk.com/' :
  'https://file.lgmtalk.com/';

// 프로필 이미지 경로에서 S3 Key 추출
function extractS3Key(url: string): string | null {
  if (url.startsWith(s3UrlPrefix)) {
    return url.slice(s3UrlPrefix.length); // S3 Key는 URL에서 도메인 부분을 제외한 나머지 부분
  }
  return null;
}

import companyCompanyModel from 'models/company/company_company_info';
import companyDepartmentModel from 'models/company/company_department_info';
import userSchema from 'models/account/user_info';
import userStatusSchema from 'models/account/user_status_info';
import userBadgeSchema from 'models/account/user_badge';
import userCancelSchema from 'models/account/user_cancel';
import syncSummaryLogModel from 'models/log/sync_summary_log';
import syncErrorLogModel from 'models/log/sync_error_log';
import syncHeaderModel from 'models/log/sync_header_info';
import syncSummarySyncdataLogModel from 'models/log/sync_summary_syncdata_log';
import encryptionKeyModel from 'models/encryption/encryption_key';
import logApiAccessModel from 'models/log/log_api_access';
import userSignModel from 'models/account/user_sign_info';

const REGION = 'ap-northeast-2';
const s3Client = new S3Client({region: REGION});

const TENANT_FLAG = 'nmp';

const syncUser = async (ctx: Koa.Context, ) => {
  try{
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');
    const verificationKey = ctx.headers['verification-key'] ?? ctx.query.verificationKey;

    //========================================================================================================
    // 암복호화 키 및 iv 조회
    //========================================================================================================
    const targetEncryptionKeyModel = encryptionKeyModel({tenantFlag});
    const key = await targetEncryptionKeyModel.findOne({ tenantFlag: tenantFlag });
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("[syncUser][DB 조회 - enc key 및 iv] :::::::::::::::::::::: ", key);
    }

    let paramEncKey;
    let paramIv;

    // encryptionKey와 lv 값이 있는지 확인
    if (key && key.encryptionKey && key.iv) {
      paramEncKey = key.encryptionKey;
      paramIv = key.iv;
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("[syncUser] paramEncKey >>>>>>>>>>>> ", paramEncKey);
        console.log("[syncUser] paramIv >>>>>>>>>>>> ", paramIv);
      }
    } else {
      paramEncKey = '';
      paramIv = '';
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("[syncUser] Encryption key 또는 iv 값을 찾을 수 없습니다.");
      }
    }
    //========================================================================================================


    //========================================================================================================
    // API 호출 권한 체크 - 암호화키의 앞부분 5자리, 뒷부분5자리를 뺀 나머지 정보를 가지고 비교한다.
    //========================================================================================================
    if(verificationKey != paramEncKey.slice(5,-5)){
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': 403,
        'message': 'permission denied',
      };
      return;
    }
    //========================================================================================================


    let createSuccessCounts = 0;
    let updateSuccessCounts = 0;
    let deleteSuccessCounts = 0;
    let createErrorCounts = 0;
    let updateErrorCounts = 0;
    let deleteErrorCounts = 0;


    const targetCompanyCompanyModel = companyCompanyModel({ tenantFlag });
    const targetCompanyDepartmentModel = companyDepartmentModel({ tenantFlag });
    const targetSyncSummaryLogModel = syncSummaryLogModel({ tenantFlag });
    const targetSyncErrorLogModel = syncErrorLogModel({ tenantFlag });
    const targetUserInfo = userSchema({tenantFlag}) as any;
    const targetUserStatus = userStatusSchema({tenantFlag});
    const targetUserBadge = userBadgeSchema({tenantFlag});
    const targetUserCancel = userCancelSchema({tenantFlag});
    const targetSyncHeaderModel = syncHeaderModel({ tenantFlag });
    const targetSyncSummarySyncdataLogModel = syncSummarySyncdataLogModel({ tenantFlag });
    const targetLogApiAccessModel = logApiAccessModel({ tenantFlag });
    const targetUserSignModel = userSignModel({ tenantFlag });

    let { flag, data, fileName, companyCode } = ctx.request.body as any;



    //========================================================================================================
    // 복호화
    //========================================================================================================
    let decoded: string;

    try {
      decoded = decrypt_iv(data, paramEncKey, paramIv);
    } catch (err) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'code': 400,
        'message': 'BROKEN_DATA',
      };
      return;
    }
    //========================================================================================================


    //개행처리를 정규표현식으로 처리한다. \r이 있을수도 없을수도 있다.
    const tempRows = decoded.split(/\r?\n/);

    // 빈 행(공백 또는 엔터만 있는 행) 제거
    const rows = tempRows.filter((row: String) => row.trim() !== '');

    if (rows.length <= 1) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        code: 400,
        message: 'EMPTY_FILE_OR_NO_VALID_DATA',
      };
      return;
    }

    const spliter = rows[0][12];

    const awsEcsTaskId = ecsTaskId?.value || '';

    const summaryLog = new targetSyncSummaryLogModel({
      syncFileName: fileName,
      startedAt: new Date().getTime(),
      transDivision: 'U',
      ecsTaskId: awsEcsTaskId,
      executionDivision: "MANUAL_IF",
    });

    const MAX_SIZE_MB = 14; // 최대 크기 14MB
    const MAX_SIZE_BYTES = MAX_SIZE_MB * 1024 * 1024; // 바이트로 변환

    // data와 decoded의 데이터 크기 계산
    const dataSize = Buffer.byteLength(data, 'utf-8'); // 데이터 크기 계산 (UTF-8 기준)
    const decodedSize = Buffer.byteLength(decoded, 'utf-8');
    const totalSize = dataSize + decodedSize;

    // 데이터 크기 초과 여부 확인
    if (totalSize > MAX_SIZE_BYTES) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[syncUser.ts] 데이타 양이 16MB가 넘어감.>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>`);
      }
      data = '[syncUser.ts] 16MB가 넘어가므로 데이터 저장 안됨';
      decoded = '[syncUser.ts] 16MB가 넘어가므로 데이터 저장 안됨';
    }

    const summarySyncdataLog = new targetSyncSummarySyncdataLogModel({
      createdAt: new Date().getTime(),
      syncEncData: data,
      syncDecData: decoded,
      transDivision: 'U',
      companyCode: companyCode,
      totalCount: rows.length - 1,
      processDivision: 'Y',
      syncFileName: fileName,
    });

    summarySyncdataLog.parentSummary = summaryLog._id;
    await summarySyncdataLog.save();

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'code': 200,
      'message': 'Data was transmitted successfully. Please contact the administrator for the results.',
    };


    // 위의 정보를 response로 보내고, 비동기로 나머지 로직을 처리한다.
    setImmediate(async (): Promise<void> => {
      const users: any[] = [];

      try {
        //헤더 인덱스 정보 추출
        const headerArray = rows[0].split(spliter).map(item => item.toUpperCase());
				rows[0] = headerArray.join(spliter);

				const headerIndex: { [key: string]: number } = {};
				headerArray.forEach((header: string, index: number) => {
					headerIndex[header] = index;
				});
				if (process.env.DEVELOPMENT_MODE === 'local') {
					console.log("[syncUser.ts] headerIndex >>>>>>>>>>>>>>>>> ", headerIndex);
				}

        for (let i = 1; i < rows.length; i++) {
            const cols = rows[i].split(spliter);

            //LGE 콜센터 협력사(GUC060) 이메일정보가 없음.
            let tempEmail = '';
            if (companyCode === 'GUC060') {
              tempEmail = (cols[headerIndex['EMAIL']] || cols[headerIndex['USER_ID']]).trim();
            } else {
                tempEmail = (cols[headerIndex['EMAIL']]).trim();
            }

            //--------------------------------------------------------------------------------------
            // GDPR 관련 : mTalk의 europeCorp 여부 판단
            //--------------------------------------------------------------------------------------
            const locationCode = cols[headerIndex['LOCATION_CODE']];
            const subsidiary = cols[headerIndex['SUBSIDIARY']];
            let tempEuropeCorp = false;

            switch (companyCode) {
              //LG Display
              case 'GUC007':
                  tempEuropeCorp = ['83', '85'].includes(subsidiary);
                  break;
              //LG화학
              case 'GUC005':
                  tempEuropeCorp = ['G260', 'G290', 'G480'].includes(locationCode);
                  break;
              //LG에너지솔루션
              case 'GUC057':
                  tempEuropeCorp = ['G260', 'G290', 'G480'].includes(locationCode);
                  break;
              //LX하우시스
              case 'GUC024':
                  tempEuropeCorp = ['HE01', 'HE02', 'HE03', 'HE04', 'HE05', 'HE06', 'HE07','HE08', 'HE09', 'HE10', 'HE11', 'HE12', 'HE13', 'HE14'].includes(locationCode);
                  break;
              //LG CNS
              case 'GUC006':
                  //LG40(eu), LG41(eu폴란드), LG44(hq폴란드), LG45(그리스)
                  tempEuropeCorp = ['LG40', 'LG41', 'LG44', 'LG45'].includes(locationCode);
                  break;
              //LG Innotek
              case 'GUC021':
                  //LG40(유럽(LGITEU)), LG41(폴란드법인(LGITPO))
                  tempEuropeCorp = ['LG40', 'LG41'].includes(locationCode);
                  break;
              // LX 인터내셔널
              case 'GUC028':
                  // 부서코드(DEPT_ID)가 유럽법인이면 true로 설정
                  tempEuropeCorp = cols[headerIndex['DEPT_ID']] === '301704';
                  break;
              //LX MMA
              case 'GUC013':
                  //LX41(유럽지사 - 독일)
                  tempEuropeCorp = ['LX41'].includes(locationCode);
                  break;
              //LG 전자
              case 'GUC002':
                  // 유럽지사 locationCode 목록
                  tempEuropeCorp = [
                    'EAAH','EAAJ','EAAO','EAAQ','EABH','EABI','EABJ','EABK','EABL','EABQ','EABS','EABT','EABU','EABV','EABW','EABX','EACA','EACM','EACT','EACV',
                    'EADF','EADG','EADM','EADN','EADO','EADP','EADS','EADT','EADU','EADV','EADW','EADX','EAEB','EAEG','EAEH','EAEI','EAFG','EAFI','EZAK','EZAL',
                    'EZAS','EZAT','EZAU','EZBO','EZBP','EZGI','EZGJ','EZGK','EZGL','EZGM','EZGN','EZGO','EZGP','EZGQ','EZGR','EZGS','EZGT','EZHI','EZHJ','EZHK',
                    'EZHL','EZHM','EZHN','EZHO','EZHP','EZHQ','EZHR','EZHS','EZHT','EZHU','EZHV','EZHW','EZHX','EZHY','EZHZ','EZIB','EZIC','EZID','EZIG','EZIH',
                    'EZKD','EZNK','EZNL','EZNM','EZNN','EZNO','EZNP','EZOL','EZOM','EZON','EZOP','EZOQ','EZOR','EZOS','EZPT','EZPU','EZPV','EZPW','EZPX','EZPY',
                    'EZPZ','EZQZ','EZRA','EZRB','EZRC','EZRD','EZRE','EZRF','EZRG','EZRH','EZRI','EZRJ','EZRK','EZRL','EZRM','EZRN','EZRO','EZRP','EZRQ','EZRR',
                    'EZRS','EZRT','EZRU','EZRV','EZRW','EZRX','EZRY','EZRZ','EZSA','EZSB','EZSC','EZSD','EZSE','EZSF','EZSG','EZSH','EZSI','EZSJ','EZSK','EZSL',
                    'EZSM','EZSV','EZSW','EZTT','EZTU','EZUB','EZUC','EZUD','EZUE','EZUF','EZUG'
                  ].includes(locationCode);
                  break;
              //서브원
              case 'GUC054':
                  //P000:폴란드, E000:헝가리
                  tempEuropeCorp = ['P000', 'E000'].includes(locationCode);
                  break;
              //SNI
              case 'GUC061':
                  //P000:폴란드
                  tempEuropeCorp = ['P108'].includes(locationCode);
                  break;
            }
            //--------------------------------------------------------------------------------------

            const userInfo = {
                companyCode: cols[headerIndex['COMPANY_CODE']], // COMPANY_CODE
                departmentCode: cols[headerIndex['DEPT_ID']], // DEPT_ID
                emailId: cols[headerIndex['USER_ID']].trim(), // USER_ID
                userName: {
                    ko: cols[headerIndex['USER_NAME']] || '', // USER_NAME
                    en: headerIndex['USER_NAME_EN'] !== undefined && cols[headerIndex['USER_NAME_EN']]
                        ? cols[headerIndex['USER_NAME_EN']]
                        : cols[headerIndex['USER_NAME']] || '', // USER_NAME_EN fallback to USER_NAME
                },
              jobTitle: {
                    ko: cols[headerIndex['GRADE']] || '', // GRADE
                    en: cols[headerIndex['GRADE_EN']] || '', // GRADE_EN
                },
                siblingOrders: cols[headerIndex['LIST_ORDER']], // LIST_ORDER
                //email: cols[headerIndex['EMAIL']], // EMAIL
                email: tempEmail,
                officePhoneNumber: cols[headerIndex['LINE_NUMBER']] || '', // LINE_NUMBER
                personalPhoneNumber: cols[headerIndex['HP_NUMBER']] || '', // HP_NUMBER
                userType: cols[headerIndex['EMP_TYPE']], // EMP_TYPE
                flag: cols[headerIndex['IF_FLAG']], // IF_FLAG
                europeCorp: tempEuropeCorp, //EUROPE_CORP
                inWorkYn: cols[headerIndex['IN_WORK_YN']] || '', // IN_WORK_YN - 휴직여부(N:휴직, Y or 값이 없으면 재직)
                policyOrgAuthMobile: cols[headerIndex['POLICY_ORG_AUTH_MOBILE']] || '', //모바일에서 조직도 조회여부
                policyOrgAuthPc: cols[headerIndex['POLICY_ORG_AUTH_PC']] || '', //PC버전에서 조직도 조회여부
                empNo: cols[headerIndex['EMP_NO']] || '', //사번
                lineNumberC: cols[headerIndex['LINE_NUMBER_C']] || '',
                hpNumberC: cols[headerIndex['HP_NUMBER_C']] || '',
                policyConfAuth: cols[headerIndex['POLICY_CONF_AUTH']] || '',
                policyMadnAuth: cols[headerIndex['POLICY_MADN_AUTH']] || '',
                policyPstnAuth: cols[headerIndex['POLICY_PSTN_AUTH']] || '',
                inKoreaYn: cols[headerIndex['IN_KOREA_YN']] || '',
                extEmail: cols[headerIndex['EXT_EMAIL']] || '',
                vacationYn: cols[headerIndex['VACATION_YN']] || '',
                mobileUseYn: cols[headerIndex['MOBILE_USE_YN']] || '',
                empCategory: cols[headerIndex['EMP_CATEGORY']] || '',
                policyMsgBoxAuth: cols[headerIndex['POLICY_MSG_BOX_AUTH']] || '',
                policyFileAuthPc: cols[headerIndex['POLICY_FILE_AUTH_PC']] || '',
                policyFileAuthMobile: cols[headerIndex['POLICY_FILE_AUTH_MOBILE']] || '',
                policyFileAuthWeb: cols[headerIndex['POLICY_FILE_AUTH_WEB']] || '',
                location: cols[headerIndex['LOCATION']] || '',
                locationCode: cols[headerIndex['LOCATION_CODE']] || '',
                policyCodeAuth: cols[headerIndex['POLICY_CODE_AUTH']] || '',
                usageStartDate: cols[headerIndex['USAGE_START_DATE']] || '',
                usageEndDate: cols[headerIndex['USAGE_END_DATE']] || '',
                deptName: cols[headerIndex['DEPT_NAME']] || '',
                locationCd: cols[headerIndex['LOCATION_CD']] || '',
                subsidiary: cols[headerIndex['SUBSIDIARY']] || '',
                userNameCn: cols[headerIndex['USER_NAME_CN']] || '',
            };
            users.push(userInfo);
        }
      } catch (err) {
        ctx.status = 400;
        ctx.body = {
          'success': false,
          'code': 400,
          'message': 'BROKEN_FILE',
        };
        return;
      }
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("[syncUser] users.length >>>>>>>>>>>>>> ", users.length);
      }

      let totalCounts = users.length;
      summaryLog.totalCounts = totalCounts;
      await summaryLog.save();

      /*
          as-is : msg_user_info.emp_type , to-be : nmp_user_infos.userType

          ***************************
          *** 임직원 구분
          ***************************

          V : VIP, 임원급 : 이사 이상....CNS 2명.
          R : 정직원

          P : 협력사


          G :
          H : 협력사
          I :
          J :
          M :


          헬로커넥트앤(GUC012)
            L0: 임원
            L1: 정규직원
            L2: 기간제
            L4: 인턴
            L9: 사무식파견
            LZ: 사외사용자


-------------------------
*** 2025년 4월 1일 조회
-------------------------
userType: R - 267575명
userType: V - 736명

userType: L1 - 311명
userType: L2 - 7명
userType: LZ - 30명

userType: H - 33410명
userType: P - 16971명

userType: M - 8681명
userType: G - 2758명
userType: Y - 89명
userType: T - 26명
userType: J - 21명
userType: N - 14명
userType: K - 2명



      */

      let processCount = 0;

      const company = await targetCompanyCompanyModel.findOne({ companyCode: companyCode }).select("_id");

      if (!company) {
        throw Error('[syncUser] NO_COMPANY_DATA Create');
      }


      //프로세스 체크 카운트
      let processChkCount = 0;

      const limit = pLimit(5); // 동시 최대 5개 작업 제한

      const AtomicCounter = {
          processChkCount: 0,
          totalCounts: users.length,
          incrementProcessChkCount() {
            this.processChkCount += 1;
          },
          decrementTotalCounts() {
          this.totalCounts -= 1;
          },
      };

      //조직도 보기권한 무조건 'Y'로 할 회사.
      //[LX MMA, LG재단, AI 연구원]
      const targetCompanyCodes = ['GUC013', 'GUC052', 'GUC058'];

      // 모든 작업을 순차적으로 처리
      for (const user of users) {
        await limit(async () => {
          // 비동기 작업 동기화
          AtomicCounter.incrementProcessChkCount();
          AtomicCounter.decrementTotalCounts();

          try {
            if (user.flag === 'I' || user.flag === 'U') {

              //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
              // LG디스플레이 인 경우, 정직원이면 조직도에서 보이고, !정직원 이면 조직도에서 안보인다.
              // 해당 필드는 조직도에서 안보이게만 한다.
              //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
              //version 0.0.1
              //const policyOrgViewYn = user.companyCode === 'GUC007' ? (['R', 'V'].includes(user.userType) ? 'Y' : 'N') : 'Y';

              //version 0.0.2
              // policy 관련 처리
              let policyOrgViewYn = 'Y';
              let policyOrgAuthMobile = user.policyOrgAuthMobile;
              let policyOrgAuthPc = user.policyOrgAuthPc;

              if (user.companyCode === 'GUC007') {
                // LG디스플레이: 정직원(R, V)만 Y, 나머지 N
                const isRegular = ['R', 'V'].includes(user.userType);
                policyOrgViewYn = isRegular ? 'Y' : 'N';
                policyOrgAuthMobile = isRegular ? 'Y' : 'N';
                policyOrgAuthPc = isRegular ? 'Y' : 'N';
              } else {
                // 그 외 회사: 기존 정책 유지
                policyOrgAuthMobile = targetCompanyCodes.includes(user.companyCode)
                  ? 'Y'
                  : (user.policyOrgAuthMobile ?? undefined);
                policyOrgAuthPc = targetCompanyCodes.includes(user.companyCode)
                  ? 'Y'
                  : (user.policyOrgAuthPc ?? undefined);
              }
              //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

              // 기존에 데이터가 있으면 업데이트, 없으면 신규등록
              const preData = await targetUserInfo.findOne({ emailId: user.emailId.toLowerCase(), parentCompany: company._id });

              // 신규 등록
              if (!preData) {
                try {
                  if (process.env.DEVELOPMENT_MODE === 'local') {
                    console.log(companyCode+" [syncUser][100.신규등록] >>>> Process: " + AtomicCounter.processChkCount, AtomicCounter.totalCounts, totalCounts, user.email.toLowerCase(), user.userName, user.departmentCode, user.empNo);
                  }
                  const pdepartment = await targetCompanyDepartmentModel.findOne({originCode: user.departmentCode, parentCompany: company._id});

                  const newUser = new targetUserInfo({
                    userName: user.userName,
                    jobTitle: user.jobTitle,
                    email: user.email.toLowerCase(),
                    emailId: user.emailId.toLowerCase(),
                    personalPhoneNumber: user.personalPhoneNumber,
                    officePhoneNumber: user.officePhoneNumber,
                    parentDepartment: pdepartment._id,
                    parentGroup: pdepartment.parentGroup,
                    parentCompany: pdepartment.parentCompany,
                    useMessenger: false,
                    profileImage: '',
                    hashedPassword: user.emailId.toLowerCase(),
                    passwordSalt: user.emailId.toLowerCase(),
                    siblingOrders: user.siblingOrders,
                    listOrder: user.siblingOrders,
                    ...( { userType: user.userType !== undefined && user.userType !== null && user.userType !== '' ? user.userType : 'R' } ),
                    europeCorp: user.europeCorp,
                    inWorkYn: user.inWorkYn,

                    //version 0.0.1
                    // ...(targetCompanyCodes.includes(user.companyCode)
                    // ? { policyOrgAuthMobile: 'Y' }
                    // : (user.policyOrgAuthMobile !== undefined && user.policyOrgAuthMobile !== null && user.policyOrgAuthMobile !== ''
                    //   ? { policyOrgAuthMobile: user.policyOrgAuthMobile }
                    //   : {})),
                    // ...(targetCompanyCodes.includes(user.companyCode)
                    // ? { policyOrgAuthPc: 'Y' }
                    // : (user.policyOrgAuthPc !== undefined && user.policyOrgAuthPc !== null && user.policyOrgAuthPc !== ''
                    //   ? { policyOrgAuthPc: user.policyOrgAuthPc }
                    //   : {})),
                    //version 0.0.2
                    ...(policyOrgAuthMobile !== undefined ? { policyOrgAuthMobile } : {}),
                    ...(policyOrgAuthPc !== undefined ? { policyOrgAuthPc } : {}),

                    empNo: user.empNo,
                    policyOrgViewYn: policyOrgViewYn, //조직도에서 보이기/안보이기 옵션값
                    ...(companyCode === 'GUC002' ? { isDeleted: true } : {}),
                    lineNumberC: user.lineNumberC,
                    hpNumberC: user.hpNumberC,
                    policyConfAuth: user.policyConfAuth,
                    policyMadnAuth: user.policyMadnAuth,
                    policyPstnAuth: user.policyPstnAuth,
                    inKoreaYn: user.inKoreaYn,
                    extEmail: user.extEmail,
                    vacationYn: user.vacationYn,
                    mobileUseYn: user.mobileUseYn,
                    empCategory: user.empCategory,
                    policyMsgBoxAuth: user.policyMsgBoxAuth,
                    policyFileAuthPc: user.policyFileAuthPc,
                    policyFileAuthMobile: user.policyFileAuthMobile,
                    policyFileAuthWeb: user.policyFileAuthWeb,
                    location: user.location,
                    locationCode: user.locationCode,
                    policyCodeAuth: user.policyCodeAuth,
                    usageStartDate: user.usageStartDate,
                    usageEndDate: user.usageEndDate,
                    deptName: user.deptName,
                    locationCd: user.locationCd,
                    subsidiary: user.subsidiary,
                    userNameCn: user.userNameCn,
                    createdAt: new Date().getTime(),
                  });

                  const newUserStatus = new targetUserStatus({ statusCode: '', statusString: '', parentUser: newUser._id });
                  const newBadge = new targetUserBadge({ parentUser: newUser._id });
                  newUser.childStatusInfo = newUserStatus._id;

                  await newBadge.save();
                  await newUser.save();
                  await newUserStatus.save();

                  await targetCompanyDepartmentModel.updateOne(
                    { _id: pdepartment._id },
                    { $push: { childUsers: newUser._id } }
                  );
                  await targetCompanyCompanyModel.updateOne(
                    { _id: pdepartment.parentCompany },
                    { $inc: { totalChildUsers: 1 } }
                  );

                  createSuccessCounts += 1;
                } catch (err) {
                  createErrorCounts += 1;

                  if (process.env.DEVELOPMENT_MODE === 'local') {
                    console.log(companyCode+` [syncUser][100.신규등록][error][1] >>> ::: ${AtomicCounter.processChkCount} - ${AtomicCounter.totalCounts} - ${user.email.toLowerCase()} - ${user.departmentCode} - ${company._id}`)
                    console.log(companyCode+" [syncUser][100.신규등록][error][2] >>> ::: ", err);
                  }
                  const errorLog = new targetSyncErrorLogModel({
                    parentLog: summaryLog._id,
                    originData: user,
                    error: `[syncUser][100-EEE.신규등록 처리시 에러 발생함]...${user.email.toLowerCase()} - ${companyCode} - ${user.departmentCode} - ${company._id} :::: `+err,
                    createdAt: new Date().getTime(),
                  });
                  await errorLog.save();
                }
              }
              // 수정 처리
              else {
                if (process.env.DEVELOPMENT_MODE === 'local') {
                  console.log(companyCode+" [syncUser][200.수정처리] >>>> Process: ",AtomicCounter.processChkCount, AtomicCounter.totalCounts, totalCounts, user.email.toLowerCase(), user.userName, user.departmentCode, preData._id, user.inWorkYn, user.empNo);
                }

                const pdepartment = await targetCompanyDepartmentModel.findOne({originCode: user.departmentCode, parentCompany: company._id}).select('_id');

                try {
                  await targetUserInfo.updateOne({_id: preData._id}, {
                    userName: user.userName,
                    jobTitle: user.jobTitle,
                    siblingOrders: user.siblingOrders,
                    listOrder:  user.siblingOrders,
                    ...( { userType: user.userType !== undefined && user.userType !== null && user.userType !== '' ? user.userType : 'R' } ),
                    officePhoneNumber: user.officePhoneNumber,
                    personalPhoneNumber: user.personalPhoneNumber,
                    parentDepartment: pdepartment._id,
                    europeCorp: user.europeCorp,
                    inWorkYn: user.inWorkYn,

                    //version W.0.1
                    //isDeleted: user.inWorkYn === 'N' ? true : false,
                    //version W.0.2
                    ...(companyCode !== 'GUC002' ? { isDeleted: user.inWorkYn === 'N' ? true : false } : {}),

                    //version 0.0.1
                    // ...(user.policyOrgAuthMobile !== undefined && user.policyOrgAuthMobile !== null && user.policyOrgAuthMobile !== ''
                    //   ? { policyOrgAuthMobile: user.policyOrgAuthMobile }
                    //   : {}),
                    // ...(user.policyOrgAuthPc !== undefined && user.policyOrgAuthPc !== null && user.policyOrgAuthPc !== ''
                    //   ? { policyOrgAuthPc: user.policyOrgAuthPc }
                    //   : {}),
                    //version 0.0.2
                    ...(policyOrgAuthMobile !== undefined ? { policyOrgAuthMobile } : {}),
                    ...(policyOrgAuthPc !== undefined ? { policyOrgAuthPc } : {}),

                    empNo: user.empNo,
                    policyOrgViewYn: policyOrgViewYn, //조직도에서 보이기/안보이기 옵션값
                    lineNumberC: user.lineNumberC,
                    hpNumberC: user.hpNumberC,
                    policyConfAuth: user.policyConfAuth,
                    policyMadnAuth: user.policyMadnAuth,
                    policyPstnAuth: user.policyPstnAuth,
                    inKoreaYn: user.inKoreaYn,
                    extEmail: user.extEmail,
                    vacationYn: user.vacationYn,
                    mobileUseYn: user.mobileUseYn,
                    empCategory: user.empCategory,
                    policyMsgBoxAuth: user.policyMsgBoxAuth,
                    policyFileAuthPc: user.policyFileAuthPc,
                    policyFileAuthMobile: user.policyFileAuthMobile,
                    policyFileAuthWeb: user.policyFileAuthWeb,
                    location: user.location,
                    locationCode: user.locationCode,
                    policyCodeAuth: user.policyCodeAuth,
                    usageStartDate: user.usageStartDate,
                    usageEndDate: user.usageEndDate,
                    deptName: user.deptName,
                    locationCd: user.locationCd,
                    subsidiary: user.subsidiary,
                    userNameCn: user.userNameCn,
                    updatedAt: new Date().getTime(),
                  });

                  await targetCompanyDepartmentModel.updateOne(
                    { _id: pdepartment._id },
                    {
                        $addToSet: { childUsers: preData._id } //중복이 없을 때만 추가(동일한 값이 있으면 추가하지 않는다. $addToSet)
                    }
                  );

                  // 쓰기 작업 후 바로 primary에서 읽기
                  const updatedDepartment = await targetCompanyDepartmentModel.findOne(
                    { _id: pdepartment._id },
                    null,
                    { readPreference: 'primary' } // primary에서 읽기 옵션을 명시
                  );

                  // childUsers의 길이를 확인
                  const totalChildUsersCount = updatedDepartment.childUsers.length;

                  // totalChildUsers 필드를 업데이트
                  await targetCompanyDepartmentModel.updateOne(
                    { _id: pdepartment._id },
                    {
                        $set: { totalChildUsers: totalChildUsersCount } // 배열의 길이에 맞춰 totalChildUsers 필드를 업데이트
                    }
                  );


                  // 부서가 변경되었는지 확인 (이전 부서와 현재 부서가 다른 경우에만 처리)
                  if (pdepartment._id.toString() !== preData.parentDepartment.toString()) {
                    // 이전 부서에서 사용자 ID 제거
                    await targetCompanyDepartmentModel.updateOne(
                        { _id: preData.parentDepartment },
                        {
                            $pull: { childUsers: preData._id } // 이전 부서의 childUsers 배열에서 제거
                        }
                    );

                    // 이전 부서의 totalChildUsers 업데이트
                    const previousDepartment = await targetCompanyDepartmentModel.findOne(
                        { _id: preData.parentDepartment },
                        null,
                        { readPreference: 'primary' } // primary에서 읽기
                    );

                    const previousTotalChildUsersCount = previousDepartment.childUsers.length;

                    await targetCompanyDepartmentModel.updateOne(
                        { _id: preData.parentDepartment },
                        {
                            $set: { totalChildUsers: previousTotalChildUsersCount } // 이전 부서의 totalChildUsers 업데이트
                        }
                    );
                  }

                  updateSuccessCounts += 1;
                } catch (err) {
                  updateErrorCounts += 1;

                  if (process.env.DEVELOPMENT_MODE === 'local') {
                    console.log(companyCode+` [syncUser][200.수정처리][error][1] >>> ::: ${AtomicCounter.processChkCount} - ${AtomicCounter.totalCounts} - ${user.email.toLowerCase()} - ${user.userName} - ${user.departmentCode}}`)
                    console.log(companyCode+" [syncUser][200.수정처리][error][2] >>> ::: ", err);
                  }

                  // 에러난 데이터는 db에 별도 저장
                  const errorLog = new targetSyncErrorLogModel({
                    parentLog: summaryLog._id,
                    originData: user,
                    error: `[syncUser][200-EEE.수정처리시 에러 발생함] - ${companyCode} ${preData.parentDepartment} -  ${company._id} - ${user.departmentCode} - ${user.userName} - ${user.email.toLowerCase()} :::: `+err,
                    createdAt: new Date().getTime(),
                  });
                  await errorLog.save();
                }
              }
            }
             //삭제 처리
             else if (user.flag === 'D') {
              if (process.env.DEVELOPMENT_MODE === 'local') {
                console.log(companyCode+" [syncUser][300.삭제처리] >>>> START >>>>>>>>>> ", user.email.toLowerCase(), company._id);
              }
              try {
                  //삭제할 사용자 조회
                  const deleteUser = await targetUserInfo.findOne({emailId: user.emailId.toLowerCase(), parentCompany: company._id});


                  if(deleteUser){
                    if (process.env.DEVELOPMENT_MODE === 'local') {
                      console.log(companyCode+" [syncUser][300.삭제처리] >>>> ", AtomicCounter.processChkCount, AtomicCounter.totalCounts, totalCounts, user.email.toLowerCase(), user.userName, user.departmentCode, deleteUser._id, user.empNo);
                    }
                    try{
                      // 프로필 이미지 삭제
                      if (deleteUser && deleteUser.profileImage) {
                        const s3Key = extractS3Key(deleteUser.profileImage);

                        if (s3Key) {
                            const deleteCommand = new DeleteObjectCommand({
                              Bucket: s3Bucket,
                              Key: s3Key,
                            });

                            try {
                                await s3Client.send(deleteCommand);

                                const currentTime = new Date().toLocaleString('ko-KR', {
                                  year: 'numeric',
                                  month: 'long',
                                  day: 'numeric',
                                  hour: 'numeric',
                                  minute: 'numeric',
                                  second: 'numeric',
                                });
                                if (process.env.DEVELOPMENT_MODE === 'local') {
                                  console.log(companyCode+` [syncUser][300.삭제처리][AWS S3 Remove] ::: ${user.email.toLowerCase()} - ${currentTime} - ${s3Key} - 프로필 이미지가 삭제되었습니다.`);
                                }
                            } catch (err) {
                              console.log(err);
                            }
                        } else {
                            if (process.env.DEVELOPMENT_MODE === 'local') {
                              console.warn(companyCode+` [syncUser][300.삭제처리][AWS S3 Remove] ::: ${user.email.toLowerCase()} - Invalid profile image URL::::::::::::::::::::::`);
                            }
                        }
                      }
                      else{
                        if (process.env.DEVELOPMENT_MODE === 'local') {
                            console.warn(companyCode+` [syncUser][300.삭제처리][AWS S3 Remove] ::: ${user.email.toLowerCase()} - 프로필 이미지가 없습니다.`);
                        }
                      }
                    }catch(err){
                      console.warn(companyCode+` [syncUser][300-EEEEEEE.삭제처리][AWS S3 Remove][프로필 이미지 삭제] ::: ${user.email.toLowerCase()} - try~catch ERROR ::: `+err);
                    }

                    //사용자해지 디비에 들어갈 정보 설정
                    const uc = new targetUserCancel({
                      parentUser: deleteUser._id,
                      originData: deleteUser.toObject(),
                      createdAt: new Date().getTime(),
                      willCancelAt: new Date().getTime() + (1000 * 60 * 60 * 24 * 90),
                    })

                    //사용자정보 업데이트(개인정보항목 빈값으로 업데이트, isDeleted:true로 업데이트)
                    await targetUserInfo.updateOne({_id: deleteUser._id}, {
                      isDeleted: true, //삭제여부 true로 업데이트
                      inWorkYn: 'N', //삭제처리시 휴직(N)으로 업데이트 한다. (Y 또는 빈값이거나 널이면 재직)
                      realDeleted: true, //실제 삭제처리 대상으로 간주함. 퇴사자를 체크할때 해당조건의 값을 사용한다. realDeleted === true이면 퇴사자.
                      userName: {ko: '', en: ''}, //성명
                      jobTitle: {ko: '', en: ''}, //직급
                      hashedPassword: '', //비밀번호
                      passwordSalt: '', //비밀번호 Salt
                      email: '', //이메일
                      emailId: '', //이메일 ID
                      personalPhoneNumber: '', //휴대전화번호
                      officePhoneNumber: '', //사내전화번호
                      profileImage: '', //프로필 이미지 경로 정보
                      parentCompany: null, //소속회사
                      parentDepartment: null, //소속부서
                      empNo: '', //사번
                      deletedAt: new Date().getTime(),
                    });
                    if (process.env.DEVELOPMENT_MODE === 'local') {
                      console.log(companyCode+` [syncUser][300.삭제처리] ::: ${deleteUser._id} - ${user.email.toLowerCase()} - 사용자정보(nmp_user_infos) 업데이트(개인정보항목 빈값으로 업데이트, isDeleted:true로 업데이트) ...................`);
                    }

                    //사용자 해지정보 저장
                    await uc.save();


                    //사용자 배지정보 삭제
                    await targetUserBadge.deleteMany({parentUser : deleteUser._id});
                    if (process.env.DEVELOPMENT_MODE === 'local') {
                      console.log(companyCode+` [syncUser][300.삭제처리] ::: ${user.email.toLowerCase()} - 사용자 배지정보(nmp_user_badges) 삭제 ...................`);
                    }


                    //사용자 상태정보 삭제
                    await targetUserStatus.deleteMany({parentUser : deleteUser._id});
                    if (process.env.DEVELOPMENT_MODE === 'local') {
                      console.log(companyCode+` [syncUser][300.삭제처리] ::: ${user.email.toLowerCase()} - 사용자 상태정보(nmp_user_status_infos) 삭제 ...................`);
                    }


                    //사용자가 속해있던 부서에서 해당 사용자 정보를 제거한다.(사용자 ID제거 - 부서정보에는 개인정보 항목 없음.)
                    await targetCompanyDepartmentModel.updateOne({originCode: user.departmentCode, parentCompany: company._id}, {
                      $pull: {
                        childUsers: deleteUser._id,
                      }
                    });
                    if (process.env.DEVELOPMENT_MODE === 'local') {
                      console.log(companyCode+` [syncUser][300.삭제처리] ::: ${user.email.toLowerCase()} - 사용자가 속해있던 부서(nmp_company_department_infos)에서 해당 사용자 정보를 제거한다.(사용자 ID제거 - 부서정보에는 개인정보 항목 없음.) ...................`);
                    }

                    //사용자가 속해있던 부서의 totalChildUsers값 업데이트
                    const department = await targetCompanyDepartmentModel.findOne(
                      { originCode: user.departmentCode, parentCompany: company._id },
                      null,
                      { readPreference: 'primary' } // primary에서 읽기
                    );

                    const totalChildUsersCount = department.childUsers.length;

                    await targetCompanyDepartmentModel.updateOne(
                        { originCode: user.departmentCode, parentCompany: company._id },
                        {
                            $set: { totalChildUsers: totalChildUsersCount } // 부서의 totalChildUsers 업데이트
                        }
                    );
                    if (process.env.DEVELOPMENT_MODE === 'local') {
                      console.log(companyCode+` [syncUser][300.삭제처리] ::: ${user.email.toLowerCase()} - 사용자가 속해있던 부서(nmp_company_department_infos)의 totalChildUsers값 업데이트 ...................${totalChildUsersCount}`);
                    }


                    //사용자가 속해있던 회사의 totalChildUser값 업데이트
                    const result = await targetCompanyDepartmentModel.aggregate([
                      {
                        $match: { parentCompany: company._id }
                      },
                      {
                        $group: {
                          _id: null,
                          totalChildUsers: { $sum: { $size: { $ifNull: ["$childUsers", []] } } }
                        }
                      }
                    ]);

                    const companyTotalChildUsers = result.length > 0 ? result[0].totalChildUsers : 0;

                    // 회사의 totalChildUsers 업데이트
                    await targetCompanyCompanyModel.updateOne(
                      { _id: company._id },
                      { $set: { totalChildUsers: companyTotalChildUsers } }
                    );
                    if (process.env.DEVELOPMENT_MODE === 'local') {
                      console.log(companyCode+` [syncUser][300.삭제처리] ::: ${user.email.toLowerCase()} - 사용자가 속해있던 회사(nmp_company_company_infos)의 totalChildUsers값 업데이트 ...................${companyTotalChildUsers}`);
                    }



                    //로그인 기록, IP Address 삭제
                    await targetLogApiAccessModel.deleteMany({userId : deleteUser._id.toString()});
                    if (process.env.DEVELOPMENT_MODE === 'local') {
                      console.log(companyCode+` [syncUser][300.삭제처리] ::: ${user.email.toLowerCase()} - (nmp_log_api_accesses) 로그인 기록, IP Address 삭제 ...................`);
                    }


                    //디바이스 타입, 디바이스 ID 삭제
                    await targetUserSignModel.deleteMany({parentUser : deleteUser._id});
                    if (process.env.DEVELOPMENT_MODE === 'local') {
                      console.log(companyCode+` [syncUser][300.삭제처리] ::: ${user.email.toLowerCase()} - 인증정보(nmp_user_sign_infos) 디바이스 타입, 디바이스 ID 삭제 ...................`);
                    }


                    //사용자 개인 대화내용 삭제(???????) - 미정...




                    //사용자 해지정보 - 3개월 지난 정보 삭제.
                    //await removeUserCancelInfoCore();
                    //if (process.env.DEVELOPMENT_MODE === 'local') {
                      //console.log(`[syncUser] ::: 사용자 해지정보 - 3개월 지난 정보 삭제. ...................`);
                    //}




                    //대화내용 삭제 - 3개월 지난 정보 삭제 - 우선 주석으로 막음.
                    //await removeChattingMessageCore();




                    deleteSuccessCounts += 1;
                  }else{
                    if (process.env.DEVELOPMENT_MODE === 'local') {
                      console.log(companyCode+" [syncUser][300-222222.삭제처리][삭제할 사용자가 존재하지 않습니다. >>>>>>>", user.emailId.toLowerCase(), user.email.toLowerCase(), company._id);
                    }
                  }
              } catch (err) {
                  if (process.env.DEVELOPMENT_MODE === 'local') {
                    console.log(companyCode+` [syncUser][300-99999.삭제처리][에러발생함] >>>>>>> ${user.email.toLowerCase()} - ${company._id} :::: ${err}`);
                  }

                  deleteErrorCounts += 1;

                  // 에러난 데이터는 db에 별도 저장
                  const errorLog = new targetSyncErrorLogModel({
                    parentLog: summaryLog._id,
                    originData: user,
                    error: `[syncUser][300-99999.삭제처리][에러발생함] >>>>>>> ${companyCode} ${user.email.toLowerCase()} - ${company._id} :::: ${err}`,
                    createdAt: new Date().getTime(),
                  });
                  await errorLog.save();
              }
            }
          } catch (err) {
            if (process.env.DEVELOPMENT_MODE === 'local') {
              console.log(`[syncUser][try~catch error] 작업 처리 중 에러 >>>>>>>>>>>>>>>> ::: ${err}`);
            }
          }
        });
      }

      //최종적으로 회사의 totalChildUsers값을 다시 한번 총 업데이트 한다.
      //회사의 totalChildUsers 업데이트 - 해당 회사의 사용자(nmp_user_infos) isDeleted = false인 갯수.
      await targetCompanyCompanyModel.findOne({ companyCode: companyCode })
      .then(async (company) => {
          // totalChildUsers 카운트
          const userCount = await targetUserInfo.countDocuments({
            parentCompany: company._id,
            isDeleted: false
          });

          // totalChildDepartments와 totalChildUsers 업데이트
          return targetCompanyCompanyModel.updateOne(
            { _id: company._id },
            {
                $set: {
                    totalChildUsers: userCount
                }
            }
          );
      })
      .then(() => {
          if (process.env.DEVELOPMENT_MODE === 'local') {
              console.log(`${companyCode} >>> [syncUser][900-사용자 작업마무리 완료...최종적으로 회사의 totalChildUsers 값을 다시 한번 총 업데이트 완료...]`);
          }
      })
      .catch((err) => {
          if (process.env.DEVELOPMENT_MODE === 'local') {
              console.log(`${companyCode} ::: [syncUser][900-EEE.최종적으로 회사의 totalChildUsers 값 업데이트 에러].....${err}`);
          }
      });

      ctx.status = 200;
      ctx.body = {
        'success': true,
        'code': 200,
        'message': 'It was processed successfully.',
      };

      summaryLog.endedAt = new Date().getTime();
      summaryLog.successCounts = {
        create: createSuccessCounts,
        update: updateSuccessCounts,
        delete: deleteSuccessCounts,
      };
      summaryLog.errorCounts = {
        create: createErrorCounts,
        update: updateErrorCounts,
        delete: deleteErrorCounts,
      };

      const duration = (summaryLog.endedAt - summaryLog.startedAt) / 1000; // 초 단위 변환

			await targetSyncSummaryLogModel.updateOne(
				{ _id: summaryLog._id },
				{
					$set: {
						successCounts: summaryLog.successCounts,
						errorCounts: summaryLog.errorCounts,
						endedAt: summaryLog.endedAt,
						duration: duration,
					},
				}
			);

    });

  }catch(err){
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'code': 500,
      'message': 'internal server error',
    };
  }
};

export default syncUser;