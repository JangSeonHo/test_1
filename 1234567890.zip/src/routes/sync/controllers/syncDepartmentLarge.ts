import Koa from 'koa';
import { decrypt_iv, encrypt_iv } from 'utils/cipher';
import mongoose from 'mongoose';
import pLimit from 'p-limit';

const ObjectId = mongoose.Types.ObjectId;

import companyCompanyModel from 'models/company/company_company_info';
import companyDepartmentModel from 'models/company/company_department_info';
import syncSummaryLogModel from 'models/log/sync_summary_log';
import syncErrorLogModel from 'models/log/sync_error_log';
import syncHeaderModel from 'models/log/sync_header_info';
import syncSummarySyncdataLogModel from 'models/log/sync_summary_syncdata_log';
import {json} from 'express';
import encryptionKeyModel from 'models/encryption/encryption_key';

const syncDepartment = async (ctx: Koa.Context) => {
	try {
		const userId = ctx.response.get('userId');
		const tenantFlag = ctx.response.get('tenantFlag');
		const verificationKey = ctx.headers['verification-key'] ?? ctx.query.verificationKey;

		//========================================================================================================
		// 암복호화 키 및 IV 조회
		//========================================================================================================
		const targetEncryptionKeyModel = encryptionKeyModel({tenantFlag});
		const key = await targetEncryptionKeyModel.findOne({ tenantFlag: tenantFlag });

		if (process.env.DEVELOPMENT_MODE === 'local') {
			console.log("[syncDepartment][DB 조회 - enc key 및 IV] :::::::::::::::::::::: ", key);
		}

		let paramEncKey;
		let paramIv;

		// encryptionKey와 IV 값이 있는지 확인
		if (key && key.encryptionKey && key.iv) {
			paramEncKey = key.encryptionKey;
			paramIv = key.iv;
			if (process.env.DEVELOPMENT_MODE === 'local') {
				console.log("[syncDepartment] paramEncKey >>>>>>>>>>>> ", paramEncKey);
				console.log("[syncDepartment] paramIv >>>>>>>>>>>> ", paramIv);
			}
		} else {
			paramEncKey = '';
			paramIv = '';
			if (process.env.DEVELOPMENT_MODE === 'local') {
				console.log("[syncDepartment] Encryption key 또는 iv 값을 찾을 수 없습니다.");
			}
		}
    //========================================================================================================



		//========================================================================================================
		// API 호출 권한 체크 - 암호화키의 앞부분 5자리, 뒷부분5자리를 뺀 나머지 정보를 가지고 비교한다.
		//========================================================================================================
		if (process.env.DEVELOPMENT_MODE === 'local') {
     	console.log('[syncDepartment] 3KJTKTKDLXTBE1MK25AY3I');
     	console.log("[syncDepartment] verificationKey >>> ",verificationKey);
     	console.log("[syncDepartment] paramEncKey.slice(5,-5) >>> ", paramEncKey.slice(5,-5));
		}
		if(verificationKey != paramEncKey.slice(5,-5)){
			ctx.status = 403;
			ctx.body = {
				'success': false,
				'code': 403,
				'message': 'permission denied',
			};
			return;
		}
		//========================================================================================================

		let createSuccessCounts = 0;
		let updateSuccessCounts = 0;
		let deleteSuccessCounts = 0;
		let createErrorCounts = 0;
		let updateErrorCounts = 0;
		let deleteErrorCounts = 0;


		const targetCompanyCompanyModel = companyCompanyModel({ tenantFlag });
		const targetCompanyDepartmentModel = companyDepartmentModel({ tenantFlag });
		const targetSyncSummaryLogModel = syncSummaryLogModel({ tenantFlag });
		const targetSyncErrorLogModel = syncErrorLogModel({ tenantFlag });
		const targetSyncHeaderModel = syncHeaderModel({ tenantFlag });
		const targetSyncSummarySyncdataLogModel = syncSummarySyncdataLogModel({ tenantFlag });

		let { flag, data, fileName, companyCode } = ctx.request.body as any;


		//========================================================================================================
		// 복호화
		//========================================================================================================
		let decoded: string;

		try {
			decoded = decrypt_iv(data, paramEncKey, paramIv);
		} catch (err) {
			ctx.status = 400;
			ctx.body = {
				'success': false,
				'code': 400,
				'message': 'BROKEN_DATA',
			};
			return;
		}
		//========================================================================================================



		//개행처리를 정규표현식으로 처리한다. \r이 있을수도 없을수도 있다.
		const tempRows = decoded.split(/\r?\n/);

		// 빈 행(공백 또는 엔터만 있는 행) 제거
    const rows = tempRows.filter((row: string) => row.trim() !== '');

    if (rows.length <= 1) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        code: 400,
        message: 'EMPTY_FILE_OR_NO_VALID_DATA',
      };
      return;
    }

		const summaryLog = new targetSyncSummaryLogModel({
			syncFileName: fileName,
			startedAt: new Date().getTime(),
			transDivision: 'D',
		});

		const MAX_SIZE_MB = 14; // 최대 크기 14MB
    const MAX_SIZE_BYTES = MAX_SIZE_MB * 1024 * 1024; // 바이트로 변환

    // data와 decoded의 데이터 크기 계산
    const dataSize = Buffer.byteLength(data, 'utf-8'); // 데이터 크기 계산 (UTF-8 기준)
    const decodedSize = Buffer.byteLength(decoded, 'utf-8');
    const totalSize = dataSize + decodedSize;

    // 데이터 크기 초과 여부 확인
    if (totalSize > MAX_SIZE_BYTES) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`데이타 양이 16MB가 넘어감.>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>`);
      }
      data = '16MB가 넘어가므로 데이터 저장 안됨';
      decoded = '16MB가 넘어가므로 데이터 저장 안됨';
    }

		const summarySyncdataLog = new targetSyncSummarySyncdataLogModel({
			createdAt: new Date().getTime(),
			syncEncData: data,
			syncDecData: decoded,
			transDivision: 'D',
			companyCode: companyCode,
			totalCount: rows.length - 1,
			processDivision: 'Y',
			syncFileName: fileName,
		});

		summarySyncdataLog.parentSummary = summaryLog._id;
		await summarySyncdataLog.save();

		ctx.status = 200;
		ctx.body = {
			'success': true,
			'code': 200,
			'message': 'Data was transmitted successfully. Please contact the administrator for the results.',
		};


		// 위의 정보를 response로 보내고, 비동기로 나머지 로직을 처리한다.
		setImmediate(async () => {
			//조직 정보를 담는다.
			const departments = [];

			// 조직 정보와 dept_id, parent_id를 저장할 맵 정의
			const departmentMap = new Map<string, { no: number, dept_id: string, parent_id: string | null }>();

			//프로세스 체크 카운트
			let processChkCount = 0;

			//프로세스 에러체크 카운트
			let processErrorChkCount = 0;

			try {
				//첫행의 COMPANY_CODE에 설정되어 있는 구분자를 전체 구분자로 설정한다. 해당 구분자로 문서의 정보들이 구분되어져 있어야 한다.
				//  으로 정하였다. <0X7f>, 추후 어떤 구분자로 해도 무방하나, 원문데이타와는 별개로 유니크해야 한다. 별도 설정될수 있다. §
				const spliter = rows[0][12];


				// 헤더 문자열은 무조건 대문자로 변경한다.
				const tmpHeaderArray = rows[0].split(spliter);
				const headerString = tmpHeaderArray.map((item: string) => item.toUpperCase());
				rows[0] = headerString.join(spliter);



				//========================================================================================================
				// 헤더 정보 가져오기 ::: 헤더정보를 디비로 관리한다.
				//========================================================================================================
				let headerArray: string[] = rows[0].split(spliter); // rows의 첫 번째 행을 헤더로 사용
				let headerIndex: { [key: string]: number } = {};

				// 헤더 인덱스를 저장할 객체 생성
				headerArray.forEach((header: string, index: number) => {
					headerIndex[header] = index;
				});
				if (process.env.DEVELOPMENT_MODE === 'local') {
					console.log("headerIndex >>>>>>>>>>>>>>>>> ", headerIndex);
				}
				//========================================================================================================




				//========================================================================================================
				// 맵 생성 - 최상위 부서 및 GUC001 예외 처리 포함
				//========================================================================================================

				// Set으로 department 데이터 생성 (dept_id를 빠르게 조회하기 위함)
				const departmentSet = new Set<string>(
					rows.map((row: string) => {
							const cols = row.split(spliter);
							return cols[headerIndex['DEPT_ID']];
					})
				);

				// parent_id가 유효한지 검증하는 함수
				const validateParentId = (parentId: string | null): boolean => {
					if (!parentId) return true; // parent_id가 없는 경우 유효
					return departmentSet.has(parentId); // Set을 사용하여 빠르게 검증
				};

				// departmentMap 생성 (dept_id와 parent_id 매핑)
				let currentNo = 1;
				const departmentMap = new Map<string, { no: number; dept_id: string; parent_id: string | null }>();

				rows.forEach((line: string, index: number) => {
					if (index === 0) return; // 헤더 스킵

					const cols = line.split(spliter);
					const dept_id = cols[headerIndex['DEPT_ID']];
					const parent_id = cols[headerIndex['PARENT_ID']] === '' ? null : cols[headerIndex['PARENT_ID']];
					const company_code = cols[headerIndex['COMPANY_CODE']];

					if (process.env.DEVELOPMENT_MODE === 'local') {
							console.log("rows.forEach , dept_id parent_id >>>>>>>>>>>> ", dept_id, parent_id);
					}

					// GUC001 처리: parent_id를 회사코드로 매핑
					if (company_code === 'GUC001' && parent_id && departmentSet.has(parent_id)) {
							departmentMap.set(dept_id, { no: currentNo++, dept_id, parent_id });
					}
					// 최상위 부서 처리
					else if (
							(parent_id === company_code && !departmentMap.has(dept_id)) || // 기본 최상위 조건
							(company_code === 'GUC001' && dept_id === '00010000') // GUC001 예외 처리
					) {
							departmentMap.set(dept_id, { no: currentNo++, dept_id, parent_id: null });
					}
					// 일반 부서 처리
					else if (validateParentId(parent_id)) {
							departmentMap.set(dept_id, { no: currentNo++, dept_id, parent_id });
					} else {
							// 유효하지 않은 parent_id의 경우 처리 (옵션)
							if (process.env.DEVELOPMENT_MODE === 'local') {
									console.log(`[INVALID_PARENT] Invalid parent_id for dept_id=${dept_id}: parent_id=${parent_id}`);
							}
					}
				});

				if (process.env.DEVELOPMENT_MODE === 'local') {
					console.log("[MAP_GENERATION] departmentMap size:", departmentMap.size);
				}

				//========================================================================================================
				// DFS로 부서 정렬 및 처리
				//========================================================================================================
				// Map으로 rows 데이터를 사전 처리 (dept_id를 키로)
				const rowsMap = new Map<string, string[]>();
				rows.forEach((row, index) => {
					if (index === 0) return; // 헤더 스킵
					const cols = row.split(spliter);
					rowsMap.set(cols[headerIndex['DEPT_ID']], cols);
				});

				// departmentMap에서 parent_id를 기반으로 계층 구조 생성
				const childMap = new Map<string, string[]>(); // 각 parent_id에 연결된 child 목록
				departmentMap.forEach(({ dept_id, parent_id }) => {
					if (!childMap.has(parent_id || 'ROOT')) {
							childMap.set(parent_id || 'ROOT', []);
					}
					childMap.get(parent_id || 'ROOT')?.push(dept_id);
				});

				// DFS로 부서 정렬 및 처리
				const stack: string[] = childMap.get('ROOT') || []; // 최상위 부서부터 시작
				const visitedDepartments = new Set<string>(); // 방문한 부서를 추적
				let processedCount = 0; // 처리된 부서 수
				const totalDepartments = departmentMap.size; // 전체 부서 수

				if (process.env.DEVELOPMENT_MODE === 'local') {
					console.log(`[INIT] Starting department processing. Total departments: ${totalDepartments}`);
					console.log(`[INIT] Initial stack: ${stack.join(', ')}`);
				}

				while (stack.length > 0) {
					const currentDeptId = stack.pop()!;
					if (visitedDepartments.has(currentDeptId)) {
							if (process.env.DEVELOPMENT_MODE === 'local') {
									console.log(`[SKIP] Already visited: dept_id=${currentDeptId}`);
							}
							continue; // 이미 방문한 부서는 스킵
					}
					visitedDepartments.add(currentDeptId);

					// rowsMap에서 데이터 가져오기
					const cols = rowsMap.get(currentDeptId);
					if (cols) {
							departments.push({
									companyCode: cols[headerIndex['COMPANY_CODE']],
									departmentCode: cols[headerIndex['DEPT_ID']],
									parentDepartmentCode: cols[headerIndex['PARENT_ID']] === '' ? null : cols[headerIndex['PARENT_ID']],
									departmentName: {
											ko: cols[headerIndex['DEPT_NAME']],
											en: cols[headerIndex['DEPT_NAME_EN']],
									},
									siblingOrders: cols[headerIndex['LIST_ORDER']],
									flag: cols[headerIndex['IF_FLAG']],
									siblingDepth: cols[headerIndex['LIST_DEPTH']],
									deptType: cols[headerIndex['DEPT_TYPE']],
									locationCode: cols[headerIndex['LOCATION_CODE']],
							});

							processedCount++;
							if (process.env.DEVELOPMENT_MODE === 'local') {
									console.log(`[PROCESS] Processed department: dept_id=${currentDeptId}, parent_id=${cols[headerIndex['PARENT_ID']] || 'ROOT'}`);
									if (processedCount % 1000 === 0) {
											console.log(`[PROGRESS] Processed ${processedCount}/${totalDepartments} departments.`);
									}
							}
					} else {
							if (process.env.DEVELOPMENT_MODE === 'local') {
									console.log(`[MISSING_ROW] Department not found in rows: dept_id=${currentDeptId}`);
							}
					}

					// 스택에 자식 부서 추가
					const children = childMap.get(currentDeptId);
					if (children) {
							stack.push(...children);
							if (process.env.DEVELOPMENT_MODE === 'local') {
									console.log(`[ADD_TO_STACK] Added children of dept_id=${currentDeptId} to stack. Children: ${children.join(', ')}`);
							}
					}
				}

				// 최종 로그
				if (process.env.DEVELOPMENT_MODE === 'local') {
					console.log(`[FINAL_RESULT] Total departments processed: ${processedCount}`);
					console.log(`[FINAL_RESULT] Total departments stored in departments array: ${departments.length}`);
					console.log(`[FINAL_RESULT] Total visited departments: ${visitedDepartments.size}`);
					console.log(`[FINAL_RESULT] Unvisited departments (if any): ${
							totalDepartments - visitedDepartments.size > 0 ? totalDepartments - visitedDepartments.size : 'None'
					}`);
				}
				//========================================================================================================


			} catch (err) {
				const errorLog = new targetSyncErrorLogModel({
					parentLog: summaryLog._id,
					originData: "BROKEN_FILE",
					error: err,
					createdAt: new Date().getTime(),
				});
				await errorLog.save();
			}

			if (process.env.DEVELOPMENT_MODE === 'local') {
				console.log("[syncDepartment] departments.length 로우 갯수 :", departments.length);
			}

			const totalCounts = departments.length;
			summaryLog.totalCounts = totalCounts;
			await summaryLog.save();

			interface DepartmentAttempt {
				depart: typeof departments[0];
				attempts: number;
			}

			const pendingDepartments: DepartmentAttempt[] = departments
			.filter(depart => {
				// 필터링 조건을 강화하여 빈 로우를 포함되지 않게 함.
				return (
					depart &&
					depart.companyCode &&
					depart.departmentCode &&
					depart.parentDepartmentCode &&
					depart.flag &&
					Object.keys(depart).length > 0
				);
			})
			.map(depart => ({ depart, attempts: 0 }));

			if (process.env.DEVELOPMENT_MODE === 'local') {
				console.log("[syncDepartment] pendingDepartments.length 로우 갯수 :", pendingDepartments.length);
			}


			const limit = pLimit(5); // 동시에 최대 5개의 작업만 실행

			//==============================================================================================
			// 조직 정보를 동기적으로 처리하는 기존 로직에 동시 실행 제한 적용
			//==============================================================================================
			async function processPendingDepartments() {
				const errors: any[] = []; // 에러 데이터를 저장할 배열

				while (pendingDepartments.length > 0) {
					const tasks = pendingDepartments.splice(0, 5); // 동시에 처리할 최대 5개의 작업을 꺼냄

					await Promise.all(
						tasks.map(nextDepart =>
							limit(async () => {
								processChkCount = processChkCount + 1;

								if (!nextDepart) {
									if (process.env.DEVELOPMENT_MODE === 'local') {
										console.log("[syncDepartmentCore] processPendingDepartments Complete....!!!!!!!",(processChkCount-1), (totalCounts - processErrorChkCount), processErrorChkCount);
									}
									return; // 아무 작업도 없는 경우 종료
								}

								const { depart, attempts } = nextDepart;

								if (attempts > pendingDepartments.length + 1) {
									createErrorCounts += 1;

									const errorLog = new targetSyncErrorLogModel({
										parentLog: summaryLog._id,
										originData: depart,
										error: `[syncDepartmentCore] Max attempts reached for department: ${depart.departmentCode}`,
										createdAt: new Date().getTime(),
									});
									await errorLog.save();
									return;
								}

								// 최상위 부서는 하지 않는다.
								if (depart.deptType !== 'R') {
									try {
										const company = await targetCompanyCompanyModel.findOne({ companyCode: depart.companyCode }).select('_id');

										if (!company) {
											throw Error('[syncDepartmentCore] NO_COMPANY_DATA Create');
										}

										// 신규등록 및 수정
										if (depart.flag === 'I' || depart.flag === 'U') {
											const preData = await targetCompanyDepartmentModel.findOne({originCode: depart.departmentCode, parentCompany: company._id});

											// 신규등록
											if (!preData) {
												let parentDepart;

												try {
													// parent_id가 DB에 존재하는지 여부 조회
													parentDepart = await targetCompanyDepartmentModel.findOne({originCode: depart.parentDepartmentCode, parentCompany: company._id});

													// 1. parent_id가 deptMap에도 없고, DB에도 없으면 에러 처리
													if ( depart.parentDepartmentCode && !departmentMap.has(depart.parentDepartmentCode) && !parentDepart ) {
														processErrorChkCount = processErrorChkCount + 1;
														if (process.env.DEVELOPMENT_MODE === 'local') {
															console.log('[syncDepartmentCore][100.신규등록 - 에러처리] - [ DeptMap : X] PARENT_ID 없음, parentDB : X  >>>>>>>>>>>>>>>>>>>>>>>>>>>>> ',
																processChkCount,
																processErrorChkCount,
																pendingDepartments.length + 1,
																attempts,
																totalCounts,
																depart.departmentCode,
																depart.parentDepartmentCode,
																company._id,
																createErrorCounts,
															);
														}
														const errorLog = new targetSyncErrorLogModel({
															parentLog: summaryLog._id,
															originData: depart,
															error: `[syncDepartmentCore] Parent department with code ${depart.parentDepartmentCode} not found in both departmentMap and database.`,
															createdAt: new Date().getTime(),
														});

														await errorLog.save();

														createErrorCounts += 1;

														return;
													}

													// 2. parent_id가 deptMap에 있고, DB에 없으면 pendingDepartments에 푸쉬
													if ( depart.parentDepartmentCode && departmentMap.has(depart.parentDepartmentCode) && !parentDepart ) {
														if (process.env.DEVELOPMENT_MODE === 'local') {
															console.log(
																'[syncDepartmentCore][101.신규등록 - pendingDepartments - 대기열에 저장.] - DeptMap : O , parentDB : X >>>>> ',
																processChkCount,
																processErrorChkCount,
																pendingDepartments.length + 1,
																attempts,
																totalCounts,
																depart.departmentCode,
																depart.parentDepartmentCode,
																company._id,
																createErrorCounts,
															);
														}
														pendingDepartments.push({ depart, attempts: attempts + 1 });

														await delay(10);

														return;
													}

													// 3.
													// 3.1 parent_id가 deptMap에 있고, DB에도 있으면 신규 등록 or
													// 3.2 parent_id가 deptMap에는 없고, DB에만 있으면 신규 등록 처리
													if ((depart.parentDepartmentCode && departmentMap.has(depart.parentDepartmentCode) && parentDepart) ||
													    (depart.parentDepartmentCode && !departmentMap.has(depart.parentDepartmentCode) && parentDepart)
													) {
														if (process.env.DEVELOPMENT_MODE === 'local') {
															console.log('[syncDepartmentCore][199.신규등록 - 정상처리] ->>>>>>>>>>>>>>>>>>>>>>>>>>>>> ',
																processChkCount,
																processErrorChkCount,
																pendingDepartments.length + 1,
																attempts,
																totalCounts,
																depart.departmentCode,
																depart.parentDepartmentCode,
																company._id,
																createErrorCounts,
															);
														}
														const parentDepartments = parentDepart? [...parentDepart.parentDepartments, parentDepart._id] : [];

														const newDepart = new targetCompanyDepartmentModel({
															originCode: depart.departmentCode,
															departmentName: depart.departmentName,
															parentGroup: company.parentGroup,
															parentCompany: company._id,
															parentDepartments,
															childDepartments: [],
															childUsers: [],
															totalChildUsers: 0,
															lastModifiedAt: new Date().getTime(),
															siblingOrders: depart.siblingOrders,
															siblingDepth: depart.siblingDepth,
														});

														const updateCompany = {
															$inc: { totalChildDepartments: 1 },
														} as any;

														if (parentDepartments.length === 0) {
															updateCompany['$push'] = {
																childDepartments: newDepart._id,
															};
															await newDepart.save();
															await targetCompanyCompanyModel.updateOne(
																{ _id: company._id },
																updateCompany,
															);
														} else if (parentDepartments.length > 0 && parentDepartments[parentDepartments.length - 1] ) {
															const pd = parentDepartments[parentDepartments.length - 1];
															await newDepart.save();
															await targetCompanyCompanyModel.updateOne(
																{ _id: company._id },
																updateCompany,
															);
															await targetCompanyDepartmentModel.updateOne(
																{ _id: pd },
																{
																	$push: { childDepartments: newDepart._id },
																},
															);
														}


// 														// 새로운 부서 저장
// 														await newDepart.save();

// 														// bulkWrite를 위한 업데이트 작업 준비
// const bulkOperations: any[] = [
//   {
//     updateOne: {
//       filter: { _id: company._id },
//       update: { $inc: { totalChildDepartments: 1 } },
//     },
//   },
// ];

// if (parentDepartments.length === 0) {
//   // 부모 부서가 없는 경우, 회사에 새 부서를 추가
//   bulkOperations[0].updateOne.update['$push'] = { childDepartments: newDepart._id };
// } else if (parentDepartments.length > 0 && parentDepartments[parentDepartments.length - 1]) {
//   // 부모 부서가 있는 경우, 상위 부서에 새 부서를 추가
//   const pd = parentDepartments[parentDepartments.length - 1];
//   bulkOperations.push({
//     updateOne: {
//       filter: { _id: pd },
//       update: { $push: { childDepartments: newDepart._id } },
//     },
//   });
// }

// // bulkWrite 실행
// await targetCompanyCompanyModel.bulkWrite(bulkOperations);

														createSuccessCounts += 1;
													}
												} catch (err) {
													createErrorCounts += 1;

													const errorLog = new targetSyncErrorLogModel({
														parentLog: summaryLog._id,
														originData: depart,
														error:
															err +
															` [syncDepartmentCore][111.신규등록 처리시 에러] >>>>>>>>>>>> departmentCode : ${depart.departmentCode} , parentDepartmentCode : ${depart.parentDepartmentCode}`,
														createdAt: new Date().getTime(),
													});
													await errorLog.save();
												}
											}
											// 수정
											else {
												if (process.env.DEVELOPMENT_MODE === 'local') {
													console.log("[syncDepartmentCore][200.수정처리] >>>>> ", processChkCount, updateErrorCounts, (pendingDepartments.length+1), attempts, totalCounts, depart.departmentCode, depart.parentDepartmentCode, depart.departmentName);
												}
												try {
													const parentDepart = await targetCompanyDepartmentModel.findOne({
														originCode: depart.parentDepartmentCode,
														parentCompany: company._id
													});

													const parentDepartments = parentDepart ? [...parentDepart.parentDepartments, parentDepart._id] : [];

													await targetCompanyDepartmentModel.updateOne({originCode: depart.departmentCode, parentCompany: company._id}, {
														departmentName: depart.departmentName,
														parentDepartments,
														siblingOrders: depart.siblingOrders,
														siblingDepth: depart.siblingDepth,
														lastModifiedAt: new Date().getTime(),
													});

													if (JSON.stringify(parentDepartments) !== JSON.stringify(preData.parentDepartments)) {
														await targetCompanyDepartmentModel.updateOne({_id: parentDepartments[parentDepartments.length - 1]._id}, {
															$push: {
																	childDepartments: preData._id,
																},
														});

														await targetCompanyDepartmentModel.updateOne({_id: preData.parentDepartments[preData.parentDepartments.length - 1]._id}, {
															$pull: {
																	childDepartments: preData._id,
																},
														});
													}

													updateSuccessCounts += 1;
												}catch(err){
													if (process.env.DEVELOPMENT_MODE === 'local') {
														console.log('[syncDepartmentCore][200-EEE.수정처리시 에러] Error during department update:', err);
													}
													updateErrorCounts += 1;

													const errorLog = new targetSyncErrorLogModel({
														parentLog: summaryLog._id,
														originData: depart,
														error: err,
														createdAt: new Date().getTime(),
													});
													await errorLog.save();
												}
											}
										}
										// 삭제
										else if (depart.flag === 'D') {
											if (process.env.DEVELOPMENT_MODE === 'local') {
												console.log("[syncDepartmentCore][300.삭제처리] >>>>> ", processChkCount, (pendingDepartments.length+1), attempts, totalCounts, depart.departmentCode, depart.parentDepartmentCode);
											}
											try {
												const d = await targetCompanyDepartmentModel.findOne({originCode: depart.departmentCode, parentCompany: company._id}).select('_id');

												if(d && d._id){
													await targetCompanyDepartmentModel.updateOne({_id: d._id}, {
														isDeleted: true,
													});

													await targetCompanyDepartmentModel.updateOne({originCode: depart.parentDepartmentCode, parentCompany: company._id}, {
														$pull: {
														childDepartments: d._id,
														}
													});

													deleteSuccessCounts += 1;
												} else {
													deleteErrorCounts += 1;

													if (process.env.DEVELOPMENT_MODE === 'local') {
														console.log(`[syncDepartmentCore][300-EEE.삭제처리시 에러] - 정보가 존재하지 않습니다....${depart.departmentCode} - ${company._id}`);
													}
													const errorLog = new targetSyncErrorLogModel({
														parentLog: summaryLog._id,
														originData: depart,
														error: `[syncDepartmentCore][300-EEE.삭제처리시 에러] - 정보가 존재하지 않습니다....${depart.departmentCode} - ${company._id}`,
														createdAt: new Date().getTime(),
													});
													await errorLog.save();
												}
											}catch(err){
												if (process.env.DEVELOPMENT_MODE === 'local') {
													console.log('[syncDepartmentCore] Error during department delete:', err);
												}
												deleteErrorCounts += 1;

												const errorLog = new targetSyncErrorLogModel({
													parentLog: summaryLog._id,
													originData: depart,
													error: `${err} ::: [syncDepartmentCore][300-EEE.삭제처리시 에러].....${depart.departmentCode} - ${company._id}`,
													createdAt: new Date().getTime(),
												});
												await errorLog.save();
											}
										}
									} catch (err) {
										if (process.env.DEVELOPMENT_MODE === 'local') {
											console.log('[syncDepartmentCore] ---- Error processing department:', err);
										}
										const errorLog = new targetSyncErrorLogModel({
											parentLog: summaryLog._id,
											originData: depart,
											error: err+` ::: [syncDepartmentCore] ---- Error processing department - 면밀히 살펴볼것...!!!`,
											createdAt: new Date().getTime(),
										});
										await errorLog.save();
									}
								}
							}),
						),
					);
				}
			}

			await processPendingDepartments();

			function delay(ms: number) {
				return new Promise(resolve => setTimeout(resolve, ms));
			}
			summaryLog.endedAt = new Date().getTime();
			summaryLog.successCounts = {
				create: createSuccessCounts,
				update: updateSuccessCounts,
				delete: deleteSuccessCounts,
			};
			summaryLog.errorCounts = {
				create: createErrorCounts,
				update: updateErrorCounts,
				delete: deleteErrorCounts,
			};


			const duration = (summaryLog.endedAt - summaryLog.startedAt) / 1000; // 초 단위 변환

			await targetSyncSummaryLogModel.updateOne(
				{ _id: summaryLog._id },
				{
					$set: {
						successCounts: summaryLog.successCounts,
						errorCounts: summaryLog.errorCounts,
						endedAt: summaryLog.endedAt,
						duration: duration,
					},
				}
			);

		});



	} catch (err) {
		ctx.status = 500;
		ctx.body = {
			'success': false,
      		'code': 500,
			'message': 'internal server error',
		};
	}

};

export default syncDepartment;