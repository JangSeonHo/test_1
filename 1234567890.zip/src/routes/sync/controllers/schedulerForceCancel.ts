import Koa from 'koa';
import { runningJobs } from '../../../scheduler/executeScheduler';

const schedulerForceCancel = async (ctx: Koa.Context, ) => {
//--------------------------------------------------------------------------------------------------
// 즉시중단 API
//--------------------------------------------------------------------------------------------------
  const {scheduleId} = ctx.request.body;

  const job = runningJobs[scheduleId];

  if (!job) {
    ctx.status = 404;
    ctx.body = { error: `[schedulerForceCancel] 스케줄러 ${scheduleId}가 실행 중이지 않습니다.>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>` };
    return;
  }

  // job.abortController.abort(); // 강제 중단
  console.log(`[schedulerForceCancel][${scheduleId}] 작업 강제 중단 요청 완료.>>>>>>>>>>>>>>>>>>>>>>>>>`);
  ctx.body = { message: `[schedulerForceCancel] 스케줄러 ${scheduleId} 중단 요청 완료 >>>>>>>>>>>>>>>>>>>>>>>>` };
}

export default schedulerForceCancel;