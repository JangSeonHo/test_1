import Koa from 'koa';
import { decrypt_iv, encrypt_iv } from 'utils/cipher';
import mongoose from 'mongoose';
const ObjectId = mongoose.Types.ObjectId;
import schedulerLockModel from 'models/sync/scheduler_lock';


import syncSummarySyncdataLogModel from 'models/log/sync_summary_syncdata_log';
import syncUserCore from './syncUserCore';

const TENANT_FLAG = 'nmp';
const LOCK_ID = 'syncDepartmentScheduleLock';

const targetSyncSummarySyncdataLogModel = syncSummarySyncdataLogModel({ tenantFlag : TENANT_FLAG });
const targetSchedulerLockModel = schedulerLockModel({ tenantFlag: TENANT_FLAG });

const syncUserSchedule = async () => {
	try {
		const { unixTimestamp, formattedDate } = getFormattedKoreaTime();
    if (process.env.DEVELOPMENT_MODE === 'local') {
		  console.log(`[syncUserSchedule][사용자 연동] - 스케쥴을 실행한다................................... ${unixTimestamp} ::: ${formattedDate}`);
    }

    // *** 사용자연동 데이타 스케쥴링 데이타 추출
    // 1. transDivision === 'U' and processDivision === 'N' 인 레코드중에 전송된지 가장 오래된 데이타 1개만 가져온다.
    const execUserRows = await targetSyncSummarySyncdataLogModel
    .find({transDivision: 'U', processDivision: 'N'})
    .sort({_id : 1})
    .limit(1)
    .select("_id totalCount companyCode syncFileName createdAt updatedAt syncDecData");


    if (execUserRows.length === 0) {
      //락 정보 해체
      await targetSchedulerLockModel.deleteOne({ _id: LOCK_ID });

      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("[syncUserSchedule][execUserRows] 수행할 사용자 연동정보가 없습니다.....No rows to process...............................");
      }
      return;
    }

    // 데이터를 Map 형태로 변환
    const execUserMap = new Map<string, any>();
    const row = execUserRows[0];
    Object.keys(row.toObject()).forEach(key => {
      execUserMap.set(key, row[key]);
    });

    // 조직도 연동 모듈 호출
    await syncUserCore(execUserMap);

		return {
			success: true,
			message: "success",
		};
	} catch (err) {
    await targetSchedulerLockModel.deleteOne({ _id: LOCK_ID });
		console.log(err);
		return {
			success: false,
			message: 'internal server error',
		};
	}
}


//---------------------------------------------------------------------------------------------------------
// 시간을 포맷팅하는 함수
//---------------------------------------------------------------------------------------------------------
function getFormattedKoreaTime() {
  const now = new Date();
  const unixTimestamp = now.getTime();
  const koreaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));

  const year = koreaTime.getFullYear();
  const month = String(koreaTime.getMonth() + 1).padStart(2, '0');
  const day = String(koreaTime.getDate()).padStart(2, '0');

  const hours = koreaTime.getHours();
  const minutes = String(koreaTime.getMinutes()).padStart(2, '0');
  const seconds = String(koreaTime.getSeconds()).padStart(2, '0');
  const ampm = hours >= 12 ? '오후' : '오전';
  const formattedHour = hours % 12 || 12; // 12시간제로 변환

  const formattedDate = `${year}-${month}-${day} ${ampm} ${formattedHour}:${minutes}:${seconds}`;

  return { unixTimestamp, formattedDate };
}
//---------------------------------------------------------------------------------------------------------

export default syncUserSchedule;