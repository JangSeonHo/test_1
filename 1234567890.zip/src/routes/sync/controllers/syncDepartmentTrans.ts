import Koa from 'koa';
import { decrypt_iv, encrypt_iv } from 'utils/cipher';
import syncSummarySyncdataLogModel from 'models/log/sync_summary_syncdata_log';
import encryptionKeyModel from 'models/encryption/encryption_key';
import fs from 'fs';

const TRANS_DEPARTMENT_DIVISION = "D";
const CONDITION_NO_STR = 'N';

const syncDepartment = async (ctx: Koa.Context) => {
	try {
		const userId = ctx.response.get('userId');
		const tenantFlag = ctx.response.get('tenantFlag');
		const verificationKey = ctx.headers['verification-key'] ?? ctx.query.verificationKey;

		//========================================================================================================
		// 암복호화 키 및 IV 조회
		//========================================================================================================
		const targetEncryptionKeyModel = encryptionKeyModel({tenantFlag});
		const key = await targetEncryptionKeyModel.findOne({ tenantFlag: tenantFlag });
		if (process.env.DEVELOPMENT_MODE === 'local') {
			console.log("[syncDepartment][DB 조회 - enc key 및 IV] :::::::::::::::::::::: ", key);
		}

		let paramEncKey;
		let paramIv;

		// encryptionKey와 IV 값이 있는지 확인
		if (key && key.encryptionKey && key.iv) {
			paramEncKey = key.encryptionKey;
			paramIv = key.iv;
			if (process.env.DEVELOPMENT_MODE === 'local') {
				console.log("[syncDepartment] paramEncKey >>>>>>>>>>>> ", paramEncKey);
				console.log("[syncDepartment] paramIv >>>>>>>>>>>> ", paramIv);
			}
		} else {
			paramEncKey = '';
			paramIv = '';
			if (process.env.DEVELOPMENT_MODE === 'local') {
				console.log("[syncDepartment] Encryption key 또는 iv 값을 찾을 수 없습니다.");
			}
		}
		//========================================================================================================



		//========================================================================================================
		// API 호출 권한 체크 - 암호화키의 앞부분 5자리, 뒷부분5자리를 뺀 나머지 정보를 가지고 비교한다.
		//========================================================================================================
		if (process.env.DEVELOPMENT_MODE === 'local') {
			console.log('[syncDepartment] 3KJTKTKDLXTBE1MK25AY3I');
			console.log("[syncDepartment] verificationKey >>> ",verificationKey);
			console.log("[syncDepartment] paramEncKey.slice(5,-5) >>> ", paramEncKey.slice(5,-5));
		}

		if(verificationKey != paramEncKey.slice(5,-5)) {
			ctx.status = 403;
			ctx.body = {
				'success': false,
				'code': 403,
				'message': 'permission denied',
			};
			return;
		}
		//========================================================================================================

		const targetSyncSummarySyncdataLogModel = syncSummarySyncdataLogModel({ tenantFlag });

		const { flag, data, fileName, companyCode } = ctx.request.body as any;


		//========================================================================================================
		// 복호화
		//========================================================================================================
		let decoded: string;

		try {
			decoded = decrypt_iv(data, paramEncKey, paramIv);
		} catch (err) {
      ctx.status = 400;
      ctx.body = {
      	'success': false,
        'code': 400,
				'message': 'BROKEN_DATA',
      };
      return;
		}
		//========================================================================================================

		//개행처리를 정규표현식으로 처리한다. \r이 있을수도 없을수도 있다.
		const rows = decoded.split(/\r?\n/);


		//해당 조건의 정보가 있으면, 업데이트를 하고 없으면 신규등록을 한다.
		const existingLog = await targetSyncSummarySyncdataLogModel.findOne({
			transDivision : TRANS_DEPARTMENT_DIVISION,
			companyCode: companyCode,
			syncFileName: fileName,
			processDivision: CONDITION_NO_STR,
		});

		if(existingLog){
			existingLog.syncEncData = data;
			existingLog.syncDecData = decoded;
			existingLog.totalCount = rows.length - 1;
			existingLog.updatedAt = new Date().getTime();
			await existingLog.save();
		}else{
			const summarySyncdataLog = new targetSyncSummarySyncdataLogModel({
				createdAt: new Date().getTime(),
				syncEncData: data,
				syncDecData: decoded,
				transDivision: TRANS_DEPARTMENT_DIVISION,
				processDivision: CONDITION_NO_STR,
				totalCount: rows.length - 1,
				syncFileName: fileName,
				companyCode: companyCode,
			});
			await summarySyncdataLog.save();
		}

		ctx.status = 200;
		ctx.body = {
			'success': true,
			'code': 200,
			'message': 'Data was transmitted successfully. Please contact the administrator for the results.',
		};

	} catch (err) {
		ctx.status = 500;
		ctx.body = {
			'success': false,
      'code': 500,
			'message': 'internal server error',
		};
	}

};

export default syncDepartment;