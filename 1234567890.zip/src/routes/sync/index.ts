import Router from '@koa/router';
const router = new Router();

import isLoggedIn from 'middlewares/isLoggedIn';
import syncDepartment from './controllers/syncDepartment';
import syncDepartmentNew from './controllers/syncDepartmentNew';
import syncDepartmentLarge from './controllers/syncDepartmentLarge';
import syncDepartmentTrans from './controllers/syncDepartmentTrans';
import syncUser from './controllers/syncUser';
import syncUserNew from './controllers/syncUserNew';
import syncUserTrans from './controllers/syncUserTrans';
import schedulerForceCancel from './controllers/schedulerForceCancel';
import syncMsgRetrievalDeletion from './controllers/syncMsgRetrievalDeletion';

router.post('/syncDepartment', syncDepartment);
router.post('/syncDepartmentNew', syncDepartmentNew);
router.post('/syncDepartmentLarge', syncDepartmentLarge);
router.post('/syncDepartmentTrans', syncDepartmentTrans);
router.post('/syncUser', syncUser);
router.post('/syncUserNew', syncUserNew);
router.post('/syncUserTrans', syncUserTrans);
router.post('/syncMsgRetrievalDeletion', syncMsgRetrievalDeletion);

router.post('/schedulerForceCancel', schedulerForceCancel);


export default router;