import Koa from 'koa';
import sendEmail from 'utils/email/sendEmail';

const emailCheck = async (ctx: Koa.Context) => {
  try {
    await sendEmail({
      to: 'glory@d-eighty.com',
      text: '123123',
      subject: '이메일 테스트',
    });
    ctx.status = 200;
    ctx.body = {
      state: 'normal',
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = 'error';
  }
};

export default emailCheck;
