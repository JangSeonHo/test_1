import Koa from 'koa';
import mongoose, { CallbackError, ObjectId } from 'mongoose';
import { DeleteResult } from 'mongodb'; // mongodb 모듈에서 DeleteResult를 가져옵니다.
import userCancelModel from 'models/account/user_cancel';

const removeUserCancelInfoCore = async () => {
  try {
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("[removeUserCancelInfoCore] :::: START");
    }
    const targetUserCancelModel = userCancelModel({ tenantFlag: "nmp" });

    const nowDate = new Date().getTime();

    // Date 객체 생성
    const currentDate = new Date(nowDate);

    // 3개월 전으로 이동
    currentDate.setMonth(currentDate.getMonth() - 3);

    // 3개월 전의 유닉스 타임스탬프
    const threeMonthsAgoTimestamp = currentDate.getTime();

    const deleteList = await targetUserCancelModel.find({ createdAt: { $lt: threeMonthsAgoTimestamp} });
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("[removeUserCancelInfoCore][tempStartedAt][deleteList] :::::::::::::::::::::: ", deleteList);
    }

    const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

    // Q-Gate에서 삭제로그는 남겨야 한다는 지침이 있어서 console.log를 남긴다.
    // 사용자 해지 컬렉션(디비정보) 데이터 삭제
    targetUserCancelModel.deleteMany(
      { createdAt: { $lt: threeMonthsAgoTimestamp } },
      (err: CallbackError, result: DeleteResult) => {
        if (err) {
          console.error(`[removeUserCancelInfo][removeUserCancelInfo] >>> 데이터 삭제 중 오류 발생 : ${unixTimestamp} - ${formattedDate} ::: `, err);
        } else {
          console.log(`[removeUserCancelInfo][removeUserCancelInfo] ::: ${unixTimestamp} - ${formattedDate} - ${result.deletedCount} 개의 데이터가 삭제되었습니다.`);
        }
    });
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("[removeUserCancelInfoCore] :::: END");
    }

    return {
      success: true,
      deletedCount: deleteList.length,
    };
  } catch (err) {
    console.log(err);
    return {
      success: false,
      error: 'internal server error',
    };
  }
}

//--------------------------------------------------------------------------------------------------
// 시간을 포맷팅하는 함수
//--------------------------------------------------------------------------------------------------
function getFormattedKoreaTime() {
  const now = new Date();
  const unixTimestamp = now.getTime();
  const koreaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));

  const year = koreaTime.getFullYear();
  const month = String(koreaTime.getMonth() + 1).padStart(2, '0');
  const day = String(koreaTime.getDate()).padStart(2, '0');

  const hours = koreaTime.getHours();
  const minutes = String(koreaTime.getMinutes()).padStart(2, '0');
  const seconds = String(koreaTime.getSeconds()).padStart(2, '0');
  const ampm = hours >= 12 ? '오후' : '오전';
  const formattedHour = hours % 12 || 12;

  const formattedDate = `${year}-${month}-${day} ${ampm} ${formattedHour}:${minutes}:${seconds}`;
  return { unixTimestamp, formattedDate };
}

export default removeUserCancelInfoCore;