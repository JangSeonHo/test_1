import Koa from 'koa';
import mongoose, { CallbackError } from 'mongoose';
import { DeleteResult } from 'mongodb'; // mongodb 모듈에서 DeleteResult를 가져옵니다.
import userInfoModel from 'models/account/user_info';
import userCancelModel from 'models/account/user_cancel';

const removeUserCancelInfo = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const targetUserCancelModel = userCancelModel({ tenantFlag });

    const nowDate = new Date().getTime();

    // Date 객체 생성
    const currentDate = new Date(nowDate);

    // 3개월 전으로 이동
    currentDate.setMonth(currentDate.getMonth() - 3);

    // 3개월 전의 유닉스 타임스탬프
    const threeMonthsAgoTimestamp = currentDate.getTime();

    const deleteList = await targetUserCancelModel.find({ createdAt: { $lt: threeMonthsAgoTimestamp} });

    // 사용자 해지 컬렉션(디비정보) 데이터 삭제
    targetUserCancelModel.deleteMany(
      { createdAt: { $lt: threeMonthsAgoTimestamp } },
      (err: CallbackError, result: DeleteResult) => {
        if (err) {
            console.error('[removeUserCancelInfo][removeUserCancelInfo] >>> 데이터 삭제 중 오류 발생:', err);
        } else {
            console.log(`[removeUserCancelInfo][removeUserCancelInfo] ::: ${result.deletedCount} 개의 데이터가 삭제되었습니다.`);
        }
    });

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
}

export default removeUserCancelInfo;