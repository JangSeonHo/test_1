/* eslint-disable max-len */
/* eslint-disable indent */
import Koa from 'koa';
import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';

const setChinaMode = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');
    const accessToken = ctx.headers["access-token"] ?? ctx.query.accessToken;

    const body: any = ctx.request.body;
    //const {userId, isEnable, pushToken} = body;
    const {isEnable, pushToken} = body;

    const targetUserInfoModel = userInfoModel({tenantFlag});
    const targetUserSignInfoModel = userSignInfoModel({tenantFlag});

    const singInfo = await targetUserSignInfoModel.findOne({parentUser : userId, accessToken: accessToken});

    if (singInfo) {
      try {
        await Promise.all([
          targetUserSignInfoModel.updateOne(
            { parentUser: userId, accessToken: accessToken },
            { $set: { isChina: isEnable, pushToken: pushToken, pushType: isEnable ? 'pushy.me' : 'fcm' } }
          ),
          targetUserInfoModel.updateOne(
            { _id: userId },
            { $set: { isChina: isEnable } }
          )
        ]);
      } catch (err: unknown) {
        const errorMsg = err instanceof Error ? err.message : 'Internal server error';
        ctx.status = 500;
        ctx.body = {
          success: false,
          error: errorMsg
        };
        return;
      }
    } else {
      ctx.status = 404;
      ctx.body = {
        success: false,
        error: 'User not found'
      };
      return;
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default setChinaMode;
