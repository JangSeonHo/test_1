import Koa from 'koa';
import userInfoModel from 'models/account/user_info';
import userGroupInfoModel from 'models/account/user_group_info';

const addGroup = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const targetUserGroupModel = userGroupInfoModel({tenantFlag});

    const body: any = ctx.request.body;
    const {groupName} = body;

    // eslint-disable-next-line new-cap
    const newGroup = new targetUserGroupModel({
      groupName,
      childGroupUsers: [],
      createdAt: new Date().getTime(),
      parentUser: userId,
    });

    await Promise.all([
      newGroup.save(),
      targetUserModel.updateOne({_id: userId}, {
        $push: {
          childUserGroups: newGroup._id,
        },
      }),
    ]);

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        newGroup,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default addGroup;
