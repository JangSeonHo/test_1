import Koa from 'koa';
import userInfoModel from 'models/account/user_info';
import userGroupInfoModel from 'models/account/user_group_info';
import refreshBookmarkUsers from 'utils/user/refreshBookmarkUser';

const deleteGroup = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const targetUserGroupModel = userGroupInfoModel({tenantFlag});

    const body: any = ctx.request.body;
    const {groupId} = body;

    await Promise.all([
      targetUserGroupModel.deleteOne({_id: groupId, parentUser: userId}),
      targetUserModel.updateOne({_id: userId}, {
        $pull: {
          childUserGroups: groupId,
        },
      }),
    ]);

    await refreshBookmarkUsers(tenantFlag, userId);

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default deleteGroup;
