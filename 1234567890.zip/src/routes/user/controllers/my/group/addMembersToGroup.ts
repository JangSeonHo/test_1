/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import userGroupInfoModel from 'models/account/user_group_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyInfoModel from 'models/company/company_company_info';
import departmentInfoModel from 'models/company/company_department_info';

const addMembersToGroup = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const targetUserGroupModel = userGroupInfoModel({tenantFlag});

    const body: any = ctx.request.body;
    const {groupId, userIds} = body;

    const groupInfo = await targetUserGroupModel.findOne({_id: groupId, parentUser: userId})
      .select('childGroupUsers');

    if (groupInfo === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'permission denied',
      };
    }

    const targetLists = groupInfo.childGroupUsers.map((id: any) => id.toString());
    const addIds: Array<string> = [];
    userIds.forEach((id: string) => {
      if (id !== userId && targetLists.indexOf(id) === -1) {
        addIds.push(id);
      }
    });

    await targetUserGroupModel.updateOne({_id: groupId}, {
      childGroupUsers: [...targetLists, ...addIds],
    });

    //
    departmentInfoModel({tenantFlag});
    companyInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    //

    const newGroupMembers = await Promise.all(addIds.map(async (id: string) => {
      return await targetUserModel.findOne({_id: id})
        .select('userName jobTitle email personalPhoneNumber officePhoneNumber profileImage childStatusInfo useMessenger parentCompany parentDepartment')
        .populate('parentCompany', 'companyName _id')
        .populate('parentDepartment', 'departmentName _id')
        .populate('childStatusInfo', '-_id -_v');
    }));

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        newGroupMembers,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default addMembersToGroup;
