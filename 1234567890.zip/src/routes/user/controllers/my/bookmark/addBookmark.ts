/* eslint-disable max-len */
import Koa from 'koa';
import userInfoModel from 'models/account/user_info';

const addBookmarkMember = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const userInfo = await targetUserModel.findOne({_id: userId})
      .select('childBookmarkUsers');

    const body: any = ctx.request.body;
    const {userId: newUser} = body;

    const targetLists = userInfo.childBookmarkUsers.map((id: any) => id.toString());
    if (newUser !== userId && targetLists.indexOf(newUser) === -1) {
      await targetUserModel.updateOne({_id: userId}, {$push: {childBookmarkUsers: newUser}});
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default addBookmarkMember;
