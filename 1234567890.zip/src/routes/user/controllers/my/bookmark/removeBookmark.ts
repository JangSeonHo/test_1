/* eslint-disable max-len */
import Koa from 'koa';
import userInfoModel from 'models/account/user_info';

const removeBookmarkMember = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const userInfo = await targetUserModel.findOne({_id: userId})
      .select('childBookmarkUsers');

    const body: any = ctx.request.body;
    const {userId: deleteUser} = body;

    const targetLists = userInfo.childBookmarkUsers.map((id: any) => id.toString());
    if (targetLists.indexOf(deleteUser) !== -1) {
      await targetUserModel.updateOne({_id: userId}, {$pull: {childBookmarkUsers: deleteUser}});
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default removeBookmarkMember;
