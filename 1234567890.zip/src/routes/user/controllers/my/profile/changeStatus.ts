import Koa from 'koa';
import userStatusInfoModel from 'models/account/user_status_info';

const changeStatus = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const body: any = ctx.request.body;
    const {status} = body;

    // const targetUserStatusModel = userStatusInfoModel({tenantFlag});

    // await targetUserStatusModel.updateOne({parentUser: userId}, {
    //   statusCode: status === '자동설정' ? '온라인' : status,
    // });
    // Presence 통합하여 기존 API 미처리

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default changeStatus;
