import Koa from 'koa';
import {userStatusModelPrimaryOnly} from 'models/account/user_status_info';
import userSignInfoModel from 'models/account/user_sign_info';
import {UserStatusCode} from '../../../../../constants/commonConstants';

const updateUserStatus = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {status, isManual = false}: {status: number, isManual: boolean} = ctx.request.body as any;
    const headers = ctx.headers;
    const deviceType = headers['device-type'] as string ?? '';

    const targetUserStatusModel = userStatusModelPrimaryOnly({tenantFlag});
    const targetUserSignInfoModel = userSignInfoModel({tenantFlag});

    if (deviceType === 'android' || deviceType === 'ios') { // iPad는 사용자 상태 변경과 무관함.
      await targetUserStatusModel.updateOne({parentUser: userId}, {$set: {
        mobileStatus: Number(status),
      }});
    } else if (deviceType === 'win32' || deviceType === 'macos') {
      await targetUserSignInfoModel.updateMany({
        parentUser: userId,
      }, {$set: {
          pcStatus: status,
      }});

      if (status == 0) { // 오프라인 처리는 온라인 또는 자리비움 상태일 경우만
        await targetUserStatusModel.updateOne({
          $and: [{
            parentUser: userId,
          }, {
            $or: [{pcStatus: UserStatusCode.ONLINE}, {pcStatus: 'online'}, {pcStatus: UserStatusCode.AWAY}, {pcStatus: null}],
          }]}, {
            $set: {pcStatus: Number(status)},
        });
      } else if (status == 1 && !isManual) { // 자동온라인 처리는 오프라인 또는 자리비움 상태일 경우만
        await targetUserStatusModel.updateOne({
          $and: [{
            parentUser: userId,
          }, {
            $or: [{pcStatus: UserStatusCode.OFFLINE}, {pcStatus: 'offline'}, {pcStatus: UserStatusCode.AWAY}, {pcStatus: null}],
          }]}, {$set: {
          pcStatus: Number(status),
        }});
      } else if (status == 2) { // 자리비움 처리는 온라인 상태일 경우만
        await targetUserStatusModel.updateOne({
          $and: [{
            parentUser: userId,
          }, {
            $or: [{pcStatus: UserStatusCode.ONLINE}, {pcStatus: 'online'}],
          }]}, {$set: {
          pcStatus: Number(status),
        }});
      } else {
        await targetUserStatusModel.updateOne({parentUser: userId}, {$set: {
          pcStatus: Number(status),
        }});
      }
    } // 동시성 오류 방어

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default updateUserStatus;
