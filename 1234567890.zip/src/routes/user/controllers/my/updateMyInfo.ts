import Koa from 'koa';
import userInfoModel from 'models/account/user_info';

const updateMyInfo = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const body: any = ctx.request.body;

    await userInfoModel({tenantFlag})
      .updateOne({
        _id: userId,
      }, {
        [body.key]: body.value,
      });

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default updateMyInfo;
