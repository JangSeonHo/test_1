/* eslint-disable max-len */
import Koa from 'koa';
import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyInfoModel from 'models/company/company_company_info';
import departmentInfoModel from 'models/company/company_department_info';

const addFromPhoneNumbers = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const userInfo = await targetUserModel.findOne({_id: userId})
      .select('parentDepartment childPrivateContacts');

    const body: any = ctx.request.body;
    const {phoneNumbers} = body;

    //
    departmentInfoModel({tenantFlag});
    companyInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    //

    const targetUsers = await Promise.all(phoneNumbers.map(async (personalPhoneNumber: string) => {
      return await targetUserModel.findOne({
        '$or': [
          {personalPhoneNumber},
          {officePhoneNumber: personalPhoneNumber},
        ],
      })
        .select('userName jobTitle email personalPhoneNumber officePhoneNumber profileImage childStatusInfo useMessenger parentCompany parentDepartment')
        .populate('parentCompany', 'companyName _id')
        .populate('parentDepartment', 'departmentName _id')
        .populate('childStatusInfo', '-_id -_v');
    }));

    const newPrivateMembers = targetUsers.filter((user: any) => {
      return user != null && user['_id'].toString() !== userId && userInfo.childPrivateContacts.indexOf(user['_id']) === -1;
    });

    await targetUserModel.updateOne({_id: userId},
      {
        childPrivateContacts: [
          ...userInfo.childPrivateContacts,
          ...newPrivateMembers.map(({_id}) => _id),
        ],
      });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        newPrivateMembers,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 200;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default addFromPhoneNumbers;
