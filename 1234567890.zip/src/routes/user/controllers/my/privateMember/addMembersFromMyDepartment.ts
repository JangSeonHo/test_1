/* eslint-disable max-len */
import Koa from 'koa';
import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyInfoModel from 'models/company/company_company_info';
import departmentInfoModel from 'models/company/company_department_info';

const addFromMyDepartment = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const targetDepartmentModel = departmentInfoModel({tenantFlag});
    const targetCompanyModel = companyInfoModel({tenantFlag});

    // 사용자 정보 조회
    const userInfo = await targetUserModel.findOne({_id: userId})
      .select('parentCompany parentDepartment childPrivateContacts');

    const departmentId = userInfo.parentDepartment;

    // 부서 정보에서 childUsers 목록 조회 (자기 자신 제외)
    const departmentInfo = await targetDepartmentModel.findOne({_id: departmentId}).select('childUsers');
    const allChildUserIds = departmentInfo.childUsers.filter((id: any) => id.toString() !== userId);

    // GUC007 회사ID 목록 조회 - LG디스플레이에서 요구한 사항이라서...
    const companyInfos = await targetCompanyModel.find({ companyCode: 'GUC007' }).select('_id companyCode');
    const guc007CompanyIds = companyInfos.map(c => c._id.toString());
    const isGUC007 = guc007CompanyIds.length > 0;

    // 사용자 조회 조건 구성
    const userQuery: any = {
      _id: { $in: allChildUserIds },
      isDeleted: { $exists: true, $eq: false },
    };

    if (isGUC007) {
      userQuery.policyOrgViewYn = 'Y';
    }

    // 조건에 맞는 childUser 조회
    const allChildUsers = await targetUserModel.find(userQuery).select('_id parentCompany policyOrgViewYn');

    // 기존 연락처 목록을 문자열로 변환해서 비교
    const existingContactStrs = (userInfo.childPrivateContacts as string[]).map((id) => id.toString());
    const filteredIds = allChildUsers.map(user => user._id.toString());

    // 신규 추가할 ID만 추출
    const newContactIds = filteredIds.filter(id => !existingContactStrs.includes(id));

    //
    companyInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    //

    // 사용자 정보 업데이트
    await targetUserModel.updateOne(
      { _id: userId },
      { childPrivateContacts: [...userInfo.childPrivateContacts, ...newContactIds] }
    );

    // 신규 사용자 정보 조회 및 응답 구성
    const newPrivateMembers = await Promise.all(
      newContactIds.map(async (id: string) => {
        return await targetUserModel.findOne({ _id: id })
          .select('userName jobTitle email personalPhoneNumber officePhoneNumber profileImage childStatusInfo useMessenger parentCompany parentDepartment')
          .populate('parentCompany', 'companyName _id')
          .populate('parentDepartment', 'departmentName _id')
          .populate('childStatusInfo', '-_id -_v');
      })
    );

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        newPrivateMembers,
      },
    };
  } catch (err) {
    console.error('[addFromMyDepartment] error:', err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default addFromMyDepartment;
