/* eslint-disable max-len */
import Koa from 'koa';
import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyInfoModel from 'models/company/company_company_info';
import departmentInfoModel from 'models/company/company_department_info';
import mongoose from 'mongoose';


const addFromMyDepartment = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const targetDepartmentModel = departmentInfoModel({tenantFlag});

    const userInfo = await targetUserModel.findOne({_id: userId})
      .select('parentCompany parentDepartment childPrivateContacts');

    const departmentId = userInfo.parentDepartment;
    const departmentInfo = await targetDepartmentModel.findOne({_id: departmentId}).select('childUsers');

    // eslint-disable-next-line new-cap
    const rawIds = departmentInfo.childUsers.filter((id: any) => id.toString() !== userId);

    // ✅ isDeleted === false 인 사용자만 필터링 (존재하면서 false인 경우만)
    const validUsers = await targetUserModel.find({
      _id: { $in: rawIds },
      isDeleted: { $exists: true, $eq: false }
    }).select('_id');

    const addIds = validUsers.map((doc: any) => doc._id);

    const childPrivateContacts = userInfo.childPrivateContacts;
    const childNewContactIds: Array<string> = [];

    //
    companyInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    //

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //현재 사용자 회사 정보 조회
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    const targetCompanyInfoModel = companyInfoModel({tenantFlag});

    const userCompany = await targetCompanyInfoModel.findOne({_id: userInfo.parentCompany}).select('companyCode');
    const isGUC007 = userCompany?.companyCode === 'GUC007';
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    // ✅ childPrivateContacts에 없고, (GUC007이면 policyOrgViewYn === 'Y'인) 사용자만 필터링
    await Promise.all(addIds.map(async (id: string) => {
      const query: any = { _id: new mongoose.Types.ObjectId(id) };

      if (isGUC007) {
        query.policyOrgViewYn = 'Y';
      }

      const alreadyHas = childPrivateContacts.includes(id);
      const mongooseQuery = targetUserModel.findOne(query).select('_id');

      console.log(`📄 MongoDB Query:`, JSON.stringify(mongooseQuery.getQuery()));

      const result = await mongooseQuery;
      if (!alreadyHas && result) {
        childNewContactIds.push(id);
      }
    }));


    console.log(childNewContactIds);

    await targetUserModel.updateOne({_id: userId}, {childPrivateContacts: [...childPrivateContacts, ...childNewContactIds]});

    const newPrivateMembers = await Promise.all(childNewContactIds.map(async (id: string) => {
      const query: any = { _id: id };
      if (isGUC007) {
        query.policyOrgViewYn = 'Y';
      }

      console.log(`🔍 Executing findOne for id: ${id}`);
      console.log(`📄 Query: ${JSON.stringify(query)}`);

      const result = await targetUserModel.findOne(query)
        .select('userName jobTitle email personalPhoneNumber officePhoneNumber profileImage childStatusInfo useMessenger parentCompany parentDepartment')
        .populate('parentCompany', 'companyName _id')
        .populate('parentDepartment', 'departmentName _id')
        .populate('childStatusInfo', '-_id -_v');

      console.log(`✅ Result for id: ${id}`, result ? `→ ${result.userName?.ko || result.email}` : '→ ❌ Not found');

      return result;
    }));

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        newPrivateMembers,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default addFromMyDepartment;
