/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import refreshBookmarkUsers from 'utils/user/refreshBookmarkUser';

const removeMemberFromUserIds = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const userInfo = await targetUserModel.findOne({_id: userId})
      .select('childPrivateContacts');

    const body: any = ctx.request.body;
    const {userIds} = body;

    const beforeUserIds = userInfo.childPrivateContacts.map((id: string) => id.toString());
    userIds.forEach((id: string) => {
      const i1 = beforeUserIds.indexOf(id);
      if (i1 !== -1) {
        beforeUserIds.splice(i1, 1);
      }
    });

    await targetUserModel.updateOne({_id: userId},
      {
        childPrivateContacts: beforeUserIds,
      });

    await refreshBookmarkUsers(tenantFlag, userId);

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default removeMemberFromUserIds;
