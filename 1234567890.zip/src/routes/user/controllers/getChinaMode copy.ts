/* eslint-disable max-len */
/* eslint-disable indent */
import Koa from 'koa';
import userSignInfoModel from 'models/account/user_sign_info';

const getChinaMode = async (ctx: Koa.Context) => {
  try {
    //const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');
    const accessToken = ctx.headers["access-token"] ?? ctx.query.accessToken;

    const body: any = ctx.request.body;
    const {userId} = body;

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[getChinaMode] userId >>>> ${userId}`);
      console.log(`[getChinaMode] tenantFlag >>>> ${tenantFlag}`);
      console.log(`[getChinaMode] accessToken >>>> ${accessToken}`);
    }

    const targetUserSignInfoModel = userSignInfoModel({tenantFlag});

    const singInfo = await targetUserSignInfoModel
    .findOne({ parentUser: userId, accessToken: accessToken })
    .select("_id parentUser isChina");

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[getChinaMode] singInfo >>>> ${JSON.stringify(singInfo, null, 2)}`);
    }

    if (!singInfo) {
      console.log("[getChinaMode] No matching document found.");
    } else {
      console.log(`[getChinaMode] Retrieved document: _id=${singInfo._id}, parentUser=${singInfo.parentUser}, isChina=${singInfo.isChina}`);
    }

    if (singInfo) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[getChinaMode] Updated singInfo.isChina to ${singInfo.isChina}`);
      }
    } else {
      ctx.status = 404;
      ctx.body = {
        'success': false,
        'error': 'User not found',
      };
      return;
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'isEnable' : singInfo.isChina
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getChinaMode;
