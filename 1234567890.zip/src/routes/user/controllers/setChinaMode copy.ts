/* eslint-disable max-len */
/* eslint-disable indent */
import Koa from 'koa';
import userSignInfoModel from 'models/account/user_sign_info';

const setChinaMode = async (ctx: Koa.Context) => {
  try {
    //const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');
    const accessToken = ctx.headers["access-token"] ?? ctx.query.accessToken;

    const body: any = ctx.request.body;
    const {userId, isEnable} = body;

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[setChinaMode] userId >>>> ${userId}`);
      console.log(`[setChinaMode] tenantFlag >>>> ${tenantFlag}`);
      console.log(`[setChinaMode] accessToken >>>> ${accessToken}`);
    }

    const targetUserSignInfoModel = userSignInfoModel({tenantFlag});

    const singInfo = await targetUserSignInfoModel.findOne({parenetUser : userId, accessToken: accessToken});
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[setChinaMode] singInfo >>>> ${singInfo}`);
    }

    if (singInfo) {
      await targetUserSignInfoModel.updateOne(
        {parentUser: userId, accessToken: accessToken},
        {$set: {isChina: isEnable}}
      );

      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[setChinaMode] Updated isChina to ${isEnable}`);
      }
    } else {
      ctx.status = 404;
      ctx.body = {
        'success': false,
        'error': 'User not found',
      };
      return;
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default setChinaMode;
