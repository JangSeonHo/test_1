import Koa from 'koa';
import removeUserCancelInfoCore from './removeUserCancelInfoCore';

const removeUserCancelInfo = async (ctx: Koa.Context) => {
  try {
    const result = await removeUserCancelInfoCore();

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
}

export default removeUserCancelInfo;