import Router from '@koa/router';
import { io } from '../server'; // ✅ `server.ts`에서 생성한 WebSocket `io` 가져오기
import createPushRouter from 'routes/push'; // ✅ push 라우터 가져오기

const router = new Router();

import __platform__ from 'routes/__platform__';
router.use('/__platform__', __platform__.routes());

import __health__ from 'routes/__health__';
router.use('/__health__', __health__.routes());

import auth from 'routes/auth';
router.use('/auth', auth.routes());

import aws from 'routes/aws';
router.use('/aws', aws.routes());

import company from 'routes/company';
router.use('/company', company.routes());

import user from 'routes/user';
router.use('/user', user.routes());

import search from 'routes/search';
router.use('/search', search.routes());

import chatting from 'routes/chatting';
router.use('/chatting', chatting.routes());

import alarm from 'routes/alarm';
router.use('/alarm', alarm.routes());

import note from 'routes/note';
router.use('/note', note.routes());

import notice from 'routes/notice';
router.use('/notice', notice.routes());

import system from 'routes/system';
router.use('/system', system.routes());

import sync from 'routes/sync';
router.use('/sync', sync.routes());

import push from 'routes/push';
router.use('/push', push.routes());

import hrws from 'routes/hrws/routes';
router.use('/hrws', hrws.routes());

import fileTrans from 'routes/fileTrans';
router.use('/fileTrans', fileTrans.routes());

// 파일 업/다운 도메인 분기 테스트
import file from './file';
router.use('/file', file.routes());

export default router;
