import Koa from 'koa';

import appVersionModel from 'models/system/deploy_version';

const getRecentAppVersion = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const version = await appVersionModel({tenantFlag}).findOne({});

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {version},
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'error': 'interneal server error',
    };
  }
};

export default getRecentAppVersion;
