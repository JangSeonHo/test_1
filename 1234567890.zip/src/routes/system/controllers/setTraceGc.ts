import Koa from 'koa';

import v8 from 'v8';
import {ecsTaskId} from '../../../server';

const setTraceGc = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {traceGc, taskId} = body;
    if (taskId != 'any' && ecsTaskId.value != taskId) {
      ctx.status = 403;
      ctx.body = {
        'success': true,
        'msg': '해당하는 ECS Task가 아닙니다.',
      };
      return;
    }

    if (traceGc == 'on') {
      v8.setFlagsFromString('--trace-gc');
      console.log('[setTraceGc] Trace GC ON');
    } else if (traceGc == 'off') {
      v8.setFlagsFromString('--notrace-gc');
      console.log('[setTraceGc] Trace GC OFF');
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      traceGc,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'error': 'interneal server error',
    };
  }
};

export default setTraceGc;
