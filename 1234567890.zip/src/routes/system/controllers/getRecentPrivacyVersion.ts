import Koa from 'koa';

import policyVersionModel from 'models/system/policy_version';

const getRecentPrivacyVersion = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const version = await policyVersionModel({tenantFlag}).findOne({});

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {version},
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'error': 'interneal server error',
    };
  }
};

export default getRecentPrivacyVersion;
