import Koa from 'koa';

import {PutObjectCommand, S3Client} from '@aws-sdk/client-s3';
import {s3Bucket} from 'configs/s3';
const REGION = 'ap-northeast-2';
const s3Client = new S3Client({region: REGION});

import fs from 'fs';
import path from 'path';
import v8 from 'v8';
import {pipeline} from 'stream';
import {promisify} from 'util';
import {ecsTaskId} from '../../../server';

const pipelineAsync = promisify(pipeline);
// eslint-disable-next-line require-jsdoc
function uploadToS3(filePath: string): void {
  setTimeout(async () => {
    const folderPath = '/svc/engn001/nmp/temp';

    try {
      const fileStream = fs.createReadStream(path.join(folderPath, filePath));
      const fileName = path.basename(filePath);
      console.log('[heapdump] fileName :', fileName);
      const key = `heapdumps/${filePath.split('/').pop()}`;
      console.log('[heapdump] key :', key);
      const s3Params = {
        Bucket: s3Bucket,
        Key: key,
        Body: fileStream,
        ContentType: 'application/octet-stream',
      };
      const command = new PutObjectCommand(s3Params);
      // console.log('[heapdump] PutObjectCommand :', command);
      const sendResult = await s3Client.send(command);
      console.log('[heapdump] S3 업로드 완료:', sendResult);
      fs.unlinkSync(`${folderPath}/${filePath}`);
    } catch (err) {
      console.log('[heapdump] S3 업로드 실패:', err);
    }
  }, 0);
};

// eslint-disable-next-line require-jsdoc
async function getDump(filePath: string): Promise<string> {
  return new Promise(async (resolve, reject) => {
    const folderPath = '/svc/engn001/nmp/temp';
    // console.log('getHeapSnapshot 직전');
    const snapshotStream = v8.getHeapSnapshot();
    console.log('[heapdump] getHeapSnapshot 완료');
    if (!fs.existsSync(folderPath)) {
      fs.mkdirSync(folderPath, {recursive: true});
    }
    const fileStream = fs.createWriteStream(path.join(folderPath, filePath));
    fileStream.on('finish', () => {
      console.log('[heapdump] Heap Dump 저장됨:', filePath);
      resolve(filePath);
    });
    fileStream.on('error', (err) => {
      console.log('[heapdump] Heap Dump 저장 실패:', err);
      reject(err);
    });

    await pipelineAsync(snapshotStream, fileStream);
  });
};


const takeHeapdump = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {taskId} = body;
    if (!!taskId && ecsTaskId.value != taskId) {
      ctx.status = 403;
      ctx.body = {
        'success': true,
        'msg': '해당하는 ECS Task가 아닙니다.',
      };
      return;
    }

    const filePath = `heapdump_${ecsTaskId.value ?? 'unknownTaskId'}_${Date.now()}.heapsnapshot`;
    const s3Path = await getDump(filePath);

    ctx.status = 200;
    ctx.body = {
      'success': true,
      's3Path': s3Path,
    };

    process.nextTick(() => {
      uploadToS3(filePath);
    });
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'error': 'interneal server error',
    };
  }
};

export default takeHeapdump;
