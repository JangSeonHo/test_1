import Koa from 'koa';

import {PutObjectCommand, S3Client, ListObjectsV2Command} from '@aws-sdk/client-s3';
import fs from 'fs';
import path from 'path';
import {s3Bucket} from 'configs/s3';
import {getMinusDayLogModel} from 'models/log/message_log_for_auditfile';
import {ecsTaskId} from '../../../server';
import companyInfoModel from 'models/company/company_company_info';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import noteMemberModel from 'models/note/note_member';
const {Client} = require('ssh2');

const REGION = 'ap-northeast-2';
const localFolderPath = '/svc/engn001/nmp/temp';
const tenantFlag = 'nmp';
const ftpRententionDays = 14;

const companyLogInfo = {
  // 'GUC100': {logTypes: ['chat', 'chatUser', 'note', 'noteUser'],
  //   header: {
  //     chat: `ROOM_SEQEVENT_SEQCHAT_TYPEREG_DATEEMP_IDEMP_NOUSER_NAMECOMPANY_CODECOMPANY_DOMAINCONTENT\b`,
  //     chatUser: `ROOM_SEQEMP_IDEMP_NOUSER_NAMECOMPANY_CODECOMPANY_DOMAIN\b`,
  //   },
  // }, // 유캡 테스트중
  'GUC057': {logTypes: ['chat', 'chatUser', 'note', 'noteUser'],
    header: {
      chat: `ROOM_SEQEVENT_SEQCHAT_TYPEREG_DATEEMP_IDEMP_NOUSER_NAMECOMPANY_CODECOMPANY_DOMAINCONTENT\b`,
      chatUser: `ROOM_SEQEMP_IDEMP_NOUSER_NAMECOMPANY_CODECOMPANY_DOMAIN\b`,
    },
    ftpServerHost: 'ftp.lgmtalk.com',
    ftpID: 'ap_user',
    ftpPassword: '1q2w3e4r5t!@',
    isDeleteOldFile: true,
    isDisableInDev: false,
  }, // 엔솔
  'GUC005': {logTypes: ['chat', 'chatUser', 'note', 'noteUser'],
    header: {
      chat: `ROOM_SEQEVENT_SEQCHAT_TYPEREG_DATEEMP_IDEMP_NOUSER_NAMECOMPANY_CODECOMPANY_DOMAINCONTENT\b`,
      chatUser: `ROOM_SEQEMP_IDEMP_NOUSER_NAMECOMPANY_CODECOMPANY_DOMAIN\b`,
    },
    ftpServerHost: 'ftp.lgmtalk.com',
    ftpID: 'ap_user',
    ftpPassword: '1q2w3e4r5t!@',
    isDeleteOldFile: true,
    isDisableInDev: false,
  }, // LG화학
  'GUC007': {logTypes: ['chat', 'chatUser', 'note', 'noteUser'],
    ftpServerHost: '172.19.78.252',
    ftpID: 'splsvc01',
    ftpPassword: '01splsvc',
    isDeleteOldFile: false,
    isDisableInDev: true,
  }, // LG Display
  'GUC054': {logTypes: ['chat'],
    ftpServerHost: '10.59.39.16',
    ftpID: 'msguser',
    ftpPassword: 'Serve0ne2)2$',
    isDeleteOldFile: false,
    isDisableInDev: true,
  }, // 서브원
};

// eslint-disable-next-line require-jsdoc
function getMinusDate(minus: number) {
  const formatter = new Intl.DateTimeFormat('ko-KR', {
    timeZone: 'Asia/Seoul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  const date = new Date();
  date.setDate(date.getDate() - minus);
  const [{value: year}, , {value: month}, , {value: day}] = formatter.formatToParts(date);
  return `${year}${month}${day}`;
}

function findOldFilesAndDeleteFromAllDirectory(sftp: any, directory: any, dateString: string) {
  return new Promise((resolve, reject) => {
    // 디렉토리 내용 목록 조회
    sftp.readdir(directory, async (err: any, list: any) => {
      if (err) {
        console.log(`[MsgAudit] 디렉토리 읽기 실패: ${directory}`);
        reject(err);
        return;
      }

      // 파일 목록과 디렉토리 목록을 순차적으로 처리
      for (const item of list) {
        const filePath = path.join(directory, item.filename);

        const res = await isDirectory(sftp, filePath);
        if (res) {
          // 디렉토리인 경우 하위 디렉토리 순회
          await findOldFilesAndDeleteFromAllDirectory(sftp, filePath, dateString);
        } else {
          // 파일인 경우 파일명에 해당날짜 값이 포함된 경우 삭제
          if (item.filename.includes(dateString)) {
            await deleteFile(sftp, filePath);
          }
        }
      }

      resolve(true);
    });
  });
}

// 디렉토리인지 확인하는 함수 (Windows FTP 서버에서 사용)
function isDirectory(sftp: any, filePath: any) {
  return new Promise((resolve, reject) => {
    sftp.readdir(filePath, (err: any, list: any) => {
      if (err) {
        resolve(false); // 디렉토리일 경우 실패하지 않고, 다른 오류가 발생함
      } else {
        resolve(true); // 디렉토리일 경우 목록이 반환됨
      }
    });
  });
}

function deleteFile(sftp: any, filePath: any) {
  return new Promise((resolve, reject) => {
    sftp.unlink(filePath, (err: any) => {
      if (err) {
        console.log(`[MsgAudit] 파일 삭제 실패: ${filePath}`);
        reject(err);
      } else {
        console.log(`[MsgAudit] 파일 삭제 성공: ${filePath}`);
        resolve(true);
      }
    });
  });
}

export const createUserData = async (minusDays: number): Promise<any> => {
  return new Promise(async (resolve, reject) => {
    try {
      const logModel = getMinusDayLogModel({tenantFlag, minusDays});
      const roomMemberModel = chattingRoomMemberModel({tenantFlag});
      const noteModel = noteMemberModel({tenantFlag});

      await logModel.deleteMany({logType: {$in: ['chatUser', 'noteUser']}});
      const companyForChatUser: string[] = [];
      const companyForNoteUser: string[] = [];

      Object.keys(companyLogInfo).forEach((key) => {
        // @ts-ignore
        if (companyLogInfo[key].logTypes.indexOf('chatUser') !== -1) {
          companyForChatUser.push(key);
        }
        // @ts-ignore
        if (companyLogInfo[key].logTypes.indexOf('noteUser') !== -1) {
          companyForNoteUser.push(key);
        }
      });

      // 채팅유저 데이터 생성
      for (const compCode of companyForChatUser) {
        const roomIds = await logModel.distinct('logTypeId', {
          logType: 'chat',
          companyCode: compCode,
        }).lean();
        // console.log(`roomIds : ${roomIds}`);
        const roomMembers = await roomMemberModel.find({
          parentChattingRoom: {$in: roomIds},
          isDeleted: false,
          isEntered: true,
        }).select('parentChattingRoom parentUser')
          .populate({
            path: 'parentUser',
            select: compCode == 'GUC007' ? 'userName jobTitle emailId empNo email parentDepartment' : 'userName jobTitle emailId empNo email',
            match: {isDeleted: false},
            populate: compCode == 'GUC007' ? [{
              path: 'parentDepartment',
              select: 'departmentName',
            }] : [], // LG디스플레이가 발송한 경우 사용자 부서이름 추가
          })
          .lean();
        // console.log(`회사 ${compCode} roomMember - ${roomMembers}`);

        if (roomMembers.length == 0) {
          continue;
        }

        let logBulk = [];
        for (const memberInfo of roomMembers) {
          if (!memberInfo.parentUser) {
            continue;
          }
          const userInfo = memberInfo.parentUser;
          let text = '';

          // 회사별 text 포맷 분기
          switch (compCode) {
            // case 'GUC100': // 유캡
            case 'GUC057': // 엔솔
            case 'GUC005': // 화학
              text = `${memberInfo.parentChattingRoom}${userInfo.emailId}${userInfo.empNo}${userInfo.userName.ko}${compCode}${userInfo.email.split('@')[1] ?? ''}\b`;
              break;
            case 'GUC007': // 디스플레이
              const deptName = userInfo.parentDepartment.departmentName.ko ?? '';
              text = `ROOM_SEQ="${memberInfo.parentChattingRoom}"\bEMP_NO="${userInfo.empNo}"\bUSER_NAME="${userInfo.userName.ko}"\bGRADE="${userInfo.jobTitle.ko}"\bDEPT_NAME="${deptName}"^`;
              break;
          }

          if (text.length === 0) {
            continue;
          }
          logBulk.push({
            companyCode: compCode,
            logType: 'chatUser',
            text,
          });
          if (logBulk.length % 1000 == 0) {
            await logModel.insertMany(logBulk);
            logBulk = [];
          }
        }
        if (logBulk.length > 0) {
          await logModel.insertMany(logBulk);
        }
      }

      // 쪽지유저 데이터 생성
      for (const compCode of companyForNoteUser) {
        const noteIds = await logModel.distinct('logTypeId', {
          logType: 'note',
          companyCode: compCode,
        }).lean();

        const noteMembers = await noteModel.find({
          parentNote: {$in: noteIds},
          type: 'R',
        }).select('parentNote parentUser')
          .populate({
            path: 'parentUser',
            select: 'userName jobTitle empNo parentDepartment',
            match: {isDeleted: false},
            populate: [{
              path: 'parentDepartment',
              select: 'departmentName',
            }],
          })
          .lean();
        // console.log(`noteMembers : ${noteMembers}`);

        let logBulk = [];
        for (const memberInfo of noteMembers) {
          const userInfo = memberInfo.parentUser;
          const noteId = String(memberInfo.parentNote._id);
          const empNo = userInfo.empNo ?? '';
          const userName = userInfo.userName.ko ?? '';
          const grade = userInfo.jobTitle.ko ?? '';
          const deptName = userInfo.parentDepartment ? userInfo.parentDepartment.departmentName.ko : '';

          let text = '';
          // 회사별 text 포맷 분기
          switch (compCode) {
            // case 'GUC100': // 유캡
            case 'GUC057': // 엔솔
            case 'GUC005': // 화학
            case 'GUC007': // 디스플레이
              text = `MSG_SEQ="${noteId}"\bEMP_NO="${empNo}"\bUSER_NAME="${userName}"\bGRADE="${grade}"\bDEPT_NAME="${deptName}"^`;
              break;
          }

          if (text.length === 0) {
            continue;
          }
          logBulk.push({
            companyCode: compCode,
            logType: 'noteUser',
            text,
          });
          if (logBulk.length % 1000 == 0) {
            await logModel.insertMany(logBulk);
            logBulk = [];
          }
        }
        if (logBulk.length > 0) {
          await logModel.insertMany(logBulk);
        }
      }

      resolve({
        success: true,
      });
    } catch (err) {
      console.log(`[MsgAudit] createUserData Err : ${err}`);
      // eslint-disable-next-line prefer-promise-reject-errors
      reject({
        error: err,
        success: false,
      });
    }
  });
};

const uploadFileToFtp = async (sftp: any, localFilePath: string, remoteFilePath: string): Promise<any> => {
  return new Promise((resolve, reject) => {
    sftp.fastPut(localFilePath, remoteFilePath, {
      flags: 'w',
      mode: 0o644,
    }, (err: any) => {
      if (err) {
        console.log(`[MsgAudit] FTP 업로드 실패: ${localFilePath}`);
        reject(err);
      } else {
        console.log(`[MsgAudit] FTP 업로드 성공: ${localFilePath}`);
        resolve(true);
      }
    });
  });
};

let ftpClient: any;
export const createFile = async (minusDays: number): Promise<any> => {
  return new Promise(async (resolve, reject) => {
    try {
      const targetDate = getMinusDate(minusDays);
      // s3Client = new S3Client({region: REGION});

      if (!fs.existsSync(localFolderPath)) {
        fs.mkdirSync(localFolderPath, {recursive: true});
      }

      const Model = getMinusDayLogModel({tenantFlag, minusDays});
      const companyCodes = Object.keys(companyLogInfo);
      const companyTmp = await companyInfoModel({tenantFlag})
        .find({companyCode: {$in: companyCodes}}).select('companyCode').lean();

      companyTmp.forEach((info) => {
        // @ts-ignore
        const compLogInfo = companyLogInfo[info.companyCode];
        compLogInfo.logTypes.forEach((type: any) => {
          compLogInfo.companyOId = info._id;
          const fileName = `msglog_${type}_${info.companyCode}_${targetDate}.txt`;
          if (typeof compLogInfo.fileInfo === 'undefined') {
            compLogInfo.fileInfo = {};
          }
          const filePath = path.join(localFolderPath, fileName);
          if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
          }
          const fd = fs.openSync(filePath, 'w');
          compLogInfo.fileInfo[type] = {
            filePath,
            fileStream: fs.createWriteStream(filePath, {
              encoding: 'utf8',
              fd,
              flags: 'w',
            }),
            fileName,
          };

          if (compLogInfo.hasOwnProperty('header')) {
            if (!!compLogInfo.header[type]) {
              compLogInfo.fileInfo[type].fileStream.write(compLogInfo.header[type]);
            }
            // console.log(`header ${type} - ${info.companyCode} - ${compLogInfo.header[type]}`);
          } // 첫줄 헤더 입력
        });
      });

      const cursor = Model.find({}, {
        companyCode: 1, logType: 1, text: 1, _id: 0,
      }).cursor();

      for await (const doc of cursor) {
        // console.log('doc :', doc);
        // @ts-ignore
        const info = companyLogInfo[doc.companyCode].fileInfo[doc.logType];
        info.fileStream.write(`${doc.text}`);
      }

      for (const info of Object.entries(companyLogInfo)) {
        const logInfo = info[1];
        for (const type of logInfo.logTypes) {
          // @ts-ignore
          const stream = logInfo['fileInfo'][type].fileStream;
          fs.fdatasync(stream.fd, (err) => {
            if (err) {
              console.log(`[MsgAudit] flush 실패`);
              throw err;
            }
          });
        }
      }
      await cursor.close();

      // const s3Commands: any[] = [];
      const ftpPaths: any[] = [];
      const keys: Array<string> = [];
      for (const [companyCode, logInfo] of Object.entries(companyLogInfo)) {
        for (const type of logInfo.logTypes) {
          // @ts-ignore
          const infoType = logInfo['fileInfo'][type];
          const filePath = infoType.filePath;

          const fileStat = fs.statSync(filePath);
          if (fileStat.size > 0) {
            const fileStream = fs.createReadStream(filePath);
            infoType.readStream = fileStream;
            const fileName = path.basename(filePath);
            // @ts-ignore
            // const s3Key = `msgAuditFile/${logInfo['companyOId']}/${fileName}`;
            // const s3Key = `msgAuditFile/${companyCode}/${fileName}`;
            // console.log('[MsgAudit] key :', s3Key);
            // const s3Params = {
            //   Bucket: s3Bucket,
            //   Key: s3Key,
            //   Body: fileStream,
            //   ContentType: 'text/plain',
            // };
            // const command = new PutObjectCommand(s3Params);
            // s3Commands.push(command);

            let ftpPath = '';
            if (process.env.STATE_ENV !== 'dev' && process.env.STATE_ENV !== 'stg') {
              ftpPath = `/${companyCode}/${fileName}`;
            } else {
              ftpPath = `/dev/${companyCode}/${fileName}`;
            }
            // console.log('[MsgAudit] ftp path :', ftpPath);
            ftpPaths.push({localPath: filePath, ftpPath, companyCode});
            keys.push(ftpPath);
          } else {
            infoType.readStream = null;
          }
        }
      }

      resolve({
        ftpPaths: keys,
      });
      // for (const cmd of s3Commands) {
      //   await s3Client.send(cmd);
      // }
      // console.log('[MsgAudit] S3 업로드 완료: 데이터 해당일자 ', targetDate);

      function uploadFilesToFtp(companyCode: string) {
        return new Promise(async (resolve, reject) => {
          try {
            // @ts-ignore
            // if (process.env.STATE_ENV !== 'prd' && companyLogInfo[companyCode].isDisableInDev) {
            //   console.log(`[MsgAudit][${companyCode}] 해당 회사는 운영환경에서의 파일 업로드만 허용됩니다.`);
            //   resolve(true);
            //   return;
            // }
            // TODO - 개발AP에서의 LGD, 서브원 SFTP 발송 테스트를 위해 주석처리 중
            await new Promise((resolve, reject) => {
              ftpClient = new Client();
              const sftpOptions = {
                // @ts-ignore
                host: companyLogInfo[companyCode].ftpServerHost, username: companyLogInfo[companyCode].ftpID, password: companyLogInfo[companyCode].ftpPassword,
                port: 22,
                algorithms: {
                  kex: ['diffie-hellman-group14-sha1', 'diffie-hellman-group-exchange-sha256'],
                  cipher: ['aes256-ctr', 'aes128-ctr'],
                  hmac: ['hmac-sha2-256', 'hmac-sha1'],
                  compress: ['none']
                },
              };

              ftpClient.on('ready', () => {
                console.log(`[MsgAudit][${companyCode}] SFTP 서버 접속 성공`);
                resolve(true);
              }).on('error', (err: any) => {
                console.log(`[MsgAudit][${companyCode}] SFTP 서버 접속 실패`);
                reject(err);
              }).connect(sftpOptions);
            });

            const sftp = await new Promise((resolve, reject) => {
              ftpClient.sftp((err: any, sftpInstance: any) => {
                if (err) {
                  reject(err);
                }
                resolve(sftpInstance);
              });
            });

            for (const path of ftpPaths) {
              if (path.companyCode == companyCode) {
                await uploadFileToFtp(sftp, path.localPath, path.ftpPath);
              }
            }
            console.log(`[MsgAudit][${companyCode}] FTP 업로드 완료: 데이터 해당일자 `, targetDate);

            // @ts-ignore
            if (companyLogInfo[companyCode].isDeleteOldFile) {
              await findOldFilesAndDeleteFromAllDirectory(sftp, '/', getMinusDate(ftpRententionDays + 1));
            }
            resolve(true);
          } catch (error) {
            console.log(`[MsgAudit][${companyCode}] FTP 업로드 중 오류 발생:`, error);
            reject(error);
          } finally {
            if (!!ftpClient) {
              ftpClient.end();
              ftpClient = null;
            }
          }
        });
      }
      // const listParam = {
      //   Bucket: s3Bucket,
      //   Prefix: `msgAuditFile/GUC100/`,
      // };
      // const listRes = await s3Client.send(new ListObjectsV2Command(listParam));
      // console.log(`[MsgAudit] S3 유캡 디렉토리 내 파일목록:`, listRes.Contents);

      await uploadFilesToFtp('GUC057'); // 엔솔
      await uploadFilesToFtp('GUC005'); // 화학
      await uploadFilesToFtp('GUC007'); // LGD
      await uploadFilesToFtp('GUC054'); // 서브원
      // console.log('[MsgAudit] FTP 업로드 완료: 데이터 해당일자 ', targetDate);
    } catch (err) {
      console.log(`[MsgAudit] createFile Err : ${err}`);
      reject(err);
    } finally {
      // ftpClient.end();
      // ftpClient = null;
      // s3Client.destroy();
      // s3Client = null;
      for (const info of Object.entries(companyLogInfo)) {
        const logInfo = info[1];
        for (const type of logInfo.logTypes) {
          // @ts-ignore
          const fileInfo = logInfo['fileInfo'][type];
          const stream = fileInfo.fileStream;
          stream.close(() => {
            if (!!fileInfo.readStream) {
              fileInfo.readStream.close(() => {
                fs.unlinkSync(fileInfo.filePath);
                console.log('[MsgAudit] local file clear :', fileInfo.filePath);
                fileInfo.fileStream = null;
                fileInfo.readStream = null;
                // @ts-ignore
                logInfo['companyOId'] = null;
              });
            } else {
              fs.unlinkSync(fileInfo.filePath);
              fileInfo.fileStream = null;
              // @ts-ignore
              logInfo['companyOId'] = null;
            }
          });
        }
      }
    }
  });
};

const createMsgLogAuditFile = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {minusDays} = body;

    const res = await createUserData(minusDays);

    if (res.success) {
      const resFile = await createFile(minusDays);
      if (resFile.hasOwnProperty('ftpPaths')) {
        ctx.status = 200;
        ctx.body = {
          'success': true,
          'isCreatingUserData': false,
          'ftpPaths': resFile.ftpPaths,
          minusDays,
          'taskId': ecsTaskId.value,
        };
      } else {
        ctx.status = 500;
        ctx.body = {
          'success': false,
          'code': -1,
          'error': 'internal server error',
          'message': 'Fail - create File',
        };
      }
    } else {
      ctx.status = 500;
      ctx.body = {
        'success': false,
        'code': -1,
        'error': 'internal server error',
        'message': 'Fail - create UserData',
      };
    }
    // for merge
  } catch (err) {
    console.log(`[MsgAudit] createMsgLogAuditFile Err : ${err}`);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'code': -1,
      'error': 'internal server error',
    };
  }
};

export default createMsgLogAuditFile;
