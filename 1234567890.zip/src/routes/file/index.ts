import Koa from 'koa';
import Router from '@koa/router';
import {s3Bucket} from 'configs/s3';
import downloadAuthForChina from 'middlewares/downloadAuthForChina';
import isLoggedIn from 'middlewares/isLoggedIn';

const {S3Client, GetObjectCommand, PutObjectCommand} = require('@aws-sdk/client-s3');
const REGION = 'ap-northeast-2';
const getRawBody = require('raw-body');

const s3Client = new S3Client({region: REGION});
const router = new Router();

router.get('(.*)', downloadAuthForChina, async (ctx: Koa.Context) => {
  // console.log('ctx path :', ctx.path);

  const key = ctx.path.slice(10); // "/api/file/" 이후부터
  console.log('[TEST-CDN][Download] key :', key);
  try {
    const command = new GetObjectCommand({
      Bucket: s3Bucket,
      Key: key,
    });

    const data = await s3Client.send(command);

    ctx.set('Content-Type', data.ContentType || 'application/octet-stream');
    ctx.set('Content-Disposition', `inline; filename="${key.split('/').pop()}"`);
    ctx.body = data.Body;
  } catch (err: any) {
    console.log(`[GET ERROR] ${key}:`, err.message);
    ctx.status = 404;
    ctx.body = 'File not found';
  }
});

// 업로드 제한 및 디폴트 사이즈
const DEFAULT_LENGTH = 30 * 1024 * 1024;
const MAX_UPLOAD_LIMIT = '100mb';

// key 유효성 검사 + XSS / 경로 조작 방어
const isValidS3Key = (key: string): boolean => {
  if (!key || typeof key !== 'string') return false;
  if (key.includes('..')) return false;
  if (key.includes('//')) return false;
  if (key.includes('\\')) return false;
  if (key.includes('\0')) return false;
  if (key.length > 512) return false; // 너무 긴 키 제한
  return true;
};

// XSS 방어용 escape 처리 함수
const escapeHtml = (unsafe: string): string => {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
};

router.put('(.*)', isLoggedIn, async (ctx: Koa.Context) => {
  try {
    let key = ctx.path.slice(10);
    console.log('[TEST-CDN][Upload] key :', key);

    if (!key) {
      const rawKey = ctx.headers['key'];
      key = typeof rawKey === 'string' ? decodeURIComponent(rawKey) : '';
    }

    // 유효성 + 보안 검사
    if (!isValidS3Key(key)) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: "[fileTrans][fileStreamUpload] Invalid or missing 'key' (query/header)",
      };
      return;
    }

    const safeKeyLog = escapeHtml(key);
    console.log('[fileTrans][fileStreamUpload][key] >>>', safeKeyLog);

    // Content-Type 및 Content-Length 검사
    const contentType = ctx.headers['content-type'] || 'application/octet-stream';
    const rawLength = ctx.headers['content-length'];
    const contentLength = rawLength ? parseInt(rawLength as string, 10) : DEFAULT_LENGTH;

    if (isNaN(contentLength) || contentLength <= 0 || contentLength > 100 * 1024 * 1024) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: '[fileTrans][fileStreamUpload] Invalid or excessive Content-Length',
      };
      return;
    }

    // 실제 body 읽기 (binary stream)
    const body = await getRawBody(ctx.req, {
      length: contentLength,
      limit: MAX_UPLOAD_LIMIT,
    });

    // S3 업로드
    const command = new PutObjectCommand({
      Bucket: s3Bucket,
      Key: key,
      Body: body,
      ContentType: contentType,
      ContentLength: body.length,
    });

    await s3Client.send(command);

    ctx.status = 200;
    ctx.body = {
      success: true,
      message: '[fileTrans][fileStreamUpload] - Uploaded successfully',
    };
  } catch (err: any) {
    console.log('[fileTrans][fileStreamUpload][ERROR]', err);

    let statusCode = 500;
    let message = '[fileTrans][fileStreamUpload] internal server error';

    if (err?.type === 'entity.too.large') {
      statusCode = 413;
      message = '[fileTrans][fileStreamUpload] Uploaded file exceeds limit (100MB)';
    } else if (err?.name === 'TimeoutError') {
      statusCode = 408;
      message = '[fileTrans][fileStreamUpload] Request Timeout while reading file';
    }

    ctx.status = statusCode;
    ctx.body = {
      success: false,
      error: message,
    };
  }
});

export default router;
