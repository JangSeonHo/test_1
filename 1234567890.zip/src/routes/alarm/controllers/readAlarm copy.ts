import Koa from 'koa';

import alarmModel from 'models/alarm/alarm';
import userBadgeModel from 'models/account/user_badge';

const readAlarm = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const {alarmId} = ctx.request.body;

    const TargetAlarmModel = await alarmModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    await Promise.all([
      TargetAlarmModel.updateOne({_id: alarmId, parentUser: userId}, {
        isRead: true,
      }),
      // TargetUserBadgeModel.updateOne({parentUser: userId}, {
      //   $inc: {unreadAlarms: -1},
      // }),
      // unreadAlarms값을 -1 하다가 0보다 자게 되면, 그냥 0으로 한다.
      TargetUserBadgeModel.updateOne(
        { parentUser: userId },  // parentUser 필드가 userId와 일치하는 문서를 찾습니다.
        {
          $set: {
            unreadAlarms: { $max: [ { $subtract: [ "$unreadAlarms", 1 ] }, 0 ] }
          }
        }
      )
    ]);

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default readAlarm;
