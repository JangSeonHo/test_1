import Koa from 'koa';

import alarmModel from 'models/alarm/alarm';
import userInfoModel from 'models/account/user_info';
import companyCompanyModel from 'models/company/company_company_info';
import companyDepartmentModel from 'models/company/company_department_info';
import systemAlarmInfo from 'models/push/system_alarm_info';

const getAlarms = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const { type, page, pageSize } = ctx.query;

    console.log(type, page, pageSize);

    const TargetAlarmModel = await alarmModel({ tenantFlag });

    // populate 대상 모델들 등록
    userInfoModel({ tenantFlag });
    companyCompanyModel({ tenantFlag });
    companyDepartmentModel({ tenantFlag });
    systemAlarmInfo({ tenantFlag });

    const p = Number(page ?? 1);
    const ps = Number(pageSize ?? 20);

    const filter = { parentUser: userId } as any;
    if (type) {
      filter.type = type;
    } else {
      filter['$or'] = [
        { type: 'reminder' },
        { type: 'system_alarm' },
      ];
    }

    const alarms = await TargetAlarmModel.find(filter)
      .sort({ createdAt: 'desc' })
      .skip((p - 1) * ps)
      .limit(ps)
      .populate({
        path: 'actionUser',
        select: 'userName jobTitle parentDepartment parentCompany profileImage',
        populate: [
          {
            path: 'parentDepartment',
            select: 'departmentName',
          },
          {
            path: 'parentCompany',
            select: 'companyName',
          }
        ],
      })
      .populate({
        path: 'parentSystemAlarm',
        select: 'attachedFiles',
      });

    // 방어 처리 로직 추가
    const alarmList = alarms.map(alarm => {
      const alarmObj = alarm.toObject(); // Document → Plain Object

      // parentSystemAlarm 없을 경우 빈 객체로 초기화
      if (!alarmObj.parentSystemAlarm) {
        alarmObj.parentSystemAlarm = { attachedFiles: [] };
      } else {
        // attachedFiles 필드가 없거나 비정상일 경우 빈 배열로 보정
        if (!Array.isArray(alarmObj.parentSystemAlarm.attachedFiles)) {
          alarmObj.parentSystemAlarm.attachedFiles = [];
        }
      }

      return alarmObj;
    });

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        alarms: alarmList,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
      err,
    };
  }
};

export default getAlarms;
