import Koa from 'koa';
import crypto from 'crypto';
import { decrypt_iv, encrypt_iv } from 'utils/cipher'
import userInfoModel from 'models/account/user_info';
import encryptionKeyModel from 'models/encryption/encryption_key';
import issueToken from 'utils/account/issueToken';
import policyVersionModel from 'models/system/policy_version';
import policyGDPRVersionModel from 'models/system/policy_gdpr_version';

const getLgeUserInfo = async (ctx: Koa.Context) => {
  try {

    const { data } = ctx.request.body;
    const tenantFlag = ctx.response.get('tenantFlag');

    // Get AES-CBC Encryption Key, IV
    const targetEncryptionKeyModel = encryptionKeyModel({tenantFlag});
    const encKey = await targetEncryptionKeyModel.findOne({ tenantFlag: tenantFlag });

    // Get AES-CBC Decryption
    const decData = decrypt_iv(data, encKey.encryptionKey, encKey.iv);
    const targetUserId = JSON.parse(decData).userId;

    // Get Target User _id
    const userModel = userInfoModel({tenantFlag});
    const userInfo = await userModel.findOne({email: targetUserId});
    if (userInfo === null) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        errorCode: '0001',
        errorMsg: 'User does not exist.',
      };
      return;
    }

    const userId: any = userInfo['_id'];
    const deviceId = 'web';
    const deviceType = 'win32';
    const agreePrivacyPolicyVersion = userInfo.agreePrivacyPolicyVersion;
    const europeCorp = userInfo.europeCorp;
    const companyId = userInfo.parentCompany;

    const [
      {
        accessToken,
        refreshToken,
      },
      policyVersion,
      policyGDPRVersion,
        ] = await Promise.all([
          issueToken({
          tenantFlag, userId, deviceId, deviceType, agreePrivacyPolicyVersion, isRefresh: false,
        }),
        policyVersionModel({tenantFlag}).findOne({}),
        policyGDPRVersionModel({tenantFlag}).findOne({})
      ]);

    const userGDPRVersion = userInfo.agreeGDPRVersion === policyGDPRVersion.ver ? '' : policyGDPRVersion.ver;
  
    const retJson = `{ "accessToken" : "${accessToken}",  "refreshToken" : "${refreshToken}", 
                       "europeCorp" : "${europeCorp}", "policyGDPRVersion" : "${userGDPRVersion}", 
                       "companyId" : "${companyId}", "objectId" : "${userId}" }`

    // Get AES-CBC Encryption
    const encData = encrypt_iv(retJson, encKey.encryptionKey, encKey.iv);

    ctx.status = 200;
    ctx.body = {
      success: true,
      data : encData
    };

  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default getLgeUserInfo;
