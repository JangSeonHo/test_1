import Koa from 'koa';
import crypto from 'crypto';
import mongoose from 'mongoose';
import userInfoModel from 'models/account/user_info';
import { publicKey, privateKey } from '../../../utils/cipher'
import { lgeCrypto } from '../../../utils/lge/index'
import companyInfoModel from '../../../models/company/company_company_info';

const lgeLogin = async (ctx: Koa.Context) => {
  try {

    const {userIdEnc, userKey} = ctx.request.body;
    const tenantFlag = ctx.response.get('tenantFlag');

    // const userIdEnc = "p6OwiYSuAinPtOkulOBU1A==";
    // const userKey = "t4a6ATN/Sfu1qUiuy1Fq2w==";

    const lgeOid = await companyInfoModel({tenantFlag}).findOne({companyCode: 'GUC002'})
      .select('_id');
    // 복호화 실행
    const userId = lgeCrypto.SsoDecryptedPassword.toDecryptedPassword(userKey, userIdEnc).replace(/\0/g, ""); // null 문자 제거해야함
    // console.log("### Decrypted User ID:", userId);

    // Generating random ​​for client/server mutual authentication
    const random = Math.random().toString(36).substring(2, 18);

    const targetUserModel = userInfoModel({tenantFlag});
    const userInfo = await targetUserModel.findOne({emailId: userId, parentCompany: lgeOid._id, isDeleted: false}).select('_id, email');

    if (lgeOid === null) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        errorCode: '0003',
        errorMsg: '회사 정보가 유효하지 않습니다.',
      };
      return;
    }
    // If userId does not exist
    if (userInfo === null) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        errorCode: '0002',
        errorMsg: 'New 메신저를 이용할 수 없는 사용자입니다.',
      };
      return;
    }

    // Save a random in the userInfo collection for future comparison.
    await targetUserModel.updateOne({_id: userInfo._id}, {
      'authKey': random,
    });

    const encryptByPrivKey = (message: string) => {
      return crypto.privateEncrypt(privateKey, Buffer.from(message, 'utf8')).toString('base64');
    };

    // Encrypt the random with the private key.
    const authKey = encryptByPrivKey(random);;
    const pubKey = publicKey.export({
                        type: "pkcs1",
                        format: "pem",
                    });

    // Provides the ability for the client to decrypt random data using a public key.
    ctx.status = 200;
    ctx.body = {
      success: true,
      userId: userInfo.email,
      pubKey: pubKey,
      authKey: authKey
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default lgeLogin;
