/* eslint-disable max-len */
import Koa from 'koa';

import chattingRoomModel from 'models/message/chatting_room_info';
import chattingMemberModel from 'models/message/chatting_room_member';

const renameChattingRoom = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const body: any = ctx.request.body;
    const {roomId, roomName, updateAll} = body;
    let {reName} = body;

    const targetMemberModel = chattingMemberModel({tenantFlag});
    const targetRoomModel = chattingRoomModel({tenantFlag});

    const member = targetMemberModel.findOne({parentChattingRoom: roomId, parentUser: userId, isDeleted: false});

    if (reName == "undefined" || reName == null) {
      reName = false;
    }

    if (member === null) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        error: 'internal server error',
      };
    }

    if (updateAll === true) {
      await Promise.all([
        targetRoomModel.updateOne({_id: roomId}, {
          roomName,
          reName,
        }),
        targetMemberModel.updateMany({parentChattingRoom: roomId}, {
          roomName,
        }),
      ]);
    } else {
      await targetMemberModel.updateOne({parentChattingRoom: roomId, parentUser: userId, isDeleted: false}, {
        roomName,
      });
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default renameChattingRoom;
