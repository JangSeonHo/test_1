/* eslint-disable max-len */
import Koa from 'koa';

import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chattingRoomMemberModel from 'models/message/chatting_room_member';

const isGroupChatRoomExists = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {userIds} = ctx.request.body;

    chattingRoomInfoModel({tenantFlag});
    const TM = chattingRoomMemberModel({tenantFlag});

    const rooms = await TM.find({parentUser: userId, isGroupChat: true, isDeleted: false})
      .sort({joinedAt: 1})
      .populate({
        path: 'parentChattingRoom',
        select: '_id totalRoomMembers roomName createdAt',
      });

    const qs = [userId, ...userIds].map((id: string) => ({parentUser: id}));

    let roomId = '';
    let roomName = '';

    const rs: any = [];
    await Promise.all(rooms.map(async (room: any) => {
      if (roomId !== '') {
        return true;
      }

      if (room['parentChattingRoom']['totalRoomMembers'] === userIds.length + 1) {
        const cs = await TM.find({
          isGroupChat: true,
          parentChattingRoom: room['parentChattingRoom']['_id'],
          isDeleted: false,
          $or: qs,
        }).select('_id');

        if (cs.length === userIds.length + 1) {
          // roomId = room['parentChattingRoom']['_id'];
          // roomName = room['parentChattingRoom']['roomName'];
          rs.push(room['parentChattingRoom']);
          return false;
        } else {
          return true;
        }
      }

      return true;
    }));

    if (rs.length > 0) {
      rs.sort((a: any, b: any) => b.createdAt - a.createdAt);
      roomId = rs[0]['_id'];
      roomName = rs[0]['roomName'];
    }

    ctx.status = 200;
    ctx.body = {
      data: {
        roomId,
        roomName,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default isGroupChatRoomExists;
