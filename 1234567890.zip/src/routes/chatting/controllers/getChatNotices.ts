import Koa from 'koa';
import chatNoticeModel from 'models/message/chatting_room_message_notice';
import chatRoomModel from 'models/message/chatting_room_info';
import compareVersions from 'utils/string/compareVersions';
import {
  ENCKEYFORPARAM,
  ENCRYPT_APPVERSION, MAX_CHAT_MSG_RETENTION_DAYS,
} from 'constants/commonConstants';
import {decryptURL} from 'utils/cipher';

const getChatNotices = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const versionInfo = ctx.headers['version-info'] as string ?? '';

    const {roomId, page = 1, itemsPerPage = 20} = ctx.query;

    const requestPage = Number(page);
    const requestItemsPerPage = Number(itemsPerPage);

    const TargetMessageModel = chatNoticeModel({tenantFlag});
    const TargetRoomModel = chatRoomModel({tenantFlag});

    let notices = await TargetMessageModel.find({
      parentChattingRoom: roomId,
      createdAt: {$gt: new Date().getTime() - (MAX_CHAT_MSG_RETENTION_DAYS * 24 * 60 * 60 * 1000)},
    })
    .populate({
      path: 'parentUser',
      // eslint-disable-next-line max-len
      select: 'userName profileImage jobTitle parentCompany parentDepartment',
      populate: [{
        path: 'parentCompany',
        select: 'companyName',
      }, {
        path: 'parentDepartment',
        select: 'departmentName',
      }],
    })
    .sort({createdAt: 'desc'})
    .skip((requestPage - 1) * requestItemsPerPage)
    .limit(requestItemsPerPage).lean();

    // TODO - 추후 압호화 버전으로 모든 사용자가 바뀌면 제거할 코드
    if (compareVersions(versionInfo, ENCRYPT_APPVERSION) < 0) {
      notices = notices.map((notice) => ({
        ...notice,
        // @ts-ignore
        files: notice['files'].map((file: any) => ({
          ...file,
          url: !file.url.startsWith('https:') ? decryptURL(file.url, ENCKEYFORPARAM).url : file.url
        })),
      }));
    }

    const {childNoticeMessage} = await TargetRoomModel
      .findOne({_id: roomId}).select('childNoticeMessage');

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        notices,
        childNoticeMessage,
      },
    };
  } catch (err) {
    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  }
};

export default getChatNotices;
