import Koa from 'koa';

import messageSpModel from 'models/message/chatting_room_message_sp';

const setBookmarkMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {roomId, messageId} = ctx.request.body;

    const MessageSpModel = messageSpModel({tenantFlag});

    const m = await MessageSpModel.findOne({
      parentUser: userId,
      parentChattingRoom: roomId,
      type: 'bookmark',
    });

    if (m === null) {
      const nm = new MessageSpModel({
        parentUser: userId,
        parentChattingRoom: roomId,
        type: 'bookmark',
        messages: [messageId],
      });

      await nm.save();
    } else {
      if (!m.messages.includes(messageId)) {
        await MessageSpModel.updateOne({
          parentUser: userId,
          parentChattingRoom: roomId,
          type: 'bookmark',
        }, {
          $push: {
            messages: messageId,
          },
        });
      }
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 200;
    ctx.body = {
      success: false,
    };
  }
};

export default setBookmarkMessage;
