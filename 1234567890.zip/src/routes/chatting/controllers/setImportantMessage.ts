/* eslint-disable max-len */
import Koa from 'koa';

import chatMessageModel from 'models/message/chatting_room_message';
import userInfoModel from 'models/account/user_info';
import admin from 'firebase-admin';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import userSignInfoModel from 'models/account/user_sign_info';
import alarmModel from 'models/alarm/alarm';
import userBadgeModel from 'models/account/user_badge';
import getUserBadge, {getUserBadgePrimaryOnly} from 'utils/account/getUserBadge';
import userStatusInfoModel from '../../../models/account/user_status_info';
import {UserStatusCode} from '../../../constants/commonConstants';

const setImportantMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {messageId, roomId} = ctx.request.body;

    const TargetChatMessageModel = chatMessageModel({tenantFlag});
    const TargetAlarmModel = alarmModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    const updatedAt = new Date().getTime();
    await TargetChatMessageModel.updateOne({
      _id: messageId,
      parentChattingRoom: roomId,
    }, {
      isImportant: true,
      updatedAt,
    });

    const originMessage = await await TargetChatMessageModel.findOne({
      _id: messageId,
      parentChattingRoom: roomId,
    }).select('content');

    const userInfo = await userInfoModel({tenantFlag}).findOne({_id: userId})
      .select('userName jobTitle');
    const content = `${userInfo.userName['ko']}님이 중요메시지로 변경했습니다.`;

    const newSystemMessage = new TargetChatMessageModel({
      systemMessageType: 'important_add',
      content,
      isSystemMessage: true,
      parentChattingRoom: roomId,
      messageSeq: -1,
      systemMessegeTargetId: messageId,
      createdAt: new Date().getTime(),
      translate: [
        {
          locale: 'en',
          text: `${userInfo.userName['en']}님이 중요메시지로 변경했습니다.`,
        },
      ],
    });

    await newSystemMessage.save();

    const members = await chattingRoomMemberModel({tenantFlag})
      .find({
        parentChattingRoom: roomId,
        $or: [
          {isDeleted: false},
          {isDeleted: true, isGroupChat: false},
        ],
      })
      .select('parentUser isGroupChat isDeleted');

    const tokens: any = [];
    const locales: any = [];
    const os: any = [];
    const badges: any = [];

    await Promise.all(members.map(async (member: any) => {
      if (member.parentUser.toString() !== userId) {
        const pushTargets = await userSignInfoModel({tenantFlag})
          .find({
            parentUser: member.parentUser,
            $or: [{deviceType: 'android'}, {deviceType: 'ios'}, {deviceType: 'iPad'}],
            alarmOffChattingRooms: {
              $nin: [roomId],
            },
          });
        const userStatus = await userStatusInfoModel({tenantFlag})
          .findOne({parentUser: member.parentUser})
          .select('pcStatus mobileStatus').lean();

        // eslint-disable-next-line max-len
        await Promise.all(pushTargets.map(async ({pushToken, usePushAlarm, useAlarmImportantMessage, useEnUserInfo, deviceType, onlyAlarmWhenPCIsAbsence}) => {
          if (onlyAlarmWhenPCIsAbsence && userStatus!.hasOwnProperty('pcStatus') && userStatus!.hasOwnProperty('mobileStatus')) {
            // if (userStatus.pcStatus === 'online' && (userStatus.statusCode === '온라인' || userStatus.statusCode === '재택')) {
            // @ts-ignore
            if ((userStatus['pcStatus'] === UserStatusCode.ONLINE || userStatus['pcStatus'] === 'online') && userStatus['mobileStatus'] === UserStatusCode.ONLINE) {
              return;
            }
          }

          if (!usePushAlarm) {
            return;
          }

          if (!useAlarmImportantMessage) {
            return;
          }

          if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
            const badge = await getUserBadgePrimaryOnly(member.parentUser, tenantFlag);
            badges.push(badge);
            tokens.push(pushToken);
            locales.push(useEnUserInfo ? 'en' : 'ko');
            os.push(deviceType);
          }
        }));
      }

      // 중요메시지는 알림도 만들어야함
      const nam = new TargetAlarmModel({
        'type': 'chatting_important',
        'parentUser': member.parentUser,
        'actionUser': userId,
        'chatRoomId': roomId,
        'chatMessageId': messageId,
        'content': originMessage.content,
        'createdAt': new Date().getTime(),
        'isRead': true,
      });

      await Promise.all([
        // TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
        //   $inc: {unreadAlarms: 1},
        // }),
        nam.save(),
      ]);
    }));

    if (tokens.length !== 0) {
      // 파일 종류에 따라 다른 푸쉬
      // const message = {
      //   data: {type: 'chatting_room', id: roomId},
      //   notification: {
      //     title: `${userInfo.userName['ko']} ${userInfo.jobTitle['ko']}`,
      //     body: content,
      //   },
      //   tokens,
      // };

      // admin.messaging()
      //   .sendMulticast(message as admin.messaging.MulticastMessage);

      tokens.forEach((token: string, i: number) => {
        const notification = {
          title: `${userInfo.userName[locales[i] ?? 'ko']} ${userInfo.jobTitle[locales[i] ?? 'ko']}`,
          body: content,
        };

        const msg: any = {
          data: {
            type: 'chatting_room',
            id: roomId,
            ...notification,
            badge: badges[i].toString(),
          },
          token: token,
        };

        if (os[i] === 'android') {
          msg.android = {
            priority: 'HIGH',
          };
        }

        if (os[i] === 'ios' || os[i] === 'iPad') {
          msg.notification = notification;
          msg.apns = {
            payload: {
              aps: {
                sound: 'default',
                badge: badges[i],
              },
            },
          };
        }

        admin.messaging().send(msg);
      });
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default setImportantMessage;
