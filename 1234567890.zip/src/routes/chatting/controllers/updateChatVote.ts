/* eslint-disable max-len */
import Koa from 'koa';

import chatMessageVoteModel from 'models/message/chatting_room_message_vote';

const updateChatVote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {
      voteId,
      allowMultipleVote,
      anonymousVote,
      deadline,
      voteItems,
      allowTextReply,
      voteType,
    } = ctx.request.body as any;

    await chatMessageVoteModel({tenantFlag}).updateOne({_id: voteId, parentUser: userId}, {
      allowMultipleVote,
      anonymousVote,
      deadline,
      voteItems,
      allowTextReply,
      voteType,
    });

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
    };
  }
};

export default updateChatVote;
