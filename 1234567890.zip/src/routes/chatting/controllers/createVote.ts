/* eslint-disable max-len */
import Koa from 'koa';
import admin from 'firebase-admin';

import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';
// import alarmModel from 'models/alarm/alarm';
import chatRoomModel from 'models/message/chatting_room_info';
import chatCounterModel from 'models/message/chatting_counter';
import chatMemberModel from 'models/message/chatting_room_member';
import chatMessageModel from 'models/message/chatting_room_message';
import chatMessageVoteModel from 'models/message/chatting_room_message_vote';
import userBadgeModel from 'models/account/user_badge';
import getUserBadge, {getUserBadgePrimaryOnly} from 'utils/account/getUserBadge';
import isValidAlarmTime from 'utils/alarm/isValidAlarmTime';
import userStatusInfoModel from '../../../models/account/user_status_info';
import {UserStatusCode} from '../../../constants/commonConstants';

import pushIntegration from 'utils/push/pushIntegration';

const createVote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {
      voteTitle,
      roomId,
      allowMultipleVote,
      anonymousVote,
      deadline,
      voteItems,
      allowTextReply,
      voteType,
    } = ctx.request.body as any;

    const UserInfoModel = userInfoModel({tenantFlag});
    const UserSignInfoModel = userSignInfoModel({tenantFlag});
    // const AlarmModel = alarmModel({tenantFlag});
    const ChatRoomModel = chatRoomModel({tenantFlag});
    const ChatCounterModel = chatCounterModel({tenantFlag});
    const ChatMemberModel = chatMemberModel({tenantFlag});
    const ChatMessageModel = chatMessageModel({tenantFlag});
    const ChatMessageVoteModel = chatMessageVoteModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    const [
      {roomName, isGroupChat, reName},
      members,
    ] = await Promise.all([
      ChatRoomModel.findOne({_id: roomId})
        .select('roomName isGroupChat reName'),
      ChatMemberModel
        .find({
          parentChattingRoom: roomId,
          $or: [
            {isDeleted: false},
            {isDeleted: true, isGroupChat: false},
          ],
        })
        .select('parentUser isGroupChat isDeleted roomName'),
    ]);
    const chattingRoomName = roomName;

    let voteRecords = {};

    members.forEach(({parentUser}: {parentUser: string}) => {
      voteRecords = {
        ...voteRecords,
        [`${parentUser}`]: [],
      };
    });

    const counter = await ChatCounterModel
      .findOneAndUpdate({childChattingRoom: roomId}, {
        $inc: {messageSeq: 1},
      });

    const newVoteModel = new ChatMessageVoteModel({
      voteType,
      parentUser: userId,
      parentChattingRoom: roomId,
      allowMultipleVote,
      anonymousVote,
      createdAt: new Date().getTime(),
      deadline,
      voteTitle,
      voteItems,
      voteRecords,
      allowTextReply,
    });
    newVoteModel.voteTitle = voteTitle;

    const newMessage = new ChatMessageModel({
      content: '',
      parentUser: userId,
      parentChattingRoom: roomId,
      createdAt: new Date().getTime(),
      isVote: true,
      childVote: newVoteModel._id,
      messageSeq: counter.messageSeq + 1,
    });
    newVoteModel.parentChattingMessage = newMessage._id;

    await Promise.all([
      ChatRoomModel.updateOne({_id: roomId},
        {childLastMessage: newMessage._id}),
      newVoteModel.save(),
      newMessage.save(),
      ChatMemberModel.updateOne({
        parentChattingRoom: roomId, parentUser: userId, isDeleted: false}, {
        lastCheckedMessageSeq: newMessage.messageSeq,
      }),
    ]);

    const {userName, jobTitle} = await UserInfoModel.findOne({_id: userId})
      .select('userName jobTitle');

    const tokens: any = [];
    const locales: any = [];
    const os: any = [];
    const roomNames: any = [];
    const badges: any = [];

    const memberInfo = members.map((participant: any) => {
      return participant.parentUser;
    });
    const memberInfoTmp = await userInfoModel({tenantFlag})
      .find({_id: {$in: memberInfo}})
      .select('userName.ko userName.en')
      .lean();

    const roomNameKo = memberInfoTmp.map((info: any) => {
      return info.userName.ko;
    }).join(',');
    const roomNameEn = memberInfoTmp.map((info: any) => {
      return info.userName.en;
    }).join(',');

    await Promise.all(members.map(async (member: any) => {
      if (member.parentUser.toString() !== userId) {
        if (!member.isGroupChat && member.isDeleted) {
          await ChatMemberModel
            .updateOne({parentUser: member.parentUser, parentChattingRoom: roomId}, {
              isDeleted: false,
            });
        }

        await TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
          $inc: {unreadChatMessages: 1},
        });

        const pushTargets = await UserSignInfoModel
          .find({
            parentUser: member.parentUser,
            $or: [{deviceType: 'android'}, {deviceType: 'ios'}, {deviceType: 'iPad'}],
            alarmOffChattingRooms: {
              $nin: [roomId],
            },
            usePushAlarm: true,
          });
        const userStatus = await userStatusInfoModel({tenantFlag})
          .findOne({parentUser: member.parentUser})
          .select('pcStatus mobileStatus').lean();

        // eslint-disable-next-line max-len
        await Promise.all(pushTargets.map(async ({pushToken, useAlarmChatMessage, useAlarmAllowedTime, parentUser, useAlarmChatVote,
                                                   useEnUserInfo, deviceType, onlyAlarmWhenPCIsAbsence, timezoneOffset, alarmAllowedTime}) => {
          if (onlyAlarmWhenPCIsAbsence && userStatus!.hasOwnProperty('pcStatus') && userStatus!.hasOwnProperty('mobileStatus')) {
            // if (userStatus.pcStatus === 'online' && (userStatus.statusCode === '온라인' || userStatus.statusCode === '재택')) {
            // @ts-ignore
            if ((userStatus['pcStatus'] === UserStatusCode.ONLINE || userStatus['pcStatus'] === 'online') && userStatus['mobileStatus'] === UserStatusCode.ONLINE) {
              return;
            }
          }

          if (!useAlarmChatVote) {
            return;
          }

          if (useAlarmAllowedTime) {
            if (!isValidAlarmTime(timezoneOffset, alarmAllowedTime.start, alarmAllowedTime.end)) {
              return;
            }
          }

          if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
            const badge = await getUserBadgePrimaryOnly(member.parentUser, tenantFlag);
            badges.push(badge);
            tokens.push(pushToken);
            const l = useEnUserInfo ? 'en' : 'ko';
            locales.push(l);
            os.push(deviceType);
            const rn = !isGroupChat ? `${userName[l]} ${jobTitle[l]}` :
              member.roomName.toString() === '' && !reName ? (useEnUserInfo ? roomNameEn : roomNameKo) :
                member.roomName.toString() !== '' ? member.roomName.toString() : chattingRoomName;

            roomNames.push(rn);
          }
        }));
      }
    }));

    if (tokens.length !== 0) {
      tokens.forEach((token: string, i: number) => {
        const notification = {
          title: roomNames[i]?.substring(0, 100),
          body: isGroupChat ? `${userName[locales[i] ?? 'ko']} ${jobTitle[locales[i] ?? 'ko']}: 투표가 등록되었습니다` : '투표가 등록되었습니다',
        };
        // console.log('투표뱃지 debug : ', badges[i]);

        const msg: any = {
          data: {
            type: 'chatting_room_vote',
            id: roomId,
            ...notification,
            voteId: newVoteModel._id.toString(),
            badge: badges[i].toString(),
          },
          token: token,
        };

        if (os[i] === 'android') {
          msg.android = {
            priority: 'HIGH',
          };
        }

        if (os[i] === 'ios' || os[i] === 'iPad') {
          msg.notification = notification;
          msg.apns = {
            payload: {
              aps: {
                sound: 'default',
                badge: badges[i],
              },
            },
          };
        }

        //admin.messaging().send(msg);
        pushIntegration(msg, false);
      });
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
    };
  }
};

export default createVote;
