import Koa from 'koa';
import crypto from 'crypto';
import { decrypt_iv, encrypt_iv } from 'utils/cipher'
import userInfoModel from 'models/account/user_info';
import encryptionKeyModel from 'models/encryption/encryption_key';

const getUserInfo = async (ctx: Koa.Context) => {
  try {

    const { data } = ctx.request.body;
    const tenantFlag = ctx.response.get('tenantFlag');

    // Get AES-CBC Encryption Key, IV
    const targetEncryptionKeyModel = encryptionKeyModel({tenantFlag});
    const encKey = await targetEncryptionKeyModel.findOne({ tenantFlag: tenantFlag });

    // Get AES-CBC Decryption
    const decData = decrypt_iv(data, encKey.encryptionKey, encKey.iv);

    const targetUserId = JSON.parse(decData).targetUserId;
    const companyId = JSON.parse(decData).companyId;
    const email = JSON.parse(decData).email;

    // Get Target User _id
    const targetUserModel = userInfoModel({tenantFlag});

    let targetUser = null;
    if (targetUserId.includes('@')) {
      targetUser = await targetUserModel.findOne({email: targetUserId}).select('_id');
    } else {
      targetUser = await targetUserModel.findOne({emailId: targetUserId, parentCompany: companyId}).select('_id');
    }

    const callUser = await targetUserModel.findOne({email: email}).select('_id');

    if (targetUser === null) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        errorCode: '0001',
        errorMsg: 'User does not exist.',
      };
      return;
    }

    const callUserObjId = String(callUser._id); 
    const targetUserObjId = String(targetUser._id);

    const retJson = `{ "targetUserId" : "${targetUserObjId}", "objectId" : "${callUserObjId}"}`

    // Get AES-CBC Encryption
    const encData = encrypt_iv(retJson, encKey.encryptionKey, encKey.iv);

    ctx.status = 200;
    ctx.body = {
      success: true,
      data : encData
    };

  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default getUserInfo;