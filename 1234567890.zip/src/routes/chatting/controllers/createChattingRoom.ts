/* eslint-disable new-cap */
/* eslint-disable max-len */
import Koa from 'koa';

import chattingRoomMessageModel, {chatRoomMsgModelPrimaryOnly} from 'models/message/chatting_room_message';
import chattingCounterModel from 'models/message/chatting_counter';
import chattingRoomMemberModel, {roomMemberModelPrimaryOnly} from 'models/message/chatting_room_member';
import chattingRoomInfoModel, {roomInfoModelPrimaryOnly} from 'models/message/chatting_room_info';
import companyInfoModel, {companyModelPrimaryOnly} from 'models/company/company_company_info';
import departmentInfoModel, {deptModelPrimaryOnly} from 'models/company/company_department_info';
import userInfoModel, {userInfoModelPrimaryOnly} from 'models/account/user_info';
import {userStatusModelPrimaryOnly} from 'models/account/user_status_info';
import { CHAT_ROOM_MAX_MEMBERS } from '../../../constants/commonConstants';
import { checkGUC040_P_wOther } from '../utils/userTypeCheck';

const createChattingRoom = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    // counter
    const body: any = ctx.request.body;
    const {userIds: uids, roomName} = body;
    let {reName} = body;

    const userIds: any = [];
    uids.forEach((id: string) => {
      if (!userIds.includes(id)) {
        userIds.push(id);
      }
    });

    // GUC040 userType:P 대화 차단 : 20 lines 
    const targetUserModel = userInfoModel({tenantFlag});
    
    const usrs = await Promise.all([
      targetUserModel.findOne({_id: userId})
        .populate({ path: 'parentCompany', select: 'companyCode' })
        .select('userType parentCompany'),
      ...userIds.map(async (id: string) =>
        await targetUserModel.findOne({_id: id})
          .populate({ path: 'parentCompany', select: 'companyCode' })
          .select('userType parentCompany')
      )
    ]);

    if (checkGUC040_P_wOther(usrs)) {
      ctx.status = 420;
      ctx.body = {
        'success': false,
        'error': 'GUC040(P) not allowed to invite other users.',
      };
      return;
    }

    // userIds 는 대화방 개설자 빼고 계산하여 1 빼기 
    if (userIds.length > CHAT_ROOM_MAX_MEMBERS - 1) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': `${CHAT_ROOM_MAX_MEMBERS}`,
      };
      return;
    }

    if (reName == "undefined" || reName == null) {
      reName = false;
    }

    const isGroupChat = userIds.length > 1;

    const targetChattingRoomModel = chattingRoomInfoModel({tenantFlag});

    // 내 채팅방
    const isMyChat = userIds.length === 1 && userIds[0] === userId;

    // 개인 채팅방 만약에 이미 있으면
    if (!isGroupChat) {
      const beforeRoom: any = await targetChattingRoomModel.findOne({
        isMyChat,
        totalRoomMembers: isMyChat ? 1 : 2,
        $and: [
          {
            childUsers: {
              $in: [userId],
            },
          },
          {
            childUsers: {
              $in: [userIds[0]],
            },
          },
        ],
      }).select('_id');

      if (beforeRoom !== null) {
        const newRoom = await chattingRoomMemberModel({tenantFlag}).findOne({parentUser: userId, parentChattingRoom: beforeRoom._id.toString()})
          .populate({
            path: 'parentChattingRoom',
            populate: [
              {
                path: 'childUsers',
                select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
                populate: [{
                  path: 'childStatusInfo',
                  select: '-parentUser -__v -_id',
                }, {
                  path: 'parentCompany',
                  select: 'companyName',
                }, {
                  path: 'parentDepartment',
                  select: 'departmentName',
                }],
              },
              {
                path: 'childLastMessage',
              },
              {
                path: 'childNoticeMessage',
              },
            ],
          });
        if (newRoom.isDeleted) {
          newRoom.isDeleted = false;
          // 현재 퇴장 상태이고, 재진입 케이스라면 대화방에서의 마지막 메시지가 보여지지 않도록 예외 처리('채팅방이 생성되었습니다' 표출)
          // getChattingRooms의 childLastMessage 예외처리 반영
          if (!newRoom.parentChattingRoom.isMyChat && newRoom.parentChattingRoom.childLastMessage && newRoom.parentChattingRoom.childLastMessage.messageSeq > 0) {
            if (newRoom.parentChattingRoom.childLastMessage.messageSeq - newRoom.deletedMessageSeq < 1) {
              newRoom.parentChattingRoom.childLastMessage = null;
            }
          }
        }
        await chattingRoomMemberModel({tenantFlag}).updateOne({parentUser: userId, parentChattingRoom: beforeRoom._id.toString()}, {
          isDeleted: false,
        });

        ctx.status = 200;
        ctx.body = {
          'success': true,
          'data': {
            newChattingRoom: newRoom,
          },
        };

        return;
      }
    }

    const totalRoomMembers = isMyChat ?
      1 :
      userIds.length + 1;

    const newChattingRoom: any = new targetChattingRoomModel({
      isGroupChat,
      isMyChat,
      totalRoomMembers,
      createdAt: new Date().getTime(),
      reName,
    });

    if (isGroupChat) {
      newChattingRoom.roomName = roomName;
    } else if (isMyChat) {
      newChattingRoom.childUsers = [userId];
    } else {
      newChattingRoom.childUsers = [...userIds, userId];
    }

    const targetChattingCounterModel = chattingCounterModel({tenantFlag});
    const newChattingCounter: any = new targetChattingCounterModel({
      childChattingRoom: newChattingRoom._id,
      messageSeq: 0,
    });

    newChattingRoom.childChattingCounter = newChattingCounter._id;

    const targetChattingRoomMemberModel = chattingRoomMemberModel({tenantFlag});

    // 내 채팅방 예외 처리
    const users = [...userIds];
    if (!users.includes(userId)) {
      users.push(userId);
    }

    await Promise.all([
      newChattingRoom.save(),
      newChattingCounter.save(),
      targetChattingRoomMemberModel.insertMany(users.map((id) => ({
        parentUser: id,
        parentChattingRoom: newChattingRoom._id,
        isMyChat,
        isGroupChat,
        joinedAt: new Date().getTime(),
      }))),
    ]);

    if (isGroupChat) {
      const targetUserModel = userInfoModel({tenantFlag});
      const tus = userIds.length > 10 ? userIds.slice(0, 10) : [...userIds];
      const users = await Promise.all([
        targetUserModel.findOne({_id: userId}).select('userName'),
        ...tus.map(async (tu: string) => await targetUserModel.findOne({_id: tu}).select('userName')),
      ]);

      let content = `${users[0]['userName']['ko']}님이 `;
      let contentEn = `${users[0]['userName']['en']}님이 `;
      for (let i = 1; i < users.length; i++) {
        content += `${users[i]['userName']['ko']}님`;
        contentEn += `${users[i]['userName']['en']}님`;
        if (i !== users.length - 1) {
          content += ', ';
          contentEn += ', ';
        }
      }

      if (userIds.length > 10) {
        content += ` 외 ${userIds.length - 10}명을 초대했습니다`;
        contentEn += ` 외 ${userIds.length - 10}명을 초대했습니다`;
      } else {
        content += '을 초대했습니다';
        contentEn += '을 초대했습니다';
      }

      const targetMessageModel = chattingRoomMessageModel({tenantFlag});
      const systemMessage = new targetMessageModel({
        systemMessageType: 'join',
        content,
        isSystemMessage: true,
        parentChattingRoom: newChattingRoom._id,
        messageSeq: -1,
        createdAt: new Date().getTime(),
        translate: [
          {
            locale: 'en',
            text: contentEn,
          },
        ],
      });

      // [성능튜닝] 하기 소스는 성능향상을 위해 수정됨. 
      // await systemMessage.save();
      systemMessage.save();
    }

    // for populate
    companyInfoModel({tenantFlag});
    departmentInfoModel({tenantFlag});
    //

    chatRoomMsgModelPrimaryOnly({tenantFlag});
    roomInfoModelPrimaryOnly({tenantFlag});
    companyModelPrimaryOnly({tenantFlag});
    deptModelPrimaryOnly({tenantFlag});
    userInfoModelPrimaryOnly({tenantFlag});
    userStatusModelPrimaryOnly({tenantFlag});

    // const newRoom = await chattingRoomMemberModel({tenantFlag}).findOne({parentUser: userId, parentChattingRoom: newChattingRoom._id})
    const newRoom = await roomMemberModelPrimaryOnly({tenantFlag}).findOne({parentUser: userId, parentChattingRoom: newChattingRoom._id})
      .populate({
        path: 'parentChattingRoom',
        populate: [
          {
            path: 'childUsers',
            select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
            populate: [{
              path: 'childStatusInfo',
              select: '-parentUser -__v -_id',
            }, {
              path: 'parentCompany',
              select: 'companyName',
            }, {
              path: 'parentDepartment',
              select: 'departmentName',
            }],
          },
          {
            path: 'childLastMessage',
          },
          {
            path: 'childNoticeMessage',
          },
        ],
      });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        newChattingRoom: newRoom,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default createChattingRoom;
