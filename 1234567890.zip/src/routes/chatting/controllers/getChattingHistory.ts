import Koa from 'koa';
import { CHATTING_HISTORY_URL } from '../../../constants/commonConstants';

const getChattingHistory = async (ctx: Koa.Context) => {
  try {

    const {userId, companyCode, ucapRoomId} = ctx.request.body;
    const tenantFlag = ctx.response.get('tenantFlag');

    // 로그인 패스워드 구하는 로직
    const getHashVal = (message: string, nMaxVal: number) => {
      let nHash = 0;
      let dVal = 0;
      let nLen = message.length;
  
      for (let i = 0; i <  nLen; i++) {
          dVal += 31 * message.charCodeAt(i) * Math.exp(nLen - i);
      }
      nHash = Math.floor(dVal) % nMaxVal;
      return nHash;
    };
         
    const loginPwd = getHashVal(userId, 10000);
    // 대화이력 보기 url
    const mMessengerUrl = CHATTING_HISTORY_URL + `?p_login_id=${userId}&p_login_pwd=${loginPwd}&p_companyCode=${companyCode}&g_room_id=${ucapRoomId}`

    ctx.status = 200;
    ctx.body = {
      success: true,
      chattingHistoryUrl : mMessengerUrl
    };

  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default getChattingHistory;
