/* eslint-disable new-cap */
/* eslint-disable max-len */
import Koa from 'koa';
import mime from 'mime-types';
import admin from 'firebase-admin';

import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chattingCounterModel from 'models/message/chatting_counter';
import chattingRoomMessageModel from 'models/message/chatting_room_message';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import alarmModel from 'models/alarm/alarm';
import translateMessage from 'utils/openai/translateMessage';
import userBadgeModel from 'models/account/user_badge';
import userStatusModel from 'models/account/user_status_info';
import getUserBadge from 'utils/account/getUserBadge';
import isValidAlarmTime from 'utils/alarm/isValidAlarmTime';
import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs';

import {PutObjectCommand, S3Client} from '@aws-sdk/client-s3';

import {s3Bucket} from 'configs/s3';
const REGION = 'ap-northeast-2';
const s3Client = new S3Client({region: REGION});

const getVideoData = (url: string, roomId: string) => {
  return new Promise((resolve: any, reject: any) => {
    const folderPath = '/svc/engn001/nmp/temp';
    const fn = url.split('/')[url.split('/').length - 1];
    const thumbName = `thumb.${fn}.jpeg`;
    ffmpeg(url).screenshots({
      filename: thumbName,
      folder: folderPath,
      count: 1,
    }).on('end', async () => {
      const tk = url.replace('https://', '').split('/');
      let key = '';
      for (let i = 1; i < tk.length - 1; i++) {
        if (i === 1) {
          key += tk[i];
        } else {
          key += `/${tk[i]}`;
        }
      }

      key += `/${thumbName}`;

      const command = new PutObjectCommand({Bucket: s3Bucket, Key: key});
      await s3Client.send(command);
      fs.unlinkSync(`${folderPath}/${thumbName}`);
    });

    ffmpeg.ffprobe(url, (err: any, metadata: any) => {
      resolve(metadata.format.duration);
    });
  });
};

const createChattingMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    // counter
    const body: any = ctx.request.body;
    const {
      roomId,
      content,
      isReply,
      replyOrigin,
      isEmoticon,
      isImportant,
      mentionedUsers = JSON.stringify([]),
      // isGptRoom = false,
      noticeTitle,
      isNotice,
      useTopNotice,
      needTranslate,
      translateLocale,
      translateLocaleText,
      files = [],
    } = body;
    // file url 외부 url 요청시 예외처리
    let invalidFileUrl = false;
    files.forEach((f: any) => {
      if (f.url.split('https://file.lgmtalk.com')[0] !== '' &&
        f.url.split('https://dev-file.lgmtalk.com')[0] !== '' &&
        f.url.split('https://stg-file.lgmtalk.com')[0] !== '') {
        invalidFileUrl = true;
      }
    });

    if (invalidFileUrl) {
      ctx.status = 400;
      return;
    }

    const targetCounterModel = chattingCounterModel({tenantFlag});
    const targetMessageModel = chattingRoomMessageModel({tenantFlag});
    const TargetAlarmModel = alarmModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    // const counter = await targetCounterModel.findOneAndUpdate({childChattingRoom: roomId}, {$inc: {messageSeq: 1},});
    // findOneAndUpdate => findOne로 수정(index추가)하여 빠르게 counter 조회하고 다음 로직 실행하도록 수정
    // updateOne {messageSeq: 1} 로직은 아래 Promise.all에서 비동기 처리함
    const counter = await targetCounterModel.findOne({childChattingRoom: roomId});

    const boolIsReply = typeof isReply === 'string' ? isReply === 'true' : isReply;
    const boolIsEmoticon = typeof isEmoticon === 'string' ? isEmoticon === 'true' : isEmoticon;
    const boolIsImportant = typeof isImportant === 'string' ? isImportant === 'true' : isImportant;
    let arrayMentionedUsers = typeof mentionedUsers === 'string' ? JSON.parse(mentionedUsers) : mentionedUsers;
    arrayMentionedUsers = arrayMentionedUsers.map((v: string) => {
      if (v === 'GPT_BOT') {
        return 'GPTBOTGPTBOT';
      }

      return v;
    });
    // const boolIsGptRoom = typeof isGptRoom === 'string' ? isGptRoom === 'true' : isGptRoom;
    const boolIsNotice = typeof isNotice === 'string' ? isNotice === 'true' : isNotice;
    const boolUseTopNotice = typeof useTopNotice === 'string' ? useTopNotice === 'true' : useTopNotice;
    const boolNeedTranslate = typeof needTranslate === 'string' ? needTranslate === 'true' : needTranslate;

    const hasFiles = files.length > 0;

    let fs = [...files];
    if (hasFiles) {
      if (fs.length === 1 && fs[0].mimeType.includes('video')) {
        let videoUrl = fs[0].url;
        videoUrl = videoUrl.slice(0, videoUrl.lastIndexOf('/') + 1) + encodeURIComponent( videoUrl.slice(videoUrl.lastIndexOf('/') + 1, videoUrl.length) );
        // 특수문자 파일명 encodeURI 처리
        fs = [{
          ...fs[0],
          'url': videoUrl,
          'duration': await getVideoData(videoUrl, roomId),
        }];
      }
    }

    const newMessage = new targetMessageModel({
      content,
      isEmoticon: boolIsEmoticon === true,
      isImportant: boolIsImportant === true,
      parentUser: userId,
      isReply: boolIsReply === true,
      parentChattingRoom: roomId,
      hasFiles,
      files: fs,
      messageSeq: counter.messageSeq + 1,
      createdAt: new Date().getTime(),
      mentionedUsers: arrayMentionedUsers,
    });

    if (boolIsReply === true) {
      newMessage.replyOrigin = replyOrigin;
    }

    if (boolIsNotice) {
      newMessage.isNotice = true;
      newMessage.noticeTitle = noticeTitle ?? '';
    }

    if (boolNeedTranslate) {
      // 번역
      const m = await translateMessage(content, translateLocaleText);

      const translate = {
        locale: translateLocale,
        text: m.trim(),
      };

      newMessage.translate = [translate];
    }

    const roomUpdateData: any = {childLastMessage: newMessage._id};
    if (boolUseTopNotice) {
      roomUpdateData.childNoticeMessage = newMessage._id;
    }

    /*
    const [
      {userName, jobTitle},
      {roomName, isGroupChat},
      members,
    ] = await Promise.all([
      userInfoModel({tenantFlag})
        .findOne({_id: userId})
        .select('userName jobTitle'),
      chattingRoomInfoModel({tenantFlag})
        .findOne({_id: roomId})
        .select('roomName isGroupChat'),
      chattingRoomMemberModel({tenantFlag})
        .find({
          parentChattingRoom: roomId,
          $or: [
            {isDeleted: false},
            {isDeleted: true, isGroupChat: false},
          ],
        })
        .select('parentUser isGroupChat isDeleted roomName'),
      newMessage.save(),
      chattingRoomInfoModel({tenantFlag})
        .updateOne({_id: roomId}, roomUpdateData),
      chattingRoomMemberModel({tenantFlag})
        .updateOne({parentChattingRoom: roomId, parentUser: userId, isDeleted: false}, {
          lastCheckedMessageSeq: newMessage.messageSeq,
        }),
    ]);
    */

    // 1.조회하여 변수에 할당하는 부분만 await 처리함
    const [
      {userName, jobTitle},
      {roomName, isGroupChat},
      members,
    ] = await Promise.all([
      userInfoModel({tenantFlag})
        .findOne({_id: userId})
        .select('userName jobTitle'),
      chattingRoomInfoModel({tenantFlag})
        .findOne({_id: roomId})
        .select('roomName isGroupChat'),
      chattingRoomMemberModel({tenantFlag})
        .find({
          parentChattingRoom: roomId,
          $or: [
            {isDeleted: false},
            {isDeleted: true, isGroupChat: false},
          ],
        })
        .select('parentUser isGroupChat isDeleted roomName'),
    ]);

    // 2. 저장하는 부분은 await 처리하지 않음
    Promise.all([
      newMessage.save(),
      chattingRoomInfoModel({tenantFlag})
        .updateOne({_id: roomId}, roomUpdateData),
      chattingRoomMemberModel({tenantFlag})
        .updateOne({parentChattingRoom: roomId, parentUser: userId, isDeleted: false}, {
          lastCheckedMessageSeq: newMessage.messageSeq,
        }),
      targetCounterModel.updateOne({childChattingRoom: roomId}, {
          $inc: {messageSeq: 1},
        }),
    ]);

    const tokens: any = [];
    const locales: any = [];
    const os: any = [];
    const roomNames: any = [];
    const badges: any = [];

    Promise.all(members.map(async (member: any) => {
      if (member.parentUser.toString() !== userId) {
        if (!member.isGroupChat && member.isDeleted) {
          await chattingRoomMemberModel({tenantFlag}).updateOne({parentUser: member.parentUser, parentChattingRoom: roomId}, {
            isDeleted: false,
          });
        }

        await TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
          $inc: {unreadChatMessages: 1},
        });

        const pushTargets = await userSignInfoModel({tenantFlag})
          .find({
            parentUser: member.parentUser,
            $or: [{deviceType: 'android'}, {deviceType: 'ios'}],
            alarmOffChattingRooms: {
              $nin: [roomId],
            },
            usePushAlarm: true,
          });

        await Promise.all(pushTargets.map(async ({pushToken, useAlarmChatMessage, useAlarmImportantMessage, useAlarmAllowedTime, parentUser,
            useAlarmChatMention, useAlarmChatNotice, useEnUserInfo, deviceType, onlyAlarmWhenPCIsAbsence, timezoneOffset, alarmAllowedTime, pcStatus}) => {
          if (onlyAlarmWhenPCIsAbsence && pcStatus === 'online') {
            const {statusCode} = await userStatusModel({tenantFlag})
              .findOne({parentUser: member.parentUser}).select('statusCode');

            if (statusCode === '온라인' || statusCode === '재택') {
              return;
            }
          }

          if (JSON.parse(mentionedUsers).includes(member.parentUser.toString()) && useAlarmChatMention) {
            if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
              const badge = await getUserBadge(member.parentUser, tenantFlag);
              badges.push(badge);
              const l = useEnUserInfo ? 'en' : 'ko';
              tokens.push(pushToken);
              locales.push(l);
              os.push(deviceType);
              const rn = !member.isGroupChat ? `${userName[l]} ${jobTitle[l]}` :
                member.roomName === '' || !member.roomName ? roomName : member.roomName;
              roomNames.push(rn);
            }

            return;
          }

          // if (mentionedUsers.includes(parentUser) && !useAlarmChatMention) {
          //   return;
          // }

          if (!boolIsNotice && !boolIsImportant && !useAlarmChatMessage) {
            return;
          }

          if (boolIsImportant && !useAlarmImportantMessage) {
            return;
          }

          if (boolIsNotice && !useAlarmChatNotice) {
            return;
          }

          if (!boolIsImportant) {
            if (useAlarmAllowedTime) {
              if (!isValidAlarmTime(timezoneOffset, alarmAllowedTime.start, alarmAllowedTime.end)) {
                return;
              }
            }
          }

          if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
            const badge = await getUserBadge(member.parentUser, tenantFlag);
            badges.push(badge);
            const l = useEnUserInfo ? 'en' : 'ko';
            tokens.push(pushToken);
            locales.push(l);
            os.push(deviceType);
            const rn = !member.isGroupChat ? `${userName[l]} ${jobTitle[l]}` :
              member.roomName === '' || !member.roomName ? roomName : member.roomName;
            roomNames.push(rn);
          }
        }));
      }

      if (mentionedUsers.includes(member.parentUser)) {
        const nam = new TargetAlarmModel({
          'type': 'chatting_mention',
          'parentUser': member.parentUser,
          'actionUser': userId,
          'chatRoomId': roomId,
          'chatMessageId': newMessage._id,
          'content': content,
          'createdAt': new Date().getTime(),
        });

        Promise.all([
          nam.save(),
          TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
            $inc: {unreadAlarms: 1},
          }),
        ]);
      }

      // 중요메시지는 알림도 만들어야함
      if (boolIsImportant === true) {
        const nam = new TargetAlarmModel({
          'type': 'chatting_important',
          'parentUser': member.parentUser,
          'actionUser': userId,
          'chatRoomId': roomId,
          'chatMessageId': newMessage._id,
          'content': content,
          'createdAt': new Date().getTime(),
        });

        Promise.all([
          nam.save(),
          TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
            $inc: {unreadAlarms: 1},
          }),
        ]);
      }

      if (boolIsNotice === true) {
        const nam = new TargetAlarmModel({
          'type': 'chatting_notice',
          'parentUser': member.parentUser,
          'actionUser': userId,
          'chatRoomId': roomId,
          'chatMessageId': newMessage._id,
          'content': content,
          'createdAt': new Date().getTime(),
        });

        Promise.all([
          nam.save(),
          TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
            $inc: {unreadAlarms: 1},
          }),
        ]);
      }
    })).then(() => {
      if (tokens.length !== 0) {
        let m = '';
        if (hasFiles) {
          const mimeType: any = mime.lookup(files[0]['url']) ? mime.lookup(files[0]['url']) : '';
          const isImage = mimeType.includes('image');
          const isVideo = mimeType.includes('video');

          if (boolIsEmoticon) {
            m = '(이모티콘)';
          } else if (isImage) {
            m = '(이미지)';
          } else if (isVideo) {
            m = '(비디오)';
          } else {
            m = '(파일)';
          }
        } else {
          m = content;
        }

        // 파일 종류에 따라 다른 푸쉬
        // const message = {
        //   data: {type: 'chatting_room', id: roomId},
        //   notification: {
        //     title: `${userName['ko']} ${jobTitle['ko']}`,
        //     body: m,
        //   },
        //   tokens,
        // };

        tokens.forEach((token: string, i: number) => {
          const body = isGroupChat ? `${userName[locales[i] ?? 'ko']} ${jobTitle[locales[i] ?? 'ko']}: ${m}` : m;
          const notification = {
            title: roomNames[i],
            body: body.substring(0, 100),
          };
          const msg: any = {
            data: {
              type: 'chatting_room',
              id: roomId,
              ...notification,
              badge: badges[i].toString(),
            },
            token: token,
          };

          if (os[i] === 'android') {
            msg.android = {
              priority: 'HIGH',
            };
          }

          if (os[i] === 'ios') {
            msg.notification = notification;
            msg.apns = {
              payload: {
                aps: {
                  sound: 'default',
                  badge: badges[i],
                },
              },
            };
          }

          admin.messaging().send(msg);
        });
      }
    });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        newMessage,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default createChattingMessage;
