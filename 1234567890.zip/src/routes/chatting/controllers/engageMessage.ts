import Koa from 'koa';

// eslint-disable-next-line max-len
import chatMessageEngagementModel from 'models/message/chatting_room_message_eg';
import chatMessageModel from 'models/message/chatting_room_message';

const engageMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {roomId, messageId, egType, egValue} = ctx.request.body;

    const TargetEGModel = chatMessageEngagementModel({tenantFlag});
    const TargetMessageModel = chatMessageModel({tenantFlag});

    const em = await TargetEGModel
      .findOne({parentChattingRoom: roomId, parentChattingMessage: messageId});

    if (em === null) {
      if (egValue) {
        const nem = new TargetEGModel({
          parentChattingRoom: roomId,
          parentChattingMessage: messageId,
          R1: [],
          R2: [],
          R3: [],
          R4: [],
          R5: [],
          R6: [],
          R7: [],
          R8: [],
          R9: [],
          ...{[egType]: [userId]},
        });

        await Promise.all([
          nem.save(),
          TargetMessageModel.updateOne({_id: messageId},
            {
              'childEngagement': nem._id,
              '$inc': {
                [`totalEngagements.${egType}`]: 1,
              },
            },
          ),
        ]);
      }
    } else {
      var isSave = false;
      let dicCounts = {
        // totalEngagements: {}
      };
      const promises = [];
      if (egValue) {
        if (!em[egType].includes(userId)) {
          let dicPull = {};
          for (var i=1; i<=9; i++) {
            if (egType != `R${i}`) {
              eval(`dicPull.R${i} = ['${userId}']`);
            }
            else {
              eval(`dicCounts['totalEngagements.R${i}'] = 1`);
            }

            if (em[`R${i}`].includes(userId)) {
              eval(`dicCounts['totalEngagements.R${i}'] = -1`);
            }
          }

          promises.push(
            TargetEGModel.updateOne({
              parentChattingRoom: roomId,
              parentChattingMessage: messageId,
            }, {
              $pullAll: dicPull, //{'R1': [userId], 'R2': [userId]},
              $push: {[egType]: [userId]},
            })
          );
          isSave = true;
        }
      }
      else {
        promises.push(
          TargetEGModel.updateOne({
            parentChattingRoom: roomId,
            parentChattingMessage: messageId,
          }, {
            $pullAll: {[egType]: [userId]},
          })
        );
        eval(`dicCounts['totalEngagements.${egType}'] = -1`);
        isSave = true;
      }
      
      if (isSave) {
        promises.push(
          TargetMessageModel.updateOne({_id: messageId},
            {
              '$inc': dicCounts,
            },
          )
        );
      }
      
      if (promises.length > 0) {
        await Promise.all(promises);
      }
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default engageMessage;
