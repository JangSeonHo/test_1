/* eslint-disable max-len */
import Koa from 'koa';

// eslint-disable-next-line max-len
import chatMessageEngagementModel from 'models/message/chatting_room_message_eg';

const getMessageAllEngagement = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const {messageId} = ctx.query;

    const TargetEGModel = chatMessageEngagementModel({tenantFlag});

    const getPopulation = (type: string) => ({
      path: type,
      select: '_id userName jobTitle profileImage childStatusInfo parentDepartment parentCompany',
      populate: [
        {path: 'childStatusInfo', select: 'statusCode pcStatus mobileStatus'},
        {path: 'parentDepartment', select: 'departmentName'},
        {path: 'parentCompany', select: 'companyName'},
      ],
    });

    const messageEngagement = await TargetEGModel
      .findOne({parentChattingMessage: messageId})
      .populate([
        getPopulation('R1'),
        getPopulation('R2'),
        getPopulation('R3'),
        getPopulation('R4'),
        getPopulation('R5'),
        getPopulation('R6'),
        getPopulation('R7'),
        getPopulation('R8'),
        getPopulation('R9'),
      ]);

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {messageEngagement},
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default getMessageAllEngagement;
