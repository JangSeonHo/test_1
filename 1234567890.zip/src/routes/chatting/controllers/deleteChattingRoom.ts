/* eslint-disable new-cap */
/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chattingRoomMessageModel from 'models/message/chatting_room_message';
import chattingRoomBookedMessageModel from 'models/message/chatting_room_booked_message';
import userBadgeModel from 'models/account/user_badge';
import userSignInfoModel from 'models/account/user_sign_info';
import messageSpModel from 'models/message/chatting_room_message_sp';
import chattingRoomTranslationInfoModel from 'models/message/chatting_room_translation_info';
import updateUserBadge from '../../../utils/user/updateUserBadge';


const deleteChattingRoom = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    // counter
    const body: any = ctx.request.body;
    const {roomId} = body;

    const TargetChattingRoomMember = chattingRoomMemberModel({tenantFlag});

    const roomInfo = await TargetChattingRoomMember.findOneAndUpdate({
      parentUser: userId,
      parentChattingRoom: roomId,
      isDeleted: false,
    }, {
      roomName: '',
      isDeleted: true,
    });

    const targetChattingRoomModel = chattingRoomInfoModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});
    const TargetBookedMessageModel = chattingRoomBookedMessageModel({tenantFlag});
    const TargetMessageSp = messageSpModel({tenantFlag});

    await TargetBookedMessageModel.deleteMany({
      parentChattingRoom: roomId,
      parentUser: userId,
    });

    const {childLastMessage} = await targetChattingRoomModel.findOne({_id: roomId})
      .select('childLastMessage')
      .populate('childLastMessage')
      .select('messageSeq') as any;

    if (childLastMessage) {
      const unreadCount = childLastMessage.messageSeq - roomInfo.lastCheckedMessageSeq;

      //메세지 읽지 않고 채팅방 나가기를 한 유저의 채팅방 재 진입에 대한 counter 처리
      await chattingRoomMemberModel({tenantFlag}).findOneAndUpdate({
        parentUser: userId,
        parentChattingRoom: roomId,
      }, {
        lastCheckedMessageSeq: childLastMessage.messageSeq,
        deletedMessageSeq: childLastMessage.messageSeq,
        deletedLastCheckedMessageSeq: (roomInfo.isEntered) ? roomInfo.lastCheckedMessageSeq : roomInfo.deletedLastCheckedMessageSeq,
        isEntered: false,
      });

      // if (unreadCount > 0) {
      //   const {unreadChatMessages} = await TargetUserBadgeModel.findOne({parentUser: userId})
      //     .select('unreadChatMessages');
      //   await TargetUserBadgeModel.updateOne({parentUser: userId}, {
      //     $inc: {unreadChatMessages: unreadChatMessages > unreadCount ? -1 * unreadCount : -1 * unreadChatMessages},
      //   });
      // }
      await updateUserBadge(tenantFlag, userId);
    }

    // 방에서 나가면 북마크 내역 삭제
    await TargetMessageSp.updateOne({
      parentUser: userId,
      parentChattingRoom: roomId,
      type: 'bookmark',
    }, {
      messages: [],
    });

    // 방에서 나가면 알람 설정 초기화
    await userSignInfoModel({tenantFlag}).updateMany({
      parentUser: userId
    }, {
      $pull: {
        'alarmOffChattingRooms': roomId,
      },
    });

    // 방에서 나가면 번역 설정 삭제
    await chattingRoomTranslationInfoModel({tenantFlag}).deleteOne({
      parentChattingRoom: roomId,
      parentUser: userId,
    });

    if (roomInfo.isGroupChat === true) {
      // 나가기 메세지
      const targetUserInfoModel = userInfoModel({tenantFlag});

      const {userName, jobTitle} = await targetUserInfoModel.findOne({_id: userId}).select('userName jobTitle');
      const targetChattingMessageModel = chattingRoomMessageModel({tenantFlag});
      const newSystemMessage = new targetChattingMessageModel({
        systemMessageType: 'leave',
        content: `${userName['ko']} ${jobTitle['ko']}님이 퇴장했습니다`,
        isSystemMessage: true,
        parentChattingRoom: roomId,
        messageSeq: -1,
        createdAt: new Date().getTime(),
        translate: [
          {
            locale: 'en',
            text: `${userName['en']} ${jobTitle['en']}님이 퇴장했습니다`,
          },
        ],
      });

      await Promise.all([
        newSystemMessage.save(),
        targetChattingRoomModel.updateOne({_id: roomId}, {
          $pull: {
            childUsers: userId,
          },
          $inc: {
            totalRoomMembers: -1,
          },
        }),
      ]);
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default deleteChattingRoom;
