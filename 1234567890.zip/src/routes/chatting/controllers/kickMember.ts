/* eslint-disable new-cap */
/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chattingRoomMessageModel from 'models/message/chatting_room_message';
import chattingRoomBookedMessageModel from 'models/message/chatting_room_booked_message';
import userBadgeModel from 'models/account/user_badge';
import userSignInfoModel from 'models/account/user_sign_info';
import messageSpModel from 'models/message/chatting_room_message_sp';
import chattingRoomTranslationInfoModel from 'models/message/chatting_room_translation_info';

const kickMember = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    // counter
    const body: any = ctx.request.body;
    const {roomId, kickUserId} = body;

    const TargetChattingRoomMember = chattingRoomMemberModel({tenantFlag});

    const roomInfo = await TargetChattingRoomMember.findOneAndUpdate({
      parentUser: kickUserId,
      parentChattingRoom: roomId,
      isDeleted: false,
    }, {
      roomName: '',
      isDeleted: true,
    });

    const targetChattingRoomModel = chattingRoomInfoModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});
    const TargetBookedMessageModel = chattingRoomBookedMessageModel({tenantFlag});
    const TargetMessageSp = messageSpModel({tenantFlag});
    const TargetTranslationInfoModel = chattingRoomTranslationInfoModel({tenantFlag});

    await TargetBookedMessageModel.deleteMany({
      parentChattingRoom: roomId,
      parentUser: kickUserId,
    });

    const {childLastMessage} = await targetChattingRoomModel.findOne({_id: roomId})
      .select('childLastMessage')
      .populate('childLastMessage')
      .select('messageSeq') as any;

    if (childLastMessage) {
      const unreadCount = childLastMessage.messageSeq - roomInfo.lastCheckedMessageSeq;

      if (unreadCount > 0) {
        await TargetUserBadgeModel.updateOne({parentUser: kickUserId}, {
          $inc: {unreadChatMessages: -1 * unreadCount},
        });
      }
    }

    // 방에서 나가면 북마크 내역 삭제
    await TargetMessageSp.updateOne({
      parentUser: kickUserId,
      parentChattingRoom: roomId,
      type: 'bookmark',
    }, {
      messages: [],
    });

    // 방에서 나가면 번역 설정 삭제
    await TargetTranslationInfoModel.deleteOne({
      parentChattingRoom: roomId,
      parentUser: kickUserId,
    });

    // 방에서 나가면 알람 설정 초기화
    await userSignInfoModel({tenantFlag}).updateMany({
      parentUser: kickUserId,
    }, {
      $pull: {
        'alarmOffChattingRooms': roomId,
      },
    });

    if (roomInfo.isGroupChat === true) {
      // 나가기 메세지
      const targetUserInfoModel = userInfoModel({tenantFlag});

      const owner = await targetUserInfoModel.findOne({_id: userId}).select('userName');
      const {userName} = await targetUserInfoModel.findOne({_id: kickUserId}).select('userName');
      const targetChattingMessageModel = chattingRoomMessageModel({tenantFlag});
      if (!!userName['ko']) {
        const newSystemMessage = new targetChattingMessageModel({
          systemMessageType: 'kick',
          content: `${owner.userName['ko']}님이 ${userName['ko']}님을 내보냈습니다`,
          isSystemMessage: true,
          parentChattingRoom: roomId,
          messageSeq: -1,
          createdAt: new Date().getTime(),
          translate: [
            {
              locale: 'en',
              text: `${owner.userName['en']}님이 ${userName['en']}님을 내보냈습니다`,
            },
          ],
        });
        await newSystemMessage.save();
      } // 이름 데이터가 없는 사용자는 퇴장 메시지 생성 안됨.

      await targetChattingRoomModel.updateOne({_id: roomId}, {
        $pull: {
          childUsers: kickUserId,
        },
        $inc: {
          totalRoomMembers: -1,
        },
      });
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default kickMember;
