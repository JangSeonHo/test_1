/* eslint-disable max-len */
import Koa from 'koa';
import mongoose from 'mongoose';

import chattingTranslationLanguageModel from 'models/message/chatting_translation_language';
import chattingRoomTranslationInfoModel from 'models/message/chatting_room_translation_info';

const setRecvTranslateLocale = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const {userId, roomId, recvLocale, isEnable, lastMessageSeq} = ctx.request.body;
    const currentTime = new Date().getTime();

    if (!mongoose.Types.ObjectId.isValid(userId) || !mongoose.Types.ObjectId.isValid(roomId) || recvLocale === undefined || isEnable === undefined || lastMessageSeq === undefined) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };
      return;
    }

    const chattingRoomTranslationInfo = await chattingRoomTranslationInfoModel({tenantFlag})
      .findOne({
        parentUser: userId,
        parentChattingRoom: roomId,
      });

    if( chattingRoomTranslationInfo ){
      await chattingRoomTranslationInfoModel({tenantFlag})
      .updateOne(
        {
          parentUser: userId,
          parentChattingRoom: roomId,
        },
        {$set: {recvLocale: recvLocale, isRecvEnable: isEnable, lastMessageSeq: lastMessageSeq, updatedAt: currentTime}},
      );
    } else {
      const ChattingRoomTranslationInfoModel = await chattingRoomTranslationInfoModel({tenantFlag});
      const chattingRoomTranslationInfo = new ChattingRoomTranslationInfoModel({
        parentUser: userId,
        parentChattingRoom: roomId,
        sendLocale: '',
        isSendEnable: false,
        recvLocale: recvLocale,
        isRecvEnable: isEnable,
        lastMessageSeq: lastMessageSeq,
        createdAt: currentTime,
        updatedAt: currentTime,
      });
      await chattingRoomTranslationInfo.save();
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    console.log(`setRecvTranslateLocale error: ${err}`);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default setRecvTranslateLocale;
