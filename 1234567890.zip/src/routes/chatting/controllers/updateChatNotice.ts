import Koa from 'koa';
import chatNoticeModel from 'models/message/chatting_room_message_notice';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import mongoose from 'mongoose';

const updateChatNotice = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const {content, noticeId, files, needTop} = ctx.request.body;

    const TargetMessageModel = chatNoticeModel({tenantFlag});

    await TargetMessageModel.updateOne({_id: noticeId}, {
      content,
      files,
    });
    const targetNotice = await TargetMessageModel
      .find({_id: new mongoose.mongo.ObjectId(noticeId)})
      .select('parentChattingRoom').lean();

    const roomInfo = await chattingRoomInfoModel({tenantFlag})
      .findOne({_id: new mongoose.mongo.ObjectId(targetNotice[0].parentChattingRoom)})
      .select('childNoticeMessage');
    const childNoticeId = (roomInfo.childNoticeMessage || '').toString();

    if (!!needTop && childNoticeId !== noticeId) {
      await chattingRoomInfoModel({tenantFlag}).updateOne(
        {_id: new mongoose.mongo.ObjectId(targetNotice[0].parentChattingRoom)},
        {childNoticeMessage: new mongoose.mongo.ObjectId(noticeId)});
    } else if (typeof needTop !== 'undefined' && !needTop && childNoticeId === noticeId) {
      await chattingRoomInfoModel({tenantFlag}).updateOne(
        {_id: new mongoose.mongo.ObjectId(targetNotice[0].parentChattingRoom)},
        {childNoticeMessage: null});
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default updateChatNotice;
