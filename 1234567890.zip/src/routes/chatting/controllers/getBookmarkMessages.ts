import Koa from 'koa';

import messageSpModel from 'models/message/chatting_room_message_sp';

const getBookmarkMessages = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {roomId} = ctx.query;

    const MessageSpModel = messageSpModel({tenantFlag});

    const m = await MessageSpModel.findOne({
      parentUser: userId,
      parentChattingRoom: roomId,
      type: 'bookmark',
    }).select('messages')
      .populate({
        path: 'messages',
        select: '_id content parentUser isDeleted',
        populate: {
          path: 'parentUser',
          select: 'userName jobTitle parentDepartment',
          populate: {
            path: 'parentDepartment',
            select: 'departmentName',
          },
        },
      });

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        messages: m === null ? [] : m.messages,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default getBookmarkMessages;
