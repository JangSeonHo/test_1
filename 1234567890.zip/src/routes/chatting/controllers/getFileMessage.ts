/* eslint-disable max-len */
import Koa from 'koa';

import chattingMessageModel from 'models/message/chatting_room_message';
import chattingMemberModel from 'models/message/chatting_room_member';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import compareVersions from 'utils/string/compareVersions';
import {ENCKEYFORPARAM, ENCRYPT_APPVERSION} from 'constants/commonConstants';
import {decryptURL} from 'utils/cipher';


const getFileMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    const versionInfo = ctx.headers['version-info'] as string ?? '';

    const {roomId} = ctx.request.query;

    const currentTime = new Date();

    const enterRoomMember = await chattingRoomMemberModel({tenantFlag}).findOne({parentUser: userId, parentChattingRoom: roomId});

    let messageSeq = -1;
    if (enterRoomMember.deletedMessages != null && enterRoomMember.deletedMessageSeq > 0) {
      messageSeq = enterRoomMember.deletedMessageSeq;
    }

    let chatMessages = await chattingMessageModel({tenantFlag})
      .find({
        parentChattingRoom: roomId,
        isEmoticon: false,
        isDeleted: false,
        hasFiles: true,
        isNotice: false,
        createdAt: {
          $gt: new Date(currentTime.getFullYear(), currentTime.getMonth(), currentTime.getDate() - 7, currentTime.getHours(), currentTime.getMinutes()),
        },
        messageSeq: {
          $gt: messageSeq,
        },
      })
      .sort({createdAt: 'desc'})
      .populate({
        path: 'parentUser',
        select: 'userName jobTitle parentDepartment parentCompany',
        populate: [{
          path: 'parentDepartment',
          select: 'departmentName',
        }, {
          path: 'parentCompany',
          select: 'companyName',
        }],
      }).lean();

    // TODO - 추후 압호화 버전으로 모든 사용자가 바뀌면 제거할 코드
    if (compareVersions(versionInfo, ENCRYPT_APPVERSION) < 0) { // 0.5.94보다 이전 버전이면 암호화URL에 대해 대체 메시지로 치환
      chatMessages = chatMessages.map((msg: any) => {
        if (msg.files.length > 0) {
          if (!msg.files[0].url.startsWith('https:')) {
            msg.files = msg.files.map((file: any) => ({
              ...file,
              url: decryptURL(file.url, ENCKEYFORPARAM).url,
            }));
          }
        }
        return msg;
      });
    }

    const member = await chattingMemberModel({tenantFlag})
      .findOne({
        parentChattingRoom: roomId,
        parentUser: userId,
        isDeleted: false,
      })
      .select('deletedMessages') as any;

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        chatMessages,
        deletedMessages: member.deletedMessages ?? [],
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getFileMessage;
