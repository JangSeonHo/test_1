import Koa from 'koa';

import chatMessageVoteModel from 'models/message/chatting_room_message_vote';

const vote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {
      voteId,
      messageId,
      record,
    } = ctx.request.body;

    const ChatMessageVoteModel = chatMessageVoteModel({tenantFlag});
    await ChatMessageVoteModel.updateOne(
      {parentChattingMessage: messageId, _id: voteId},
      {[`voteRecords.${userId}`]: record},
    );

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default vote;
