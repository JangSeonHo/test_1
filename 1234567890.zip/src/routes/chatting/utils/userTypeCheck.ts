import { Types } from 'mongoose';

interface User {
  parentUser?: {
    parentCompany?: {
      companyCode?: string;
    };
    userType?: string;
  };
  parentCompany?: {
    companyCode?: string;
  };
  userType?: string;
}

const getUserCompanyCode = (user: User): string | undefined => {
  return user?.parentUser?.parentCompany?.companyCode || user?.parentCompany?.companyCode;
};

const getUserType = (user: User): string | undefined => {
  return user?.parentUser?.userType || user?.userType;
};

export const checkGUC040_P_wOther = (users: User[]): boolean => {
  // GUC040 사용자들끼리는 userType에 상관없이 대화 가능
  const isAllGUC040 = users.every(
    (user) => getUserCompanyCode(user) === 'GUC040',
  );
  
  if (isAllGUC040) {
    return false;
  }

  // GUC040(P) 사용자와 다른 사용자가 섞여있는 경우 체크
  const hasGUC040P = users.some(
    (user) => getUserCompanyCode(user) === 'GUC040' && getUserType(user) === 'P',
  );
  const hasOtherUsers = users.some(
    (user) => !(getUserCompanyCode(user) === 'GUC040' && getUserType(user) === 'P'),
  );

  return hasGUC040P && hasOtherUsers;
}; 