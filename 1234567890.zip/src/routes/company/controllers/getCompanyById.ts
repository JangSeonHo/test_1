/* eslint-disable indent */
import Koa from 'koa';
import mongoose from 'mongoose';

import companyGroupModel from 'models/company/company_group_info';
import companyCompanyModel from 'models/company/company_company_info';
import companyDepartmentModel from 'models/company/company_department_info';

const getCompanyById = async (ctx: Koa.Context) => {
  try {
    const {id} = ctx.query;

    if (!id || !mongoose.Types.ObjectId.isValid(id.toString())) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');

    // compile before populate
    companyGroupModel({tenantFlag});
    companyDepartmentModel({tenantFlag});
    //

    const companyInfo = await companyCompanyModel({tenantFlag})
      .findOne({
        _id: id,
      })
      .populate('parentGroup', '-childCompanyIds')
      .populate('childDepartments');

    if (companyInfo === null) {
      ctx.status = 404;
      ctx.body = {
        'success': false,
        'error': 'no content',
      };

      return;
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        companyInfo,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getCompanyById;
