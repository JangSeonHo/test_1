/* eslint-disable max-len */
import Koa from 'koa';
import mongoose from 'mongoose';
import { Types } from 'mongoose';

const ObjectId = Types.ObjectId;

import userInfoModel from 'models/account/user_info';
import companyCompanyModel from 'models/company/company_company_info';
import companyDepartmentModel from 'models/company/company_department_info';
import userStatusInfoModel from 'models/account/user_status_info';

const getDepartmentById = async (ctx: Koa.Context) => {
  try {
    const {id, companyId} = ctx.query;

    if (id !== 'top' && id !== 'root' && id !== 'my' &&
      (!id || !mongoose.Types.ObjectId.isValid(id.toString()))) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    console.log(tenantFlag);
    console.log(userId);

    // compile before populate
    userInfoModel({tenantFlag});
    companyCompanyModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    //

    // 최상단 조직도의 경우,
    if (id === 'top') {
      let parentCompany = companyId;
      if (!parentCompany) {
        const userInfo = await userInfoModel({tenantFlag})
          .findOne({_id: userId}).select('parentCompany');
        parentCompany = userInfo.parentCompany;
      }

      const departmentInfo: any = (await companyDepartmentModel({tenantFlag})
        .find({parentDepartments: [], parentCompany})
        .select('_id departmentName totalChildUsers lastModifiedAt childDepartments')
        .populate('childDepartments', '_id departmentName totalChildUsers lastModifiedAt childDepartments'))
        .map((v) => v.toObject());

      const childDepartments = [...(departmentInfo ?? []).map((v: any) => {
        return {
          _id: v._id,
          hasSubChild: (v.childDepartments ?? []).length > 0,
          departmentName: v.departmentName,
          totalChildUsers: v.totalChildUsers,
          lastModifiedAt: v.lastModifiedAt,
        };
      })];

      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          departmentInfo: {
            _id: companyId,
            departmentName: {
              'ko': '본사',
              'en': 'Company',
            },
            parentDepartments: [],
            childDepartments,
            hasSubChild: childDepartments.length > 0,
          },
        },
      };

      return;
    }

    if (id === 'root') {
      let parentCompany = companyId;
      if (!parentCompany) {
        const userInfo = await userInfoModel({tenantFlag})
          .findOne({_id: userId}).select('parentCompany');
        parentCompany = userInfo.parentCompany;
      }
      console.log("");
      console.log("root parentCompany >>>>>>> ", parentCompany);
      console.log("");

      const departmentInfo: any = (await companyDepartmentModel({tenantFlag})
        .find({parentDepartments: [], parentCompany})
        .select('_id departmentName totalChildUsers lastModifiedAt childDepartments')
        .populate('childDepartments', '_id departmentName totalChildUsers lastModifiedAt childDepartments'))
        .map((v) => v.toObject());

        console.log("");
        console.log("departmentInfo >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        console.log("");
  console.log(JSON.stringify(departmentInfo, null, 2));

      const childDepartments = [...(departmentInfo ?? []).map((v: any) => {
        return {
          _id: v._id,
          hasSubChild: (v.childDepartments ?? []).length > 0,
          departmentName: v.departmentName,
          totalChildUsers: v.totalChildUsers,
          lastModifiedAt: v.lastModifiedAt,
        };
      })];

console.log("childDepartments >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
console.log(JSON.stringify(childDepartments, null, 2));





      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          departmentInfo: {
            _id: 'root',
            departmentName: {
              'ko': '본사',
              'en': 'Company',
            },
            parentDepartments: [],
            childDepartments,
            hasSubChild: childDepartments.length > 0,
          },
        },
      };

      console.log("root >>>>>>> return ");

      return;
    }

    // 내 부서 조회인 경우
    if (id === 'my') {
      const userInfo = await userInfoModel({tenantFlag})
        .findOne({_id: userId}).select('parentDepartment');

      const departmentInfo: any = await companyDepartmentModel({tenantFlag})
      .findOne({_id: userInfo.parentDepartment})
      .select('_id departmentName parentDepartments childDepartments childUsers totalChildUsers lastModifiedAt')
      .populate('parentDepartments', '_id departmentName')
      .populate('childDepartments', '_id departmentName totalChildUsers lastModifiedAt childDepartments')
      .populate({
        path: 'childUsers',
        select: '_id userName jobTitle profileImage email personalPhoneNumber lastModifiedAt parentCompany parentDepartment listOrder childStatusInfo',
        options: { sort: { listOrder: 1, 'userName.ko': 1, _id: 1 } },
        populate: [
          {
            path: 'childStatusInfo',
            select: 'statusCode',
          },
          {
            path: 'parentCompany',
            select: 'companyName',
          },
          {
            path: 'parentDepartment',
            select: 'departmentName',
          },
        ],
      })
      .lean();


      const rv = {
        ...departmentInfo,
        childDepartments: [...(departmentInfo.childDepartments ?? []).map((v: any) => {
          return {
            _id: v._id,
            hasSubChild: (v.childDepartments ?? []).length > 0,
            departmentName: v.departmentName,
            totalChildUsers: v.totalChildUsers,
            lastModifiedAt: v.lastModifiedAt,
          };
        })],
        hasSubChild: departmentInfo.childDepartments.length > 0,
      };

      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          departmentInfo: rv,
        },
      };

      return;
    }

    console.log("asl;kdfja;lskdjfl;askjdf;laksjdf;lkasjdf;laksdjfl;askdfj;lasdkfj;");

    // const departmentInfo: any = await companyDepartmentModel({tenantFlag})
    // .findOne({_id: id})
    // .select('_id departmentName parentDepartments childDepartments childUsers totalChildUsers lastModifiedAt')
    // .populate('parentDepartments', '_id departmentName')
    // .populate('childDepartments', '_id departmentName totalChildUsers lastModifiedAt childDepartments')
    // .populate({
    //   path: 'childUsers',
    //   select: '_id userName jobTitle profileImage email personalPhoneNumber lastModifiedAt childStatusInfo listOrder',
    //   options: { sort: { listOrder: 1, 'userName.ko': 1, _id: 1 } },
    //   populate: [
    //     {
    //       path: 'childStatusInfo',
    //       select: 'statusCode',
    //     },
    //     {
    //       path: 'parentCompany',
    //       select: 'companyName',
    //     },
    //     {
    //       path: 'parentDepartment',
    //       select: 'departmentName',
    //     },
    //   ],
    // })
    // .lean();




    // const departmentInfo: any = await companyDepartmentModel({ tenantFlag })
    // .findOne({ _id: id })
    // .select('_id departmentName parentDepartments childDepartments childUsers totalChildUsers lastModifiedAt')
    // .populate({
    //     path: 'parentDepartments',
    //     select: '_id departmentName',
    //     options: { sort: { level: 1, siblingDepth: 1, 'departmentName.en': 1 } }
    // })
    // .populate({
    //     path: 'childDepartments',
    //     select: '_id departmentName totalChildUsers lastModifiedAt childDepartments level siblingOrders siblingDepth',
    //     options: {
    //         sort: {
    //             level: 1,
    //             siblingDepth: 1,
    //             $cond: {
    //                 if: { $eq: ['$siblingOrders', '$siblingDepth'] },
    //                 then: '$departmentName.en',
    //                 else: '$siblingOrders'
    //             }
    //         }
    //     }
    // })
    // .populate({
    //     path: 'childUsers',
    //     select: '_id userName jobTitle profileImage email personalPhoneNumber lastModifiedAt childStatusInfo listOrder',
    //     options: { sort: { listOrder: 1, 'userName.ko': 1, _id: 1 } },
    //     populate: [
    //         {
    //             path: 'childStatusInfo',
    //             select: 'statusCode'
    //         },
    //         {
    //             path: 'parentCompany',
    //             select: 'companyName'
    //         },
    //         {
    //             path: 'parentDepartment',
    //             select: 'departmentName'
    //         }
    //     ]
    // })
    // .lean();








  //   const companyDepartment = companyDepartmentModel({tenantFlag});

  //   const departmentInfo = await  companyDepartment.aggregate([
  //     { $match: { _id: id } },
  //     {
  //         $lookup: {
  //             from: 'parentDepartments',  // 부모 부서 컬렉션 이름
  //             localField: 'parentDepartments',
  //             foreignField: '_id',
  //             as: 'parentDepartments'
  //         }
  //     },
  //     {
  //         $lookup: {
  //             from: 'childDepartments',  // 자식 부서 컬렉션 이름
  //             localField: 'childDepartments',
  //             foreignField: '_id',
  //             as: 'childDepartments'
  //         }
  //     },
  //     {
  //         $lookup: {
  //             from: 'childUsers',  // 자식 사용자 컬렉션 이름
  //             localField: 'childUsers',
  //             foreignField: '_id',
  //             as: 'childUsers'
  //         }
  //     },
  //     {
  //         $project: {
  //             _id: 1,
  //             departmentName: 1,
  //             parentDepartments: {
  //                 $map: {
  //                     input: '$parentDepartments',
  //                     as: 'parent',
  //                     in: {
  //                         _id: '$$parent._id',
  //                         departmentName: '$$parent.departmentName'
  //                     }
  //                 }
  //             },
  //             childDepartments: {
  //                 $map: {
  //                     input: '$childDepartments',
  //                     as: 'child',
  //                     in: {
  //                         _id: '$$child._id',
  //                         departmentName: '$$child.departmentName',
  //                         totalChildUsers: '$$child.totalChildUsers',
  //                         lastModifiedAt: '$$child.lastModifiedAt',
  //                         childDepartments: '$$child.childDepartments',
  //                         level: '$$child.level',
  //                         siblingOrders: '$$child.siblingOrders',
  //                         siblingDepth: '$$child.siblingDepth'
  //                     }
  //                 }
  //             },
  //             childUsers: 1,
  //             totalChildUsers: 1,
  //             lastModifiedAt: 1
  //         }
  //     },
  //     {
  //         $addFields: {
  //             childDepartments: {
  //                 $map: {
  //                     input: '$childDepartments',
  //                     as: 'child',
  //                     in: {
  //                         _id: '$$child._id',
  //                         departmentName: '$$child.departmentName',
  //                         totalChildUsers: '$$child.totalChildUsers',
  //                         lastModifiedAt: '$$child.lastModifiedAt',
  //                         childDepartments: '$$child.childDepartments',
  //                         level: '$$child.level',
  //                         siblingOrders: '$$child.siblingOrders',
  //                         siblingDepth: '$$child.siblingDepth',
  //                         sortKey: {
  //                             $cond: {
  //                                 if: { $eq: ['$$child.siblingOrders', '$$child.siblingDepth'] },
  //                                 then: '$$child.departmentName.en',
  //                                 else: { $toString: '$$child.siblingOrders' }
  //                             }
  //                         }
  //                     }
  //                 }
  //             }
  //         }
  //     },
  //     {
  //         $unwind: {
  //             path: '$childDepartments',
  //             preserveNullAndEmptyArrays: true
  //         }
  //     },
  //     {
  //         $sort: {
  //             'childDepartments.level': 1,
  //             'childDepartments.sortKey': 1,
  //             'childDepartments.siblingDepth': 1
  //         }
  //     },
  //     {
  //         $group: {
  //             _id: '$_id',
  //             departmentName: { $first: '$departmentName' },
  //             parentDepartments: { $first: '$parentDepartments' },
  //             childDepartments: { $push: '$childDepartments' },
  //             childUsers: { $first: '$childUsers' },
  //             totalChildUsers: { $first: '$totalChildUsers' },
  //             lastModifiedAt: { $first: '$lastModifiedAt' }
  //         }
  //     }
  // ]).lean();





  const pipeline = [
    { $match: { _id: id } },
    {
        $lookup: {
            from: 'parentDepartments',
            localField: 'parentDepartments',
            foreignField: '_id',
            as: 'parentDepartments'
        }
    },
    {
        $lookup: {
            from: 'childDepartments',
            localField: 'childDepartments',
            foreignField: '_id',
            as: 'childDepartments'
        }
    },
    {
        $lookup: {
            from: 'childUsers',
            localField: 'childUsers',
            foreignField: '_id',
            as: 'childUsers'
        }
    },
    {
        $project: {
            _id: 1,
            departmentName: 1,
            parentDepartments: {
                $map: {
                    input: '$parentDepartments',
                    as: 'parent',
                    in: {
                        _id: '$$parent._id',
                        departmentName: '$$parent.departmentName'
                    }
                }
            },
            childDepartments: {
                $map: {
                    input: '$childDepartments',
                    as: 'child',
                    in: {
                        _id: '$$child._id',
                        departmentName: '$$child.departmentName',
                        totalChildUsers: '$$child.totalChildUsers',
                        lastModifiedAt: '$$child.lastModifiedAt',
                        childDepartments: '$$child.childDepartments',
                        level: '$$child.level',
                        siblingOrders: '$$child.siblingOrders',
                        siblingDepth: '$$child.siblingDepth',
                        sortKey: {
                            $cond: {
                                if: { $eq: ['$$child.siblingOrders', '$$child.siblingDepth'] },
                                then: '$$child.departmentName.en',
                                else: { $toString: '$$child.siblingOrders' }
                            }
                        }
                    }
                }
            },
            childUsers: 1,
            totalChildUsers: 1,
            lastModifiedAt: 1
        }
    },
    {
        $addFields: {
            childDepartments: {
                $map: {
                    input: '$childDepartments',
                    as: 'child',
                    in: {
                        _id: '$$child._id',
                        departmentName: '$$child.departmentName',
                        totalChildUsers: '$$child.totalChildUsers',
                        lastModifiedAt: '$$child.lastModifiedAt',
                        childDepartments: '$$child.childDepartments',
                        level: '$$child.level',
                        siblingOrders: '$$child.siblingOrders',
                        siblingDepth: '$$child.siblingDepth',
                        sortKey: '$$child.sortKey'
                    }
                }
            }
        }
    },
    {
        $unwind: {
            path: '$childDepartments',
            preserveNullAndEmptyArrays: true
        }
    },
    {
        $sort: {
            'childDepartments.level': 1,
            'childDepartments.sortKey': 1,
            'childDepartments.siblingDepth': 1
        }
    },
    {
        $group: {
            _id: '$_id',
            departmentName: { $first: '$departmentName' },
            parentDepartments: { $first: '$parentDepartments' },
            childDepartments: { $push: '$childDepartments' },
            childUsers: { $first: '$childUsers' },
            totalChildUsers: { $first: '$totalChildUsers' },
            lastModifiedAt: { $first: '$lastModifiedAt' }
        }
    }
];

// Aggregation 실행
const departmentInfo = await companyDepartmentModel.aggregate(pipeline).exec();












    console.log("last >>>>>>>>>>>>>>>>>>> ");
    console.log(departmentInfo);

    const rv = {
      ...departmentInfo,
      childDepartments: [...(departmentInfo.childDepartments ?? []).map((v: any) => {
        return {
          _id: v._id,
          hasSubChild: (v.childDepartments ?? []).length > 0,
          departmentName: v.departmentName,
          totalChildUsers: v.totalChildUsers,
          lastModifiedAt: v.lastModifiedAt,
        };
      })],
      hasSubChild: departmentInfo.childDepartments.length > 0,
    };

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        departmentInfo: rv,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }


};



export default getDepartmentById;
