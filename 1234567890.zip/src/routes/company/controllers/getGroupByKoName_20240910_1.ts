/* eslint-disable indent */
import Koa from 'koa';

import companyGroupModel from 'models/company/company_group_info';
import companyCompanyModel from 'models/company/company_company_info';

const getGroupByKoName = async (ctx: Koa.Context) => {
  try {
    const {groupName} = ctx.query;

    if (!groupName) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');

    // compile before populate
    companyCompanyModel({tenantFlag});

    const groupInfo = await companyGroupModel({ tenantFlag })
          .findOne({ 'groupName.ko': groupName })
          .populate({
                      path: 'childCompanies',
                      match: { useYn: 'Y' },
                      select: '-childDepartments',
                      options: { sort: { companyCode: 1 } }
                    });

    if (groupInfo === null) {
      ctx.status = 404;
      ctx.body = {
        'success': false,
        'error': 'no content',
      };

      return;
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        groupInfo,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getGroupByKoName;
