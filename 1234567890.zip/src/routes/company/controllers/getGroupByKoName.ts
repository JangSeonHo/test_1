/* eslint-disable indent */
import Koa from 'koa';

import companyGroupModel from 'models/company/company_group_info';
import companyCompanyModel from 'models/company/company_company_info';
import companyDetailModel from 'models/company/company_detail';

import userInfoModel from 'models/account/user_info';
import userSignModel from 'models/account/user_sign_info';
import mongoose from 'mongoose';

const getGroupByKoName = async (ctx: Koa.Context) => {
  try {
    const {groupName} = ctx.query;

    if (!groupName) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');
    const headers = ctx.headers;
    const accessToken = headers['access-token'] as string ?? ctx.query.accessToken ?? '';
    // console.log('getGroupByKoName headers :', headers);
    let isCallSearch = false;
    let isMyCompanyOnly = false;
    let companyIds: any[] = [];

    if (!!accessToken) {
      const userSignInfo = await userSignModel({tenantFlag}).findOne({
        'accessToken': accessToken,
      }).select('parentUser');

      if (!!userSignInfo) {
        isCallSearch = true;
        const userInfo = await userInfoModel({tenantFlag}).findOne({
          _id: userSignInfo.parentUser,
        }).populate('parentCompany', '_id');

        const comDetails = await companyDetailModel({tenantFlag}).find({})
          .select('parentCompany useCompanyOnlyYn').lean();
        const myCompanyDetail = comDetails.filter((detail: any) => detail.parentCompany == String(userInfo.parentCompany._id));
        isMyCompanyOnly = myCompanyDetail[0].useCompanyOnlyYn === 'Y';
        // parentCompany: userInfo.parentCompany._id
        const normalCompanies = comDetails.filter((details) => {
          return details.useCompanyOnlyYn != 'Y';
        });
        companyIds = isMyCompanyOnly ?
          [userInfo.parentCompany._id] :
          normalCompanies.map((com) => new mongoose.Types.ObjectId(com.parentCompany));
      }
    }

    // compile before populate
    companyCompanyModel({tenantFlag});
    const matchValue = isCallSearch ? {useYn: 'Y', _id: {$in: companyIds}} : {useYn: 'Y'};
    const groupInfo = await companyGroupModel({tenantFlag})
      .findOne({'groupName.ko': groupName})
      .populate({
        path: 'childCompanies',
        match: matchValue,
        select: '-childDepartments',
        options: {sort: {sortNo: 1}},
      });

    if (groupInfo === null) {
      ctx.status = 404;
      ctx.body = {
        'success': false,
        'error': 'no content',
      };

      return;
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        groupInfo,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getGroupByKoName;
