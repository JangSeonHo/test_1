// note member info를 삭제

import Koa from 'koa';

import noteMemberModel from 'models/note/note_member';
import userBadgeModel from 'models/account/user_badge';

const deleteNotes = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {noteIds} = ctx.request.body as any;

    const targetModel = noteMemberModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});
    let sumUnreadUpdateCnt = 0;
    await Promise.all(noteIds.map(async (noteId: string) => {
      const noteMember = await targetModel.findOne({_id: noteId});

      if (noteMember.type === 'R') {
        if (!noteMember.isRead && !noteMember?.isDeleted) {
          sumUnreadUpdateCnt++;
        }
        await targetModel.updateOne({_id: noteMember._id}, {
          'isDeleted': true,
        });
      } else {
        await targetModel.deleteOne({_id: noteMember._id});
      }
    }));

    if (sumUnreadUpdateCnt > 0) {
      await TargetUserBadgeModel.updateOne({parentUser: userId}, {
        $inc: {unreadNotes: (-1 * sumUnreadUpdateCnt)},
      });
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default deleteNotes;
