/* eslint-disable max-len */
/* eslint-disable new-cap */
import Koa from 'koa';

import noteInfoModel from 'models/note/note_info';
import noteMemberModel from 'models/note/note_member';
import userSignInfo from 'models/account/user_sign_info';
import userInfoModel from 'models/account/user_info';
import userBadgeModel from 'models/account/user_badge';
import {getUserBadgePrimaryOnly} from 'utils/account/getUserBadge';
import isValidAlarmTime from 'utils/alarm/isValidAlarmTime';
import userStatusInfoModel from '../../../models/account/user_status_info';
import {UserStatusCode} from '../../../constants/commonConstants';

import pushIntegration from 'utils/push/pushIntegration';
import createMsgLogForAuditfile from '../../../utils/log/create_msg_log_for_auditfile';
import departmentModel from 'models/company/company_department_info';

const sendNote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {
      title,
      content,
      sendTo,
      fileFolderId = '',
      attachedFiles = [],
      attachedImages = [],
    } = ctx.request.body as any;

    const targetNoteInfoModel = noteInfoModel({tenantFlag});
    const targetNoteMemberModel = noteMemberModel({tenantFlag});
    const TargetUserSignInfo = userSignInfo({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});
    const TargetUserModel = userInfoModel({tenantFlag});
    departmentModel({tenantFlag});

    const createdAt = new Date().getTime();

    const me = await TargetUserModel.findOne({_id: userId})
      .select('userName jobTitle emailId empNo parentCompany parentDepartment')
      .populate([
        {
          path: 'parentDepartment',
          select: 'departmentName',
        },
      ]);
    const us = await Promise.all(sendTo.map(async (st: string) => {
      const u = await TargetUserModel.findOne({_id: st}).select('userName');
      return u.userName;
    }));

    const usko = us.map((u: any) => u['ko']).join(' ');
    const usen = us.map((u: any) => u['en']).join(' ');

    const note = new targetNoteInfoModel({
      'sender': userId,
      'receivers': sendTo,
      'senderUserName': me.userName,
      'receiverUserNames': {
        ko: usko,
        en: usen,
      },
      title,
      content,
      fileFolderId,
      attachedFiles,
      attachedImages,
      createdAt,
    });

    const senderMember = new targetNoteMemberModel({
      parentUser: userId,
      type: 'S',
      parentNote: note._id,
      createdAt,
    });

    await Promise.all([
      note.save(),
      senderMember.save(),
    ]);

    await Promise.all(sendTo.map(async (uid: string) => {
      const nm = new targetNoteMemberModel({
        parentNote: note._id,
        type: 'R',
        parentUser: uid,
        createdAt,
      });

      await Promise.all([
        nm.save(),
        TargetUserBadgeModel.updateOne({parentUser: uid}, {
          $inc: {unreadNotes: 1},
        }),
      ]);
    }));

    const tokens: Array<string> = [];
    const locales: any = [];
    const os: any = [];
    const badges: any = [];

    await Promise.all(sendTo.map(async (member: any) => {
      const pushTargets = await TargetUserSignInfo
        .find({
          parentUser: member,
          $or: [{deviceType: 'android'}, {deviceType: 'ios'}, {deviceType: 'iPad'}],
          usePushAlarm: true,
          useAlarmNote: true,
        }).select('pushToken useAlarmAllowedTime useEnUserInfo deviceType onlyAlarmWhenPCIsAbsence timezoneOffset alarmAllowedTime');
      const userStatus = await userStatusInfoModel({tenantFlag})
        .findOne({parentUser: member})
        .select('pcStatus mobileStatus').lean();

      await Promise.all(pushTargets.map(async ({pushToken, useAlarmAllowedTime, useEnUserInfo, deviceType, onlyAlarmWhenPCIsAbsence, timezoneOffset, alarmAllowedTime}) => {
        if (onlyAlarmWhenPCIsAbsence && userStatus!.hasOwnProperty('pcStatus') && userStatus!.hasOwnProperty('mobileStatus')) {
          // if (userStatus.pcStatus === 'online' && (userStatus.statusCode === '온라인' || userStatus.statusCode === '재택')) {
          // @ts-ignore
          if ((userStatus.pcStatus === UserStatusCode.ONLINE || userStatus.pcStatus === 'online') && userStatus.mobileStatus === UserStatusCode.ONLINE) {
            return;
          }
        }

        if (useAlarmAllowedTime) {
          if (!isValidAlarmTime(timezoneOffset, alarmAllowedTime.start, alarmAllowedTime.end)) {
            return;
          }
        }

        if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
          const badge = await getUserBadgePrimaryOnly(member, tenantFlag);
          badges.push(badge);
          tokens.push(pushToken);
          locales.push(useEnUserInfo ? 'en' : 'ko');
          os.push(deviceType);
        }
      }));
    }));


    if (tokens.length !== 0) {
      const user: any = await userInfoModel({tenantFlag}).findOne({_id: userId})
        .select('userName jobTitle');

      // 파일 종류에 따라 다른 푸쉬
      // const message = {
      //   data: {type: 'note', id: note._id.toString()},
      //   notification: {
      //     title: `${user.userName['ko']} ${user.jobTitle['ko']}`,
      //     body: '쪽지가 도착했습니다',
      //   },
      //   tokens,
      // };

      // admin.messaging().sendMulticast(
      //   message as admin.messaging.MulticastMessage);

      tokens.forEach((token: string, i: number) => {
        const notification = {
          title: `${user.userName[locales[i] ?? 'ko']} ${user.jobTitle[locales[i] ?? 'ko']}`,
          body: '쪽지가 도착했습니다',
        };

        const msg: any = {
          data: {type: 'note', id: note._id.toString(), ...notification, badge: badges[i].toString()},
          token: token,
        };

        if (os[i] === 'android') {
          msg.android = {
            priority: 'HIGH',
          };
        }

        if (os[i] === 'ios' || os[i] === 'iPad') {
          msg.notification = notification;
          msg.apns = {
            payload: {
              aps: {
                sound: 'default',
                badge: badges[i],
              },
            },
          };
        }

        // admin.messaging().send(msg);
        pushIntegration(msg, false);
      });
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        note: {_id: note._id},
      },
    };

    setImmediate(() => {
      const deptName = me.parentDepartment.departmentName.ko ?? '';
      createMsgLogForAuditfile({logType: 'note', data: {
          noteId: note._id,
          userId,
          content,
          regDate: createdAt,
          userName: me.userName.ko ?? '',
          jobTitle: me.jobTitle.ko ?? '',
          emailId: me.emailId ?? '',
          empNo: me.empNo ?? '',
          parentCompany: me.parentCompany.toString(),
          deptName,
        }});
    });
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default sendNote;
