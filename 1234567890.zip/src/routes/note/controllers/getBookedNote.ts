import Koa from 'koa';
import bookedNoteInfoModel from 'models/note/booked_note';
import userInfoModel from 'models/account/user_info';
import departmentModel from 'models/company/company_department_info';
import companyModel from 'models/company/company_company_info';

const getBookedNote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {noteId} = ctx.query;

    // population
    userInfoModel({tenantFlag});
    departmentModel({tenantFlag});
    bookedNoteInfoModel({tenantFlag});
    companyModel({tenantFlag});
    //

    const note = await bookedNoteInfoModel({tenantFlag}).findOne({
      _id: noteId,
      sender: userId,
    })
    .populate([
      {
        path: 'sender',
        // eslint-disable-next-line max-len
        select: '_id userName jobTitle parentDepartment parentCompany profileImage',
        populate: [
          {
            path: 'parentDepartment',
            select: 'departmentName',
          },
          {
            path: 'parentCompany',
            select: 'companyName',
          },
        ],
      },
      {
        path: 'receivers',
        select: '_id userName jobTitle parentDepartment profileImage',
        populate: [{
          path: 'parentDepartment',
          select: 'departmentName',
        }, {
          path: 'parentCompany',
          select: 'companyName',
        }],
      },
    ]);

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {note},
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getBookedNote;
