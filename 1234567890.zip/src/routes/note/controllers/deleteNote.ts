// note member info를 삭제

import Koa from 'koa';

import noteMemberModel from 'models/note/note_member';
import userBadgeModel from '../../../models/account/user_badge';

const deleteNote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {noteId} = ctx.request.body as any;

    const targetModel = noteMemberModel({tenantFlag});
    const targetUserBadgeModel = userBadgeModel({tenantFlag});
    const noteMember = await targetModel.findOne({parentNote: noteId, parentUser: userId});

    if (noteMember.type === 'R') {
      await targetModel.updateOne({parentNote: noteId, parentUser: userId}, {
        'isDeleted': true,
      });
      if (!noteMember.isRead && !noteMember?.isDeleted) {
        await targetUserBadgeModel.updateOne({
          parentUser: userId,
          unreadNotes: {$gt: 0}}, {
            $inc: {unreadNotes: -1},
        });
      }
    } else {
      await targetModel.deleteOne({parentNote: noteId, parentUser: userId});
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default deleteNote;
