import Koa from 'koa';

import {noteMemberModelPrimaryOnly} from 'models/note/note_member';
import userBadgeModel from 'models/account/user_badge';

const readNote = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const {noteMemberId, noteId} = ctx.request.body as any;

    const TargetNoteModel = await noteMemberModelPrimaryOnly({tenantFlag});
    const TargetBadgeModel = await userBadgeModel({tenantFlag});

    const query: any = {parentUser: userId};
    if (noteMemberId !== undefined) {
      query._id = noteMemberId;
    }
    if (noteId !== undefined) {
      query.parentNote = noteId;
      query.type = 'R';
    }

    const pre = await TargetNoteModel.findOne(query);
    if (pre !== null && !pre.isRead && !pre?.isDeleted) {
      await Promise.all([
        TargetNoteModel.updateOne(query, {
          isRead: true,
          readAt: new Date().getTime(),
        }),
        TargetBadgeModel.updateOne({
          parentUser: userId,
          unreadNotes: {$gt: 0}}, {
            $inc: {unreadNotes: -1},
        }),
      ]);
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default readNote;
