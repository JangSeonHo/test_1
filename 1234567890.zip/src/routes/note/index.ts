/* eslint-disable max-len */
import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

import Router from '@koa/router';
const router = new Router();

import sendNote from './controllers/sendNote';
router.post('/sendNote', isLoggedIn, sendNote);

import sendBookedNote from './controllers/sendBookedNote';
router.post('/sendBookedNote', isLoggedIn, sendBookedNote);

import getNote from './controllers/getNote';
router.get('/getNote', isLoggedIn, getNote);

import getNotes from './controllers/getNotes';
router.get('/getNotes', isLoggedIn, logApiAccess, getNotes);

import getBookedNote from './controllers/getBookedNote';
router.get('/getBookedNote', isLoggedIn, getBookedNote);

import getBookedNotes from './controllers/getBookedNotes';
router.get('/getBookedNotes', isLoggedIn, getBookedNotes);

import getNoteReadMembers from './controllers/getNoteReadMembers';
router.get('/getNoteReadMembers', isLoggedIn, getNoteReadMembers);

import deleteNote from './controllers/deleteNote';
router.post('/deleteNote', isLoggedIn, deleteNote);

import deleteNotes from './controllers/deleteNotes';
router.post('/deleteNotes', isLoggedIn, deleteNotes);

import bookNote from './controllers/bookNote';
router.post('/bookNote', isLoggedIn, bookNote);

import deleteBookedNotes from './controllers/deleteBookedNotes';
router.post('/deleteBookedNotes', isLoggedIn, deleteBookedNotes);

import readNote from './controllers/readNote';
router.post('/readNote', isLoggedIn, readNote);

import cancelUnreadNote from './controllers/cancelUnreadNote';
router.post('/cancelUnreadNote', isLoggedIn, cancelUnreadNote);

// *check s3 //
// import uploadNoteFilesMiddleware from 'middlewares/uploadNoteFiles';
// import uploadNoteFiles from './controllers/uploadNoteFiles';
// router.post('/uploadNoteFiles', isLoggedIn, uploadNoteFilesMiddleware, uploadNoteFiles);

// *check s3 //
// import uploadNoteImagesMiddleware from 'middlewares/uploadNoteImages';
// import uploadNoteImages from 'middlewares/uploadNoteImages';
// router.post('/uploadNoteImages', isLoggedIn, uploadNoteImagesMiddleware, uploadNoteImages);

import modifyBookedNote from './controllers/modifyBookedNote';
router.post('/modifyBookedNote', isLoggedIn, modifyBookedNote);

export default router;
