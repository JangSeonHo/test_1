// middlewares
import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

import Router from '@koa/router';
const router = new Router();

import getS3UploadUrl from './controllers/getS3UploadUrl';
router.post('/getS3UploadUrl', isLoggedIn, logApiAccess, getS3UploadUrl);

import getS3DownloadUrl from './controllers/getS3DownloadUrl';
router.post('/getS3DownloadUrl', isLoggedIn, logApiAccess, getS3DownloadUrl);

import getUnlimitDownloadUrl from './controllers/getUnlimitDownloadUrl';
router.post('/getUnlimitDownloadUrl', getUnlimitDownloadUrl);

export default router;
