import Koa from 'koa';
import {PutObjectCommand, S3Client} from '@aws-sdk/client-s3';
import {
  getSignedUrl,
} from '@aws-sdk/s3-request-presigner';

import {s3Bucket} from 'configs/s3';

const REGION = 'ap-northeast-2';

import companyInfoModel from 'models/company/company_company_info';
import userModel from 'models/account/user_info';
import blockedIpRangeModel from '../../../models/system/blocked_ip_range_file_transmit';

const s3Client = new S3Client({region: REGION});

const getS3UploadUrl = async (ctx: Koa.Context) => {
  try {
    const {key} = ctx.request.body;
    const deviceType = ctx.response.get('deviceType');

    const splits = key.split('.');
    const ext = splits[splits.length - 1].toLowerCase();
    const allowdExts = [
      'png', 'jpeg', 'jpg', 'webp', 'gif', 'bmp',
      'xlsx', 'xls', 'ppt', 'pptx', 'doc', 'docx',
      'pdf', 'txt', 'zip',
      'mp4', 'avi', 'mov', 'm4v',
    ];

    if (!allowdExts.includes(ext)) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'invalid file key',
      };

      return;
    }

    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const userData = await userModel({tenantFlag}).findOne({_id: userId})
      .select('parentCompany');
    let uploadCheck = true;

    if (deviceType === 'android' || deviceType === 'ios') {
      uploadCheck = true;
    }
    // 업로드 블랙리스트 IP대역 테스트 중 - 권오중
    if (deviceType === 'win32') {
      const {companyCode} = await companyInfoModel({tenantFlag})
        .findOne({_id: userData.parentCompany})
        .select('companyCode');
      // console.log('companyCode :', companyCode);
      const blockInfo = await blockedIpRangeModel({tenantFlag})
        .find({
          upload: true,
          $or: [{parentCompanyCode: companyCode}, {parentCompanyCode: 'ALL'}],
        })
        .select('ipRangeStart ipRangeEnd');

      let clientIP = String(ctx.request.headers['x-forwarded-for'] || ctx.request.socket.remoteAddress || '');
      clientIP = clientIP.replace(/^.*:/, '');
      // console.log('클라이언트 IP :', clientIP);
      const arrIP = clientIP.split('.');
      const decClientIP = ((((((+arrIP[0])*256)+(+arrIP[1]))*256)+(+arrIP[2]))*256)+(+arrIP[3]);
      // console.log('클라이언트 IP decimal :', decClientIP);
      // let isBlockedIP = false;
      blockInfo.forEach((range: any) => {
        if (range.ipRangeStart <= Number(decClientIP) && range.ipRangeEnd >= Number(decClientIP)) {
          uploadCheck = false;
        }
      });
    }

    console.log("[getS3UploadUrl][uploadCheck] >>> ", uploadCheck);

    if (uploadCheck) {
      // eslint-disable-next-line max-len
      const command = new PutObjectCommand({Bucket: s3Bucket, Key: `${userData.parentCompany}/${key}`});
      const url = await getSignedUrl(s3Client, command, {expiresIn: 3600});

      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {url},
      };
    } else {
      ctx.status = 403;
      ctx.body = {
        'success': true,
        'code': -3,
        'error': 'permission denied',
      };
    }
  } catch (err) {
    console.log(err);

    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getS3UploadUrl;
