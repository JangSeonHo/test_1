import Koa from 'koa';
import {PutObjectCommand, S3Client} from '@aws-sdk/client-s3';
import {
  getSignedUrl,
} from '@aws-sdk/s3-request-presigner';

import {s3Bucket} from 'configs/s3';

const REGION = 'ap-northeast-2';

import companyInfoModel from 'models/company/company_company_info';
import userModel from 'models/account/user_info';
import blockedIpRangeModel from 'models/system/blocked_ip_range_file_transmit';
import convertIpToDecimal from 'utils/string/convertIpToDecimal';
import companyDetailModel from 'models/company/company_detail';
import {
  ALLOWED_EXTS,
  ENCKEYFORPARAM,
  CHINA_FILE_DOMAIN,
  ENCRYPT_APPVERSION,
} from 'constants/commonConstants';
import {decryptBodyParams, encryptURL} from 'utils/cipher';
import {encryptBodyParams} from 'utils/cipher';
import compareVersions from '../../../utils/string/compareVersions';

const s3Client = new S3Client({region: REGION});

const getS3UploadUrl = async (ctx: Koa.Context) => {
  try {
    let {key, isEmoticon, encParam, isChinaMode} = ctx.request.body;
    let deviceType = ctx.response.get('deviceType');
    let versionInfo = (ctx.headers['version-info'] as string) ?? '';
    isChinaMode = typeof isChinaMode === 'string' && isChinaMode == 'true';
    // console.log('[getS3UploadUrl]$$$$$$$$ enc test :', encryptBodyParams(ctx.request.body, ENCKEYFORPARAM));

    if (!!encParam) {
      const decryptRes = decryptBodyParams(encParam, ENCKEYFORPARAM);

      if (!decryptRes.success) {
        ctx.status = 403;
        ctx.body = {
          'success': true,
          'code': -4,
          'error': 'permission denied',
        };
        return;
      }
      key = decryptRes.params['key'];
      isEmoticon = decryptRes.params['isEmoticon'];
      deviceType = decryptRes.params['deviceType'];
      versionInfo = decryptRes.params['versionInfo'];
      isChinaMode = decryptRes.params['isChinaMode'];
    }

    const splits = key.split('.');
    console.log("[getS3UploadUrl][deviceType][key] >>> ", deviceType, key);
    const ext = splits[splits.length - 1].toLowerCase();
    const allowdExts = ALLOWED_EXTS;
    let isBlacklist = false;

    if (!allowdExts.includes(ext)) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'invalid file key',
      };
      return;
    }

    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');
    console.log("[getS3UploadUrl][userId] >>> ", userId);

    let uploadCheck = false;
    const userData = await userModel({tenantFlag}).findOne({_id: userId})
      .select('parentCompany');
    const companyDetail = await companyDetailModel({tenantFlag})
      .findOne({parentCompany: String(userData.parentCompany)})
      .select('fileControlAuthorityPc fileControlAuthorityMobile');

    if ((deviceType === 'win32' || deviceType === 'macos') && companyDetail.fileControlAuthorityPc.includes('U')) {
      uploadCheck = true;
    }
    if (deviceType !== 'win32' && deviceType !== 'macos' && companyDetail.fileControlAuthorityMobile.includes('U')) {
      uploadCheck = true;
    }

    if (!!isEmoticon) { // 이모티콘 업로드 예외
      uploadCheck = true;
    } else if (uploadCheck && (deviceType === 'win32' || deviceType === 'macos')) { // 업로드 블랙리스트 IP대역
      const {companyCode} = await companyInfoModel({tenantFlag})
        .findOne({_id: userData.parentCompany})
        .select('companyCode');
      //   // console.log('companyCode :', companyCode);
      const blockInfo = await blockedIpRangeModel({tenantFlag})
        .find({
          upload: true,
          $or: [{parentCompanyCode: companyCode}, {parentCompanyCode: 'ALL'}],
        })
        .select('ipRangeStart ipRangeEnd');

      let tmpClientIP = String(ctx.request.headers['x-forwarded-for'] || '');
      if (tmpClientIP.includes(',') && typeof tmpClientIP === 'string') {
        // @ts-ignore
        tmpClientIP = tmpClientIP.split(',');
      }
      const ipArr = Array.isArray(tmpClientIP) ? tmpClientIP : [tmpClientIP];
      ipArr.forEach((ipVal) => {
        const decClientIP = convertIpToDecimal(ipVal);
        // console.log('클라이언트 IP decimal :', decClientIP);
        blockInfo.forEach((range: any) => {
          if (range.ipRangeStart <= Number(decClientIP) && range.ipRangeEnd >= Number(decClientIP)) {
            uploadCheck = false;
            isBlacklist = true;
          }
        });
      });
    }

    if (key.startsWith("profileImages/") && !isBlacklist) {
      uploadCheck = true;
    } // 프로필이미지는 권한 체크 skip

    console.log("[getS3UploadUrl][uploadCheck] >>> ", uploadCheck);

    if (uploadCheck) {
      // eslint-disable-next-line max-len
      const command = new PutObjectCommand({
        Bucket: s3Bucket,
        Key: `${userData.parentCompany}/${key}`,
        // CacheControl: 'no-cache',
      });
      let url = '';
      if (!isChinaMode || compareVersions(versionInfo, '0.7.77') < 0) { // TODO - 중국 파일 업/다운 적용버전 몇??
        url = await getSignedUrl(s3Client, command, {expiresIn: 600});
      } else {
        url = `https://${CHINA_FILE_DOMAIN}/${userData.parentCompany}/${key}`;
      }
      // console.log('[getS3UploadUrl][URL] >>> ', url);

      if (!!encParam) {
        url = encryptURL(url, ENCKEYFORPARAM).url;
      }

      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {url},
      };
    } else {
      ctx.status = 403;
      ctx.body = {
        'success': true,
        'code': -3,
        'error': 'permission denied',
      };
    }
  } catch (err) {
    console.log(err);

    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getS3UploadUrl;
