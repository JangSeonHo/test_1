/* eslint-disable max-len */
import Koa from 'koa';
import {GetObjectCommand, S3Client} from '@aws-sdk/client-s3';
import {
  getSignedUrl,
} from '@aws-sdk/s3-request-presigner';

//다운로드 S3버킷은 운영에만 존재함다.
const s3Bucket = "nmp-s3-download-prd";

//import {s3Bucket} from 'configs/s3';

const REGION = 'ap-northeast-2';
const s3Client = new S3Client({region: REGION});

const getUnlimitDownloadUrl = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const {key} = ctx.request.body;

    const command = new GetObjectCommand({Bucket: s3Bucket, Key: key});
    const url = await getSignedUrl(s3Client, command, {expiresIn: 3600});

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'code' : 0,
      'data': {url},
    };

  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'code' : -1,
      'error': 'internal server error',
    };
  }
};

export default getUnlimitDownloadUrl;
