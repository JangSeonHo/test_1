/* eslint-disable max-len */
import Koa from 'koa';
import {GetObjectCommand, S3Client} from '@aws-sdk/client-s3';
import {
  getSignedUrl,
} from '@aws-sdk/s3-request-presigner';

import {s3Bucket} from 'configs/s3';
import userInfoModel from 'models/account/user_info';
import companyInfoModel from 'models/company/company_company_info';

const REGION = 'ap-northeast-2';
const s3Client = new S3Client({region: REGION});

const getS3DownloadUrl = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {key} = ctx.request.body as { key: string };


    const companyId = key.split('/')[0];
    const {parentCompany} = await userInfoModel({tenantFlag}).findOne({_id: userId})
      .select('parentCompany');
    const {fileAllowedCompanies} = await companyInfoModel({tenantFlag})
      .findOne({_id: companyId})
      .select('fileAllowedCompanies');

    if (companyId !== parentCompany && !fileAllowedCompanies.includes(parentCompany)) {
      ctx.status = 403;
      ctx.body = {
        'success': true,
        'code' : -2,
        'error': 'permission denied',
      };

      return;
    }

    const command = new GetObjectCommand({Bucket: s3Bucket, Key: key});
    const url = await getSignedUrl(s3Client, command, {expiresIn: 3600});

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'code' : 0,
      'data': {url},
    };

    // ctx.status = 403;
    // ctx.body = {
    //   'success': true,
    //   'code' : -2,
    //   'error': 'permission denied',
    // };

  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'code' : -1,
      'error': 'internal server error',
    };
  }
};

export default getS3DownloadUrl;
