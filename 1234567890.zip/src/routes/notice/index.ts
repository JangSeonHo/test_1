import Router from '@koa/router';
const router = new Router();

import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

import createSystemNotice from './controllers/createSystemNotice';
import getSystemNotices from './controllers/getSystemNotices';
import getAdminNotificationsById from './controllers/getAdminNotificationsById';
import getAdminNotifications from './controllers/getAdminNotifications';
import getAdminNotificationMain from './controllers/getAdminNotificationMain';
import updateAdminNotification from './controllers/updateAdminNotification';


// eslint-disable-next-line max-len
router.post('/createSystemNotice', logApiAccess, createSystemNotice);
router.get('/getSystemNotices', isLoggedIn, logApiAccess, getSystemNotices);
router.post('/getAdminNotificationsById', isLoggedIn, logApiAccess, getAdminNotificationsById);
router.post('/getAdminNotifications', isLoggedIn, logApiAccess, getAdminNotifications);
router.post('/getAdminNotificationMain', isLoggedIn, logApiAccess, getAdminNotificationMain);
router.post('/updateAdminNotification', isLoggedIn, logApiAccess, updateAdminNotification);

export default router;
