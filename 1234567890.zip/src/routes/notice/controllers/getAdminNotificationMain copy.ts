import Koa from 'koa';
import adminNotificationModel from 'models/notice/admin_notice';
const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;


const getAdminNotificationMain = async (ctx: Koa.Context) => {
    try {
        const {
            companyId,
        } = ctx.request.body as any;

        const filter = new ObjectId(companyId);

        const tenantFlag = ctx.response.get('tenantFlag');

        const TargetAdminNotificationModel = adminNotificationModel({tenantFlag});

        const currentDate = new Date();
        console.log(currentDate);
        console.log(new Date().getTime());



// 대한민국 시간으로 변환
const koreaOffset = 9 * 60; // 9시간을 분 단위로 변환
const koreaTime = new Date(currentDate.getTime() + koreaOffset * 60 * 1000);

console.log(`UTC Time: ${currentDate.toISOString()}`);
console.log(`KST Time: ${koreaTime.toISOString().replace('Z', '+09:00')}`);





        const list = await TargetAdminNotificationModel.aggregate([
          {
            $match: {
              notiGroupTarget: { $in: [filter] },
              type: "Pop-up notice",
              startDate: { $lte: koreaTime },
              $or: [
                { endDate: { $gte: koreaTime } },
                { endDate: { $exists: false } }
              ],
              status: "Use"
            }
          },
          {
              $project: {
                  _id: 1,
                  title: 1,
                  content: 1,
                  startDate: 1,
                  endDate: 1,
                  image: 1,
              }
          }
        ]);

        ctx.status = 200;
        ctx.body = {
            success: true,
            data : list
        };
    } catch (err) {
        ctx.status = 500;
        ctx.body = {
            'success': false,
            'error': 'internal server error',
        };
    }
};

export default getAdminNotificationMain;