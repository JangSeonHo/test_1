import Koa from 'koa';
import adminNotificationModel from 'models/notice/admin_notice';
import userInfoModel from 'models/account/user_info';
import path from 'path'; // 확장자 추출을 위한 모듈

const getAdminNotificationsById = async (ctx: Koa.Context) => {
    try {
        const { noticeId } = ctx.request.body as any;
        const tenantFlag = ctx.response.get('tenantFlag');

        const TargetAdminNotificationModel = adminNotificationModel({ tenantFlag });
        const TargetUserInfoModel = userInfoModel({ tenantFlag });

        const notiDetail = await TargetAdminNotificationModel
            .findOne({ _id: noticeId })
            .select('-_id title content views status image files type views creator startDate endDate createdAt updatedAt');

        if (notiDetail) {
            // MongoDB 문서 객체를 일반 JS 객체로 변환
            const notiDetailObj = notiDetail.toObject();

            // 1. createdAt, updatedAt을 유닉스 타임스탬프로 변환 (밀리세컨드)
            notiDetailObj.createdAt = new Date(notiDetail.createdAt).getTime();
            notiDetailObj.updatedAt = new Date(notiDetail.updatedAt).getTime();

            // creator.email로 userInfoModel에서 사용자 정보 조회
            const userInfo = await TargetUserInfoModel
                .findOne({ email: notiDetail.creator?.email })  // creator가 없는 경우를 대비해 optional chaining 사용
                .sort({ createdAt: -1 })  // createdAt 내림차순
                .limit(1)
                .select('userName jobTitle email');

            // userInfo가 없거나 null이면 notiDetailObj.creatorInfo는 null로 설정
            notiDetailObj.creatorInfo = userInfo || null;

            // 2. files 배열의 각 파일의 MIME 타입 추출
            notiDetailObj.files = notiDetailObj.files.map((file: any) => {
                const ext = path.extname(file.originalName).toLowerCase().replace('.', ''); // 확장자 추출

                // 확장자에 따른 MIME 타입 분류
                let mimeType;
                if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(ext)) {
                    mimeType = 'image';
                } else if (['mp4', 'avi', 'mov'].includes(ext)) {
                    mimeType = 'video';
                } else if (['xlsx', 'docx', 'pptx', 'xls', 'doc', 'ppt'].includes(ext)) {
                    mimeType = ext; // 해당 확장자는 그대로 MIME 타입으로 사용
                } else {
                    mimeType = ext; // 기타 파일 형식은 ext
                }

                // MIME 타입 추가
                return {
                    ...file,
                    mimeType
                };
            });

            // 조회수 증가
            await TargetAdminNotificationModel.updateOne({ _id: noticeId }, {
                $inc: { views: 1 }
            });

            ctx.status = 200;
            ctx.body = {
                success: true,
                data: notiDetailObj // 일반 객체를 응답으로 보냄
            };
        } else {
            ctx.status = 404;
            ctx.body = {
                success: false,
                error: 'Notification not found'
            };
        }
    } catch (err) {
        ctx.status = 500;
        ctx.body = {
            success: false,
            error: 'internal server error',
        };
    }
};

export default getAdminNotificationsById;
