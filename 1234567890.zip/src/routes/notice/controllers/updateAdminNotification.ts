import Koa from 'koa';
import adminNotificationModel from 'models/notice/admin_notice';
import userInfoModel from 'models/account/user_info';

const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;

const updateAdminNotification = async (ctx: Koa.Context) => {
	try {
		const tenantFlag = ctx.response.get('tenantFlag');
		const userId = ctx.response.get('userId');

		const {noticeId} = ctx.request.body as any;

		const TargetAdminNotificationModel = adminNotificationModel({tenantFlag});

		await TargetAdminNotificationModel.updateOne({_id: noticeId}, {
			$inc: {views: 1}
		});

		ctx.status = 200;
    ctx.body = {
      'success': true,
    };

	} catch (err) {
		ctx.status = 500;
		ctx.body = {
			'success': false,
			'error': 'internal server error',
		};
	}
};

export default updateAdminNotification;