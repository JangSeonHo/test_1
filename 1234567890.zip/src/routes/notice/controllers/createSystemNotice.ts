import Koa from 'koa';

import systemNoticeModel from 'models/notice/system_notice';

const createSystemNotice = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const {title, content} = ctx.request.body as any;

    const TargetSystemNoticeModel = systemNoticeModel({tenantFlag});

    const nm = new TargetSystemNoticeModel({
      title,
      content,
      createdAt: new Date().getTime(),
    });

    await nm.save();

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default createSystemNotice;
