import Koa from 'koa';
import adminNotificationModel from 'models/notice/admin_notice';
const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;


const getAdminNotifications = async (ctx: Koa.Context) => {
    try {
        const {
            companyId,
        } = ctx.request.body as any;

        const filter = new ObjectId(companyId);

        const tenantFlag = ctx.response.get('tenantFlag');

        const TargetAdminNotificationModel = adminNotificationModel({tenantFlag});

      //   const tmpList = await TargetAdminNotificationModel
      //   .find({ notiGroupTarget: { $in: [filter] } })
      //   .select('_id title content createdAt updatedAt files');


      //   const list = tmpList.map(item => ({
      //     _id: item._id,
      //     title: item.title,
      //     content: item.content,
      //     createdAt: item.createdAt,
      //     updatedAt: item.updatedAt,
      //     filesYn: item.files && item.files.length > 0 ? 'Y' : 'N'
      // }));



  const list = await TargetAdminNotificationModel.aggregate([
    { $match: { notiGroupTarget: { $in: [filter] } } },
    {
        $project: {
            _id: 1,
            title: 1,
            content: 1,
            createdAt: 1,
            updatedAt: 1,
            filesYn: { $cond: { if: { $gt: [{ $size: "$files" }, 0] }, then: "Y", else: "N" } }
        }
    }
  ]);



        console.log(list.length);

        ctx.status = 200;
        ctx.body = {
            success: true,
            data : list
        };
    } catch (err) {
        ctx.status = 500;
        ctx.body = {
            'success': false,
            'error': 'internal server error',
        };
    }
};

export default getAdminNotifications;