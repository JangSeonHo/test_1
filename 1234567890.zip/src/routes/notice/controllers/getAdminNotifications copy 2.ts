import Koa from 'koa';
import adminNotificationModel from 'models/notice/admin_notice';
import userInfoModel from 'models/account/user_info';

const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;


const getAdminNotifications = async (ctx: Koa.Context) => {
    try {
        const userId = ctx.response.get('userId');
        const tenantFlag = ctx.response.get('tenantFlag');

        const targetUserModel = userInfoModel({tenantFlag});

        const userInfo = await targetUserModel.findOne({_id: userId})
        .select('parentCompany');
        const filter = userInfo.parentCompany;

        const TargetAdminNotificationModel = adminNotificationModel({tenantFlag});

        const list = await TargetAdminNotificationModel.aggregate([
          {
            $match: {
              notiGroupTarget: { $in: [filter] },
              status: "Use"
            }
          },
          {
            $project: {
              _id: 1,
              title: 1,
              content: 1,
              createdAt: 1,
              updatedAt: 1,
              filesYn: {
                $cond: {
                  if: { $gt: [{ $size: "$files" }, 0] },
                  then: "Y",
                  else: "N"
                }
              }
            }
          },
          {
            $sort: { createdAt: -1 }
          }
        ]);


        ctx.status = 200;
        ctx.body = {
            success: true,
            data : list
        };
    } catch (err) {
        ctx.status = 500;
        ctx.body = {
            'success': false,
            'error': 'internal server error',
        };
    }
};

export default getAdminNotifications;