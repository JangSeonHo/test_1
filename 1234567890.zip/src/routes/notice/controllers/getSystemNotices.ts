import Koa from 'koa';

import systemNoticeModel from 'models/notice/system_notice';

const getSystemNotices = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const TargetSystemNoticeModel = systemNoticeModel({tenantFlag});

    const systemNotices = await TargetSystemNoticeModel.find()
      .sort({createdAt: -1});

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        systemNotices,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getSystemNotices;
