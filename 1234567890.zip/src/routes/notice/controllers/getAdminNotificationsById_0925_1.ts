import Koa from 'koa';
import adminNotificationModel from 'models/notice/admin_notice';
import userInfoModel from 'models/account/user_info';


const getAdminNotificationsById = async (ctx: Koa.Context) => {
    try {
        const {
            noticeId,
          } = ctx.request.body as any;

        const tenantFlag = ctx.response.get('tenantFlag');

        const TargetAdminNotificationModel = adminNotificationModel({tenantFlag});

        const view = await TargetAdminNotificationModel
        .findOne({_id : noticeId})
        .select('-_id title content views status image files type views creator startDate endDate createdAt updatedAt');

        await TargetAdminNotificationModel.updateOne({_id: noticeId}, {
			$inc: {views: 1}
		});



        ctx.status = 200;
        ctx.body = {
            success: true,
            data : view
        };
    } catch (err) {
        ctx.status = 500;
        ctx.body = {
            'success': false,
            'error': 'internal server error',
        };
    }
};

export default getAdminNotificationsById;