
export namespace ERROR_CODE {
  export enum AUTH {
    LOGIN_FAILURE = 'LOGIN_FAILURE',
    NOT_MATCHED_ID = 'NOT_MATCHED_ID',
    JSON_WEB_TOKEN_ERROR = 'JSON_WEB_TOKEN_ERROR',
  }
  export enum BUSINESS {
    NO_DATA = 'NO_DATA',
  }
  export enum SYSTEM {
    DB_DISCONNECTED = 'DB_DISCONNECTED',
    DB_TRANSACTION = 'DB_TRANSACTION',
    UNKNOWN = 'UNKNOWN',
  }
}
 
export const ERROR_MSG = {
  [ERROR_CODE.AUTH.LOGIN_FAILURE]: '로그인에 실패하였습니다.',
  [ERROR_CODE.AUTH.NOT_MATCHED_ID]: '아이디가 일치하지 않습니다.',
  [ERROR_CODE.AUTH.JSON_WEB_TOKEN_ERROR]: '잘못된 토큰입니다.',
 
  [ERROR_CODE.BUSINESS.NO_DATA]: '데이터가 없습니다.',
 
  [ERROR_CODE.SYSTEM.DB_DISCONNECTED]: '데이터베이스 연결이 끊겼습니다.',
  [ERROR_CODE.SYSTEM.DB_TRANSACTION]: '데이터베이스 트랜잭션',
  [ERROR_CODE.SYSTEM.UNKNOWN]: '알수 없는 에러입니다.',
};