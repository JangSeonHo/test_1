export const errorResponse = (errorCode: string, errorMessage: string) => {
  const response = {
    errorCode,
    errorMessage,
  };

  return response;
};

export const UserStatusCode = {
  OFFLINE: 0,
  ONLINE: 1,
  AWAY: 2,
  VACATION: 3,
  MEETING: 4,
  TRAINING: 5,
  BUSINESS_TRAVEL: 6,
};

// M-Messenger chatting history url
export const CHATTING_HISTORY_URL = 'http://lgucap.com:9098/uCapMsg/lgUcapChat.do';

export const PW_DEFAULT_DAYS: number = 90;
export const DATE_TO_MILLISEC: number = 24 * 60 * 60 * 1000;
export const UTC_9: number = 9 * 60 * 60 * 1000;
export const HR_WORKING_STATUS_COMPANIES: string[] = ['GUC021', 'GUC100']; // innotek working status

export const CHAT_ROOM_MAX_MEMBERS: number = 500;
export const MAX_CHAT_MSG_RETENTION_DAYS = 60;
export const ENCKEYFORPARAM = "S7E5R3KJTKTKDLXTBE1MK25AY3IRJTD9"; // TODO - 임시
export const ENCRYPT_APPVERSION = "0.5.94";

export const CHINA_FILE_DOMAIN = process.env.STATE_ENV === 'dev' ? 'dev-api.lgmtalk.com/api/file' :
  process.env.STAGE_ENV === 'stg' ? 'stg-api.lgmtalk.com/api/file' :
    'api.lgmtalk.com/api/file'; // TODO - 전용 도메인 결정되면 변경

export const ALLOWED_EXTS = [
  "doc",
  "docx",
  "dot",
  "dotx",
  "ppt",
  "pptx",
  "pot",
  "potx",
  "pps",
  "ppsx",
  "xls",
  "xlsx",
  "xlt",
  "xltx",
  "rtf",
  "txt",
  "csv",
  "pdf",
  // "hwp",
  "tif",
  "ogg",
  // "psd",
  "ai",
  "zip",
  // "alz",
  // "a01",
  // "a02",
  // "a03",
  // "a04",
  // "a05",
  // "a06",
  // "a07",
  // "a08",
  // "a09",
  "7z",
  "wav",
  "mp3",
  "swf",
  ".7z",
  // "fla",
  "bmp",
  "jpg",
  "jpeg",
  "png",
  "webp",
  "heic",
  "avi",
  "mp4",
  "wmv",
  "mov",
  "3gp",
  "mkv",
  // "ts",
  "webm",
  "m4v",
  "mpg",
  "mpeg",
  // "zdr",
  // "dat",
  "xlm",
  // "egg",
  "xlsm",
  "xltm",
  "xlsb",
  "tar",
  // "gz"
];
