import cron from 'node-cron';
import fs from 'fs';

import removeUserCancelInfoCore from '../routes/user/controllers/removeUserCancelInfoCore';
import removeChattingMessageCore from '../routes/chatting/controllers/removeChattingMessageCore';
import syncDepartmentSchedule from '../routes/sync/controllers/syncDepartmentSchedule';
import syncUserSchedule from '../routes/sync/controllers/syncUserSchedule';
import schedulerLockModel from 'models/sync/scheduler_lock';
import schedulerInfoModel from 'models/sync/scheduler_info';

const TENANT_FLAG = 'nmp';

const targetSchedulerLockModel = schedulerLockModel({ tenantFlag: TENANT_FLAG });
const targetSchedulerInfoModel = schedulerLockModel({ tenantFlag: TENANT_FLAG });

console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> executeScheduler.ts");

//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
//원자성을 보장하기 위함이다.
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
// 잠금 생성 함수
//--------------------------------------------------------------------------------------------------
async function createLock(lockId: string) {
  const lockDoc = {
    _id: lockId, //ObjectId로 락을 생성한다. 모델에서 type을 String으로 정의했다.
    createdAt: new Date().getTime(),
  };

  try {
    await targetSchedulerLockModel.create(lockDoc);
    return true;
  } catch (error) {
    return false; // Lock 생성 실패 시
  }
}

//--------------------------------------------------------------------------------------------------
// 잠금 해제 함수
//--------------------------------------------------------------------------------------------------
async function releaseLock(lockId: string) {
  try {
    await targetSchedulerLockModel.deleteOne({ _id: lockId });
  } catch (error) {
    console.error('[executeScheduler.ts][releaseLock] Error releasing lock ::: ', error);
  }
}
//--------------------------------------------------------------------------------------------------






//---------------------------------------------------------------------------------------------------------
//사용자 해지 컬렉션 금일일시 기준으로 3개월이 지난 정보 삭제. 새벽 4시에 실행
//---------------------------------------------------------------------------------------------------------
// cron.schedule('0 4 * * *', async () => {
//   try {
//     await removeUserCancelInfoCore();
//   } catch (error) {
//     console.error('Error occurred while removing user cancel info:', error);
//   }
// });
//---------------------------------------------------------------------------------------------------------






//---------------------------------------------------------------------------------------------------------
//대화내용 생성시점을 기준으로 금일일시 기준으로 3개월이 지난 대화 내용 삭제. 새벽 5시에 실행
//---------------------------------------------------------------------------------------------------------
// cron.schedule('0 5 * * *', async () => {
//   try {
//     await removeChattingMessageCore();
//   } catch (error) {
//     console.error('Error occurred while removing user cancel info:', error);
//   }
// });
//---------------------------------------------------------------------------------------------------------






//---------------------------------------------------------------------------------------------------------
// 조직도 연동 스케쥴
//---------------------------------------------------------------------------------------------------------
// //cron.schedule('*/10 * * * * *', async () => {
// cron.schedule('0 */2 * * * *', async () => {
//   const lockId = 'syncDepartmentScheduleLock';
//   let lockCreated = false; // 잠금 생성 여부를 확인하는 변수

//   try {
//     const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

//     if (!(await createLock(lockId))) {
//       console.log(`[executeScheduler.ts][syncDepartmentScheduleLock][조직도 연동] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
//       return;
//     }

//     lockCreated = true; // 잠금이 성공적으로 생성되었음을 표시

//     // 실제 조직도 연동모듈 실행.
//     await syncDepartmentSchedule();

//   } catch (error) {
//     if (process.env.DEVELOPMENT_MODE === 'local') {
//       console.error('[executeScheduler.ts][syncDepartmentScheduleLock][try ~ catch][조직도 연동] Error occurred while removing user cancel info:', error);
//     }
//   } finally {
//     if (process.env.DEVELOPMENT_MODE === 'local') {
//       console.error('[executeScheduler.ts][syncDepartmentScheduleLock][finally][조직도 연동] lockCreated >>>>> ', lockCreated);
//     }
//     if (lockCreated) { // 잠금이 생성되었을 경우에만 해제
//       const { unixTimestamp, formattedDate } = getFormattedKoreaTime();
//       if (process.env.DEVELOPMENT_MODE === 'local') {
//         console.log(`[executeScheduler.ts][syncDepartmentScheduleLock][finally][잠금해제][조직도 연동] >>>>>>>>>>>>>>>>>>>>>>>>>> .... ${unixTimestamp} ::: ${formattedDate}`);
//       }
//       await releaseLock(lockId);
//     }
//   }
// });
//---------------------------------------------------------------------------------------------------------






//---------------------------------------------------------------------------------------------------------
// 사용자 연동 스케쥴
//---------------------------------------------------------------------------------------------------------
// //cron.schedule('*/5 * * * * *', async () => {
// cron.schedule('10 */3 * * * *', async () => {
//   const lockId = 'syncUserScheduleLock';
//   let lockCreated = false; // 잠금 생성 여부를 확인하는 변수

//   try {
//     const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

//     if (!(await createLock(lockId))) {
//       console.log(`[executeScheduler.ts][syncUserScheduleLock][사용자 연동] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
//       return;
//     }

//     lockCreated = true; // 잠금이 성공적으로 생성되었음을 표시

//     // 실제 사용자 연동모듈 실행.
//     await syncUserSchedule();

//   } catch (error) {
//     if (process.env.DEVELOPMENT_MODE === 'local') {
//       console.error('[executeScheduler.ts][syncUserScheduleLock][try ~ catch][사용자 연동] Error occurred while removing user cancel info:', error);
//     }
//   } finally {
//     if (process.env.DEVELOPMENT_MODE === 'local') {
//       console.error('[executeScheduler.ts][syncUserScheduleLock][finally][사용자 연동] lockCreated >>>>> ', lockCreated);
//     }
//     if (lockCreated) { // 잠금이 생성되었을 경우에만 해제
//       const { unixTimestamp, formattedDate } = getFormattedKoreaTime();
//       if (process.env.DEVELOPMENT_MODE === 'local') {
//         console.log(`[executeScheduler.ts][syncUserScheduleLock][finally][잠금해제][사용자 연동] >>>>>>>>>>>>>>>>>>>>>>>>>> .... ${unixTimestamp} ::: ${formattedDate}`);
//       }
//       await releaseLock(lockId);
//     }
//   }
// });
//---------------------------------------------------------------------------------------------------------










//---------------------------------------------------------------------------------------------------------
// 스케줄 실행 함수
//---------------------------------------------------------------------------------------------------------
async function runScheduler(id: string, task: () => Promise<void>) {
  const scheduler = await targetSchedulerInfoModel.findById(id);

  const { unixTimestamp, formattedDate } = getFormattedKoreaTime();


  if (!scheduler) {
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.error(`[executeScheduler.ts][runScheduler][${id}] 스케줄 정보가 없습니다..........${unixTimestamp} ::: ${formattedDate}`);
    }
    return;
  }

  if (!scheduler.enabled) {
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][runScheduler][${id}] 스케줄이 비활성화 상태입니다..........${unixTimestamp} ::: ${formattedDate}`);
    }
    return;
  }

  if (process.env.DEVELOPMENT_MODE === 'local') {
    console.log(`[executeScheduler.ts][runScheduler][${id}] 스케줄 실행 시작..........${unixTimestamp} ::: ${formattedDate}`);
  }
  try {
    await task(); //실제 작업 실행
    scheduler.lastRun = new Date();
    await scheduler.save(); //마지막 실행 시간 저장
  } catch (error) {
    console.error(`[executeScheduler.ts][runScheduler][error][${id}] 실행 중 오류 발생:`, error);
  }
}
//---------------------------------------------------------------------------------------------------------




//---------------------------------------------------------------------------------------------------------
//스케줄 로드
//---------------------------------------------------------------------------------------------------------
async function loadCronSchedules() {
  if (process.env.DEVELOPMENT_MODE === 'local') {
    console.log('[executeScheduler.ts][loadCronSchedules] 스케줄 로드 시작');
  }
  const schedules = await targetSchedulerInfoModel.find({ enabled: true });

  try {
    const schedules = await targetSchedulerInfoModel.find({ enabled: true });
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log('[executeScheduler.ts][loadCronSchedules] 로드된 스케줄:', schedules);
    }

    if (schedules.length === 0) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.warn('[executeScheduler.ts][loadCronSchedules] 활성화된 스케줄이 없습니다. 스케줄러를 종료합니다.');
      }
      return;
    }

    schedules.forEach(schedule => {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][loadCronSchedules] 스케줄 등록 중: ID=${schedule._id}, CRON=${schedule.cron}`);
      }
      cron.schedule(schedule.cron, async () => {
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[executeScheduler.ts][loadCronSchedules] 실행 중인 스케줄: ${schedule._id}`);
        }
        await runScheduler(schedule._id, async () => {
          if (schedule._id === "syncUserSchedule") {
            await syncUserScheduleExec();
          } else if (schedule._id === "syncDepartmentSchedule") {
            await syncDepartmentScheduleExec();
          }
        });
      });
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][loadCronSchedules] 크론 스케줄 등록 완료: ID=${schedule._id}`);
      }
    });
  } catch (error) {
    console.error('[executeScheduler.ts][loadCronSchedules] 스케줄 로드 중 오류 발생:', error);
  }
}
//---------------------------------------------------------------------------------------------------------




//---------------------------------------------------------------------------------------------------------
// 조직도 연동 스케쥴
//---------------------------------------------------------------------------------------------------------
async function syncDepartmentScheduleExec() {
  const lockId = 'syncDepartmentScheduleLock';
  let lockCreated = false; //잠금 생성 여부를 확인하는 변수

  try {
    const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

    if (!(await createLock(lockId))) {
      console.log(`[executeScheduler.ts][syncDepartmentScheduleExec][조직도 연동] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      return;
    }

    lockCreated = true; //잠금이 성공적으로 생성되었음을 표시

    //실제 조직도 연동모듈 실행.
    await syncDepartmentSchedule();

  } catch (error) {
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.error('[executeScheduler.ts][syncDepartmentScheduleExec][try ~ catch][조직도 연동] Error occurred while removing user cancel info:', error);
    }
  } finally {
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.error('[executeScheduler.ts][syncDepartmentScheduleExec][finally][조직도 연동] lockCreated >>>>> ', lockCreated);
    }
    if (lockCreated) { //잠금이 생성되었을 경우에만 해제
      const { unixTimestamp, formattedDate } = getFormattedKoreaTime();
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][syncDepartmentScheduleExec][finally][잠금해제][조직도 연동] >>>>>>>>>>>>>>>>>>>>>>>>>> .... ${unixTimestamp} ::: ${formattedDate}`);
      }
      await releaseLock(lockId);
    }
  }
}
//---------------------------------------------------------------------------------------------------------







//---------------------------------------------------------------------------------------------------------
// 사용자 연동 스케쥴
//---------------------------------------------------------------------------------------------------------
async function syncUserScheduleExec() {
  const lockId = 'syncUserScheduleLock';
  let lockCreated = false; //잠금 생성 여부를 확인하는 변수

  try {
    const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

    if (!(await createLock(lockId))) {
      console.log(`[executeScheduler.ts][syncUserScheduleExec][사용자 연동] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      return;
    }

    lockCreated = true; //잠금이 성공적으로 생성되었음을 표시

    //실제 사용자 연동모듈 실행.
    await syncUserSchedule();

  } catch (error) {
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.error('[executeScheduler.ts][syncUserScheduleExec][try ~ catch][사용자 연동] Error occurred while removing user cancel info:', error);
    }
  } finally {
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.error('[executeScheduler.ts][syncUserScheduleExec][finally][사용자 연동] lockCreated >>>>> ', lockCreated);
    }
    if (lockCreated) { //잠금이 생성되었을 경우에만 해제
      const { unixTimestamp, formattedDate } = getFormattedKoreaTime();
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][syncUserScheduleExec][finally][잠금해제][사용자 연동] >>>>>>>>>>>>>>>>>>>>>>>>>> .... ${unixTimestamp} ::: ${formattedDate}`);
      }
      await releaseLock(lockId);
    }
  }
}
//---------------------------------------------------------------------------------------------------------



//---------------------------------------------------------------------------------------------------------
// 실행 시 크론 로드 - 서버 재시작해도 바로 구동된다.
//---------------------------------------------------------------------------------------------------------
loadCronSchedules();
//---------------------------------------------------------------------------------------------------------





//---------------------------------------------------------------------------------------------------------
// 시간을 포맷팅하는 함수
//---------------------------------------------------------------------------------------------------------
function getFormattedKoreaTime() {
  const now = new Date();
  const unixTimestamp = now.getTime();
  const koreaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));

  const year = koreaTime.getFullYear();
  const month = String(koreaTime.getMonth() + 1).padStart(2, '0');
  const day = String(koreaTime.getDate()).padStart(2, '0');

  const hours = koreaTime.getHours();
  const minutes = String(koreaTime.getMinutes()).padStart(2, '0');
  const seconds = String(koreaTime.getSeconds()).padStart(2, '0');
  const ampm = hours >= 12 ? '오후' : '오전';
  const formattedHour = hours % 12 || 12; // 12시간제로 변환

  const formattedDate = `${year}-${month}-${day} ${ampm} ${formattedHour}:${minutes}:${seconds}`;

  return { unixTimestamp, formattedDate };
}
//---------------------------------------------------------------------------------------------------------
