import cron from 'node-cron';
import mongoose from 'mongoose';

import removeUserCancelInfoCore from '../routes/user/controllers/removeUserCancelInfoCore';
import removeChattingMessageCore from '../routes/chatting/controllers/removeChattingMessageCore';
import syncDepartmentSchedule from '../routes/sync/controllers/syncDepartmentSchedule';
import syncUserSchedule from '../routes/sync/controllers/syncUserSchedule';
import createDashboardDailyReport from 'routes/report/controllers/createDashboardDailyReport';
import schedulerLockModel from 'models/sync/scheduler_lock';
import schedulerInfoModel from 'models/sync/scheduler_info';
import createStatisticsDailyReport from 'routes/report/controllers/createStatisticsDailyReport';

/*
*************************************************************************************************************************************
* Project: 뉴메신저
* File: executeScheduler.ts
* Description: AP Server의 스케쥴링 메인역활을 하는 소스이다. 스케쥴ID와 ID매핑함수 부분의 정의와 실제 실행함수만 작성하면 되게끔 설계되었다.
*              1. 스케쥴러 락 리스트를 추가한다.
*              2. 스케줄 ID와 실행 함수 매핑 - 스케쥴ID와 실행될 스케쥴 실행함수명을 기술한다.
*              3. 거의 아래쪽 실행함수 부분만 신규작성하면 된다.
*                 --- 스케쥴링 실행함수들은 아래에 기술한다.  <<<- 해당 문구가 기술된 블록부분 분석 작성하면 된다.
* Author: JangSeonHo (dev109761@cnspartner.com)
*************************************************************************************************************************************
*/


const TENANT_FLAG = 'nmp';
const SCHEDULER_MAIN = 'scheduler_main';


//------------------------------------------------------------------------------------------------------------
// 스케쥴러 락 리스트 - 스케쥴ID를 추가한다.
//------------------------------------------------------------------------------------------------------------
// syncUserScheduleLock : 사용자 연동
// syncDepartmentScheduleLock : 조직도 연동
// createDashboardDailyReportScheduleLock : 대시보드 데이터 집계
// removeUserCancelInfoCoreLock : 사용자 해지 컬렉션 삭제(3개월 이후 데이타 삭제)
// createStatisticsReportScheduleLock : 통계 데이터 집계
//------------------------------------------------------------------------------------------------------------
const LOCK_LIST = [
  'syncUserScheduleLock',
  'syncDepartmentScheduleLock',
  'createDashboardDailyReportScheduleLock',
  'removeUserCancelInfoCoreLock',
  'createStatisticsReportScheduleLock',
];
//------------------------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------------------------------------
// 스케줄 ID와 실행 함수 매핑 - 스케쥴ID와 실행될 스케쥴 실행함수명을 기술한다.
// 스케쥴 실행함수는 아래에 기술한다.
//------------------------------------------------------------------------------------------------------------
// syncUserScheduleExec : 사용자 연동 실행함수
// syncDepartmentScheduleExec : 조직도 연동 실행함수
// createDashboardDailyReportScheduleExec : 대시보드 데이터 집계 실행함수
// createStatisticsReportScheduleExec : 통계 데이터 집계 실행함수
//------------------------------------------------------------------------------------------------------------
const SCHEDULE_EXECUTORS: Record<string, (checkCancel: () => boolean) => Promise<void>> = {
  syncUserSchedule: syncUserScheduleExec,
  syncDepartmentSchedule: syncDepartmentScheduleExec,
  createDashboardDailyReportSchedule: createDashboardDailyReportScheduleExec,
  removeUserCancelInfoCore: removeUserCancelInfoCoreExec,
  createStatisticsReportSchedule: createStatisticsReportScheduleExec,
};
//------------------------------------------------------------------------------------------------------------



//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
// 추가 스케쥴링에 대한 내용 추가는 위에 2군데(스케쥴러 락 리스트, 스케줄 ID와 실행 함수 매핑)와 맨아래 실행함수 부분만 신규작성하면 된다.
// 나머지는 손대지 않아도 된다.
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★



const targetSchedulerLockModel = schedulerLockModel({ tenantFlag: TENANT_FLAG });
const targetSchedulerInfoModel = schedulerInfoModel({ tenantFlag: TENANT_FLAG });


// 크론 작업 및 실행 상태 관리 객체
const cronJobs: { [key: string]: cron.ScheduledTask } = {};

// 실행 중인 작업 상태 저장
export const runningJobs: { [key: string]: boolean } = {};

// 작업 중단 플래그
const cancelFlags: { [key: string]: boolean } = {};



//--------------------------------------------------------------------------------------------------
// 잠금 생성 함수
//--------------------------------------------------------------------------------------------------
async function createLock(lockId: string) {
  const lockDoc = {
    _id: lockId,
    createdAt: new Date().getTime(),
  };

  try {
    await targetSchedulerLockModel.create(lockDoc);
    return true;
  } catch (error) {
    return false;
  }
}
//--------------------------------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------
// 잠금 해제 함수
//--------------------------------------------------------------------------------------------------
async function releaseLock(lockId: string) {
  try {
    await targetSchedulerLockModel.deleteOne({ _id: lockId });
  } catch (error) {
    console.error('[executeScheduler.ts][releaseLock] Error releasing lock ::: ', error);
  }
}
//--------------------------------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------
// 스케줄 실행 함수
//--------------------------------------------------------------------------------------------------
async function runScheduler(id: string, task: (checkCancel: () => boolean) => Promise<void>, forceRun: boolean = false) {
  if (runningJobs[id]) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][runScheduler][${id}] 작업이 이미 실행 중입니다. 스킵합니다.`);
      }
      return;
  }

  runningJobs[id] = true;
  cancelFlags[id] = false; // 중단 플래그 초기화

  const scheduler = await targetSchedulerInfoModel.findById(id);
  const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

  if (!scheduler) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.error(`[executeScheduler.ts][runScheduler][${id}] 스케줄 정보가 없습니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      }
      runningJobs[id] = false;
      return;
  }

  if (!scheduler.enabled && !forceRun) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][runScheduler][${id}] 스케줄이 비활성화 상태입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      }
      runningJobs[id] = false;

      // 스케쥴의 모든 Lock정보를 삭제한다.
      await releaseAllLocksAtStartup();
      return;
  }

  if (process.env.DEVELOPMENT_MODE === 'local') {
    console.log(`[executeScheduler.ts][runScheduler][${id}] 스케줄 실행 시작 ::: ${unixTimestamp} ::: ${formattedDate}`);
  }
  try {
      await task(() => cancelFlags[id]); // 작업 중단 확인 전달
      scheduler.lastedRunAt = new Date();

      // 강제 실행이면 immediateRun 초기화
      if (forceRun) {
          scheduler.immediateRun = false;
          await scheduler.save(); // immediateRun 변경 사항 저장
      } else {
          await scheduler.save(); // 일반 실행 후 저장
      }
  } catch (error) {
      console.error(`[executeScheduler.ts][runScheduler][error][${id}] 실행 중 오류 발생:`, error);
  } finally {
      runningJobs[id] = false;
  }
}
//--------------------------------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------
// 작업 중단 플래그 설정
//--------------------------------------------------------------------------------------------------
function cancelScheduler(id: string) {
  if (cancelFlags[id] !== undefined) {
    cancelFlags[id] = true;
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][cancelScheduler][${id}] 작업 중단 요청 처리.`);
    }
  }
}
//--------------------------------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------
// 스케줄 로드
//--------------------------------------------------------------------------------------------------
async function loadCronSchedules() {
  const { unixTimestamp, formattedDate } = getFormattedKoreaTime();
  if (process.env.DEVELOPMENT_MODE === 'local') {
    console.log(`[executeScheduler.ts][loadCronSchedules] 스케줄 로드 시작 ::: ${unixTimestamp} ::: ${formattedDate}`);
  }

  try {
    // 스케쥴 메인의 상태를 조회한다.
    const schedulerConfig = await targetSchedulerInfoModel.findOne({ _id: SCHEDULER_MAIN });
    if (!schedulerConfig || !schedulerConfig.enabled) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log('[executeScheduler.ts][loadCronSchedules][SCHEDULER_MAIN] 스케줄러 비활성화 상태, 모든 스케줄 취소');
      }

      Object.keys(cronJobs).forEach(jobId => {
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[executeScheduler.ts][loadCronSchedules] 기존 스케줄 취소: ${jobId}`);
        }
        cronJobs[jobId].stop();
        delete cronJobs[jobId];
        cancelScheduler(jobId);
      });

      // 스케쥴의 모든 Lock정보를 삭제한다.
      await releaseAllLocksAtStartup();
      return;
    }

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log('[executeScheduler.ts][loadCronSchedules] 스케줄러 활성화 상태');
    }

    // 모든 스케줄 조회
    const schedules = await targetSchedulerInfoModel.find({_id: { $ne: SCHEDULER_MAIN }});
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][loadCronSchedules] 로드된 스케줄::: ${unixTimestamp} ::: ${formattedDate}`)
      console.log('[executeScheduler.ts][loadCronSchedules] 로드된 스케줄::: '+ schedules);
    }

    for (const schedule of schedules) {
      // CRON 스케줄 등록
      if (schedule.enabled && !cronJobs[schedule._id]) {
        cronJobs[schedule._id] = cron.schedule(schedule.cron, () => {
          (async () => {
            try {
              await runScheduler(schedule._id, async (checkCancel) => {
                const executor = SCHEDULE_EXECUTORS[schedule._id];
                if (executor) {
                  await executor(checkCancel);
                } else {
                  console.warn(`[loadCronSchedules] 실행 함수가 정의되지 않은 스케줄: ${schedule._id}`);
                }
              });
            } catch (error) {
              console.error(`[loadCronSchedules][${schedule._id}] 실행 중 오류 발생:`, error);
            }
          })();
        });

        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[loadCronSchedules] 스케줄 등록 완료: ${schedule._id}`);
        }
      }

      // 즉시 실행 처리
      if (schedule.immediateRun) {
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[loadCronSchedules] 즉시 실행 스케줄: ${schedule._id}`);
        }
        try {
          await runScheduler(schedule._id, async (checkCancel) => {
            const executor = SCHEDULE_EXECUTORS[schedule._id];
            if (executor) {
              await executor(checkCancel);
            } else {
              console.warn(`[loadCronSchedules] 즉시 실행 함수가 정의되지 않은 스케줄: ${schedule._id}`);
            }
          }, true);

          // immediateRun 초기화 및 저장
          schedule.immediateRun = false;
          await schedule.save(); // 데이터베이스 저장
        } catch (error) {
          console.error(`[loadCronSchedules][${schedule._id}] immediateRun 저장 실패:`, error);
        }
      }
    }

    Object.keys(cronJobs).forEach(jobId => {
      if (!schedules.some(schedule => schedule._id === jobId && schedule.enabled)) {
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[executeScheduler.ts][loadCronSchedules] 더 이상 필요하지 않은 스케줄 제거: ${jobId}`);
        }
        cronJobs[jobId].stop();
        delete cronJobs[jobId];

        // 비활성화인 상태의 스케쥴의 Lock정보를 삭제한다.
        targetSchedulerLockModel.deleteMany({ _id: { jobId } });
      }
    });
  } catch (error) {
    // 스케쥴의 모든 Lock정보를 삭제한다.
    await releaseAllLocksAtStartup();
    console.error('[executeScheduler.ts][loadCronSchedules] 스케줄 로드 중 오류 발생:', error);
  }
}
//--------------------------------------------------------------------------------------------------




//--------------------------------------------------------------------------------------------------
// 서버 초기화 시 락 해체 함수
//--------------------------------------------------------------------------------------------------
async function releaseAllLocksAtStartup() {
  try {
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log('[executeScheduler.ts][releaseAllLocksAtStartup] 서버 초기화 중, 모든 락 해제 시작............');
    }

    const result = await targetSchedulerLockModel.deleteMany({ _id: { $in: LOCK_LIST } });

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][releaseAllLocksAtStartup] 해제된 락 수: ${result.deletedCount}`);
    }
  } catch (error) {
    console.error('[executeScheduler.ts][releaseAllLocksAtStartup] 락 해제 중 오류 발생:', error);
  }
}
//--------------------------------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------
// 스케줄러 주기적 감지
//--------------------------------------------------------------------------------------------------
async function reloadCronSchedulesPeriodically() {
  if (process.env.DEVELOPMENT_MODE === 'local') {
    console.log('[executeScheduler.ts] 스케줄 주기적 감지 시작');
  }

  setInterval(async () => {
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log('[executeScheduler.ts][reloadCronSchedulesPeriodically] 스케줄 재로드 시작');
    }
    await loadCronSchedules();
  }, 30000); //30초 간격으로 스케쥴러 체크
}
//--------------------------------------------------------------------------------------------------




//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
// 실행 시 크론 로드 및 주기적 감지 시작.
//--------------------------------------------------------------------------------------------------
(async function initializeScheduler() {
  // //서버 초기화 시 모든 락 해체
  // await releaseAllLocksAtStartup();

  // //크론 스케줄 로드
  // await loadCronSchedules();

  // //주기적 감지 시작 - 주기적 감지 작업이 비동기로 실행되도록 설계
  // reloadCronSchedulesPeriodically();
})();
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------






//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//
// 스케쥴링 실행함수들은 아래에 기술한다.
//
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

//--------------------------------------------------------------------------------------------------
// 조직도 연동 스케쥴 실행
//--------------------------------------------------------------------------------------------------
async function syncDepartmentScheduleExec(checkCancel: () => boolean) {
  const lockId = 'syncDepartmentScheduleLock';
  let lockCreated = false;

  try {
    const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

    if (!(await createLock(lockId))) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][syncDepartmentScheduleExec] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      }
      return;
    }

    lockCreated = true;
    cancelFlags['syncDepartmentSchedule'] = false;

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][syncDepartmentScheduleExec] 조직도 동기화 시작`);
    }

    if (checkCancel()) {
      //락을 해체한다. finally에서는 락이 생성되어 있는 경우에만 락을 해체하기 때문.
      await releaseLock(lockId);
      throw new Error('[executeScheduler.ts][syncDepartmentScheduleExec] 작업이 중단되었습니다.');
    }


    //-----------------------------
    // 조직도 연동 실행
    //-----------------------------
    await syncDepartmentSchedule();
    //-----------------------------


    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][syncDepartmentScheduleExec] 조직도 동기화 완료`);
    }
  } catch (error) {
    //락을 해체한다. finally에서는 락이 생성되어 있는 경우에만 락을 해체하기 때문.
    await releaseLock(lockId);
    console.error('[executeScheduler.ts][syncDepartmentScheduleExec] Error:', error);
  } finally {
    //락이 생성되어 있을때만, 락을 해체한다.
    if (lockCreated) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][syncDepartmentScheduleExec] 조직도 연동 잠금 해제....................................................`);
      }
      await releaseLock(lockId);
    }
  }
}
//--------------------------------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------
// 사용자 연동 스케쥴 실행
//--------------------------------------------------------------------------------------------------
async function syncUserScheduleExec(checkCancel: () => boolean) {
  const lockId = 'syncUserScheduleLock';
  let lockCreated = false;

  try {
    const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

    //----------------------------------------------------------------------------------------------------------------------
    // -->> 해당 부분은 업무처리에 필요한 부분이라 추가되었음. 왠만하면 실제 처리되는 함수 호출부분 말고 나머지는 동일함.
    //----------------------------------------------------------------------------------------------------------------------
    //조직도 스케쥴링 작업이 모두 종료되면 실행한다. 조직도 연동 작업이 남아 있으면 수행을 하지 않는다.
    const departMentCronJob = await targetSchedulerLockModel.findOne({_id : 'syncDepartmentScheduleLock'});
    if (departMentCronJob != null || departMentCronJob != undefined) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("[syncUserSchedule][departMentCronJob] >>>>>>>>>>>>>>>>>>>>> 조직도 연동 작업이 마무리 되지 않았습니다..(사용자 연동 스케쥴링 실행안됨.)>>>>>>>>>>>>>>>>>>>>>>>...depart_ing...........");
      }
      return;
    }
    //----------------------------------------------------------------------------------------------------------------------


    if (!(await createLock(lockId))) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][syncUserScheduleExec] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      }
      return;
    }

    lockCreated = true;
    cancelFlags['syncUserSchedule'] = false;

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][syncUserScheduleExec] 사용자 동기화 시작`);
    }

    if (checkCancel()) {
      //락을 해체한다. finally에서는 락이 생성되어 있는 경우에만 락을 해체하기 때문.
      await releaseLock(lockId);
      throw new Error('[executeScheduler.ts][syncUserScheduleExec] 작업이 중단되었습니다.');
    }


    //-----------------------------
    // 사용자 연동 실행
    //-----------------------------
    await syncUserSchedule();
    //-----------------------------


    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][syncUserScheduleExec] 사용자 동기화 완료`);
    }
  } catch (error) {
    //락을 해체한다. finally에서는 락이 생성되어 있는 경우에만 락을 해체하기 때문.
    await releaseLock(lockId);
    console.error('[executeScheduler.ts][syncUserScheduleExec] Error:', error);
  } finally {
    //락이 생성되어 있을때만, 락을 해체한다.
    if (lockCreated) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][syncDepartmentScheduleExec] 사용자 연동 잠금 해제....................................................`);
      }
      await releaseLock(lockId);
    }
  }
}

//--------------------------------------------------------------------------------------------------
// 대시보드 데이터 집계 스케쥴 실행
//--------------------------------------------------------------------------------------------------
async function createDashboardDailyReportScheduleExec(checkCancel: () => boolean) {
  const lockId = 'createDashboardDailyReportScheduleLock';
  let lockCreated = false;

  try {
    const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

    if (!(await createLock(lockId))) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][createDashboardDailyReportScheduleExec] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      }
      return;
    }

    lockCreated = true;
    cancelFlags['createDashboardDailyReportSchedule'] = false;

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][createDashboardDailyReportScheduleExec] 대시보드 전일 데이터 집계 시작`);
    }

    if (checkCancel()) {
      await releaseLock(lockId);
      throw new Error('[executeScheduler.ts][createDashboardDailyReportScheduleExec] 작업이 중단되었습니다.');
    }

    await createDashboardDailyReport('nmp');

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][createDashboardDailyReportScheduleExec] 대시보드 전일 데이터 집계 완료`);
    }
  } catch (error) {
    await releaseLock(lockId);
    console.error('[executeScheduler.ts][createDashboardDailyReportScheduleExec] Error:', error);
  } finally {
    if (lockCreated) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][createDashboardDailyReportScheduleExec] 대시보드 전일 데이터 집계 잠금 해제....................................................`);
      }
      await releaseLock(lockId);
    }
  }
}

//--------------------------------------------------------------------------------------------------
// 통계 데이터 집계 스케쥴 실행
//--------------------------------------------------------------------------------------------------
async function createStatisticsReportScheduleExec(checkCancel: () => boolean) {
  const lockId = 'createStatisticsReportScheduleLock';
  let lockCreated = false;

  try {
    const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

    if (!(await createLock(lockId))) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][createStatisticsReportScheduleExec] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      }
      return;
    }

    lockCreated = true;
    cancelFlags['createStatisticsReportSchedule'] = false;

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][createStatisticsReportScheduleExec] 통계 데이터 집계 시작`);
    }

    if (checkCancel()) {
      await releaseLock(lockId);
      throw new Error('[executeScheduler.ts][createStatisticsReportScheduleExec] 작업이 중단되었습니다.');
    }

    await createStatisticsDailyReport('nmp');

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][createStatisticsReportScheduleExec] 통계 데이터 집계 완료`);
    }
  } catch (error) {
    await releaseLock(lockId);
    console.error('[executeScheduler.ts][createStatisticsReportScheduleExec] Error:', error);
  } finally {
    if (lockCreated) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][createStatisticsReportScheduleExec] 통계 데이터 집계 잠금 해제....................................................`);
      }
      await releaseLock(lockId);
    }
  }
}
//--------------------------------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------
// 사용자 해지 컬렉션 삭제 - 3개월 이후 데이타 삭제
//--------------------------------------------------------------------------------------------------
async function removeUserCancelInfoCoreExec(checkCancel: () => boolean) {
  const lockId = 'removeUserCancelInfoCoreLock';
  let lockCreated = false;

  try {
    const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

    if (!(await createLock(lockId))) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][removeUserCancelInfoCoreExec] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      }
      return;
    }

    lockCreated = true;
    cancelFlags['removeUserCancelInfoCore'] = false;

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][removeUserCancelInfoCoreExec] 조직도 동기화 시작`);
    }

    if (checkCancel()) {
      //락을 해체한다. finally에서는 락이 생성되어 있는 경우에만 락을 해체하기 때문.
      await releaseLock(lockId);
      throw new Error('[executeScheduler.ts][removeUserCancelInfoCoreExec] 작업이 중단되었습니다.');
    }


    //-----------------------------------------------
    // 사용자해지 컬렉션 데이타 삭제
    //-----------------------------------------------
    await removeUserCancelInfoCore();
    //-----------------------------------------------


    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`[executeScheduler.ts][removeUserCancelInfoCoreExec] 조직도 동기화 완료`);
    }
  } catch (error) {
    //락을 해체한다. finally에서는 락이 생성되어 있는 경우에만 락을 해체하기 때문.
    await releaseLock(lockId);
    console.error('[executeScheduler.ts][removeUserCancelInfoCoreExec] Error:', error);
  } finally {
    //락이 생성되어 있을때만, 락을 해체한다.
    if (lockCreated) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[executeScheduler.ts][removeUserCancelInfoCoreExec] 사용자해지 연동 잠금 해제....................................................`);
      }
      await releaseLock(lockId);
    }
  }
}
//--------------------------------------------------------------------------------------------------


//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
//★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★





//--------------------------------------------------------------------------------------------------
// 시간을 포맷팅하는 함수
//--------------------------------------------------------------------------------------------------
function getFormattedKoreaTime() {
  const now = new Date();
  const unixTimestamp = now.getTime();
  const koreaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));

  const year = koreaTime.getFullYear();
  const month = String(koreaTime.getMonth() + 1).padStart(2, '0');
  const day = String(koreaTime.getDate()).padStart(2, '0');

  const hours = koreaTime.getHours();
  const minutes = String(koreaTime.getMinutes()).padStart(2, '0');
  const seconds = String(koreaTime.getSeconds()).padStart(2, '0');
  const ampm = hours >= 12 ? '오후' : '오전';
  const formattedHour = hours % 12 || 12;

  const formattedDate = `${year}-${month}-${day} ${ampm} ${formattedHour}:${minutes}:${seconds}`;
  return { unixTimestamp, formattedDate };
}

/*
--------------------------------------------------------
UTC       KST (UTC+9)
--------------------------------------------------------
00:00     09:00
01:00     10:00
02:00     11:00
03:00     12:00
04:00     13:00
05:00     14:00
06:00     15:00
07:00     16:00
08:00     17:00
09:00     18:00
10:00     19:00
11:00     20:00
12:00     21:00
13:00     22:00
14:00     23:00
15:00     00:00 (다음날)
16:00     01:00 (다음날)
17:00     02:00 (다음날)
18:00     03:00 (다음날)
19:00     04:00 (다음날)
20:00     05:00 (다음날)
21:00     06:00 (다음날)
22:00     07:00 (다음날)
23:00     08:00 (다음날)
*/