import cron from 'node-cron';
import Koa from 'koa';
import removeUserCancelInfoCore from '../routes/user/controllers/removeUserCancelInfoCore';

const ctx = new Koa();

// 새벽 4시에 실행하는 스케줄 설정
cron.schedule('0 4 * * *', async () => {
  try {
    await removeUserCancelInfoCore();
  } catch (error) {
    console.error('Error occurred while removing user cancel info:', error);
  }
});

// 특정 시간에 실행 - 테스트
cron.schedule('55 14 20 8 *', async () => {
//cron.schedule('*/5 * * * *', async () => {
  try {
    await removeUserCancelInfoCore();
  } catch (error) {
    console.error('Error occurred while removing user cancel info:', error);
  }
});
