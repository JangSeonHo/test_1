import cron from 'node-cron';
import mongoose from 'mongoose';

import removeUserCancelInfoCore from '../routes/user/controllers/removeUserCancelInfoCore';
import removeChattingMessageCore from '../routes/chatting/controllers/removeChattingMessageCore';
import syncDepartmentSchedule from '../routes/sync/controllers/syncDepartmentSchedule';
import syncUserSchedule from '../routes/sync/controllers/syncUserSchedule';
import schedulerLockModel from 'models/sync/scheduler_lock';
import schedulerInfoModel from 'models/sync/scheduler_info';

const TENANT_FLAG = 'nmp';

const targetSchedulerLockModel = schedulerLockModel({ tenantFlag: TENANT_FLAG });
const targetSchedulerInfoModel = schedulerInfoModel({ tenantFlag: TENANT_FLAG });

// 크론 작업 및 실행 상태 관리 객체
const cronJobs: { [key: string]: cron.ScheduledTask } = {};
const runningJobs: { [key: string]: boolean } = {}; // 실행 중인 작업 상태 저장


//--------------------------------------------------------------------------------------------------
// 잠금 생성 함수
//--------------------------------------------------------------------------------------------------
async function createLock(lockId: string) {
  const lockDoc = {
    _id: lockId,
    createdAt: new Date().getTime(),
  };

  try {
    await targetSchedulerLockModel.create(lockDoc);
    return true;
  } catch (error) {
    return false;
  }
}

//--------------------------------------------------------------------------------------------------
// 잠금 해제 함수
//--------------------------------------------------------------------------------------------------
async function releaseLock(lockId: string) {
  try {
    await targetSchedulerLockModel.deleteOne({ _id: lockId });
  } catch (error) {
    console.error('[executeScheduler.ts][releaseLock] Error releasing lock ::: ', error);
  }
}

//--------------------------------------------------------------------------------------------------
// 스케줄 실행 함수
//--------------------------------------------------------------------------------------------------
async function runScheduler(id: string, task: () => Promise<void>) {
  if (runningJobs[id]) {
    console.log(`[executeScheduler.ts][runScheduler][${id}] 작업이 이미 실행 중입니다. 스킵합니다.`);
    return;
  }

  runningJobs[id] = true; // 작업 실행 상태 설정

  const scheduler = await targetSchedulerInfoModel.findById(id);
  const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

  if (!scheduler) {
    console.error(`[executeScheduler.ts][runScheduler][${id}] 스케줄 정보가 없습니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
    runningJobs[id] = false; // 작업 상태 해제
    return;
  }

  if (!scheduler.enabled) {
    console.log(`[executeScheduler.ts][runScheduler][${id}] 스케줄이 비활성화 상태입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
    runningJobs[id] = false; // 작업 상태 해제
    return;
  }

  console.log(`[executeScheduler.ts][runScheduler][${id}] 스케줄 실행 시작 ::: ${unixTimestamp} ::: ${formattedDate}`);
  try {
    await task();
    scheduler.lastRun = new Date();
    await scheduler.save();
  } catch (error) {
    console.error(`[executeScheduler.ts][runScheduler][error][${id}] 실행 중 오류 발생:`, error);
  } finally {
    runningJobs[id] = false; // 작업 상태 해제
  }
}

//--------------------------------------------------------------------------------------------------
// 스케줄 로드
//--------------------------------------------------------------------------------------------------
async function loadCronSchedules() {
  console.log('[executeScheduler.ts][loadCronSchedules] 스케줄 로드 시작');

  try {
    const schedules = await targetSchedulerInfoModel.find({ enabled: true });
    console.log('[executeScheduler.ts][loadCronSchedules] 로드된 스케줄:', schedules);

    if (schedules.length === 0) {
      console.warn('[executeScheduler.ts][loadCronSchedules] 활성화된 스케줄이 없습니다.');
    }

    schedules.forEach(schedule => {
      // 기존 스케줄이 실행 중이라면 새 작업 등록 없이 유지
      if (cronJobs[schedule._id]) {
        console.log(`[executeScheduler.ts][loadCronSchedules] 기존 스케줄 유지: ${schedule._id}`);
        return;
      }

      // 새 스케줄 등록
      console.log(`[executeScheduler.ts][loadCronSchedules] 스케줄 등록 중: ID=${schedule._id}, CRON=${schedule.cron}`);
      cronJobs[schedule._id] = cron.schedule(schedule.cron, async () => {
        console.log(`[executeScheduler.ts][loadCronSchedules] 실행 중인 스케줄: ${schedule._id}`);
        await runScheduler(schedule._id, async () => {
          if (schedule._id === "syncUserSchedule") {
            await syncUserScheduleExec();
          } else if (schedule._id === "syncDepartmentSchedule") {
            await syncDepartmentScheduleExec();
          }
        });
      });
      console.log(`[executeScheduler.ts][loadCronSchedules] 크론 스케줄 등록 완료: ID=${schedule._id}`);
    });

    // 더 이상 존재하지 않는 스케줄 제거 (필요한 경우만)
    Object.keys(cronJobs).forEach(jobId => {
      if (!schedules.some(schedule => schedule._id === jobId)) {
        console.log(`[executeScheduler.ts][loadCronSchedules] 더 이상 필요하지 않은 스케줄 제거: ${jobId}`);
        cronJobs[jobId].stop();
        delete cronJobs[jobId];
      }
    });
  } catch (error) {
    console.error('[executeScheduler.ts][loadCronSchedules] 스케줄 로드 중 오류 발생:', error);
  }
}

//--------------------------------------------------------------------------------------------------
// 조직도 연동 스케쥴 실행
//--------------------------------------------------------------------------------------------------
async function syncDepartmentScheduleExec() {
  const lockId = 'syncDepartmentScheduleLock';
  let lockCreated = false;

  try {
    const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

    if (!(await createLock(lockId))) {
      console.log(`[executeScheduler.ts][syncDepartmentScheduleExec] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      return;
    }

    lockCreated = true;
    await syncDepartmentSchedule();
  } catch (error) {
    console.error('[executeScheduler.ts][syncDepartmentScheduleExec] Error:', error);
  } finally {
    if (lockCreated) {
      console.log("조직도 연동 잠금 해제>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      await releaseLock(lockId);
    }
  }
}

//--------------------------------------------------------------------------------------------------
// 사용자 연동 스케쥴 실행
//--------------------------------------------------------------------------------------------------
async function syncUserScheduleExec() {
  const lockId = 'syncUserScheduleLock';
  let lockCreated = false;

  try {
    const { unixTimestamp, formattedDate } = getFormattedKoreaTime();

    if (!(await createLock(lockId))) {
      console.log(`[executeScheduler.ts][syncUserScheduleExec] 작업이 이미 실행 중입니다 ::: ${unixTimestamp} ::: ${formattedDate}`);
      return;
    }

    lockCreated = true;
    await syncUserSchedule();
  } catch (error) {
    console.error('[executeScheduler.ts][syncUserScheduleExec] Error:', error);
  } finally {
    if (lockCreated) {
      console.log("사용자 연동 잠금 해제>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      await releaseLock(lockId);
    }
  }
}

//--------------------------------------------------------------------------------------------------
// 스케줄러 주기적 감지
//--------------------------------------------------------------------------------------------------
async function reloadCronSchedulesPeriodically() {
  console.log('[executeScheduler.ts] 스케줄 주기적 감지 시작..................................................................');

  setInterval(async () => {
    console.log('[executeScheduler.ts][reloadCronSchedulesPeriodically] 스케줄 재로드 시작 >>>>>>>>>>>>>>>>>>');
    await loadCronSchedules();
  }, 60000); // 1분마다 실행
}

//--------------------------------------------------------------------------------------------------
// 실행 시 크론 로드 및 주기적 감지 시작
//--------------------------------------------------------------------------------------------------
loadCronSchedules();
reloadCronSchedulesPeriodically();

//--------------------------------------------------------------------------------------------------
// 시간을 포맷팅하는 함수
//--------------------------------------------------------------------------------------------------
function getFormattedKoreaTime() {
  const now = new Date();
  const unixTimestamp = now.getTime();
  const koreaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));

  const year = koreaTime.getFullYear();
  const month = String(koreaTime.getMonth() + 1).padStart(2, '0');
  const day = String(koreaTime.getDate()).padStart(2, '0');

  const hours = koreaTime.getHours();
  const minutes = String(koreaTime.getMinutes()).padStart(2, '0');
  const seconds = String(koreaTime.getSeconds()).padStart(2, '0');
  const ampm = hours >= 12 ? '오후' : '오전';
  const formattedHour = hours % 12 || 12;

  const formattedDate = `${year}-${month}-${day} ${ampm} ${formattedHour}:${minutes}:${seconds}`;
  return { unixTimestamp, formattedDate };
}
