import Koa from 'koa';
import {ENCKEYFORPARAM} from 'constants/commonConstants';
import {encryptCdnToken} from 'utils/cipher';

const xorDecrypt = (base64: any, key: string) => {
  const encrypted = atob(base64);
  let decoded = '';
  for (let i = 0; i < encrypted.length; i++) {
    decoded += String.fromCharCode(
      encrypted.charCodeAt(i) ^ key.charCodeAt(i % key.length)
    );
  }
  return decoded;
};

const downloadAuthForChina = async (ctx: Koa.Context, next: Koa.Next) => {
  const uri = ctx.request.path;
  const query = ctx.request.query;
  const headers = ctx.headers;
  const method = ctx.method;
  // console.log(`[downloadAuthForChina] 입력토큰 : ${headers['authorization']}`);

  // @ts-ignore
  const decTest = xorDecrypt(headers['authorization'].slice(7), ENCKEYFORPARAM);
  console.log(`[downloadAuthForChina] 입력토큰 복호화 : ${decTest}`);

  // @ts-ignore
  const testHostName = headers.host.lastIndexOf(':') == -1 ? headers['host'] : headers['host'].substring(0, headers.host.lastIndexOf(':'));
  console.log('[downloadAuthForChina] 테스트용 토큰 : Bearer ', encryptCdnToken(`https://${testHostName}${uri}`, ENCKEYFORPARAM));
  // console.log(`[downloadAuthForChina] --------------------------------------`);

  try {
    // OPTIONS 요청 (Preflight) 허용
    if (method === 'OPTIONS') {
      ctx.set('Access-Control-Allow-Origin', '*');
      ctx.set('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
      ctx.set('Access-Control-Allow-Headers', headers['access-control-request-headers'] || '*');
      ctx.status = 200;
      return;
    }

    // 인증 제외 URI 예외 처리
    if (
      uri.includes('/profileImages/') ||
      uri.includes('.thumb.') ||
      uri.includes('/nmp-chat/')
    ) {
      await next();
      return;
    }

    // 토큰 추출
    let token = '';
    const authHeader = headers['authorization'];
    if (authHeader && authHeader.toLowerCase().startsWith('bearer ')) {
      token = authHeader.slice(7);
    } else if (query.cdnToken) {
      // @ts-ignore
      token = decodeURIComponent(query.cdnToken);
    }

    if (!token) {
      const userAgent = headers['user-agent'] || '';
      const fileExt = uri.split('.').pop()?.toLowerCase() || '';
      const allowedDocExts = ['pdf', 'ppt', 'pptx', 'xlsx', 'xls', 'xlsb', 'doc', 'docx', 'hwp', 'zip'];
      const allowedVideoExts = ['mp4', 'avi', 'mov', 'm4v', 'mpg', 'mpeg', 'mkv', 'webm', '3gp', 'wmv', 'wav', 'mp3', 'ogg'];

      if (
        // userAgent.startsWith('Dart/3.') ||
        // (userAgent.startsWith('Apache-HttpClient/') && allowedDocExts.includes(fileExt)) ||
        (userAgent.startsWith('AppleCoreMedia/') && allowedVideoExts.includes(fileExt)) ||
        (userAgent.startsWith('ExoPlayer') && allowedVideoExts.includes(fileExt))
      ) {
        await next();
        return;
      }

      ctx.status = 401;
      ctx.body = 'Unauthorized: Missing Authorization';
      return;
    }

    // 토큰 복호화 및 검증
    const decrypted = xorDecrypt(token, ENCKEYFORPARAM);
    const parsed = JSON.parse(decrypted);
    console.log(`[downloadAuthForChina] Token cdnUrl : ${parsed.cdnUrl}`);
    // console.log(`[downloadAuthForChina] Token time : ${parsed.unixTime}`);

    const now = new Date().getTime();
    const delta = Math.abs(now - parsed.unixTime);
    if (delta > 60 * 1000) {
      ctx.status = 401;
      ctx.body = 'Unauthorized: Token expired';
      return;
    }

    // @ts-ignore
    const hostName = headers.host.lastIndexOf(':') == -1 ? headers['host'] : headers['host'].substring(0, headers.host.lastIndexOf(':'));
    const fullUrl = `https://${hostName}${uri}`;
    // console.log(`[downloadAuthForChina] headers.host : ${headers.host}`);
    // console.log(`[downloadAuthForChina] uri : ${uri}`);
    // console.log(`[downloadAuthForChina] fullUrl : ${fullUrl}`);
    // console.log(`[downloadAuthForChina] --------------------------------------`);
    console.log(`[downloadAuthForChina] --------------------------------------`);

    if (parsed.cdnUrl !== fullUrl) {
      const lastSlashIdx = parsed.cdnUrl.lastIndexOf('/');
      const expectedUrl =
        parsed.cdnUrl.substring(0, lastSlashIdx + 1) +
        encodeURIComponent(parsed.cdnUrl.substring(lastSlashIdx + 1));
      // console.log(`[downloadAuthForChina] expectedUrl : ${expectedUrl}`);
      if (fullUrl !== expectedUrl) {
        ctx.status = 401;
        ctx.body = 'Unauthorized: URL mismatch';
        return;
      }
    }

    // 통과
    await next();
    return;
  } catch (err) {
    console.log(`[downloadAuthForChina] Catch : ${err}`);
    // @ts-ignore
    ctx.status = err.status || 401;
    // @ts-ignore
    ctx.body = {message: err.message || 'Unauthorized'};
  }
};

export default downloadAuthForChina;
