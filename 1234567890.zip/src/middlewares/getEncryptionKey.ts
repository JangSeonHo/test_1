import Koa from 'koa';
import encryptionKeyModel from 'models/encryption/encryption_key';

const getEncryptionKey = async (ctx: Koa.Context, next: Koa.Next) => {
  const tenantFlag = ctx.response.get('tenantFlag');
  try {
    const targetEncryptionKeyModel = encryptionKeyModel({tenantFlag});
    const encryptionKeyDoc = await targetEncryptionKeyModel.findOne({ tenantFlag: tenantFlag });

    if (!encryptionKeyDoc || !encryptionKeyDoc.encryptionKey) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'Encryption key not found',
      };
      return;
    }

    // 조회된 키를 ctx.state에 저장하여 다음 미들웨어에서 사용할 수 있게 합니다.
    ctx.state.encryptionKey = encryptionKeyDoc.encryptionKey;

    // 다음 미들웨어로 제어를 넘깁니다.
    await next();

  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getEncryptionKey;
