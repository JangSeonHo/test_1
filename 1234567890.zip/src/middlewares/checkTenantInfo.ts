import Koa from 'koa';

const checkTenantInfo = async (ctx: Koa.Context, next: Koa.Next) => {
  try {
    if (!ctx.path.startsWith('/api')) {
      // API가 아니면 무시하고 통과. 웹라우팅을 위해서...
      return next();
    }

    if (ctx.request.url.includes('binary/iOS/')) {
      return await next();
    }
    if (ctx.path.startsWith('/api/file')) {
      return await next();
    }

    const tenantFlag = ctx.headers['tenant-flag'] ?? ctx.query.tenantFlag;
    if (!tenantFlag) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Bad Request',
      };
    } else {
      const lanCode = ctx.headers['lan-code'] ?? 'ko_KR';
      const deviceType = ctx.headers['device-type'] ?? '';
      const versionInfo = ctx.headers['version-info'] ?? '';
      const reqIp = ctx.request.ip ?? '';

      ctx.set('lanCode', lanCode);
      ctx.set('tenantFlag', tenantFlag);
      ctx.set('deviceType', deviceType);
      ctx.set('versionInfo', versionInfo);
      ctx.set('reqIp', reqIp);

      await next();
    }
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default checkTenantInfo;
