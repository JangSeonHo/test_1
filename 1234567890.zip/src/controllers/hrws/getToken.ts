import Koa from 'koa';
import { HRWS_SECRET_KEY, HRWS_ATTEND_API_KEY, HRWS_SECRET_EXPIRYTIME } from '../../configs/hrws/security';
import { allowIPaddress } from '../../services/hrws/system/allowIPaddress';
import { createToken } from '../../services/hrws/security/jwtTokenUtil';

interface JwtInfos {
  ucapAttendKey: string;
}

const getToken = async (ctx: Koa.Context) => {

  try {
    // IP 주소 확인
    const clientIP = ctx.request.ip;
    console.log('[HRWS_getToken] Remote IP Address:', clientIP);

    if (!allowIPaddress(process.env.HRWS_WHITE_LIST || '', clientIP)) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        error: 'Forbidden: IP not allowed'
      };
      return;
    }

    const ucapAttendKey = ctx.request.body?.ucapAttendKey;

    if (!ucapAttendKey) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: 'Bad Request: ucapAttendKey is required'
      };
      return;
    }

    if (ucapAttendKey !== HRWS_SECRET_KEY) {
      ctx.status = 401;
      ctx.body = {
        success: false,
        error: 'Unauthorized: Invalid ucapAttendKey'
      };
      return;
    }

    const token = createToken(
      ucapAttendKey,
      HRWS_ATTEND_API_KEY,
      HRWS_SECRET_EXPIRYTIME
    );

    if (!token) {
      ctx.status = 500;
      ctx.body = {
        success: false,
        error: 'Failed to create token'
      };
      return;
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        token
      }
    };

  } catch (err) {
    console.error('Error in getToken:', err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'Internal server error'
    };
  }
};

export default getToken; 