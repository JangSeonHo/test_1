import Koa from 'koa';
import { cleanupWorkingStatus as cleanWS } from '../../services/hrws/cleanupWorkingStatus';
import { updateWorkingStatusService as updateWS } from '../../services/hrws/updateWorkingStatus';
import { allowIPaddress as aIP } from '../../services/hrws/system/allowIPaddress';
import { checkJWT } from '../../services/hrws/security/jwtTokenUtil';
import { 
  HRWS_SECRET_KEY, 
  HRWS_ATTEND_API_KEY, 
  HRWS_WHITE_LIST 
} from '../../configs/hrws/security';
import mongoose from 'mongoose';

interface JsonUploadResponse {
  httpStatus: number;     // 표준 HTTP 상태 코드
  customCode: string;     // 사용자 정의 코드
  message?: string;       // 응답 메시지
  success?: boolean;      // 성공 여부
  data?: any;            // 응답 데이터
}

interface Employee {
  user_id: string;
  attend: string;
  attend_code?: string;
}

interface RequestBody {
  date: string;
  company_code: string;
  employee_count: string;
  token: string;
  employee: Employee[];
}

// 공통 에러 타입 정의
export enum ErrorCode {
  IP_NOT_ALLOWED = '600',
  TOKEN_EMPTY = '601',
  DB_ERROR = '602',
  SYSTEM_ERROR = '999'
}

const updateWorkingStatus = async (ctx: Koa.Context) => {
  try {
    const response: JsonUploadResponse = {
      httpStatus: 200,
      customCode: '200',    // 초기값을 성공으로 설정
      success: true
    };

    // IP 주소 검증
    console.log(`[HRWS_updateWorkingStatus] Remote IP Address: ${ctx.request.ip}`);
    if (!aIP(HRWS_WHITE_LIST, ctx.request.ip)) {
      response.httpStatus = 403;
      response.customCode = ErrorCode.IP_NOT_ALLOWED;
      response.success = false;
      response.message = 'IP address not allowed';
      ctx.status = response.httpStatus;
      ctx.body = response;
      return;
    }

    console.log(`[HRWS] RequestBody: ${JSON.stringify(ctx.request.body)}`); 
    
    // body에서 token 확인
    const { token } = ctx.request.body as RequestBody;
    if (!token || !token.startsWith('Bearer ')) {
      response.httpStatus = 401;
      response.customCode = ErrorCode.TOKEN_EMPTY;
      response.success = false;
      response.message = 'Token is missing or invalid format. Use: Bearer <token>';
      ctx.status = response.httpStatus;
      ctx.body = response;
      return;
    }

    // Bearer 제거하고 토큰만 추출
    const jwtToken = token.replace('Bearer ', '').trim();
    
    // 토큰 검증
    const jwtResult = await checkJWT(
      HRWS_SECRET_KEY,
      HRWS_ATTEND_API_KEY,
      jwtToken
    );

    if (!jwtResult.isValid) {
      response.httpStatus = 401;
      response.customCode = ErrorCode.TOKEN_EMPTY;
      response.success = false;
      response.message = jwtResult.error || 'Token verification failed';
      ctx.status = response.httpStatus;
      ctx.body = response;
      return;
    }

    // 토큰 검증 성공인 경우에만 처리
    const body = ctx.request.body as RequestBody;
    
    try {
      // 데이터 형식 변환
      const serviceParams = {
        companyCode: body.company_code,
        employeeData: body.employee.map((emp: Employee) => ({
          employeeId: emp.user_id,
          workingStatus: emp.attend
        })),
        tenantFlag: ctx.request.headers['tenant-flag'] as string
      };

      const result = await updateWS(serviceParams);
      response.data = result;
      ctx.status = response.httpStatus;
      ctx.body = response;
    } catch (error) {
      console.log('Error in data save:', error);
      response.httpStatus = 500;
      response.customCode = ErrorCode.DB_ERROR;
      response.success = false;
      response.message = 'Database transaction error : ' + error;
      ctx.status = response.httpStatus;
      ctx.body = response;
    }

  } catch (err) {
    console.log('Error in updateWorkingStatus:', err);
    ctx.status = 500;
    ctx.body = {
      httpStatus: 500,
      customCode: ErrorCode.SYSTEM_ERROR,
      success: false,
      message: 'HRWS : Internal server error'
    };
  }
};

export default updateWorkingStatus; 
