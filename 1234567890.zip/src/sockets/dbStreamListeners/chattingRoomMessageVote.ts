/* eslint-disable max-len */
import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';
import chattingRoomMessageVote, {streamModel} from 'models/message/chatting_room_message_vote';
import streamMongoose from 'configs/streamMongoose';

let currentStream: ChangeStream | null = null;

const cleanup = async () => {
  if (currentStream) {
    try {
      await currentStream.close();
      currentStream.removeAllListeners();
      currentStream = null;
    } catch (error) {
      console.error('Error during stream cleanup:', error);
    }
  }
};

const createChangeStream = async (tenantFlag: string, io: Server) => {
  await cleanup();

  try {
    currentStream = streamModel({tenantFlag}).watch([], {
      fullDocument: 'updateLookup'
    })  as unknown as ChangeStream;

    currentStream.on('change', async (data: any) => {
      try {
        const {operationType} = data;

        if (operationType === 'update') {
          const updatedFields = data.updateDescription.updatedFields;
          const {isEnded} = updatedFields;

          const voteId = data.documentKey._id;

          if (isEnded) {
            const vote = await chattingRoomMessageVote({tenantFlag})
              .findOne({_id: voteId})
              .populate({
                'path': 'parentUser',
                'select': 'userName jobTitle',
              });

            if (vote !== null) {
              io.to(`${tenantFlag}:chatting_room:${vote.parentChattingRoom.toString()}`)
                .emit('send_alarm', {
                  type: 'vote_end',
                  data: vote,
                });
            }
          }
        }
      } catch (error) {
        console.error('Error handling vote change:', error);
      }
    });

    currentStream.on('error', (error) => {
      console.error('Stream error:', error);
      cleanup().then(() => {
        setTimeout(() => {
          createChangeStream(tenantFlag, io).catch(console.error);
        }, 1000);
      });
    });

  } catch (error) {
    console.error('Error creating stream:', error);
    await cleanup();
    setTimeout(() => {
      createChangeStream(tenantFlag, io).catch(console.error);
    }, 1000);
  }
};

const chattingRoomMessageVoteListener = (tenantFlag: string, io: Server) => {
  createChangeStream(tenantFlag, io).catch(console.error);

  streamMongoose.connection.once('reconnect', () => {
    console.log('MongoDB reconnected - reinitializing stream');
    createChangeStream(tenantFlag, io).catch(console.error);
  });

  return cleanup;
};

export default chattingRoomMessageVoteListener;
