/* eslint-disable max-len */
import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';
import userInfoModel from 'models/account/user_info';
import {userStatusModelPrimaryOnly, streamModel} from 'models/account/user_status_info';
import {UserStatusCode} from '../../constants/commonConstants';
import streamMongoose from 'configs/streamMongoose';

let currentStream: ChangeStream | null = null;

const cleanup = async () => {
  if (currentStream) {
    try {
      await currentStream.close();
      currentStream.removeAllListeners();
      currentStream = null;
    } catch (error) {
      console.error('Error during stream cleanup:', error);
    }
  }
};

const createChangeStream = async (tenantFlag: string, io: Server) => {
  await cleanup();

  try {
    currentStream = streamModel({tenantFlag}).watch([], {
      fullDocument: 'updateLookup'
    }) as unknown as ChangeStream;

    currentStream.on('change', async (data: any) => {
      try {
        if (data.updateDescription) {
          const {_id} = data.documentKey;
          const userStatus = await userStatusModelPrimaryOnly({tenantFlag})
            .findOne({_id: _id})
            .select('parentUser pcStatus mobileStatus statusString');
          console.log('update_user_status stream userStatus id :', userStatus.parentUser,
            ' / pcStatus :', userStatus.pcStatus, ' / mobileStatus :', userStatus.mobileStatus);

          io.in(`${tenantFlag}:user:${userStatus.parentUser}`)
            .emit('update_user_status', {
              userId: userStatus.parentUser,
              pcStatus: userStatus.pcStatus || UserStatusCode.OFFLINE,
              mobileStatus: userStatus.mobileStatus || UserStatusCode.OFFLINE,
              statusString: userStatus.statusString,
            });

          io.in(`${tenantFlag}:user_status_info:${userStatus.parentUser}`)
            .emit('update_user_status', {
              userId: userStatus.parentUser,
              pcStatus: userStatus.pcStatus || UserStatusCode.OFFLINE,
              mobileStatus: userStatus.mobileStatus || UserStatusCode.OFFLINE,
              statusString: userStatus.statusString,
            });
        }
      } catch (error) {
        console.error('Error handling status change:', error);
      }
    });

    currentStream.on('error', (error) => {
      console.error('Stream error:', error);
      cleanup().then(() => {
        setTimeout(() => {
          createChangeStream(tenantFlag, io).catch(console.error);
        }, 1000);
      });
    });

  } catch (error) {
    console.error('Error creating stream:', error);
    await cleanup();
    setTimeout(() => {
      createChangeStream(tenantFlag, io).catch(console.error);
    }, 1000);
  }
};

const userInfoStatusListener = (tenantFlag: string, io: Server) => {
  createChangeStream(tenantFlag, io).catch(console.error);

  streamMongoose.connection.once('reconnect', () => {
    console.log('MongoDB reconnected - reinitializing stream');
    createChangeStream(tenantFlag, io).catch(console.error);
  });

  return cleanup;
};

export default userInfoStatusListener;
