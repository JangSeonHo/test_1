/* eslint-disable max-len */
import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';
import userInfoModel, {streamModel} from 'models/account/user_info';
import companyInfoModel from 'models/company/company_company_info';
import companyDepartmentInfoModel from 'models/company/company_department_info';
import userStatusInfoModel from 'models/account/user_status_info';
import userGroupInfoModel from 'models/account/user_group_info';
import streamMongoose from 'configs/streamMongoose';

let currentStream: ChangeStream | null = null;

const cleanup = async () => {
  if (currentStream) {
    try {
      await currentStream.close();
      currentStream.removeAllListeners();
      currentStream = null;
    } catch (error) {
      console.error('Error during stream cleanup:', error);
    }
  }
};

const createChangeStream = async (tenantFlag: string, io: Server) => {
  await cleanup();

  try {
    currentStream = streamModel({tenantFlag}).watch([], {
      fullDocument: 'updateLookup'
    }) as unknown as ChangeStream;

    currentStream.on('change', async (data: any) => {
      try {
        const {operationType} = data;

        if (operationType === 'update') {
          const {_id} = data.documentKey;
          const {
            profileImage,
            useAlarmWhenPCIsUnfocused,
          } = data.updateDescription.updatedFields;

          if (profileImage !== undefined) {
            io.in(`${tenantFlag}:user:${_id}`)
              .emit('update_user_profile_image', {
                userId: _id,
                profileImage,
              });

            io.in(`${tenantFlag}:user_status_info:${_id}`)
              .emit('update_user_profile_image', {
                userId: _id,
                profileImage,
              });
          }

          if (useAlarmWhenPCIsUnfocused !== undefined) {
            io.in(`${tenantFlag}:user:${_id}`)
              .emit('update_alarm_setting', {
                type: 'only_alarm_when_pc_absence',
                value: useAlarmWhenPCIsUnfocused,
              });
          }

          const fieldKeys = Object.keys(data.updateDescription.updatedFields);
          await Promise.all(fieldKeys.map(async (key: string) => {
            if (key.includes('childUserGroups')) {
              const {childUserGroups} = await userInfoModel({tenantFlag}).findOne({_id})
                .select('childUserGroups')
                .populate({
                  path: 'childUserGroups',
                  match: { isDeleted: false },
                  populate: {
                    path: 'childGroupUsers',
                    select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
                    populate: [{
                      path: 'childStatusInfo',
                      select: '-parentUser -__v -_id',
                    }, {
                      path: 'parentCompany',
                      select: 'companyName',
                    }, {
                      path: 'parentDepartment',
                      select: 'departmentName',
                    }],
                  },
                });

              io.in(`${tenantFlag}:user:${_id}`)
                .emit('update_my_user_groups', {
                  childUserGroups,
                });
            }

            if (key.includes('childBookmarkUsers')) {
              const {childBookmarkUsers} = await userInfoModel({tenantFlag}).findOne({_id})
                .select('childBookmarkUsers')
                .populate({
                  path: 'childBookmarkUsers',
                  match: { isDeleted: false },
                  select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -parentGroup -childUserGroups -childPrivateContacts -childBookmarkUsers',
                  populate: [{
                    path: 'childStatusInfo',
                    select: '-parentUser -__v -_id',
                  }, {
                    path: 'parentCompany',
                    select: 'companyName',
                  }, {
                    path: 'parentDepartment',
                    select: 'departmentName',
                  }],
                });

              io.in(`${tenantFlag}:user:${_id}`)
                .emit('update_my_bookmark_users', {
                  childBookmarkUsers,
                });
            }

            if (key.includes('childPrivateContacts')) {
              const {childPrivateContacts} = await userInfoModel({tenantFlag}).findOne({_id})
                .select('childPrivateContacts')
                .populate({
                  path: 'childPrivateContacts',
                  match: { isDeleted: false },
                  select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -parentGroup -childUserGroups -childPrivateContacts -childBookmarkUsers',
                  populate: [{
                    path: 'childStatusInfo',
                    select: '-parentUser -__v -_id',
                  }, {
                    path: 'parentCompany',
                    select: 'companyName',
                  }, {
                    path: 'parentDepartment',
                    select: 'departmentName',
                  }],
                });

              io.in(`${tenantFlag}:user:${_id}`)
                .emit('update_my_private_contacts', {
                  childPrivateContacts,
                });
            }
          }));
        }
      } catch (error) {
        console.error('Error handling user info change:', error);
      }
    });

    currentStream.on('error', (error) => {
      console.error('Stream error:', error);
      cleanup().then(() => {
        setTimeout(() => {
          createChangeStream(tenantFlag, io).catch(console.error);
        }, 1000);
      });
    });

  } catch (error) {
    console.error('Error creating stream:', error);
    await cleanup();
    setTimeout(() => {
      createChangeStream(tenantFlag, io).catch(console.error);
    }, 1000);
  }
};

const userInfoListener = (tenantFlag: string, io: Server) => {
  // before populate
  companyInfoModel({tenantFlag});
  companyDepartmentInfoModel({tenantFlag});
  userStatusInfoModel({tenantFlag});
  userGroupInfoModel({tenantFlag});

  createChangeStream(tenantFlag, io).catch(console.error);

  streamMongoose.connection.once('reconnect', () => {
    console.log('MongoDB reconnected - reinitializing stream');
    createChangeStream(tenantFlag, io).catch(console.error);
  });

  return cleanup;
};

export default userInfoListener;
