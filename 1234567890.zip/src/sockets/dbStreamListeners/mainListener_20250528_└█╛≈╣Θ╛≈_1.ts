// import mongoose from 'mongoose';
import {Server} from 'socket.io';

import userInfoModel from 'models/account/user_info';
// import companyInfoModel from 'models/company/company_company_info';
// import companyDepartmentInfoModel from 'models/company/company_department_info';
import userStatusInfoModel, {userStatusModelPrimaryOnly} from 'models/account/user_status_info';
import userGroupInfoModel from 'models/account/user_group_info';
import chattingNoticeMessageModel from '../../models/message/chatting_room_message_notice';
import chattingRoomMessageEgModel from '../../models/message/chatting_room_message_eg';
import chattingRoom from '../../models/message/chatting_room_info';
import chattingRoomMessageNotice from '../../models/message/chatting_room_message_notice';
import chattingRoomMessageVote from '../../models/message/chatting_room_message_vote';
import noteInfoModel from '../../models/note/note_info';
import userAlarmModel from '../../models/alarm/alarm';
import {ENCKEYFORPARAM, UserStatusCode} from '../../constants/commonConstants';
import userSignInfoModel from '../../models/account/user_sign_info';
import chattingRoomMessageModel from '../../models/message/chatting_room_message';
import chatVoteModel from '../../models/message/chatting_room_message_vote';
import chatMemberModel from '../../models/message/chatting_room_member';
import {chatRoomBookMsgModelPrimaryOnly} from '../../models/message/chatting_room_booked_message';
import streamMongoose from 'configs/streamMongoose';
import chattingRoomInfoModel from '../../models/message/chatting_room_info';
import {msgLogJobHistoryModelPrimaryOnly} from '../../models/log/message_log_job_history';
import {ecsTaskId} from '../../server';
import {createFile, createUserData} from 'routes/system/controllers/createMsgLogAuditFile';
import getDateDiffFromToday from 'utils/string/getDateDiffFromToday';
import {decryptURL} from '../../utils/cipher';
import companyInfoModel from 'models/company/company_company_info';

const tenantFlag = 'nmp';
let resumeToken: unknown | null = null;
let io: Server;
let lastChantStream: any = null;

const mainListener = (ioParam: Server) => {
  // const db = mongoose.connection.db;
  io = ioParam;
  createChangeStream(io);

  streamMongoose.connection.on('reconnected', () => {
    console.log(`${ecsTaskId.value} ### stream db reconnected successfully.`);
    if (!!lastChantStream) {
      lastChantStream.close();
      console.log('mainListener - last stream close.');
    }
    setTimeout(() => {
      console.log('Retrying mainListener change stream... by reconnected event');
      createChangeStream(io);
    }, 100);
  });
};

// eslint-disable-next-line require-jsdoc
async function createChangeStream(io: Server) {
  const db = streamMongoose.connection.db;
  const changeStream = db!.watch([], {
    ...(resumeToken ? {resumeAfter: resumeToken} : {}),
  });
  lastChantStream = changeStream;

  changeStream.on('change', (dataTmp: any) => {
    const data = {...dataTmp};
    // resumeToken = data.id;
    handleChange(data, io);
  });

  // changeStream.on('error', (error: Error) => {
  //   console.log('mainListener Error :', error);
  //
  //   setTimeout(() => {
  //     console.log('Retrying mainListener change stream... by stream error event');
  //     createChangeStream(io);
  //   }, 5000);
  // });
};

// eslint-disable-next-line require-jsdoc
async function handleChange(data: any, io: Server) {
  const {operationType, ns, fullDocument, documentKey} = data;
  const colName = ns.coll;

  try {
    switch (colName) {
      case 'nmp_user_infos':
        if (operationType === 'update') {
          const {_id} = data.documentKey;
          const {
            profileImage,
            useAlarmWhenPCIsUnfocused,
          } = data.updateDescription.updatedFields;

          if (profileImage !== undefined) {
            io.in(`${tenantFlag}:user:${_id}`)
              .emit('update_user_profile_image', {
                userId: _id,
                profileImage,
              });

            io.in(`${tenantFlag}:user_status_info:${_id}`)
              .emit('update_user_profile_image', {
                userId: _id,
                profileImage,
              });
          }
          if (useAlarmWhenPCIsUnfocused !== undefined) {
            // console.log('Detect change : userInfo useAlarmWhenPCIsUnfocused :', useAlarmWhenPCIsUnfocused);
            io.in(`${tenantFlag}:user:${_id}`)
              .emit('update_alarm_setting', {
                type: 'only_alarm_when_pc_absence',
                value: useAlarmWhenPCIsUnfocused,
              });
          }

          const fieldKeys = Object.keys(data.updateDescription.updatedFields);
          await Promise.all(fieldKeys.map(async (key: string) => {
            if (key.includes('childUserGroups')) {
              const uInfo = await userInfoModel({tenantFlag}).find({_id})
                .select('childUserGroups')
                .populate({
                  path: 'childUserGroups',
                  populate: {
                    path: 'childGroupUsers',
                    select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
                    match: { isDeleted: false },
                    populate: [{
                      path: 'childStatusInfo',
                      select: '-parentUser -__v -_id',
                    }, {
                      path: 'parentCompany',
                      select: 'companyName',
                    }, {
                      path: 'parentDepartment',
                      select: 'departmentName',
                    }],
                  },
                }).lean();

              io.in(`${tenantFlag}:user:${_id}`)
                .emit('update_my_user_groups', {
                  childUserGroups: uInfo[0].childUserGroups,
                });
            }

            if (key.includes('childBookmarkUsers')) {
              const uInfo = await userInfoModel({tenantFlag}).find({_id})
                .select('childBookmarkUsers')
                .populate({
                  path: 'childBookmarkUsers',
                  match: { isDeleted: false },
                  select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -parentGroup -childUserGroups -childPrivateContacts -childBookmarkUsers',
                  populate: [{
                    path: 'childStatusInfo',
                    select: '-parentUser -__v -_id',
                  }, {
                    path: 'parentCompany',
                    select: 'companyName',
                  }, {
                    path: 'parentDepartment',
                    select: 'departmentName',
                  }],
                }).lean();

              io.in(`${tenantFlag}:user:${_id}`)
                .emit('update_my_bookmark_users', {
                  childBookmarkUsers: uInfo[0].childBookmarkUsers,
                });
            }

            // if (key.includes('childPrivateContacts')) {
            //   const uInfo = await userInfoModel({tenantFlag}).find({_id})
            //     .select('childPrivateContacts')
            //     .populate({
            //       path: 'childPrivateContacts',
            //       match: { isDeleted: false },
            //       select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -parentGroup -childUserGroups -childPrivateContacts -childBookmarkUsers',
            //       populate: [{
            //         path: 'childStatusInfo',
            //         select: '-parentUser -__v -_id',
            //       }, {
            //         path: 'parentCompany',
            //         select: 'companyName',
            //       }, {
            //         path: 'parentDepartment',
            //         select: 'departmentName',
            //       }],
            //     }).lean();

            //   io.in(`${tenantFlag}:user:${_id}`)
            //     .emit('update_my_private_contacts', {
            //       childPrivateContacts: uInfo[0].childPrivateContacts,
            //     });
            // }
            if (key.includes('childPrivateContacts')) {
              const userModel = userInfoModel({ tenantFlag });
              const targetCompanyModel = companyInfoModel({ tenantFlag });

              // GUC007 회사 단일 조회
              const guc007Company = await targetCompanyModel.findOne({ companyCode: 'GUC007' }).select('_id');
              const guc007CompanyId = guc007Company?._id?.toString();

              const uInfo = await userModel.find({ _id })
                .select('childPrivateContacts')
                .populate({
                  path: 'childPrivateContacts',
                  match: {
                    isDeleted: false,
                  },
                  select:
                    '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -parentGroup -childUserGroups -childPrivateContacts -childBookmarkUsers',
                  populate: [
                    { path: 'childStatusInfo', select: '-parentUser -__v -_id' },
                    { path: 'parentCompany', select: 'companyName companyCode' },
                    { path: 'parentDepartment', select: 'departmentName' },
                  ],
                })
                .lean();

              // 2차 필터링: GUC007이면 policyOrgViewYn === 'Y', 그 외는 허용
              const filteredContacts = (uInfo[0]?.childPrivateContacts || []).filter((user: any) => {
                const companyId = user.parentCompany?._id?.toString();
                if (companyId === guc007CompanyId) {
                  return user.policyOrgViewYn === 'Y';
                }
                return true;
              });

              // 전송
              io.in(`${tenantFlag}:user:${_id}`).emit('update_my_private_contacts', {
                childPrivateContacts: filteredContacts,
              });
            }
          }));
        }
        break;

      case 'nmp_chatting_room_infos':
        if (operationType === 'update') {
          const {_id} = data.documentKey;
          const {totalRoomMembers, childNoticeMessage} =
            data.updateDescription.updatedFields;
          if (totalRoomMembers) {
            io.to(`${tenantFlag}:chatting_room:${_id}`)
              .emit('update_chatting_room_members_count');
          }

          if (childNoticeMessage === null || childNoticeMessage) {
            if (childNoticeMessage === null) {
              io.to(`${tenantFlag}:chatting_room:${_id}`)
                .emit('update_chat_notice', {
                  parentChattingRoom: _id, isClear: true});
            } else {
              const message = await chattingNoticeMessageModel({tenantFlag})
                .findOne({_id: childNoticeMessage})
                .populate({
                  path: 'parentUser',
                  select: 'jobTitle userName parentDepartment',
                  populate: {
                    path: 'parentDepartment',
                    select: 'departmentName',
                  },
                }).lean();

              io.to(`${tenantFlag}:chatting_room:${_id}`)
                .emit('update_chat_notice', message);
            }
          }
        }
        break;

      case 'nmp_chatting_room_message_egs':
        if (operationType === 'insert') {
          const {parentChattingRoom} = data.fullDocument;

          io.to(`${tenantFlag}:chatting_room:${parentChattingRoom}`)
            .emit('update_chat_message_eg', data.fullDocument);
        }

        if (operationType === 'update') {
          const fullDoc = await chattingRoomMessageEgModel({tenantFlag})
            .findOne({_id: data.documentKey._id});

          io.to(`${tenantFlag}:chatting_room:${fullDoc.parentChattingRoom}`)
            .emit('update_chat_message_eg', fullDoc);
        }
        break;

      case 'nmp_chatting_room_message_notices':
        if (operationType === 'update') {
          const noticeId = data.documentKey._id;
          const room = await chattingRoom({tenantFlag})
            .findOne({childNoticeMessage: noticeId})
            .select('_id').lean();
          // room = room.toJSON();

          if (room !== null) {
            const message = await chattingRoomMessageNotice({tenantFlag})
              .findOne({_id: noticeId})
              .populate({
                path: 'parentUser',
                select: 'jobTitle userName parentDepartment',
                populate: {
                  path: 'parentDepartment',
                  select: 'departmentName',
                },
              }).lean();

            // @ts-ignore
            io.to(`${tenantFlag}:chatting_room:${room['_id']}`)
              .emit('update_chat_notice', message);
          }
        }
        break;
      case 'nmp_chatting_room_message_votes':
        if (operationType === 'update') {
          const updatedFields = data.updateDescription.updatedFields;
          const {isEnded} = updatedFields;

          const voteId = data.documentKey._id;

          if (isEnded) {
            const voteTmp = await chattingRoomMessageVote({tenantFlag})
              .find({_id: voteId})
              .populate({
                'path': 'parentUser',
                'select': 'userName jobTitle',
              }).lean();
            const vote = voteTmp[0];

            if (vote !== null) {
              io.to(`${tenantFlag}:chatting_room:${vote.parentChattingRoom}`)
                .emit('send_alarm', {
                  type: 'vote_end',
                  data: vote,
                });
            }
          }
        }
        break;

      case 'nmp_note_members':
        if (operationType === 'insert') {
          const {type, parentUser, parentNote} = data.fullDocument;

          if (type === 'R') {
            const note = await noteInfoModel({tenantFlag})
              .findOne({_id: parentNote.toString()})
              .select('sender title')
              .populate('sender', 'userName jobTitle')
              .lean();

            io.in(`${tenantFlag}:user:${parentUser}`)
              .emit('send_alarm', {
                type: 'receive_note',
                data: note,
              });
          }
        }
        break;

      case 'nmp_user_alarms':
        if (operationType === 'insert') {
          const {parentUser} = data.fullDocument;

          io.in(`${tenantFlag}:user:${parentUser}`)
            .emit('insert_user_alarm');
        }

        if (operationType === 'update') {
          const updatedFields = data.updateDescription.updatedFields;

          const {isAlreadyAlert} = updatedFields;

          if (isAlreadyAlert) {
            const {_id} = data.documentKey;
            const reminderTmp = await userAlarmModel({tenantFlag})
              .find({_id})
              .populate({
                'path': 'actionUser',
                'select': 'userName jobTitle',
              }).lean();
            const reminder = reminderTmp[0];

            io.in(`${tenantFlag}:user:${reminder.parentUser}`)
              .emit('send_alarm', {
                type: 'reminder',
                data: reminder,
              });
          }
        }
        break;

      // case 'nmp_user_badges':
      //   if (operationType === 'update') {
      //     const fd = data.fullDocument;
      //
      //     io.in(`${tenantFlag}:user:${fd.parentUser}`)
      //       .emit('update_user_badge', fd);
      //   }
      //   break;

      case 'nmp_user_group_infos':
        if (data.updateDescription) {
          const {_id} = data.documentKey;

          const userGroupTmp = await userGroupInfoModel({tenantFlag})
            .find({_id})
            .populate({
              path: 'childGroupUsers',
              select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
              populate: [{
                path: 'childStatusInfo',
                select: '-parentUser -__v -_id',
              }, {
                path: 'parentCompany',
                select: 'companyName',
              }, {
                path: 'parentDepartment',
                select: 'departmentName',
              }],
            }).lean();
          const userGroup = userGroupTmp[0];

          io.in(`${tenantFlag}:user:${userGroup.parentUser}`)
            .socketsJoin(userGroup.childGroupUsers.map((user: any) => `${tenantFlag}:user_status_info:${user._id}`));

          io.in(`${tenantFlag}:user:${userGroup.parentUser}`)
            .emit('update_my_user_groups_child_users', {
              userGroup,
            });
        }
        break;

      case 'nmp_user_status_infos':
        if (data.updateDescription) {
          const {_id} = data.documentKey;
          // const updatedFields = data.updateDescription.updatedFields;

          // const userInfo = await userInfoModel({tenantFlag})
          //   .findOne({childStatusInfo: _id})
          //   .select('_id');
          const userStatusTmp = await userStatusModelPrimaryOnly({tenantFlag})
            .find({_id: _id})
            .select('parentUser pcStatus mobileStatus statusString').lean();
          const userStatus = userStatusTmp[0];
          // console.log('update_user_status stream userStatus id :', userStatus.parentUser,
          //   ' / pcStatus :', userStatus.pcStatus, ' / mobileStatus :', userStatus.mobileStatus);

          io.in(`${tenantFlag}:user:${userStatus.parentUser}`)
            .emit('update_user_status', {
              userId: userStatus.parentUser,
              pcStatus: userStatus.pcStatus || UserStatusCode.OFFLINE,
              mobileStatus: userStatus.mobileStatus || UserStatusCode.OFFLINE,
              statusString: userStatus.statusString,
            });

          io.in(`${tenantFlag}:user_status_info:${userStatus.parentUser}`)
            .emit('update_user_status', {
              userId: userStatus.parentUser,
              pcStatus: userStatus.pcStatus || UserStatusCode.OFFLINE,
              mobileStatus: userStatus.mobileStatus || UserStatusCode.OFFLINE,
              statusString: userStatus.statusString,
            });
        }
        break;

      case 'nmp_user_sign_infos':
        if (operationType === 'insert') {
          const {parentUser} = data.fullDocument;

          io.in(`${tenantFlag}:user:${parentUser}`)
            .emit('change_user_sign_info');
        }
        if (operationType === 'update') {
          const {_id} = data.documentKey;
          const {sendStream} = data.updateDescription.updatedFields;

          if (sendStream) {
            const dataT =
              await userSignInfoModel({tenantFlag})
                .find({_id}).select('parentUser accessToken').lean();
            const dataSign = dataT[0];

            if (dataSign !== null) {
              const {parentUser, accessToken} = dataSign;

              io.in(`${tenantFlag}:user:${parentUser}`)
                .emit('change_user_sign_info', {
                  type: 'pc_logout',
                  accessToken,
                });
            }
          }
        }
        break;

      case 'nmp_chatting_room_messages':
        if (operationType === 'insert') {

          const {parentChattingRoom, replyOrigin, childVote, _id, isSystemMessage, systemMessageType, parentUser} = data.fullDocument;

          let m = {...data.fullDocument};

          if (!io.sockets.adapter.rooms.get(`${tenantFlag}:chatting_room:${parentChattingRoom}`)) {
            return;
          }

          if (replyOrigin) {
            const r = await chattingRoomMessageModel({tenantFlag})
              .findOne({_id: replyOrigin})
              .select('content parentUser isEmoticon files isNotice').lean();
            m.replyOrigin = r;
          }

          if (childVote) {
            const r = await chatVoteModel({tenantFlag})
              .findOne({parentChattingMessage: _id}).lean();
            m.childVote = r;
          }

          if (isSystemMessage && systemMessageType === 'leave' || systemMessageType === 'kick') {
            const ms = await chatMemberModel({tenantFlag}).find({
              parentChattingRoom,
              isDeleted: false,
            })
              .select('parentUser')
              .populate('parentUser')
              .select('userName jobTitle').lean();
            const chatUsers = ms.filter((user) => user.parentUser);
            m.participants = chatUsers.map((m: any) => {
              return {...m['parentUser']['userName'], 'jobTitle': m['parentUser']['jobTitle']};
            });
          }

          //예약 메세지 아이콘 표시 여부 플래그 추가
          const TargetBookedMessageModel = chatRoomBookMsgModelPrimaryOnly({tenantFlag});

          const bookedMessages = await TargetBookedMessageModel.find({
            parentChattingRoom,
            parentUser: parentUser,
          }).lean();

          if (bookedMessages && bookedMessages.length > 0) {
            m.nextBookedMsg = true;
          } else {
            m.nextBookedMsg = false;
          }

          const n = {...m};

          // TODO - 추후 압호화 버전으로 모든 사용자가 바뀌면 제거할 코드
          if (m.files.length > 0) {
            const newM = {...m};
            const urlTmp = newM.files[0].url;
            // const mimeType = msg.files[0].mimeType;

            if (!urlTmp.startsWith('https:')) {
              newM.files.forEach((file: any) => {
                file.url = decryptURL(file.url, ENCKEYFORPARAM).url;
              });
            }

            m = newM;
          }

          io.to(`${tenantFlag}:chatting_room:${parentChattingRoom}`)
            .emit('create_chatting_message', m);

          const [u, roomInfoTmp] = await Promise.all([
            userInfoModel({tenantFlag})
              .findOne({_id: parentUser})
              .select('userName jobTitle').lean(),
            chattingRoomInfoModel({tenantFlag})
              .find({_id: parentChattingRoom})
              .select('isGroupChat').lean(),
          ]);
          const roomInfo = roomInfoTmp[0];
          n.parentUser = u;

          if (!roomInfo.isGroupChat) {
            io.to(`${tenantFlag}:chatting_room:${parentChattingRoom}`)
              .emit('send_alarm', {
                type: 'chat',
                data: n,
              });
          } else {
            const roomMember = await chatMemberModel({tenantFlag}).find({
              parentChattingRoom,
              isGroupChat: true,
              isDeleted: false,
            }).select('parentUser').lean();
            const participants = roomMember.filter((user) => user.parentUser);
            participants.forEach((user) => {
              io.to(`${tenantFlag}:user:${user.parentUser}`)
                .emit('send_alarm', {
                  type: 'chat',
                  data: n,
                });
            });
          }
        }

        if (operationType === 'update') {
          const {isNotice, isImportant, isDeleted} = data.updateDescription.updatedFields;

          if (isNotice === true) {
            const messageTmp1 = await chattingRoomMessageModel({tenantFlag})
              .find({_id: data.documentKey._id})
              .select('parentChattingRoom content parentUser')
              .populate({
                path: 'parentUser',
                select: 'jobTitle userName parentDepartment',
                populate: {
                  path: 'parentDepartment',
                  select: 'departmentName',
                },
              }).lean();
            const message = messageTmp1[0];

            io.to(`${tenantFlag}:chatting_room:${message.parentChattingRoom}`)
              .emit('make_message_to_notice', {
                messageId: data.documentKey._id,
                content: message.content,
                roomId: message.parentChattingRoom,
                noticeUser: message.parentUser,
              });
          }

          if (isDeleted === true) {
            const messageTmp2 = await chattingRoomMessageModel({tenantFlag})
              .find({_id: data.documentKey._id})
              .select('parentChattingRoom content parentUser')
              .populate({
                path: 'parentUser',
                select: 'jobTitle userName parentDepartment',
                populate: {
                  path: 'parentDepartment',
                  select: 'departmentName',
                },
              }).lean();
            const message = messageTmp2[0];

            io.to(`${tenantFlag}:chatting_room:${message.parentChattingRoom}`)
              .emit('delete_chat_message', {
                messageId: data.documentKey._id,
                roomId: message.parentChattingRoom,
              });
          }

          if (isImportant !== undefined) {
            const messageTmp3 = await chattingRoomMessageModel({tenantFlag})
              .find({_id: data.documentKey._id})
              .select('parentChattingRoom content parentUser')
              .populate({
                path: 'parentUser',
                select: 'jobTitle userName parentDepartment',
                populate: {
                  path: 'parentDepartment',
                  select: 'departmentName',
                },
              }).lean();
            const message = messageTmp3[0];

            io.to(`${tenantFlag}:chatting_room:${message.parentChattingRoom}`)
              .emit('handle_message_important', {
                messageId: data.documentKey._id,
                isImportant: isImportant,
                roomId: message.parentChattingRoom,
              });
          }
        }
        break;

      case 'nmp_message_log_job_histories':
        if (operationType === 'insert') {
          const {logDate, userDataStatus, _id, logFileStatus} = data.fullDocument;

          if (userDataStatus == 'NOT_STARTED') {
            console.log(`[MsgAudit] ${ecsTaskId.value} : UserData Job - Detect`);
            const beforeData = await msgLogJobHistoryModelPrimaryOnly({tenantFlag})
              .findOneAndUpdate(
              {logDate, userDataStatus: 'NOT_STARTED'},
              {userDataStatus: 'PROCESSING'},
              {returnDocument: 'before'},
              );
            if (!beforeData) {
              return;
            }

            if (beforeData.userDataStatus == 'NOT_STARTED') {
              console.log(`[MsgAudit] ${ecsTaskId.value} : UserData Job - Start`);
              await msgLogJobHistoryModelPrimaryOnly({tenantFlag})
                .updateOne({
                  _id: _id,
                }, {
                  userDataJobStartTime: new Date().getTime(),
                });

              const res = await createUserData(getDateDiffFromToday(beforeData.logDate));
              let resStatus: string;
              if (res.success) {
                resStatus = 'COMPLETE';
              } else {
                resStatus = 'ERROR';
              }

              await msgLogJobHistoryModelPrimaryOnly({tenantFlag})
                .updateOne({
                  _id: _id,
                }, {
                  userDataStatus: resStatus,
                  logFileStatus: 'NOT_STARTED',
                  userDataJobEndTime: new Date().getTime(),
                });
            }
            console.log(`[MsgAudit] ${ecsTaskId.value} : UserData Job - End`);
          }
        }
        if (operationType === 'update') {
          let {
            userDataStatus, logFileStatus,
          } = data.updateDescription.updatedFields;
          userDataStatus = userDataStatus ?? '';
          logFileStatus = logFileStatus ?? '';

          if (userDataStatus == 'COMPLETE' || logFileStatus == 'ERROR') {
            console.log(`[MsgAudit] ${ecsTaskId.value} : LogFile Job - Detect`);
            const beforeData = await msgLogJobHistoryModelPrimaryOnly({tenantFlag})
              .findOneAndUpdate({
                  _id: data.documentKey._id,
                  logFileStatus: {$in: ['NOT_STARTED', 'ERROR']},
                  userDataStatus: 'COMPLETE',
                },
                {logFileStatus: 'PROCESSING'},
                {returnDocument: 'before'},
              );
            if (!beforeData) {
              return;
            }

            if (beforeData.logFileStatus == 'NOT_STARTED' || beforeData.logFileStatus == 'ERROR') {
              console.log(`[MsgAudit] ${ecsTaskId.value} : LogFile Job - Start`);
              await msgLogJobHistoryModelPrimaryOnly({tenantFlag})
                .updateOne({
                  _id: data.documentKey._id,
                }, {
                  logFileJobStartTime: new Date().getTime(),
                });

              const res = await createFile(getDateDiffFromToday(beforeData.logDate));
              let resStatus: string;
              if (res.hasOwnProperty('ftpPaths')) {
                resStatus = 'COMPLETE';
              } else {
                resStatus = 'ERROR';
              }

              await msgLogJobHistoryModelPrimaryOnly({tenantFlag})
                .updateOne({
                  _id: data.documentKey._id,
                }, {
                  logFileStatus: resStatus,
                  logFileJobEndTime: new Date().getTime(),
                });
              console.log(`[MsgAudit] ${ecsTaskId.value} : LogFile Job - End`);
            }
          }

          if (userDataStatus == 'ERROR') {
            console.log(`[MsgAudit] ${ecsTaskId.value} : UserData Job - Detect (Error)`);
            const beforeData = await msgLogJobHistoryModelPrimaryOnly({tenantFlag})
              .findOneAndUpdate({
                  _id: data.documentKey._id,
                  userDataStatus: 'ERROR',
                },
                {userDataStatus: 'PROCESSING'},
                {returnDocument: 'before'},
              );
            if (!beforeData) {
              return;
            }

            if (beforeData.userDataStatus == 'ERROR') {
              console.log(`[MsgAudit] ${ecsTaskId.value} : UserData Job - Start (Error)`);
              await msgLogJobHistoryModelPrimaryOnly({tenantFlag})
                .updateOne({
                  _id: data.documentKey._id,
                }, {
                  userDataJobStartTime: new Date().getTime(),
                });

              const res = await createUserData(getDateDiffFromToday(beforeData.logDate));
              let resStatus: string;
              if (res.success) {
                resStatus = 'COMPLETE';
              } else {
                resStatus = 'ERROR';
              }

              await msgLogJobHistoryModelPrimaryOnly({tenantFlag})
                .updateOne({
                  _id: data.documentKey._id,
                }, {
                  userDataStatus: resStatus,
                  logFileStatus: 'NOT_STARTED',
                  userDataJobEndTime: new Date().getTime(),
                });
              console.log(`[MsgAudit] ${ecsTaskId.value} : UserData Job - End (Error)`);
            }
          }
        }
        break;

      default:
      // console.log('$$$ mainListener - not matched change :', data);
    }
  } catch (error) {
    setImmediate(() => {
      console.log(`[ChangeStream][mainListener] ${ecsTaskId.value} Error creating stream:`, error);
    });
  }
};
export default mainListener;
