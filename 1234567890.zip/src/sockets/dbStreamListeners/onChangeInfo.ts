import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';
import {streamModel} from 'models/system/onchange_info';
import {userBadgeModelPrimaryOnly} from 'models/account/user_badge';
import streamMongoose from 'configs/streamMongoose';

let currentStream: ChangeStream | null = null;

const cleanup = async () => {
  if (currentStream) {
    try {
      await currentStream.close();
      currentStream.removeAllListeners();
      currentStream = null;
    } catch (error) {
      console.error('Error during stream cleanup:', error);
    }
  }
};

const createChangeStream = async (tenantFlag: string, io: Server) => {
  await cleanup();

  const pipeline = [
    {$match: {operationType: 'insert'}},
  ];

  try {
    currentStream = streamModel({tenantFlag}).watch(pipeline, {
      fullDocument: 'updateLookup'
    }) as unknown as ChangeStream;

    currentStream.on('change', async (data: any) => {
      try {
        const {collName, changeValue} = data.fullDocument;

        switch (collName) {
          case 'user_badge':
            userBadgeModelPrimaryOnly({tenantFlag}).find({
              parentUser: {$in: changeValue},
            }).then((badges) => {
              badges.forEach((badgeInfo: any) => {
                io.in(`${tenantFlag}:user:${badgeInfo.parentUser}`)
                  .emit('update_user_badge', badgeInfo);
              });
            });
            break;
        }
      } catch (error) {
        console.error('Error handling onChange:', error);
      }
    });

    currentStream.on('error', (error) => {
      console.error('Stream error:', error);
      cleanup().then(() => {
        setTimeout(() => {
          createChangeStream(tenantFlag, io).catch(console.error);
        }, 1000);
      });
    });

  } catch (error) {
    console.error('Error creating stream:', error);
    await cleanup();
    setTimeout(() => {
      createChangeStream(tenantFlag, io).catch(console.error);
    }, 1000);
  }
};

const onChangeInfoListener = (tenantFlag: string, io: Server) => {
  createChangeStream(tenantFlag, io).catch(console.error);

  streamMongoose.connection.once('reconnect', () => {
    console.log('MongoDB reconnected - reinitializing stream');
    createChangeStream(tenantFlag, io).catch(console.error);
  });

  return cleanup;
};

export default onChangeInfoListener;
