import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';
import chattingNoticeMessageModel from 'models/message/chatting_room_message_notice';
import {streamModel} from 'models/message/chatting_room_info';
import streamMongoose from 'configs/streamMongoose';

let currentStream: ChangeStream | null = null;

const cleanup = async () => {
  if (currentStream) {
    try {
      await currentStream.close();
      currentStream.removeAllListeners();
      currentStream = null;
    } catch (error) {
      console.error('Error during stream cleanup:', error);
    }
  }
};

const createChangeStream = async (tenantFlag: string, io: Server) => {
  await cleanup();

  try {
    currentStream = streamModel({tenantFlag}).watch([], {
      fullDocument: 'updateLookup'
    }) as unknown as ChangeStream;

    currentStream.on('change', async (data: any) => {
      try {
        const {operationType} = data;

        if (operationType === 'update') {
          const {_id} = data.documentKey;
          const {totalRoomMembers, childNoticeMessage} =
            data.updateDescription.updatedFields;
          if (totalRoomMembers) {
            io.to(`${tenantFlag}:chatting_room:${_id}`)
              .emit('update_chatting_room_members_count');
          }

          if (childNoticeMessage === null || childNoticeMessage) {
            if (childNoticeMessage === null) {
              io.to(`${tenantFlag}:chatting_room:${_id}`)
                .emit('update_chat_notice', {
                  parentChattingRoom: _id, isClear: true});
            } else {
              const message = await chattingNoticeMessageModel({tenantFlag})
                .findOne({_id: childNoticeMessage})
                .populate({
                  path: 'parentUser',
                  select: 'jobTitle userName parentDepartment',
                  populate: {
                    path: 'parentDepartment',
                    select: 'departmentName',
                  },
                });

              io.to(`${tenantFlag}:chatting_room:${_id}`)
                .emit('update_chat_notice', message);
            }
          }
        }
      } catch (error) {
        console.error('Error handling room info change:', error);
      }
    });

    currentStream.on('error', (error) => {
      console.error('Stream error:', error);
      cleanup().then(() => {
        setTimeout(() => {
          createChangeStream(tenantFlag, io).catch(console.error);
        }, 1000);
      });
    });

  } catch (error) {
    console.error('Error creating stream:', error);
    await cleanup();
    setTimeout(() => {
      createChangeStream(tenantFlag, io).catch(console.error);
    }, 1000);
  }
};

const chattingRoomInfoListener = (tenantFlag: string, io: Server) => {
  createChangeStream(tenantFlag, io).catch(console.error);

  streamMongoose.connection.once('reconnect', () => {
    console.log('MongoDB reconnected - reinitializing stream');
    createChangeStream(tenantFlag, io).catch(console.error);
  });

  return cleanup;
};

export default chattingRoomInfoListener;