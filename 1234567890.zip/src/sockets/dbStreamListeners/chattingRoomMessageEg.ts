/* eslint-disable max-len */
import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';
import chattingRoomMessageEgModel, {streamModel} from 'models/message/chatting_room_message_eg';
import streamMongoose from 'configs/streamMongoose';

let currentStream: ChangeStream | null = null;

const cleanup = async () => {
  if (currentStream) {
    try {
      await currentStream.close();
      currentStream.removeAllListeners();
      currentStream = null;
    } catch (error) {
      console.error('Error during stream cleanup:', error);
    }
  }
};

const createChangeStream = async (tenantFlag: string, io: Server) => {
  await cleanup();

  try {
    currentStream = streamModel({tenantFlag}).watch([], {
      fullDocument: 'updateLookup'
    }) as unknown as ChangeStream;

    currentStream.on('change', async (data: any) => {
      try {
        const {operationType} = data;

        if (operationType === 'insert') {
          const {parentChattingRoom} = data.fullDocument;
          io.to(`${tenantFlag}:chatting_room:${parentChattingRoom}`)
            .emit('update_chat_message_eg', data.fullDocument);
        }

        if (operationType === 'update') {
          const fullDoc = await chattingRoomMessageEgModel({tenantFlag})
            .findOne({_id: data.documentKey._id});

          io.to(`${tenantFlag}:chatting_room:${fullDoc.parentChattingRoom}`)
            .emit('update_chat_message_eg', fullDoc);
        }
      } catch (error) {
        console.error('Error handling message eg change:', error);
      }
    });

    currentStream.on('error', (error) => {
      console.error('Stream error:', error);
      cleanup().then(() => {
        setTimeout(() => {
          createChangeStream(tenantFlag, io).catch(console.error);
        }, 1000);
      });
    });

  } catch (error) {
    console.error('Error creating stream:', error);
    await cleanup();
    setTimeout(() => {
      createChangeStream(tenantFlag, io).catch(console.error);
    }, 1000);
  }
};

const chattingRoomMessageEgListener = (tenantFlag: string, io: Server) => {
  createChangeStream(tenantFlag, io).catch(console.error);

  streamMongoose.connection.once('reconnect', () => {
    console.log('MongoDB reconnected - reinitializing stream');
    createChangeStream(tenantFlag, io).catch(console.error);
  });

  return cleanup;
};

export default chattingRoomMessageEgListener;
