/* eslint-disable max-len */
import {Socket} from 'socket.io';
import jwt from 'jsonwebtoken';
import debugLog from 'utils/system/debugLog';

import userSignInfoModel from 'models/account/user_sign_info';

let isLoggedInDisconnCnt = 0;
const isLoggedIn = async (socket: Socket, next: any) => {
  try {
    const token: string = socket.handshake.auth['token'] as string ?? '';
    const tenantFlag: string = socket.handshake.headers['tenant-flag'] as string ?? '';
    const userId: string = socket.handshake.headers['user-id'] as string ?? '';

    if (tenantFlag === '' || !tenantFlag) {
      isLoggedInDisconnCnt++;
      debugLog(`isLoggedIn middleware disconnect ${isLoggedInDisconnCnt} : no tenantFlag : ${socket.id}`, 'socket');
      socket.data = 'authFailed';
      next();
      return;
    }

    if (token === '' || !token) {
      isLoggedInDisconnCnt++;
      debugLog(`isLoggedIn middleware disconnect ${isLoggedInDisconnCnt} : no token : ${socket.id}`, 'socket');
      socket.data = 'authFailed';
      next();
      return;
    }

    const jwtSecret = process.env.DEV_JWT_SECRET as string ?? '';
    const decode: any = jwt.verify(token, jwtSecret);

    if (decode.userId !== userId) {
      isLoggedInDisconnCnt++;
      debugLog(`isLoggedIn middleware disconnect ${isLoggedInDisconnCnt} : no userId : ${socket.id}`, 'socket');
      socket.data = 'authFailed';
      next();
      return;
    }

    const signInfo = await userSignInfoModel({tenantFlag})
      .findOne({parentUser: userId, accessToken: token})
      .select('_id');

    if (signInfo === null) {
      isLoggedInDisconnCnt++;
      debugLog(`isLoggedIn middleware disconnect ${isLoggedInDisconnCnt} : no signinfo : ${socket.id}`, 'socket');
      socket.data = 'authFailed';
      next();
      return;
    }

    next();
  } catch (err) {
    debugLog(`isLoggedIn middleware disconnect ${isLoggedInDisconnCnt} : catch : ${socket.id}`, 'socket');
    socket.data = 'authFailed';
    next();
  }
};

export default isLoggedIn;
