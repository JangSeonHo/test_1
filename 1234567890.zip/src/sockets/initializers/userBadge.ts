/* eslint-disable max-len */
import {Socket} from 'socket.io';

import userBadgeModel from 'models/account/user_badge';

const initializeUserBadge = async (socket: Socket) => {
  const tenantFlag: string = socket.handshake.headers['tenant-flag'] as string ?? '';
  const userId: string = socket.handshake.headers['user-id'] as string ?? '';

  const badgeInfo = await userBadgeModel({tenantFlag})
    .findOne({parentUser: userId.toString()});

  socket.emit('update_user_badge', badgeInfo);
};

export default initializeUserBadge;
