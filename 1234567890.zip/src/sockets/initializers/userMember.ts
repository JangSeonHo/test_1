/* eslint-disable max-len */
import {Socket} from 'socket.io';

import userInfoModel from 'models/account/user_info';
import userGroupInfoModel from 'models/account/user_group_info';
import chattingRoomMemberModel from 'models/message/chatting_room_member';

const initializeUserMember = async (socket: Socket) => {
  const tenantFlag: string = socket.handshake.headers['tenant-flag'] as string ?? '';
  const userId = socket.handshake.headers['user-id'];
  // const tenantFlag: string = 'nmp';
  // const userId: string = '664ace599297112ece7e2068';

  // for population
  userGroupInfoModel({tenantFlag});
  //

  const userInfo = await userInfoModel({tenantFlag}).findOne({_id: userId})
    .select('childPrivateContacts childUserGroups')
    .populate('childUserGroups', 'childGroupUsers');

  const targetLists = [...userInfo.childPrivateContacts.map((id: string) => id.toString())];

  if (userInfo.childUserGroups.length !== 0) {
    userInfo.childUserGroups.forEach(({childGroupUsers}: {childGroupUsers: any}) => {
      childGroupUsers.forEach((user: string) => {
        const id = user.toString();
        if (targetLists.indexOf(id) === -1) {
          targetLists.push(id);
        }
      });
    });
  }

  let chattingRooms = await chattingRoomMemberModel({tenantFlag})
    .find({parentUser: userId, isGroupChat: false, isDeleted: false})
    .select('parentChattingRoom')
    .populate('parentChattingRoom', 'childUsers');
  chattingRooms = chattingRooms.filter((room: any) => room.parentChattingRoom !== null);

  chattingRooms.forEach(({parentChattingRoom}) => {
    const {childUsers} = parentChattingRoom;
    childUsers.forEach((user: string) => {
      if (user !== userId && targetLists.indexOf(user) === -1) {
        targetLists.push(user);
      }
    });
  });


  targetLists.forEach((user) => {
    socket.join(`${tenantFlag}:user_status_info:${user}`);
  });
};

export default initializeUserMember;
