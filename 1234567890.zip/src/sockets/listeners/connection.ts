import {Server, Socket} from 'socket.io';

import initializeUserDefault from 'sockets/initializers/default';
import initializeUserStatus from 'sockets/initializers/userStatus';
import initializeUserMember from 'sockets/initializers/userMember';
import initializeChattingRoom from 'sockets/initializers/chattingRoom';
import initializeUserBadge from 'sockets/initializers/userBadge';

import refreshUserStatusList from 'sockets/emitters/refreshUserStatusList';
import readChatMessage from 'sockets/emitters/readChatMessage';
import connect from 'sockets/emitters/connect';
import debugLog from 'utils/system/debugLog';

const connection = (socket: Socket, io: Server) => {
  const userId = socket.handshake.headers['user-id'];
  const isMobile = socket.handshake.headers['is-mobile'] === 'Y';

  // 소켓 접속 끊김
  socket.on('disconnect', (reason) => {
    const userId = socket.handshake.headers['user-id'];
    const isMobile = socket.handshake.headers['is-mobile'] === 'Y';
    // for (const room of socket.rooms) {
    //   if (room !== socket.id) {
    //     socket.leave(room);
    //   }
    // }
    // socket.removeAllListeners();
    debugLog(`Disconnected : ${io.sockets.sockets.size} / id ${socket.id} / user ${userId} / reason : ${reason} / isMobile : ${isMobile}`, 'socket');
    // console.log(`[Socket][disconnect] Current socket clients : ${io.sockets.sockets.size}`);
    // socket.disconnect(true);
    // (socket as any) = null;
    // disconnect(socket, reason);

    // 메모리 누수 방지 코드 수정 : 2025/03/10
    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    // 모든 리스너 제거
    socket.offAny();
    socket.removeAllListeners();
    socket._cleanup();

    // 소켓 연결 종료
    socket.disconnect(true);

    // socket을 소켓 컬렉션에서 제거하여 참조 해제
    io.sockets.sockets.delete(socket.id);

    // 모든 참조 해제
    socket.data = null; // socket.io v4에서는 `socket.data` 속성이 있음
    (socket as any) = null; // TypeScript에서는 직접 null 할당이 어려우므로 우회적 방법

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  });

  if (socket.data == 'authFailed') {
    socket.emit('auth_error', {message: 'Invalid Token'});
    // console.log(`[Socket] Socket ID - ${socket.id} - authFailed`);
    socket.disconnect();
    return;
  }
  debugLog(`Connect : ${io.sockets.sockets.size} / user ${userId} / isMobile ${isMobile}`, 'socket');
  // console.log(`[Socket][connection] Current socket clients : ${io.sockets.sockets.size}`);
  initializeUserDefault(socket);
  initializeUserStatus(socket);
  initializeUserMember(socket);
  initializeChattingRoom(socket);
  initializeUserBadge(socket);

  socket.on('notify_login', connect(socket, io));

  // 유저 멤버 변경시
  socket.on('refresh_user_status_list', refreshUserStatusList(socket));
  socket.on('read_chat_message', readChatMessage(socket));
};

export default connection;
