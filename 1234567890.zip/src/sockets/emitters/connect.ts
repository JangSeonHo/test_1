/* eslint-disable max-len */
import {Server, Socket} from 'socket.io';

const connect = (socket: Socket, io: Server) => async (arg: any) => {
  const tenantFlag: string = socket.handshake.headers['tenant-flag'] as string ?? '';
  const isMobile = socket.handshake.headers['is-mobile'];
  const userId = socket.handshake.headers['user-id'];

  if (isMobile == 'Y') {
    io.in(`${tenantFlag}:user:${userId}`).emit('mobile_login', {
      socketId: socket.id,
    });
  } else {
    io.in(`${tenantFlag}:user:${userId}`).emit('pc_login', {
      socketId: socket.id,
    });
  }
};

export default connect;
