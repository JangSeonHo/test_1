const forcePCLogout = () => () => {
  // const tenantFlag: string =
  //   socket.handshake.headers['tenant-flag'] as string ?? '';
  // const userId = socket.handshake.headers['user-id'];

  // io.in(`${tenantFlag}:user:${userId}`).emit('force_pc_logout');
};

export default forcePCLogout;
