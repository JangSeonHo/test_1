import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';
import {userBadgeModelPrimaryOnly, streamModel} from 'models/account/user_badge';
import streamMongoose from 'configs/streamMongoose';
import {ecsTaskId} from '../../server';

const tenantFlag = 'nmp';
let io: Server;
let lastChantStream: any = null;

const userBadgeListener = (tenantFlag: string, ioParam: Server) => {
  io = ioParam;
  createChangeStream(io);

  streamMongoose.connection.on('reconnected', () => {
    if (!!lastChantStream) {
      lastChantStream.close();
      console.log('userBadgeListener - last stream close.');
    }
    setTimeout(() => {
      console.log(`${ecsTaskId.value} MongoDB reconnected - reinitializing stream`);
      createChangeStream(io);
    }, 100);
  });
};

const createChangeStream = async (io: Server) => {
  const pipeline = [
    {$match: {operationType: 'update'}},
    {
      $project: {
        'documentKey': 1,
        'updateDescription': 1,
      },
    },
  ];

  try {
    // @ts-ignore
    const changeStream = streamModel({tenantFlag}).watch(pipeline, {
      fullDocument: 'updateLookup',
    }) as unknown as ChangeStream;
    lastChantStream = changeStream;

    // @ts-ignore
    changeStream.on('change', async (dataTmp: any) => {
      const data = {...dataTmp};
      handleChange(data, io);
    // @ts-ignore
    // currentStream.on('error', (error) => {
    //   console.error('Stream error:', error);
    //   cleanup().then(() => {
    //     setTimeout(() => {
    //       createChangeStream(tenantFlag, io).catch(console.error);
    //     }, 1000);
    //   });
    // });
    });
    // await cleanup();
    // setTimeout(() => {
    //   createChangeStream(tenantFlag, io).catch(console.error);
    // }, 1000);
  } catch (error) {
    setImmediate(() => {
      console.log(`[ChangeStream][userBadge] ${ecsTaskId.value} Error creating stream:`, error);
    });
  }
};

// eslint-disable-next-line require-jsdoc
async function handleChange(data: any, io: Server) {
  try {
    const userBadge = await userBadgeModelPrimaryOnly({tenantFlag})
      .findById(data.documentKey).lean();
    if (userBadge) {
      // @ts-ignore
      io.in(`${tenantFlag}:user:${userBadge['parentUser']}`)
        .emit('update_user_badge', userBadge);
    }
  } catch (error) {
    setImmediate(() => {
      console.log(`[ChangeStream] ${ecsTaskId.value} Error handling userBadge change:`, error);
    });
  }
};

export default userBadgeListener;
