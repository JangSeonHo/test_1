/* eslint-disable max-len */
import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';

import userInfoModel from 'models/account/user_info';
import chattingRoomMessageModel, {streamModel} from 'models/message/chatting_room_message';
import bookedMessageModel, {chatRoomBookMsgModelPrimaryOnly} from 'models/message/chatting_room_booked_message';
import chatVoteModel from 'models/message/chatting_room_message_vote';
import chatMemberModel from 'models/message/chatting_room_member';
import streamMongoose from 'configs/streamMongoose';

let currentStream: ChangeStream | null = null;

const cleanup = async () => {
  if (currentStream) {
    try {
      await currentStream.close();
      currentStream.removeAllListeners();
      currentStream = null;
    } catch (error) {
      console.error('Error during stream cleanup:', error);
    }
  }
};

const createChangeStream = async (tenantFlag: string, io: Server) => {
  await cleanup();

  try {
    currentStream = streamModel({tenantFlag}).watch([], {
      fullDocument: 'updateLookup'
    }) as unknown as ChangeStream;

    currentStream.on('change', async (data: any) => {
      try {
        const {operationType} = data;

        if (operationType === 'insert') {
          const {parentChattingRoom, replyOrigin, childVote, _id, isSystemMessage, systemMessageType, parentUser} = data.fullDocument;

          let m = {...data.fullDocument};

          if (!io.sockets.adapter.rooms.get(`${tenantFlag}:chatting_room:${parentChattingRoom}`)) {
            return;
          }

          if (replyOrigin) {
            const r = await chattingRoomMessageModel({tenantFlag})
              .findOne({_id: replyOrigin})
              .select('content parentUser isEmoticon files isNotice');
            m.replyOrigin = r;
          }

          if (childVote) {
            const r = await chatVoteModel({tenantFlag}).findOne({parentChattingMessage: _id});
            m.childVote = r;
          }

          if (isSystemMessage && systemMessageType === 'leave' || systemMessageType === 'kick') {
            const ms = await chatMemberModel({tenantFlag}).find({
              parentChattingRoom,
              isDeleted: false,
            })
              .select('parentUser')
              .populate('parentUser')
              .select('userName jobTitle');

            m.participants = ms.map((m: any) => {
              return {...m['parentUser']['userName'], 'jobTitle': m['parentUser']['jobTitle']};
            });
          }

          //예약 메세지 아이콘 표시 여부 플래그 추가
          const TargetBookedMessageModel = chatRoomBookMsgModelPrimaryOnly({tenantFlag});

          const bookedMessages = await TargetBookedMessageModel.find({
            parentChattingRoom,
            parentUser: parentUser,
          });

          if (bookedMessages && bookedMessages.length > 0) {
            m.nextBookedMsg = true;
          } else {
            m.nextBookedMsg = false;
          }

          io.to(`${tenantFlag}:chatting_room:${parentChattingRoom}`)
            .emit('create_chatting_message', m);
          const n = {...m};
          const u = await userInfoModel({tenantFlag}).findOne({_id: parentUser}).select('userName jobTitle');
          n.parentUser = u;
          io.to(`${tenantFlag}:chatting_room:${parentChattingRoom}`)
            .emit('send_alarm', {
              type: 'chat',
              data: n,
            });
        }

        if (operationType === 'update') {
          const {isNotice, isImportant, isDeleted} = data.updateDescription.updatedFields;

          if (isNotice === true) {
            const message = await chattingRoomMessageModel({tenantFlag})
              .findOne({_id: data.documentKey._id})
              .select('parentChattingRoom content parentUser')
              .populate({
                path: 'parentUser',
                select: 'jobTitle userName parentDepartment',
                populate: {
                  path: 'parentDepartment',
                  select: 'departmentName',
                },
              });

            io.to(`${tenantFlag}:chatting_room:${message.parentChattingRoom}`)
              .emit('make_message_to_notice', {
                messageId: data.documentKey._id,
                content: message.content,
                roomId: message.parentChattingRoom,
                noticeUser: message.parentUser,
              });
          }

          if (isDeleted === true) {
            const message = await chattingRoomMessageModel({tenantFlag})
              .findOne({_id: data.documentKey._id})
              .select('parentChattingRoom content parentUser')
              .populate({
                path: 'parentUser',
                select: 'jobTitle userName parentDepartment',
                populate: {
                  path: 'parentDepartment',
                  select: 'departmentName',
                },
              });

            io.to(`${tenantFlag}:chatting_room:${message.parentChattingRoom}`)
              .emit('delete_chat_message', {
                messageId: data.documentKey._id,
                roomId: message.parentChattingRoom,
              });
          }

          if (isImportant !== undefined) {
            const message = await chattingRoomMessageModel({tenantFlag})
              .findOne({_id: data.documentKey._id})
              .select('parentChattingRoom content parentUser')
              .populate({
                path: 'parentUser',
                select: 'jobTitle userName parentDepartment',
                populate: {
                  path: 'parentDepartment',
                  select: 'departmentName',
                },
              });

            io.to(`${tenantFlag}:chatting_room:${message.parentChattingRoom}`)
              .emit('handle_message_important', {
                messageId: data.documentKey._id,
                isImportant: isImportant,
                roomId: message.parentChattingRoom,
              });
          }
        }
      } catch (error) {
        console.error('Error handling message change:', error);
      }
    });

    currentStream.on('error', (error) => {
      console.error('Stream error:', error);
      cleanup().then(() => {
        setTimeout(() => {
          createChangeStream(tenantFlag, io).catch(console.error);
        }, 1000);
      });
    });

  } catch (error) {
    console.error('Error creating stream:', error);
    await cleanup();
    setTimeout(() => {
      createChangeStream(tenantFlag, io).catch(console.error);
    }, 1000);
  }
};

const chattingRoomMessageListener = (tenantFlag: string, io: Server) => {
  createChangeStream(tenantFlag, io).catch(console.error);

  streamMongoose.connection.once('reconnect', () => {
    console.log('MongoDB reconnected - reinitializing stream');
    createChangeStream(tenantFlag, io).catch(console.error);
  });

  return cleanup;
};

export default chattingRoomMessageListener;
