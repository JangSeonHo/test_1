import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';
import {systemAlarmUserModelPrimaryOnly, streamModel} from 'models/push/system_alarm_user';
import streamMongoose from 'configs/streamMongoose';

let currentStream: ChangeStream | null = null;

const cleanup = async () => {
  if (currentStream) {
    try {
      await currentStream.close();
      currentStream.removeAllListeners();
      currentStream = null;
    } catch (error) {
      setImmediate(() => {
        console.log('[systemAlarmUserListener] Error during stream cleanup:', error);
      });
    }
  }
};

const createChangeStream = async (tenantFlag: string, io: Server) => {
  await cleanup();

  try {
    currentStream = streamModel({tenantFlag}).watch([], {
      fullDocument: 'updateLookup'
    }) as unknown as ChangeStream;

    // @ts-ignore
    currentStream.on('change', async (dataTmp: any) => {
      try {
        const data = {...dataTmp};
        const systemAlarmUser = await systemAlarmUserModelPrimaryOnly({tenantFlag})
          .findById(data.documentKey);

        if (systemAlarmUser) {
            const alarmData: any = {
              _id: systemAlarmUser._id,
              systemAlarmId: systemAlarmUser.parentSystemAlarm,
              sender: {
                userName: {ko : "", en: ""},
                jobTitle: {ko : "", en: ""},
              },
              title: systemAlarmUser.title
            }

            io.in(`${tenantFlag}:user:${systemAlarmUser.parentUser}`)
              .emit('send_alarm', {
              type: 'system_alarm',
              data: alarmData,
            });
        }

      } catch (error) {
        console.log('[systemAlarmUserListener] Error handling badge change:', error);
      }
    });

    // @ts-ignore
    currentStream.on('error', (error) => {
      setImmediate(() => {
        console.log('[systemAlarmUserListener] Stream error:', error);
      });
      cleanup().then(() => {
        setTimeout(() => {
          createChangeStream(tenantFlag, io);
        }, 1000);
      });
    });

  } catch (error) {
    setImmediate(() => {
      console.log('[systemAlarmUserListener] Error creating stream:', error);
    });
    await cleanup();
    setTimeout(() => {
      createChangeStream(tenantFlag, io);
    }, 1000);
  }
};

const systemAlarmUserListener = (tenantFlag: string, io: Server) => {
  createChangeStream(tenantFlag, io);

  streamMongoose.connection.on('reconnected', () => {
    console.log('[systemAlarmUserListener] MongoDB reconnected - reinitializing stream');
    createChangeStream(tenantFlag, io);
  });

  return cleanup;
};

export default systemAlarmUserListener;