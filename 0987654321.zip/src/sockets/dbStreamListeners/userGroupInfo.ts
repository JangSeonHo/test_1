/* eslint-disable max-len */
import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';
import companyInfoModel from 'models/company/company_company_info';
import companyDepartmentInfoModel from 'models/company/company_department_info';
import userStatusInfoModel from 'models/account/user_status_info';
import userGroupInfoModel, {streamModel} from 'models/account/user_group_info';
import userInfoModel from 'models/account/user_info';
import streamMongoose from 'configs/streamMongoose';

let currentStream: ChangeStream | null = null;

const cleanup = async () => {
  if (currentStream) {
    try {
      await currentStream.close();
      currentStream.removeAllListeners();
      currentStream = null;
    } catch (error) {
      console.error('Error during stream cleanup:', error);
    }
  }
};

const createChangeStream = async (tenantFlag: string, io: Server) => {
  await cleanup();

  try {
    currentStream = streamModel({tenantFlag}).watch([], {
      fullDocument: 'updateLookup'
    }) as unknown as ChangeStream;

    currentStream.on('change', async (data: any) => {
      try {
        if (data.updateDescription) {
          const {_id} = data.documentKey;

          const userGroup = await userGroupInfoModel({tenantFlag})
            .findOne({_id})
            .populate({
              path: 'childGroupUsers',
              select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
              populate: [{
                path: 'childStatusInfo',
                select: '-parentUser -__v -_id',
              }, {
                path: 'parentCompany',
                select: 'companyName',
              }, {
                path: 'parentDepartment',
                select: 'departmentName',
              }],
            });

          io.in(`${tenantFlag}:user:${userGroup.parentUser}`)
            .socketsJoin(userGroup.childGroupUsers.map((user: any) => `${tenantFlag}:user_status_info:${user._id}`));

          io.in(`${tenantFlag}:user:${userGroup.parentUser}`)
            .emit('update_my_user_groups_child_users', {
              userGroup,
            });
        }
      } catch (error) {
        console.error('Error handling group change:', error);
      }
    });

    currentStream.on('error', (error) => {
      console.error('Stream error:', error);
      cleanup().then(() => {
        setTimeout(() => {
          createChangeStream(tenantFlag, io).catch(console.error);
        }, 1000);
      });
    });

  } catch (error) {
    console.error('Error creating stream:', error);
    await cleanup();
    setTimeout(() => {
      createChangeStream(tenantFlag, io).catch(console.error);
    }, 1000);
  }
};

const userGroupInfoListener = (tenantFlag: string, io: Server) => {
  userInfoModel({tenantFlag});
  companyInfoModel({tenantFlag});
  companyDepartmentInfoModel({tenantFlag});
  userStatusInfoModel({tenantFlag});

  createChangeStream(tenantFlag, io).catch(console.error);

  streamMongoose.connection.once('reconnect', () => {
    console.log('MongoDB reconnected - reinitializing stream');
    createChangeStream(tenantFlag, io).catch(console.error);
  });

  return cleanup;
};

export default userGroupInfoListener;
