/* eslint-disable max-len */
import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';

import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyInfoModel from 'models/company/company_company_info';
import departmentInfoModel from 'models/company/company_department_info';
import chattingRoomMemberModel, {streamModel} from 'models/message/chatting_room_member';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chattingRoomMessageModel from 'models/message/chatting_room_message';
import streamMongoose from '../../configs/streamMongoose';
import {ecsTaskId} from '../../server';

const tenantFlag = 'nmp';
let resumeToken: unknown | null = null;
let io: Server;
let lastChantStream: any = null;

const chattingRoomMemberListener = (tenantFlag: string, ioParam: Server) => {
  io = ioParam;
  createChangeStream(io);

  streamMongoose.connection.on('reconnected', () => {
    console.log(`${ecsTaskId.value} ### stream db reconnected successfully.`);
    if (!!lastChantStream) {
      lastChantStream.close();
      console.log('chattingRoomMemberListener - last stream close.');
    }
    setTimeout(() => {
      console.log(`${ecsTaskId.value} MongoDB reconnected - reinitializing stream`);
      createChangeStream(io);
    }, 100);
  });
};

const createChangeStream = async (io: Server) => {
  try {
    const changeStream = streamModel({tenantFlag}).watch([], {
      fullDocument: 'updateLookup',
      ...(resumeToken ? {resumeAfter: resumeToken} : {}),
    }) as unknown as ChangeStream;
    lastChantStream = changeStream;

    changeStream.on('change', async (dataTmp: any) => {
      const data = {...dataTmp};
      // resumeToken = data.id;
      handleChange(data, io);
    });
    // @ts-ignore
    // currentStream.on('error', (error) => {
    //   console.error('Stream error:', error);
    //   cleanup().then(() => {
    //     setTimeout(() => {
    //       createChangeStream(tenantFlag, io).catch(console.error);
    //     }, 1000);
    //   });
    // });
  } catch (error) {
    setImmediate(() => {
      console.log(`[ChangeStream][roomMember] ${ecsTaskId.value} Error creating stream:`, error);
    });
    // await cleanup();
    // setTimeout(() => {
    //   createChangeStream(tenantFlag, io);
    // }, 1000);
  }
};

// eslint-disable-next-line require-jsdoc
async function handleChange(data: any, io: Server) {
  try {
    const {operationType} = data;

    if (operationType === 'insert') {
      const {parentUser, parentChattingRoom} = data.fullDocument;

      if (!io.sockets.adapter.rooms.get(`${tenantFlag}:user:${parentUser}`) &&
        !io.sockets.adapter.rooms.get(`${tenantFlag}:chatting_room:${parentChattingRoom}`)) {
        return;
      }

      // for populate
      userInfoModel({tenantFlag});
      userStatusInfoModel({tenantFlag});
      companyInfoModel({tenantFlag});
      departmentInfoModel({tenantFlag});
      //

      const userInfo: any = await userInfoModel({tenantFlag})
        .findOne({_id: parentUser})
        .select(
          '-hashedPassword -passwordSalt -useMessenger -mfa -__v -parentGroup')
        .populate('childStatusInfo', '-parentUser -__v -_id')
        .populate('parentCompany', '-childDepartments -__v -parentGroup')
        .populate('parentDepartment', '-parentGroup -parentCompany -parentDepartments -childDepartments -childUsers -__v')
        .populate('childSignInfos', 'accessToken')
        .lean();

      const isEqual = typeof userInfo?.emailId == 'string' &&
        userInfo?.emailId.length > 0 &&
        userInfo?.emailId === userInfo?.hashedPassword;
      userInfo['isUse'] = !isEqual;

      // [성능튜닝] Compound 인덱스 순서대로 소스 수정
      const ms = await chattingRoomMemberModel({tenantFlag}).find({
        parentChattingRoom,
        isDeleted: false,
      })
        .select('parentUser')
        .populate('parentUser')
        .select('userName jobTitle profileImage').lean();

      const pcrTmp = await chattingRoomInfoModel({tenantFlag})
        .find({_id: parentChattingRoom})
        .populate([{
          path: 'childUsers',
          select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
          populate: [{
            path: 'childStatusInfo',
            select: '-parentUser -__v -_id',
          }, {
            path: 'parentCompany',
            select: 'companyName',
          }, {
            path: 'parentDepartment',
            select: 'departmentName',
          }],
        }]).lean();
      const pcr = pcrTmp[0];

      io.to(`${tenantFlag}:chatting_room:${parentChattingRoom}`)
        .emit('join_member', {
          participants: ms.map((m: any) => {let newItem = {...m['parentUser']['userName'], 'jobTitle': m['parentUser']['jobTitle']};
            return newItem;}),
          roomId: parentChattingRoom,
          userInfo: {
            ...data.fullDocument,
            'parentUser': userInfo,
          },
          totalRoomMembers: pcr.totalRoomMembers ?? 0,
        });

      io.to(`${tenantFlag}:user:${parentUser}`)
        .socketsJoin(`${tenantFlag}:chatting_room:${parentChattingRoom}`);

      io.to(`${tenantFlag}:user:${parentUser}`)
        .emit('create_chatting_room', {
          ...data.fullDocument,
          parentChattingRoom: pcr,
          roomThumbnails: ms.filter((t) => 'parentUser' in t)
            .map((m: any) => m.parentUser?.profileImage ?? ''),
          participants: ms.map((m: any) => {let newItem = {...m['parentUser']['userName'], 'jobTitle': m['parentUser']['jobTitle']};
            return newItem;}),
        });
    }

    if (operationType === 'update') {
      const {_id} = data.documentKey;
      const {parentUser, parentChattingRoom, isGroupChat} = data.fullDocument;

      if (!io.sockets.adapter.rooms.get(`${tenantFlag}:user:${parentUser}`) &&
        !io.sockets.adapter.rooms.get(`${tenantFlag}:chatting_room:${parentChattingRoom}`)) {
        return;
      }

      const {
        lastCheckedMessageSeq,
        lastCheckedMessageEventSeq,
        isDeleted,
        roomName,
        deletedMessageSeq,
      } = data.updateDescription.updatedFields;

      // for populate
      userInfoModel({tenantFlag});
      userStatusInfoModel({tenantFlag});
      companyInfoModel({tenantFlag});
      departmentInfoModel({tenantFlag});
      chattingRoomInfoModel({tenantFlag});
      //
      const chattingRoomTmp = await chattingRoomMemberModel({tenantFlag})
        .find({_id})
        .populate({
          path: 'parentChattingRoom deletedMessages',
          populate: [
            {
              path: 'childUsers',
              select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
              populate: [{
                path: 'childStatusInfo',
                select: '-parentUser -__v -_id',
              }, {
                path: 'parentCompany',
                select: 'companyName',
              }, {
                path: 'parentDepartment',
                select: 'departmentName',
              }],
            },
            {
              path: 'childLastMessage',
            },
            {
              path: 'childNoticeMessage',
            },
          ],
        }).lean();
      const chattingRoom = chattingRoomTmp[0];

      if (lastCheckedMessageSeq === undefined &&
        lastCheckedMessageEventSeq === undefined &&
        isDeleted === undefined &&
        roomName === undefined) {

        //나에게만 삭제 시 마지막 메세지 가져오는 로직 추가

        let lastDeletedMsgId = '';
        //삭제된 마지막 메세지
        if (chattingRoom.deletedMessages && Array.isArray(chattingRoom.deletedMessages) && chattingRoom.deletedMessages.length > 0) {
          lastDeletedMsgId = chattingRoom.deletedMessages[chattingRoom.deletedMessages.length - 1];
        }


        let lastMessage;

        if (lastDeletedMsgId !== '') {
          const lastDeletedMessageTmp = await chattingRoomMessageModel({ tenantFlag })
            .find({ _id: lastDeletedMsgId }).lean();
          const lastDeletedMessage = lastDeletedMessageTmp[0];

          const lastDeletedMsgSeq = lastDeletedMessage ? lastDeletedMessage.messageSeq : 0;

          // 삭제한 메세지 뒤에 삭제되지 않은 메세지가 있으면 메세지를 보내지 않는다.
          const preDeletedMsg = await chattingRoomMessageModel({tenantFlag})
            .findOne({
              parentChattingRoom: chattingRoom.parentChattingRoom._id, // parentChattingRoom 조회 조건
              isDeleted: false, // 삭제되지 않은 메시지
              _id: { $nin: chattingRoom.deletedMessages }, // chattingRoom.deletedMessages 배열에 없는 메시지
              messageSeq: { $gt: lastDeletedMsgSeq } // lastDeletedMesId 이후 메시지
            }).sort({ messageSeq: -1 }).lean(); // messageSeq 내림차순으로 정렬하여 가장 높은 값을 찾음

          if (!preDeletedMsg) {
            const chattingMember = await chattingRoomMemberModel({tenantFlag}).findOne({
              parentUser: chattingRoom.parentUser,
              parentChattingRoom: chattingRoom.parentChattingRoom._id,
            }).lean();

            if (!!chattingMember) {
              lastMessage = await chattingRoomMessageModel({tenantFlag})
                // @ts-ignore
                .findOne({messageSeq: {$lt: lastDeletedMsgSeq, $gt: chattingMember['deletedLastCheckedMessageSeq']}, // lastDeletedMesId 이후 메시지
                  parentChattingRoom: chattingRoom.parentChattingRoom._id, // parentChattingRoom 조회 조건
                  isDeleted: false, // 삭제되지 않은 메시지
                  isSystemMessage: false,
                  _id: { $nin: chattingRoom.deletedMessages }, // chattingRoom.deletedMessages 배열에 없는 메시지
                }).sort({ messageSeq: -1 }).lean() // messageSeq 내림차순으로 정렬하여 가장 높은 값을 찾음
            }
          }
          else {
            lastMessage = preDeletedMsg;
          }
        }

        let isRejoinedOrDeleteAllMsg = false; // 방에서 보이는 마지막 1개의 채팅을 지운 케이스도 포함한다.
        // @ts-ignore
        if (lastMessage != null && data.fullDocument.deletedLastCheckedMessageSeq >= lastMessage.messageSeq) {
          isRejoinedOrDeleteAllMsg = true;
        }

        if (data.fullDocument.deletedLastCheckedMessageSeq > 0 && lastMessage == null) {
          isRejoinedOrDeleteAllMsg = true;
        }

        // 나에게만 삭제
        if (chattingRoom.deletedMessages.length > 0) {
          io.to(`${tenantFlag}:user:${chattingRoom.parentUser}`)
            .emit('delete_chat_message_only_me', {
              roomId: chattingRoom.parentChattingRoom._id,
              deletedMessages: chattingRoom.deletedMessages,
              lastMessage: isRejoinedOrDeleteAllMsg ? null : lastMessage,
            });
        }
      }

      if (isDeleted === true) {
        io.to(`${tenantFlag}:user:${chattingRoom.parentUser}`)
          .emit('delete_room', {
            isGroupChat: chattingRoom.isGroupChat,
            roomId: chattingRoom.parentChattingRoom._id,
          });
      }

      if (isDeleted == true && chattingRoom.isGroupChat) {
        io.to(`${tenantFlag}:user:${chattingRoom.parentUser}`)
          .socketsLeave(`${tenantFlag}:chatting_room:${chattingRoom.parentChattingRoom}`);
      }

      if (isDeleted == false && !chattingRoom.isGroupChat) {
        const ms = await chattingRoomMemberModel({tenantFlag}).find({
          parentChattingRoom: chattingRoom.parentChattingRoom._id,
          isDeleted: false,
        })
          .select('parentUser')
          .populate('parentUser')
          .select('userName jobTitle profileImage').lean();

        //채팅방 나가기 했던 방 다시 들어갈 경우 마지막 메세지 보이기 수정
        if (chattingRoom.parentChattingRoom && chattingRoom.parentChattingRoom.childLastMessage) {
          chattingRoom.parentChattingRoom.childLastMessage.content = "(채팅방이 생성 되었습니다)";
          chattingRoom.parentChattingRoom.childLastMessage.createdAt = 0;
        }

        io.to(`${tenantFlag}:user:${chattingRoom.parentUser}`)
          .emit('create_chatting_room', {
            ...chattingRoom,
            roomThumbnails: ms.filter((t) => 'parentUser' in t)
              .map((m: any) => m.parentUser?.profileImage ?? ''),
          });
      }

      if (lastCheckedMessageSeq !== undefined || lastCheckedMessageEventSeq !== undefined) {
        io.to(`${tenantFlag}:user:${chattingRoom.parentUser}`)
          .emit('update_chatting_room_unread_count', {
            roomId: chattingRoom.parentChattingRoom._id,
            lastCheckedMessageSeq,
            lastCheckedMessageEventSeq,
          });
      }

      //채팅방 나가기 했을 경우는 count하지 않음
      if ((lastCheckedMessageSeq !== undefined || lastCheckedMessageEventSeq !== undefined) && deletedMessageSeq == undefined) {
        io.to(`${tenantFlag}:chatting_room:${chattingRoom.parentChattingRoom._id}`)
          .emit('update_chatting_message_unread_count', {
            roomId: chattingRoom.parentChattingRoom._id,
            userId: chattingRoom.parentUser,
            lastCheckedMessageSeq,
            lastCheckedMessageEventSeq,
          });
      }

      if (roomName !== undefined) {
        io.to(`${tenantFlag}:user:${chattingRoom.parentUser}`)
          .emit('rename_chatting_room', {
            forMe: true,
            roomId: chattingRoom.parentChattingRoom._id,
            roomName,
          });
      }

      //나간 채팅방 다시 초대 시
      if (isDeleted == false && chattingRoom.isGroupChat) {

        const parentUser = chattingRoom.parentUser;
        const parentChattingRoom = chattingRoom.parentChattingRoom._id;

        const userInfo: any = await userInfoModel({tenantFlag})
          .findOne({_id: parentUser})
          .select(
            '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -parentGroup')
          .populate('childStatusInfo', '-parentUser -__v -_id')
          .populate('parentCompany', '-childDepartments -__v -parentGroup')
          .populate('parentDepartment', '-parentGroup -parentCompany -parentDepartments -childDepartments -childUsers -__v')
          .populate('childSignInfos', 'accessToken')
          .lean();

        const isEqual = typeof userInfo?.emailId == 'string' &&
          userInfo?.emailId.length > 0 &&
          userInfo?.emailId === userInfo?.hashedPassword;
        userInfo['isUse'] = !isEqual;

        // [성능튜닝] Compound 인덱스 순서대로 소스 수정
        const ms = await chattingRoomMemberModel({tenantFlag}).find({
          parentChattingRoom,
          isDeleted: false,
        })
          .select('parentUser')
          .populate('parentUser')
          .select('userName jobTitle profileImage').lean();
        const chatUsers = ms.filter((user) => user.parentUser);

        const pcr = await chattingRoomInfoModel({tenantFlag})
          .findOne({_id: parentChattingRoom})
          .populate([{
            path: 'childUsers',
            select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
            populate: [{
              path: 'childStatusInfo',
              select: '-parentUser -__v -_id',
            }, {
              path: 'parentCompany',
              select: 'companyName',
            }, {
              path: 'parentDepartment',
              select: 'departmentName',
            }],
          }]).lean();

        const parentUserInfo = await chattingRoomMemberModel({tenantFlag}).findOne({
          parentUser: parentUser,
          parentChattingRoom: parentChattingRoom,
        }).lean();

        const tmpEmitObj = {
          participants: chatUsers.map((m: any) => {
            return {...m['parentUser']['userName'], 'jobTitle': m['parentUser']['jobTitle']};
          }),
          roomId: parentChattingRoom,
          userInfo: {
            ...parentUserInfo,
            'parentUser': userInfo,
          },
          totalRoomMembers: ms.length,
        }

        io.to(`${tenantFlag}:chatting_room:${chattingRoom.parentChattingRoom._id}`).emit('join_member', tmpEmitObj);

        io.to(`${tenantFlag}:user:${parentUser}`)
          .socketsJoin(`${tenantFlag}:chatting_room:${chattingRoom.parentChattingRoom._id}`);

        io.to(`${tenantFlag}:user:${parentUser}`)
          .emit('create_chatting_room', {
            ...parentUserInfo,
            parentChattingRoom: pcr,
            roomThumbnails: ms.filter((t) => 'parentUser' in t)
              .map((m: any) => m.parentUser?.profileImage ?? ''),
            participants: chatUsers.map(({parentUser}: any) => parentUser.userName),
          });
      }
    }
  } catch (error) {
    setImmediate(() => {
      console.log(`[ChangeStream] ${ecsTaskId.value} Error handling room member change:`, error);
    });
  }
}

export default chattingRoomMemberListener;
