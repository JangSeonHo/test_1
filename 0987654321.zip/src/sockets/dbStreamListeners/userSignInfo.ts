/* eslint-disable max-len */
import {Server} from 'socket.io';
import {ChangeStream} from 'mongodb';
import userSignInfoModel, {streamModel} from 'models/account/user_sign_info';
import streamMongoose from 'configs/streamMongoose';

let currentStream: ChangeStream | null = null;

const cleanup = async () => {
  if (currentStream) {
    try {
      await currentStream.close();
      currentStream.removeAllListeners();
      currentStream = null;
    } catch (error) {
      console.error('Error during stream cleanup:', error);
    }
  }
};

const createChangeStream = async (tenantFlag: string, io: Server) => {
  await cleanup();

  try {
    currentStream = streamModel({tenantFlag}).watch([], {
      fullDocument: 'updateLookup'
    }) as unknown as ChangeStream;

    currentStream.on('change', async (data: any) => {
      try {
        const {operationType} = data;

        if (operationType === 'insert') {
          const {parentUser} = data.fullDocument;

          io.in(`${tenantFlag}:user:${parentUser}`)
            .emit('change_user_sign_info');
        }

        if (operationType === 'update') {
          const {_id} = data.documentKey;
          const {sendStream} = data.updateDescription.updatedFields;

          if (sendStream) {
            const data = await userSignInfoModel({tenantFlag})
              .findOne({_id}).select('parentUser accessToken');

            if (data !== null) {
              const {parentUser, accessToken} = data;

              io.in(`${tenantFlag}:user:${parentUser}`)
                .emit('change_user_sign_info', {
                  type: 'pc_logout',
                  accessToken,
                });
            }
          }
        }
      } catch (error) {
        console.error('Error handling sign change:', error);
      }
    });

    currentStream.on('error', (error) => {
      console.error('Stream error:', error);
      cleanup().then(() => {
        setTimeout(() => {
          createChangeStream(tenantFlag, io).catch(console.error);
        }, 1000);
      });
    });

  } catch (error) {
    console.error('Error creating stream:', error);
    await cleanup();
    setTimeout(() => {
      createChangeStream(tenantFlag, io).catch(console.error);
    }, 1000);
  }
};

const userSignInfoListener = (tenantFlag: string, io: Server) => {
  createChangeStream(tenantFlag, io).catch(console.error);

  streamMongoose.connection.once('reconnect', () => {
    console.log('MongoDB reconnected - reinitializing stream');
    createChangeStream(tenantFlag, io).catch(console.error);
  });

  return cleanup;
};

export default userSignInfoListener;
