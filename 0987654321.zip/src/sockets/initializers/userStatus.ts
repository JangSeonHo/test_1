/* eslint-disable max-len */
import {Socket} from 'socket.io';

import userStatusInfoModel from 'models/account/user_status_info';

const initializeUserStatus = async (socket: Socket) => {
  const tenantFlag: string = socket.handshake.headers['tenant-flag'] as string ?? '';
  const userId: string = socket.handshake.headers['user-id'] as string ?? '';

  const statusInfo = await userStatusInfoModel({tenantFlag})
    .findOne({parentUser: userId.toString()})
    .select('statusCode');

  if (statusInfo !== null && (statusInfo.statusCode === '' || statusInfo.statusCode === '오프라인')) {
    await userStatusInfoModel({tenantFlag})
      .updateOne({parentUser: userId}, {statusCode: '온라인'});
  }
};

export default initializeUserStatus;
