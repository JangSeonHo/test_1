/* eslint-disable max-len */
import {Socket} from 'socket.io';

const initializeUserDefault = async (socket: Socket) => {
  const tenantFlag: string = socket.handshake.headers['tenant-flag'] as string ?? '';
  const userId: string = socket.handshake.headers['user-id'] as string ?? '';

  socket.join(`${tenantFlag}:user:${userId}`);
};

export default initializeUserDefault;
