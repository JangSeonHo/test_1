/* eslint-disable max-len */
import {Socket} from 'socket.io';

import chattingRoomMemberModel from 'models/message/chatting_room_member';

const initializeChattingRoom = async (socket: Socket) => {
  const tenantFlag: string = socket.handshake.headers['tenant-flag'] as string ?? '';
  const userId: string = socket.handshake.headers['user-id'] as string ?? '';

  const targetModel = chattingRoomMemberModel({tenantFlag});
  const chattingRooms = await targetModel.find({
    parentUser: userId,
    $or: [
      {isDeleted: false},
      {isDeleted: true, isGroupChat: false},
    ],
  })
    .select('parentChattingRoom');

  chattingRooms.forEach(({parentChattingRoom}: {parentChattingRoom: string}) => {
    socket.join(`${tenantFlag}:chatting_room:${parentChattingRoom}`);
  });
};

export default initializeChattingRoom;
