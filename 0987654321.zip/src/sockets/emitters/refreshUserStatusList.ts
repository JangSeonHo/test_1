/* eslint-disable max-len */
import {Socket} from 'socket.io';

import userInfoModel from 'models/account/user_info';
import userGroupInfoModel from 'models/account/user_group_info';

const refreshUserStatusList = (socket: Socket) => async (arg: any) => {
  const tenantFlag: string = socket.handshake.headers['tenant-flag'] as string ?? '';
  const userId = socket.handshake.headers['user-id'];

  const rooms = Array.from(socket.rooms).filter((v) => v.indexOf('user_status_info') !== -1);
  const beforeTargets = rooms.map((room) => room.split(':')[2]);

  // for population
  userGroupInfoModel({tenantFlag});
  //

  const userInfo = await userInfoModel({tenantFlag}).findOne({_id: userId})
    .select('childPrivateContacts childUserGroups')
    .populate('childUserGroups', 'childGroupUsers');

  const targetLists = [...userInfo.childPrivateContacts.map((id: string) => id.toString())];

  if (userInfo.childUserGroups.length !== 0) {
    userInfo.childUserGroups.forEach(({childGroupUsers}: {childGroupUsers: any}) => {
      childGroupUsers.forEach((user: string) => {
        const id = user.toString();
        if (targetLists.indexOf(id) === -1) {
          targetLists.push(id);
        }
      });
    });
  }

  beforeTargets.forEach((user: string) => {
    if (targetLists.indexOf(user) === -1) {
      socket.leave(`${tenantFlag}:user_status_info:${user}`);
    }
  });

  targetLists.forEach((user: string) => {
    if (beforeTargets.indexOf(user) === -1) {
      socket.join(`${tenantFlag}:user_status_info:${user}`);
    }
  });
};

export default refreshUserStatusList;
