/* eslint-disable max-len */
import {Socket} from 'socket.io';

// import userStatusInfoModel from 'models/account/user_status_info';
// import userSignInfoModel from 'models/account/user_sign_info';

const disconnect = (socket: Socket, reason: string) => async (arg: any) => {
  // const tenantFlag: string = socket.handshake.headers['tenant-flag'] as string ?? '';
  const userId = socket.handshake.headers['user-id'];
  const isMobile = socket.handshake.headers['is-mobile'] === 'Y';

  try {

    console.log(`[Socket] Socket Disconnected : ${userId} / reason : ${reason} / isMobile : ${isMobile}`);
    // for (const room of socket.rooms) {
    //   if (room !== socket.id) {
    //     socket.leave(room);
    //   }
    // }

    socket.removeAllListeners();
    socket.disconnect();

    // if (!isMobile) {
    //   await userStatusInfoModel({tenantFlag}).updateMany({parentUser: userId}, {pcStatus: 'offline'});
    // }

    // const [statusInfo, pcStatusInfo] = await Promise.all([
    //   userStatusInfoModel({tenantFlag})
    //     .findOne({parentUser: userId})
    //     .select('statusCode'),
    //   userSignInfoModel({tenantFlag})
    //     .findOne({
    //       parentUser: userId,
    //     })
    //     .select('pcStatus'),
    // ]);

    // if (statusInfo.statusCode === '온라인' && (!pcStatusInfo || pcStatusInfo.pcStatus === 'offline')) {
    //   await userStatusInfoModel({tenantFlag})
    //     .updateOne({parentUser: userId}, {statusCode: '오프라인'});
    // }
  } catch (err) {
    console.log('disconnect emitter error :', err);
  }
};

export default disconnect;
