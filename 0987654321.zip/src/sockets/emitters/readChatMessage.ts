/* eslint-disable max-len */
import {Socket} from 'socket.io';

import chattingRoomMemberModel, {roomMemberModelPrimaryOnly} from 'models/message/chatting_room_member';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chattingMessageModel from 'models/message/chatting_room_message';
// import userBadgeModel from 'models/account/user_badge';
import updateUserBadge from 'utils/user/updateUserBadge';

const readMessage = (socket: Socket) => async (arg: any) => {
  const tenantFlag: string = socket.handshake.headers['tenant-flag'] as string ?? '';
  const userId = socket.handshake.headers['user-id'] as string ?? '';


  chattingRoomInfoModel({tenantFlag});
  chattingMessageModel({tenantFlag});

  if (arg.messageSeq > 0) {
    await chattingRoomMemberModel({tenantFlag})
      .updateOne({parentUser: userId, parentChattingRoom: arg.roomId}, {
        lastCheckedMessageSeq: arg.messageSeq,
      });

    // const chattingRooms = await roomMemberModelPrimaryOnly({tenantFlag}).find({
    //   parentUser: userId,
    //   isDeleted: false,
    // }).select('parentChattingRoom lastCheckedMessageSeq').populate({
    //   path: 'parentChattingRoom',
    //   select: 'childLastMessage isMyChat',
    //   populate: [
    //     {
    //       path: 'childLastMessage',
    //       select: 'messageSeq',
    //     },
    //   ],
    // });
    //
    //
    // let count = 0;
    // chattingRooms.forEach((room: any) => {
    //   if (!room.parentChattingRoom.isMyChat && room.parentChattingRoom.childLastMessage && room.parentChattingRoom.childLastMessage.messageSeq > 0) {
    //     if (room.parentChattingRoom.childLastMessage.messageSeq - room.lastCheckedMessageSeq > 0) {
    //       count += (room.parentChattingRoom.childLastMessage.messageSeq - room.lastCheckedMessageSeq);
    //     }
    //   }
    // });
    //
    // await userBadgeModel({tenantFlag}).updateOne({parentUser: userId}, {
    //   unreadChatMessages: Math.trunc(count) < 0 ? 0 : Math.trunc(count),
    // });
    await updateUserBadge(tenantFlag, userId);
  }
};

export default readMessage;
