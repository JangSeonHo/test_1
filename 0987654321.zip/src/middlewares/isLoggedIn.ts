import Koa from 'koa';
import jwt from 'jsonwebtoken';
import userSignModel from 'models/account/user_sign_info';
import convertIpToDecimal from '../utils/string/convertIpToDecimal';
import {internalLBIP} from 'server';

const isLoggedIn = async (ctx: Koa.Context, next: Koa.Next) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag') ?? ctx.query.tenantFlag;
    const headers = ctx.headers;
    const deviceType = headers['device-type'] as string ?? '';

    // eslint-disable-next-line max-len
    const accessToken = headers['access-token'] as string ?? ctx.query.accessToken ?? '';
    if (!accessToken) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'permission denided 1',
      };
      return;
    }

    // const refreshToken = headers['refresh-token'] as string ?? '';
    const jwtSecret = process.env.DEV_JWT_SECRET as string ?? '';

    // check db document
    const targetUserSignModel = userSignModel({tenantFlag});
    const userSignInfo = await targetUserSignModel.findOne({
      'accessToken': accessToken,
      // 'refreshToken': refreshToken,
    }).select('_id');

    // check token verification
    const decode: any = jwt.verify(accessToken, jwtSecret);
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log('isLoggedIn decode.deviceType :', decode.deviceType);
      console.log('isLoggedIn deviceType :', deviceType);
    }
    if (accessToken && decode && userSignInfo) {
      if (decode.deviceType != deviceType) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'error': 'permission denided 2',
        };
        return;
      }

      if (decode.hasOwnProperty('companyCode')) {
        if (decode.companyCode == 'GUC001' && deviceType == 'win32') { // 유플러스
          // 내부망 여부 체크
          const lbIP = String(ctx.request.socket.remoteAddress || '');
          const decLBIP = convertIpToDecimal(lbIP);
          if (internalLBIP.ip1 !== decLBIP && internalLBIP.ip2 !== decLBIP) {
            ctx.status = 403;
            ctx.body = {
              'success': false,
              'error': 'permission denided 3',
            };
            return;
          }
        }
      }

      ctx.set('userId', decode.userId);
      ctx.set('role', decode.role);

      return await next();
    }

    ctx.status = 403;
    ctx.body = {
      'success': false,
      'error': 'permiossion denided 4',
    };
    // console.log('[isLoggedIn][accessToken] >>> ', accessToken, decode.userId);
  } catch (err) {
    // @ts-ignore
    if (err.name === 'TokenExpiredError') {
      ctx.status = 419;
      ctx.body = {
        'success': false,
        'error': 'The token has expired',
      };
    } else {
      console.log(err);
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'permiossion denided 5',
      };
    }
  }
};

export default isLoggedIn;
