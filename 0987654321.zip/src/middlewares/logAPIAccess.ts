import Koa from 'koa';
import jwt from 'jsonwebtoken';

import createApiAccessLog from 'utils/log/create_api_access_log';

const logApiAccess = async (ctx: Koa.Context, next: Koa.Next) => {
  try {
    const reqIp: string = ctx.request.ip ?? '';
    const headers = ctx.headers;
    // eslint-disable-next-line max-len
    const accessToken = headers['access-token'] as string ?? ctx.query.accessToken ?? '';

    let userId = '';
    let deviceType = '';
    if (accessToken) {
      try {
        const jwtSecret = process.env.DEV_JWT_SECRET as string ?? '';
        const decode: any = jwt.verify(accessToken, jwtSecret);
        userId = decode.userId;
        deviceType = decode.deviceType;
      } catch (err) {}
    }

    const api = ctx.url;
    createApiAccessLog({api, ip: reqIp, userId, deviceType});

    await next();
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default logApiAccess;
