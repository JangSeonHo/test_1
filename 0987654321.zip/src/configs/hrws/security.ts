export const HRWS_SECRET_KEY = process.env.HRWS_SECRET_KEY || '';
export const HRWS_ATTEND_API_KEY = process.env.HRWS_ATTEND_API_KEY || '';
export const HRWS_SECRET_EXPIRYTIME = Number(process.env.HRWS_SECRET_EXPIRYTIME) || 3600;
export const HRWS_WHITE_LIST = process.env.HRWS_WHITE_LIST || ''; 