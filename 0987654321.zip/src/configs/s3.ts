import dotenv from 'dotenv';
dotenv.config();

export const s3Bucket = process.env.STATE_ENV === 'dev' ?
  'nmp-s3-file-dev' :
  process.env.STAGE_ENV === 'stg' ?
  'nmp-s3-file-stg' :
  'nmp-s3-file-prd';
