import crypto from 'crypto';
import {ENCKEYFORPARAM} from '../constants/commonConstants';

// The `generateKeyPairSync` method accepts two arguments:
// 1. The type ok keys we want, which in this case is "rsa"
// 2. An object with the properties of the key
export const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
  // The standard secure default length for RSA keys is 2048 bits
  modulusLength: 2048,
});

export const encrypt = (value: string, encryptionKey: string): string => {
  try {
    const IV = encryptionKey.substring(0, 16);
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(encryptionKey), Buffer.from(IV));
    let encrypted = cipher.update(value);
    encrypted = Buffer.concat([encrypted, cipher.final()]);

    return encrypted.toString('base64');
  } catch (err) {
    console.error('Encryption failed', err);
    throw new Error('Encryption failed');
  }
};

export const decrypt =(value: string, encryptionKey: string): string => {
  try {
    const IV = encryptionKey.substring(0, 16);
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(encryptionKey), Buffer.from(IV));
    let decrypted = decipher.update(value, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted.toString();
  } catch (err) {
    console.error('Decryption failed', err);
    throw new Error('Decryption failed');
  }
};


export const encrypt_iv = (value: string, encryptionKey: string, iv: string): string => {
  try {
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(encryptionKey), Buffer.from(iv));
    let encrypted = cipher.update(value);
    encrypted = Buffer.concat([encrypted, cipher.final()]);

    return encrypted.toString('base64');
  } catch (err) {
    console.error('Encryption failed', err);
    throw new Error('Encryption failed');
  }
};

export const decrypt_iv =(value: string, encryptionKey: string, iv: string): string => {
  try {
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(encryptionKey), Buffer.from(iv));
    let decrypted = decipher.update(value, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted.toString();
  } catch (err) {
    // console.error('Decryption failed', err);
    throw new Error('Decryption failed');
  }
};

// eslint-disable-next-line require-jsdoc
function isOverDiffTimeLimit(msgTime: number, criteriaTime: number) {
  const diffLimit = 10 * 60 * 1000; // 10분
  const diffTime = criteriaTime - msgTime;

  if (diffTime > diffLimit) {
    console.log(`[ParamDecrypt][timeover] >>>>>>>>>>>>>>>>> ${diffTime / 1000 / 60}분`);
  }

  return diffTime > diffLimit;
}

// eslint-disable-next-line require-jsdoc
function generateIV(length: number = 16): string {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwx*****456789';
  let randomString = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    randomString += characters[randomIndex]; // 해당 인덱스의 문자 추가
  }

  return randomString;
}

export const decryptBodyParams = (params: string, encryptionKey: string): any => {
  try {
    // console.log("[ParamDecrypt][encData] >>>>>>>>>>>>>>>>> ", params);
    const iv = params.slice(-16);
    const paramRes = params.slice(0, -16);
    const decodedParam = JSON.parse(decrypt_iv(paramRes, encryptionKey, iv));
    // console.log("[ParamDecrypt][iv] >>>>>>>>>>>>>>>>> ", iv);
    // console.log("[ParamDecrypt][decrypted] >>>>>>>>>>>>>>>>> ", decodedParam);

    if (isOverDiffTimeLimit(decodedParam.time, new Date().getTime())) {
      return {
        success: false,
      };
    }

    return {
      success: true,
      params: decodedParam,
    };
  } catch (err) {
    console.log("[ParamDecrypt][Error] >>>>>>>>>>>>>>>>> ", err);
    return {
      success: false,
      error: err,
    };
  }
};

export const encryptBodyParams = (params: any, encryptionKey: string): any => {
  try {
    // console.log("[ParamEncrypt][encData] >>>>>>>>>>>>>>>>> ", params);
    const iv = generateIV();
    params.time = new Date().getTime();
    const encodedParam = encrypt_iv(JSON.stringify(params), encryptionKey, iv) + iv;
    // console.log("[ParamEncrypt][encrypted] >>>>>>>>>>>>>>>>> ", encodedParam);

    return {
      success: true,
      params: encodedParam,
    };
  } catch (err) {
    console.log("[ParamEncrypt][Error] >>>>>>>>>>>>>>>>> ", err);
    return {
      success: false,
      error: err,
    };
  }
};

export const encryptURL = (urlStr: string, encryptionKey: string): any => {
  try {
    // console.log("[URLEncrypt][orgStr] >>>>>>>>>>>>>>>>> ", urlStr);
    const iv = generateIV();
    const encodedURL = encrypt_iv(urlStr, encryptionKey, iv);
    // console.log("[URLEncrypt][iv] >>>>>>>>>>>>>>>>> ", iv);
    // console.log("[URLEncrypt][encrypted] >>>>>>>>>>>>>>>>> ", encodedURL);

    return {
      success: true,
      url: encodedURL + iv,
    };
  } catch (err) {
    console.log("[URLEncrypt][EncryptionFailed]");
    return {
      success: false,
      error: err,
    };
  }
};

export const decryptURL = (urlStr: string, encryptionKey: string): any => {
  try {
    // console.log("[URLDecrypt][encData] >>>>>>>>>>>>>>>>> ", urlStr);
    const iv = urlStr.slice(-16);
    const urlRes = urlStr.slice(0, -16);
    const decodedURL = decrypt_iv(urlRes, encryptionKey, iv);
    // console.log("[URLDecrypt][iv] >>>>>>>>>>>>>>>>> ", iv);
    // console.log("[URLDecrypt][decrypted] >>>>>>>>>>>>>>>>> ", decodedURL);

    return {
      success: true,
      url: decodedURL,
    };
  } catch (err) {
    console.log("[URLDecrypt][DecryptionFailed]");
    return {
      success: false,
      error: err,
    };
  }
};

const xorEncrypt = (text: any, encryptionKey: any) => {
  const textBytes = Buffer.from(text, 'utf8');
  const keyBytes = Buffer.from(encryptionKey, 'utf8');
  const encrypted = Buffer.alloc(textBytes.length);

  for (let i = 0; i < textBytes.length; i++) {
    encrypted[i] = textBytes[i] ^ keyBytes[i % keyBytes.length];
  }

  return encrypted.toString('base64');
};

export const encryptCdnToken = (cdnUrl: any, encryptionKey: any) => {
  const payload = {
    cdnUrl: cdnUrl,
    unixTime: new Date().getTime(),
  };

  const jsonPayload = JSON.stringify(payload);
  return xorEncrypt(jsonPayload, encryptionKey);
};
