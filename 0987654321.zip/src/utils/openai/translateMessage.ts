/* eslint-disable max-len */
import axios from 'axios';

const translateMessage = async(message: string, translateLocale: string[]) => {
	let url = "https://grp.dt.lgcns.com:9081/translate";

	let returnText = "";

	try {
		const timestamp = new Date().getTime();

		const response = await axios.post(url, {
			"company": "GIM006", // 회사코드
			"sysCode": "ucap", // 시스템코드
			"userId": "system", // 사용자아이디
			"source": "00", // 원문언어코드 - 00 : 자동언어감지
			"target": translateLocale,
			"q": `${message}`, // 원문텍스트
			"transType": "text", // 번역타입
			"rtnPage": "json", // 리턴형식
			"originalKey": `"${timestamp}_system"` // 유일키 : 유닉스 타임스탬프(밀리세컨즈 까지...)_system
		}, {
			headers: {
				'Content-Type': 'application/json',
			},
		});

		if (response.status === 200) {
			const data = response.data;

			if (data && data.translations && data.translations.length > 0) {
				returnText = data.translations;
			} else {
				returnText = message + ' [A]';
			}
		} else {
			returnText = message + ' [C]';
		}

		return returnText;
	} catch (err) {
		console.log(err);
		return `Translation could not be completed.[E] >>>>>>> ${message}`;
	}
};

export default translateMessage;
