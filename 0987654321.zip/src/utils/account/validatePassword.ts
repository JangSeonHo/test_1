// utils/account/validatePassword.ts

const validatePassword = (password: string): boolean => {
  // 띄어쓰기 금지
  if (/\s/.test(password)) {
    return false;
  }

  const hasNumber = /[0-9]/.test(password);
  const hasLetter = /[A-Za-z]/.test(password);
  const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

  let typesCount = 0;
  if (hasNumber) typesCount += 1;
  if (hasLetter) typesCount += 1;
  if (hasSpecialChar) typesCount += 1;

  // 조합 수에 따라 길이 제한
  if (typesCount === 2) {
    if (password.length < 10) {
      return false;
    }
  } else if (typesCount === 3) {
    if (password.length < 8 || password.length > 16) {
      return false;
    }
  } else {
    // 1종류 이하이면 무조건 실패
    return false;
  }

  // 반복된 문자 3자리 이상 금지 (예: aaa, 111)
  if (/(.)\1\1/.test(password)) {
    return false;
  }

  // 연속된 문자 3자리 이상 금지 (예: abc, 123)
  const sequences = [
    'abcdefghijklmnopqrstuvwxyz',
    'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    '0123456789',
  ];

  for (const seq of sequences) {
    for (let i = 0; i < seq.length - 2; i++) {
      const part = seq.substring(i, i + 3);
      const regex = new RegExp(part);
      if (regex.test(password)) {
        return false;
      }
    }
  }

  return true;
};

export default validatePassword;
