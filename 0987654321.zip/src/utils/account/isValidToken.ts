// import mongoose from 'mongoose';

// import userInfoModel from 'models/account/user_info';

// const isValidToken: Fuction = async ({
//   tenantFlag,
//   accessToken,
// }): Future<Boolean | String> => {
//   // userInfoModel({});
// };

// export default isValidToken;
