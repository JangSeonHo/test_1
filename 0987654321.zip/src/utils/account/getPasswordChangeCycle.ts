import { Types } from 'mongoose';
import companyDetailModel from 'models/company/company_detail';
import { PW_DEFAULT_DAYS } from '../../constants/commonConstants';

interface CompanyDetail {
  _id: Types.ObjectId;
  parentCompany: Types.ObjectId;
  passwordChangeCycle?: number;
}

export const getPasswordChangeCycle = async (tenantFlag: string, parentCompany: Types.ObjectId): Promise<number> => {
  const tmpDuration4pw = await companyDetailModel({ tenantFlag })
    .findOne({ parentCompany }, { passwordChangeCycle: 1 }) as CompanyDetail | null;
  return tmpDuration4pw?.passwordChangeCycle ?? PW_DEFAULT_DAYS;
}; 