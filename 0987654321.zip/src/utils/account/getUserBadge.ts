import userBadgeModel, {userBadgeModelPrimaryOnly} from 'models/account/user_badge';

const getUserBadge = async (uid: string, tenantFlag: string) => {
  const targetBadgeModel = userBadgeModel({tenantFlag});

  const re = await targetBadgeModel.findOne({parentUser: uid});

  const {
    unreadChatMessages,
    unreadNotes,
    // unreadAlarms,
  } = re;

  return unreadChatMessages + unreadNotes;
};

export const getUserBadgePrimaryOnly = async (uid: string, tenantFlag: string) => {
  const targetBadgeModel = userBadgeModelPrimaryOnly({tenantFlag});

  const re = await targetBadgeModel.findOne({parentUser: uid});

  const {
    unreadChatMessages,
    unreadNotes,
    // unreadAlarms,
  } = re;

  return unreadChatMessages + unreadNotes;
};

export const getUserListBadgePrimaryOnly = async (uidList: string[], tenantFlag: string) => {
  const targetBadgeModel = userBadgeModelPrimaryOnly({tenantFlag});

  const re = await targetBadgeModel.find({parentUser: {$in: uidList}}).sort({parentUser: 1});

  return re.map(({
    unreadChatMessages,
    unreadNotes,
    // unreadAlarms,
  }) => unreadChatMessages + unreadNotes);
};

export default getUserBadge;
