const maskPhoneNumber: Function = (phoneNumber: string): string => {
  try {
    const split1 = phoneNumber.substring(0, 3);
    // eslint-disable-next-line max-len
    const split3 = phoneNumber.substring(phoneNumber.length - 4, phoneNumber.length);

    return `${split1}****${split3}`;
  } catch (err) {
    return '';
  }
};

export default maskPhoneNumber;
