/* eslint-disable max-len */
import admin from 'firebase-admin';
import Pushy from 'pushy';

import userSignInfoModel from 'models/account/user_sign_info';
import {userBadgeModelPrimaryOnly} from 'models/account/user_badge';

const TENANT_FLAG = "nmp";

//pushy.me - api key
const pushyAPI = new Pushy('431b11499e3ade8f0df11896c8d8c4a1cfabd60c7f77241ac24fd80fde32fc68');

// client package
// ===>>> com.lgcns.mtalk(X)
// ===>>> com.lgcns.newucap.demo


//PUSHY.ME 공통함수
const sendPushyNotification = async (msg: any) => {
  const data = {
    message: msg.data.body,
    title: msg.data.title,
    body: msg.data.body,
    type: msg.data.type,
    id: msg.data.id,
    //badge: msg.data.badge.toString(),
    badge: (msg.data.badge ?? 0).toString(),
    content: msg.data.body,
    createdAt: new Date(),
  };

  const toToken = [msg.token];

  const options: Partial<Record<string, any>> = {
    notification: {
      //badge: Number(msg.data.badge),
      badge: Number(msg.data.badge ?? 0),
      sound: 'default',
      title: msg.data.title,
      body: msg.data.body,
      category: '',
      loc_key: '',
      loc_args: [],
      title_loc_key: '',
      title_loc_args: [],
      interruption_level: 'active', // Must be one of: "passive", "active", "time-sensitive", "critical"
      message: msg.data.body,
      id: msg.data.id,
      content: msg.data.body,
      createdAt: new Date(),
      type: msg.data.type,
    }
  };

  if (process.env.DEVELOPMENT_MODE === 'local') {
    console.log("[pushIntegration][sendPushyNotification][data] >>>>>>> ", data);
    console.log("[pushIntegration][sendPushyNotification][options] >>>>>>> ", options);
  }

  return new Promise((resolve, reject) => {
    pushyAPI.sendPushNotification(data, toToken, options, (err, id) => {
      if (err) {
        console.error("pushIntegration[pushy.me][푸쉬 전송 실패]", err);
        reject(err);
      } else {
        resolve(id);
      }
    });
  });
};

const pushIntegration = async (msg: any, isBatch: boolean = false, isRefreshBadge: boolean = false) => {
  const targetUserSignInfo = userSignInfoModel({ tenantFlag: TENANT_FLAG });
  let isChina = false;

  try {
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("[pushIntegration][isBatch]", isBatch);
      console.log("[pushIntegration][msg]", msg);
    }

    //---------------------------------------------------------------------------------------------------------------------------------
    //배치 처리(비지니스 로직에서 맵으로 생성한 데이타를 파라미터로 전달받음.)
    //---------------------------------------------------------------------------------------------------------------------------------
    if (isBatch) {
      const tokens = msg.map((msgEach: any) => msgEach.token);
      const signData = await targetUserSignInfo.find({
        pushToken: {$in: tokens},
      }).select('isChina parentUser pushToken');

      const userIds = msg.map((msgEach: any) => msgEach.userId);
      const badges = await userBadgeModelPrimaryOnly({tenantFlag: TENANT_FLAG}).find({
        parentUser: {$in: userIds},
      }).select('parentUser unreadChatMessages unreadNotes');
      // console.log('userIds :', userIds);
      // console.log('badges :', badges);

      const msgForFCM: any[] = [];
      const msgForPushY: any[] = [];

      msg.forEach((msgEach: any, idx: number) => {
        if (isRefreshBadge) {
          const targetBadge = badges.filter((badgeEach) => String(msgEach.userId) == String(badgeEach.parentUser))[0];
          const badgeNum = Number(targetBadge.unreadChatMessages ?? 0) + Number(targetBadge.unreadNotes ?? 0);

          if (msgEach.hasOwnProperty('apns')) { // iOS일 경우
            msgEach.apns.payload.aps.badge = badgeNum;
          } else {
            msgEach.data.badge = String(badgeNum);
          }
        }

        const targetSignD = signData.filter((signEach) => String(signEach.parentUser) == String(msgEach.userId))[0];
        if (!!targetSignD) {
          // nmp_user_sign_infos에 해당 모바일(aos, ios)에 해당하는 정보가 중국내 사용이면(isChina === true) pushy.me토큰으로 발송한다.
          delete msgEach.userId;
          targetSignD.isChina ? msgForPushY.push(msgEach) : msgForFCM.push(msgEach);
        }
      });

      const batchSize = 100;
      for (let i = 0; i < msgForFCM.length; i += batchSize) {
        const batch = msgForFCM.slice(i, i + batchSize);
        // for (const msgTmp of batch) {
        //   console.log(`msgForFCM : ${JSON.stringify(msgTmp)}`);
        // }
        try {
          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log('[pushIntegration][푸쉬 배치 전송][FCM] >>>>>>>>>>>');
          }
          const response = await admin.messaging().sendEach(batch);

          if (response.failureCount > 0) {
            response.responses.forEach((res, index) => {
              if (!res.success) {
                const error = res.error;
                if (error) {
                  if (error.code === 'messaging/registration-token-not-registered') {
                    console.error('[pushIntegration][batch] Token not registered - token : ', batch[index].token);
                  } else {
                    console.error('[pushIntegration][batch - fcm] 푸쉬 전송 실패 >>> : ', error);
                  }
                }
              }
            });
          }
        } catch (error) {
          console.error('[pushIntegration][batch] 푸쉬 배치 전송 오류', error);
        }
      }

      try {
        for (const msgPushYEach of msgForPushY) {
          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log('[pushIntegration][푸쉬 배치 전송][PUSHY.Me] >>>>>>>>>>> ', msgPushYEach);
          }
          await sendPushyNotification(msgPushYEach);
        }
      } catch (error) {
        console.error('[pushIntegration][PUSHY.Me] 푸쉬 전송 오류', error);
      }
    }

    //---------------------------------------------------------------------------------------------------------------------------------
    //단건처리(비지니스 로직단에서 loop 실행하면서 한건씩 전송함.)
    //---------------------------------------------------------------------------------------------------------------------------------
    else {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("[pushIntegration][푸쉬 단건 전송] >>>>>>>>>>> ", msg.token);
      }

      //nmp_user_sign_infos에 해당 모바일(aos, ios)에 해당하는 정보가 중국내 사용이면(isChina === true) pushy.me토큰으로 발송한다.
      const signData = await targetUserSignInfo.findOne({ pushToken: msg.token }).select('isChina');
      isChina = signData?.isChina ?? false;

      if (isChina) {
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log("[pushIntegration][푸쉬 단건 전송][PUSHY.ME] >>>>>>>>>>> ", msg);
        }
        await sendPushyNotification(msg);
      } else {
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log("[pushIntegration][푸쉬 단건 전송][FCM] >>>>>>>>>>> ", msg);
        }
        await admin.messaging().send(msg);
      }
    }
  } catch (error) {
    console.error('[pushIntegration] 오류 발생', error);
  }
};

export default pushIntegration;
