import logApiAccess from 'models/log/log_api_access';
import mongoose from 'mongoose';

const createApiAccessLog = async ({
  api,
  userId,
  ip,
  deviceType,
}: {
  api: string,
  userId: string,
  ip: string,
  deviceType: string,
}) => {
  try {
    const tm: any = logApiAccess({tenantFlag: 'nmp'});
    const nm: any = tm({
      api,
      userId,
      ip,
      calledAt: new Date().getTime(),
      deviceType,
    });
    if (mongoose.Types.ObjectId.isValid(userId)) {
      nm.parentUser = new mongoose.Types.ObjectId(userId); // ObjectId로 변환
    }
    nm.save();
  } catch (err) {
    console.log(err);
  }
};

export default createApiAccessLog;
