import downloadHistory from 'models/log/download_history';
import mongoose from 'mongoose';

const createDownloadHistory = async ({
  type,
  parentMessageId,
  userId,
}: {
  type: string,
  parentMessageId: string,
  userId: string,
}) => {
  try {
    const tm: any = downloadHistory({tenantFlag: 'nmp'});
    const nm: any = tm({
      type,
      parentMessageId,
      parentUser: new mongoose.Types.ObjectId(userId),
      createdAt: new Date().getTime(),
    });
    nm.save();
  } catch (err) {
    console.log(err);
  }
};

export default createDownloadHistory;
