const getEcsTaskId = async ({
}: {
}) => {
  // 환경 변수에서 메타데이터 엔드포인트 가져오기
  const metadataUrl = process.env.ECS_CONTAINER_METADATA_URI_V4;
  if (!metadataUrl) {
    console.log('[getEcsTaskId] 현재 환경은 ECS Fargate가 아닙니다.');
    return 'Local';
  }

  try {
    const response = await fetch(metadataUrl!);
    const data = await response.json();

    const dockerId = data.DockerId;
    const taskId = dockerId.split('-')[0];
    console.log(`[getEcsTaskId] Task ID: ${taskId}`);
    return taskId;
  } catch (error) {
    console.log('[getEcsTaskId] 메타데이터 API 호출 실패 :', error);
    return null;
  }
};

export default getEcsTaskId;
