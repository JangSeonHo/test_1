import {ecsTaskId} from '../../server';
import {debugMode} from 'configs/server';

export declare type debugType = 'socket' | 'default';
const debugLog = (logText: string, type: debugType = 'default') => {
  if (debugMode.any) {
    const t = type != 'default' ? `[${type}]` : '';
    console.log(`[Debug]${t}${ecsTaskId.value} : ${logText}`);
  } else {
    switch (type) {
      case 'socket':
        if (debugMode.socket) {
          console.log(`[Debug][socket]${ecsTaskId.value} : ${logText}`);
        }
        break;
      case 'default':
        if (debugMode.default) {
          console.log(`[Debug]${ecsTaskId.value }: ${logText}`);
        }
    }
  }
};

export default debugLog;
