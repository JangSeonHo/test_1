
import { SEED } from './lgeDecryptSEED'; // SEED 클래스가 구현되어 있어야 함

export class SsoDecryptedPassword {
  public static toDecryptedPassword(paramString1: string, paramString2: string): string {
   	let str: string | null = null;

    if (paramString2) {
      if (paramString2.length > 24) {
        str = this.toDecryptedPassword32(paramString1, paramString2);
      } else {
        str = this.toDecryptedPassword16(paramString1, paramString2);
      }
    }

    return str ?? '';
  }

  public static toDecryptedPassword16(paramString1: string, paramString2: string): string {
	let str: string | null = null;

    try {
      const arrayOfByte1 = Buffer.from(paramString1); // getBytes()
      const arrayOfByte2 = Buffer.from(arrayOfByte1.toString(), 'base64'); // Base64 decode

      const arrayOfByte3 = Buffer.alloc(16); // output buffer
      const arrayOfByte4 = Buffer.from(paramString2);
      const arrayOfByte5 = Buffer.from(arrayOfByte4.toString(), 'base64');

      const seed = new SEED(arrayOfByte2);

      const encKeys : number [] = seed.getEncryptKeys();
      const decKeys : number []= seed.getDecryptKeys();

      // console.log(encKeys);
      // console.log(decKeys);

      // process.exit(0);

      seed.decryptBlock(arrayOfByte5, arrayOfByte3);

      const str1 = arrayOfByte3.toString();
      str = str1.trim();
    } catch (e: any) {
      console.error(e);
      str = null;
    }
    return str ?? '';
  }

  static toDecryptedPassword32(paramString1: string, paramString2: string): string {
   	let str: string | null = null;

    try {
      const arrayOfByte1 = Buffer.from(paramString1); // getBytes()
      const arrayOfByte2 = Buffer.from(arrayOfByte1.toString(), 'base64');

      const arrayOfByte4 = Buffer.from(paramString2);
      const arrayOfByte5 = Buffer.from(arrayOfByte4.toString(), 'base64');

      const seed = new SEED(arrayOfByte2);
      const arrayOfByte3 = seed.Decrypt(arrayOfByte5); // returns Buffer or Uint8Array

		  const str1 = arrayOfByte3 ? Buffer.from(arrayOfByte3).toString() : '';
	// const str1 = Buffer.from(arrayOfByte3).toString();
      str = str1.trim();
    } catch (e: any) {
      console.error(e);
      str = null;
    }
    return str ?? '';
  }
}
