import { SEED } from './lgeDecryptSEED';
import { SsoDecryptedPassword } from './ssoDecryptedPassword';

export const lgeCrypto = {
  SEED,
  SsoDecryptedPassword,
};

