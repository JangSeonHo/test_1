const convertDateToKoreaTime = (date: any) => {
  const koreaTime = new Date(date.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));

  const year = koreaTime.getFullYear();
  const month = String(koreaTime.getMonth() + 1).padStart(2, '0');
  const day = String(koreaTime.getDate()).padStart(2, '0');

  const hours = koreaTime.getHours();
  const minutes = String(koreaTime.getMinutes()).padStart(2, '0');
  const seconds = String(koreaTime.getSeconds()).padStart(2, '0');
  const ampm = hours >= 12 ? '오후' : '오전';
  const formattedHour = hours % 12 || 12; // 12시간제로 변환

  return `${year}-${month}-${day} ${ampm} ${formattedHour}:${minutes}:${seconds}`;
};

export default convertDateToKoreaTime;
