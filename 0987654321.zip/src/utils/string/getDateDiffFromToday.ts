const getDateDiffFromToday = (dateStr: any) => {
  const year = parseInt(dateStr.slice(0, 4), 10);
  const month = parseInt(dateStr.slice(4, 6), 10) - 1;
  const day = parseInt(dateStr.slice(6, 8), 10);

  // 입력 날짜 (KST 기준 자정)
  const inputDate = new Date(Date.UTC(year, month, day));
  inputDate.setHours(0, 0, 0, 0); // 오늘 KST 기준 자정

  // 현재 시간 (KST 기준 자정)
  const now = new Date();
  const utc = now.getTime() + (now.getTimezoneOffset() * 60 * 1000);
  const kstNow = new Date(utc + (9 * 60 * 60 * 1000));
  kstNow.setHours(0, 0, 0, 0); // 오늘 KST 기준 자정

  const diffMs = kstNow.getTime() - inputDate.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  return diffDays;
};

export default getDateDiffFromToday;
