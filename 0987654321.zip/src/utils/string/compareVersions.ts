const compareVersions = (version1: string, version2: string): number => {
  // 버전 문자열을 'major.minor.patch'로 나누어 각 부분을 정수로 변환
  const v1Parts = version1.split('.').map(Number);
  const v2Parts = version2.split('.').map(Number);

  // major, minor, patch 순서로 비교
  for (let i = 0; i < 3; i++) {
    if (v1Parts[i] < v2Parts[i]) {
      return -1; // version1이 version2보다 이전 버전
    } else if (v1Parts[i] > v2Parts[i]) {
      return 1; // version1이 version2보다 다음 버전
    }
  }

  return 0; // 두 버전이 동일
};

export default compareVersions;
