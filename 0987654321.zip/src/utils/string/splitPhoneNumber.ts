/* eslint-disable max-len */
const splitPhoneNumber = (phone: string) => {
  if (phone.length === 8) {
    return `${phone.substring(0, 4)}-${phone.substring(4)}`;
  }
  if (phone.length === 10) {
    if (phone.substring(0, 2) === '02') {
      return `${phone.substring(0, 2)}-${phone.substring(2, 6)}-${phone.substring(6)}`;
    } else {
      return `${phone.substring(0, 3)}-${phone.substring(3, 6)}-${phone.substring(6)}`;
    }
  }

  if (phone.length === 11) {
    return `${phone.substring(0, 3)}-${phone.substring(3, 7)}-${phone.substring(7)}`;
  }


  return phone;
};

export default splitPhoneNumber;
