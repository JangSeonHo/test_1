import { Types } from 'mongoose';
import chattingRoomTranslationInfoModel from 'models/message/chatting_room_translation_info';
import translateMessage from 'utils/openai/translateMessage';

interface TranslationResult {
  translate: Array<{
    locale: string;
    text: string;
  }>;
  recvTranslate: Array<{
    locale: string;
    text: string;
  }>;
}

/**
 * Gets translations for a chat message based on room and user settings
 * @param content Message content to translate
 * @param roomId ID of the chat room
 * @param userId ID of the message sender
 * @param tenantFlag Tenant flag for DB access
 */
export const getMessageTranslations = async (
  content: string,
  roomId: string | Types.ObjectId,
  userId: string,
  tenantFlag: string
): Promise<TranslationResult> => {
  const memberSendLocale = await chattingRoomTranslationInfoModel({tenantFlag})
    .findOne({
      parentChattingRoom: roomId, 
      parentUser: userId,
      isSendEnable: true
    })
    .select('sendLocale');

  const memberRecvLocales = await chattingRoomTranslationInfoModel({tenantFlag})
    .find({
      parentChattingRoom: roomId,
      parentUser: {$ne: userId},
      isRecvEnable: true
    })
    .select('recvLocale');

  const recvLocales = memberRecvLocales.map((v: any) => v.recvLocale);

  const distinctLocales = memberSendLocale 
    ? [...new Set([...recvLocales, memberSendLocale.sendLocale])].filter(locale => locale !== '')
    : [...new Set([...recvLocales])].filter(locale => locale !== '');

  const emptyResult = {
    translate: [],
    recvTranslate: []
  };

  if (distinctLocales.length === 0) {
    return emptyResult;
  }

  const translations = await translateMessage(content, distinctLocales);
  
  if (!Array.isArray(translations) || translations.length === 0) {
    return emptyResult;
  }

  const translate = memberSendLocale ? [{
    locale: memberSendLocale.sendLocale,
    text: (typeof content === 'string' && content.length > 0)
      ? translations.find(message => 
          message.target === memberSendLocale.sendLocale && 
          message.successYN === 'Y'
        )?.result?.trim() || ''
      : ''
  }] : [];

  const filteredTranslations = translations.filter(
    message => message.successYN === 'Y' && recvLocales.includes(message.target)
  );

  const recvTranslate = filteredTranslations.map(v => ({
    locale: v.target,
    text: (typeof content === 'string' && content.length > 0) 
      ? v.result.trim() 
      : ''
  }));

  return {
    translate,
    recvTranslate
  };
}; 