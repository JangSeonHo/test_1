import Koa from 'koa';
import adminNotificationModel from 'models/notice/admin_notice';
import userInfoModel from 'models/account/user_info';

const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;


const getAdminNotificationMain = async (ctx: Koa.Context) => {
    const condType = "Popup"; //GDC에서 해당 코드값 변경하면 수정해야 한다. 06.10
    const condStatus = "Use"; //GDC에서 해당 코드값 변경하면 수정해야 한다. 06.10

    try {
        const userId = ctx.response.get('userId');
        const tenantFlag = ctx.response.get('tenantFlag');

        const targetUserModel = userInfoModel({tenantFlag});

        const userInfo = await targetUserModel.findOne({_id: userId})
        .select('parentCompany');
        const filter = userInfo.parentCompany;

        const TargetAdminNotificationModel = adminNotificationModel({tenantFlag});

        const currentDate = new Date();

        const list = await TargetAdminNotificationModel.aggregate([
          {
            $match: {
              notiGroupTarget: { $in: [filter] },
              type: condType,
              startDate: { $lte: currentDate },
              endDate: { $gt: currentDate },
              status: condStatus
            }
          },
          {
              $project: {
                  _id: 1,
                  title: 1,
                  content: 1,
                  startDate: 1,
                  endDate: 1,
                  image: 1,
              }
          }
        ]);

        ctx.status = 200;
        ctx.body = {
            success: true,
            data : list
        };
    } catch (err) {
        ctx.status = 500;
        ctx.body = {
            'success': false,
            'error': 'internal server error',
        };
    }
};

export default getAdminNotificationMain;