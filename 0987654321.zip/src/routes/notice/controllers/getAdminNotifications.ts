import Koa from 'koa';
import adminNotificationModel from 'models/notice/admin_notice';
import userInfoModel from 'models/account/user_info';

const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;


const getAdminNotifications = async (ctx: Koa.Context) => {
    const condType = "Popup"; //GDC에서 해당 코드값 변경하면 수정해야 한다. 06.10. Popup , General
    const condStatus = "Use"; //GDC에서 해당 코드값 변경하면 수정해야 한다. 06.10

    try {
        const userId = ctx.response.get('userId');
        const tenantFlag = ctx.response.get('tenantFlag');

        const targetUserModel = userInfoModel({tenantFlag});

        const userInfo = await targetUserModel.findOne({_id: userId})
        .select('parentCompany');
        const filter = userInfo.parentCompany;

        const currentDate = new Date();

        const TargetAdminNotificationModel = adminNotificationModel({tenantFlag});

        const list = await TargetAdminNotificationModel.aggregate([
          {
            $match: {
              notiGroupTarget: { $in: [filter] },
              status: condStatus,
              $or: [
                {
                  type: condType, // 팝업공지이면 시작일시, 종료일시 조건.
                  $and: [
                    { startDate: { $lte: currentDate } },
                    { endDate: { $gt: currentDate } }
                  ]
                },
                {
                  type: { $ne: condType }, // 팝업공지가 아니면(General) 시작일시, 종료일시 조건.
                  startDate: { $lte: currentDate }
                }
              ]
            }
          },
          {
            $project: {
              _id: 1,
              title: 1,
              content: 1,
              createdAt: 1,
              updatedAt: 1,
              startDate: 1,
              endDate: 1,
              filesYn: {
                $cond: {
                  if: { $gt: [{ $size: "$files" }, 0] },
                  then: "Y",
                  else: "N"
                }
              }
            }
          },
          {
            $sort: { createdAt: -1 }
          }
        ]);

        ctx.status = 200;
        ctx.body = {
            success: true,
            data : list
        };
    } catch (err) {
      console.log(err);
      ctx.status = 500;
      ctx.body = {
        'success': false,
        'error': 'internal server error',
      };
    }
};

export default getAdminNotifications;