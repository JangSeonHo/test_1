/* eslint-disable max-len */
import Koa from 'koa';

// import Re2 from 're2';

import issueToken from 'utils/account/issueToken';
import userInfoModel from 'models/account/user_info';
import userSignModel from 'models/account/user_sign_info';
import getHashedPassword from 'utils/account/getHashedPassword';
import policyVersionModel from 'models/system/policy_version';

const loginMobile = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {
      password, deviceId, companyId,
    }: {
      password: string, deviceId: string, companyId: string,
    } = body;

    const tenantFlag = ctx.response.get('tenantFlag');
    const headers = ctx.headers;
    const deviceType = headers['device-type'] as string ?? '';
    const versionInfo = headers['version-info'] as string ?? '';

    const emailId: string = body.emailId.toLowerCase();

    if (!emailId || !password || !deviceId || !companyId) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': '',
        'error': 'login failure',
      };

      return;
    }

    const targetUserModel = userInfoModel({tenantFlag});
    const userInfo: any = await targetUserModel
      .findOne({
        emailId: emailId,
        parentCompany: companyId})
      .select('_id passwordSalt hashedPassword role childSignInfos lastSignedMobileId loginFailCount agreePrivacyPolicyVersion mfa changePasswordDate lastLoginDate');

    if (userInfo === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': '',
        'error': 'login failure',
      };

      return;
    }

    if (userInfo.loginFailCount === null) {
      userInfo.loginFailCount = 0;
    }

    if (userInfo.loginFailCount > 4) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': 'PF',
        'failCount': 5,
        'error': 'login failure',
      };

      return;
    }

    // password hashing
    // eslint-disable-next-line max-len
    const hashedPassword = getHashedPassword(password, userInfo['passwordSalt']);
    if (hashedPassword !== userInfo['hashedPassword']) {
      await targetUserModel.updateOne({emailId: emailId, parentCompany: companyId}, {
        $inc: {
          loginFailCount: 1,
        },
      });

      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': 'PF',
        'failCount': userInfo.loginFailCount + 1,
        'error': 'login failure',
      };

      return;
    }

    

    const userId: string = userInfo['_id'];

    const currentDate = new Date().getTime();
    let lastLoginDate = userInfo.lastLoginDate || currentDate;

    if (currentDate - lastLoginDate > (90 * 24 * 60 * 60 * 1000)) {
      ctx.status = 200;
      ctx.body = {
        success: true,
        data: {
          authInfo: null,
          userId: userInfo._id,
          shouldChangePassword: true,
        },
      };

      await targetUserModel.updateOne({emailId: emailId, parentCompany: companyId}, {
        loginFailCount: 0,
      });

      return;
    } else {
      await targetUserModel.updateOne({emailId: emailId, parentCompany: companyId}, {
        loginFailCount: 0,
        lastLoginDate: currentDate,
      });
    }

    if (userInfo.lastSignedMobileId === null ||
        deviceId !== userInfo.lastSignedMobileId || !userInfo.mfa || !userInfo.mfa.isVerified) {
      ctx.status = 200;
      ctx.body = {
        success: true,
        data: {
          authInfo: null,
          userId: userInfo._id,
        },
      };

      return;
    }

    const {
      accessToken,
      refreshToken,
    } = await issueToken({
      tenantFlag,
      userId,
      deviceId,
      deviceType,
      versionInfo,
      role: userInfo['role'] ?? 'user',
    });

    // [성능튜닝] 하기 소스는 성능향상을 위해 수정됨.
    const signInfos = await userSignModel({tenantFlag}).find({parentUser: userId}).select('_id');

    const originArr = JSON.stringify(userInfo.childSignInfos.sort());
    const newArr = JSON.stringify(signInfos.map((si: any) => si._id).sort());
  
    if (originArr !== newArr) {
      targetUserModel.updateOne({_id: userId}, {
        childSignInfos: newArr,
      });
    }
  
    const policyVersion = await policyVersionModel({tenantFlag}).findOne({});

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        userId,
        authInfo: {
          accessToken,
          refreshToken,
          role: userInfo['role'] ?? 'user',
        },
        policyVersion: userInfo.agreePrivacyPolicyVersion === policyVersion.version ? '' : policyVersion.version,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
    };
  }
};

export default loginMobile;
