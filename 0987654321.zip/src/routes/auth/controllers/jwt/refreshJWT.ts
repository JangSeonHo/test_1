/* eslint-disable max-len */
import Koa from 'koa';
import jwt from 'jsonwebtoken';
import { Types } from 'mongoose';

import issueToken from 'utils/account/issueToken';
import userInfoModel from 'models/account/user_info';
import userSignModel from 'models/account/user_sign_info';
import policyVersionModel from 'models/system/policy_version';
import policyGDPRVersionModel from 'models/system/policy_gdpr_version';
import { PW_DEFAULT_DAYS, DATE_TO_MILLISEC } from '../../../../constants/commonConstants';
import { getPasswordChangeCycle } from 'utils/account/getPasswordChangeCycle';

interface CompanyDetail {
  _id: Types.ObjectId;
  parentCompany: Types.ObjectId;
  passwordChangeCycle?: number;
}

const refreshJWT = async (ctx: Koa.Context) => {
  const body: any = ctx.request.body;

  const rt: string = ctx.request.headers['refresh-token'] as string ?? '';
  if (!rt) {
    ctx.status = 403;
    ctx.body = {
      'success': false,
      'error': 'permission denied',
    };

    return;
  }

  const {
    deviceId,
  }: {
    deviceId: string,
  } = body;

  let userId = null;

  try {
    const jwtSecret = process.env.DEV_JWT_SECRET as string ?? '';
    const decode: any = jwt.verify(rt, jwtSecret);
    userId = decode.userId;
  } catch (err) {
    ctx.status = 403;
    ctx.body = {
      'success': false,
      'error': 'permission denied',
    };

    return;
  }

  if (!userId || !deviceId) {
    ctx.status = 400;
    ctx.body = {
      'success': false,
      'error': 'bad request',
    };

    return;
  }

  const tenantFlag = ctx.response.get('tenantFlag');
  const headers = ctx.headers;
  const deviceType = headers['device-type'] as string ?? '';
  const versionInfo = headers['version-info'] as string ?? '';

  const TargetUserSignModel = userSignModel({tenantFlag});

  const userSignInfo = await TargetUserSignModel.findOne({
    'parentUser': userId,
    'deviceId': deviceId,
    'deviceType': deviceType,
  });

  if (userSignInfo == null) {
    ctx.status = 400;
    ctx.body = {
      'success': false,
      'error': 'bad request',
    };

    return;
  }

  const {
    accessToken,
    refreshToken,
  } = await issueToken({
    tenantFlag, userId, deviceId, deviceType, versionInfo, isRefresh: true,
  });

  const [policyVersion,
    userInfo,
    policyGDPRVersion,
    ] = await Promise.all([
      policyVersionModel({tenantFlag}).findOne({}),
      userInfoModel({tenantFlag})
        .findOne({_id: userId})
        .populate('parentCompany', 'companyCode')
        .select('agreePrivacyPolicyVersion lastLoginDate europeCorp agreeGDPRVersion changePasswordDate parentCompany'),
      policyGDPRVersionModel({tenantFlag}).findOne({})
    ]) as any;

  const duration4pw = await getPasswordChangeCycle(tenantFlag, userInfo.parentCompany);

  const currentDate = new Date().getTime();
  const changePWdate = userInfo.changePasswordDate || currentDate;
  const shouldChangePassword = currentDate - changePWdate > (duration4pw * DATE_TO_MILLISEC);

  ctx.status = 200;
  ctx.body = {
    'success': true,
    'data': {
      userId,
      accessToken,
      refreshToken,
      policyVersion: userInfo.agreePrivacyPolicyVersion === policyVersion.version ? '' : policyVersion.version,
      shouldChangePassword,
      europeCorp: userInfo.europeCorp, 
      policyGDPRVersion: userInfo.agreeGDPRVersion === policyGDPRVersion.ver ? '' : policyGDPRVersion.ver,
      companyCode: userInfo.parentCompany?.companyCode,
    },
  };
};

export default refreshJWT;
