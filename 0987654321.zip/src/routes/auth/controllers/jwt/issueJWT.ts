/* eslint-disable max-len */
import Koa from 'koa';
import { Types } from 'mongoose';
// import Re2 from 're2';

import issueToken from 'utils/account/issueToken';
import userInfoModel from 'models/account/user_info';
import userSignModel from 'models/account/user_sign_info';
import userStatusModel from 'models/account/user_status_info';
import getHashedPassword from 'utils/account/getHashedPassword';
import policyVersionModel from 'models/system/policy_version';
import policyGDPRVersionModel from 'models/system/policy_gdpr_version';
import companyInfoModel from 'models/company/company_company_info';
import uplusAllowedIpModel from 'models/system/uplus_allowed_login_ip';
import createApiAccessLog from 'utils/log/create_api_access_log';
import {UserStatusCode, PW_DEFAULT_DAYS, DATE_TO_MILLISEC, ENCKEYFORPARAM} from 'constants/commonConstants';
import convertIpToDecimal from 'utils/string/convertIpToDecimal';
import {lbipModelPrimaryOnly} from 'models/system/loadbalancer_ip';
import companyDetailModel from 'models/company/company_detail';
import { getPasswordChangeCycle } from 'utils/account/getPasswordChangeCycle';
import validatePassword from 'utils/account/validatePassword';
import {decryptBodyParams} from 'utils/cipher';

interface CompanyDetail {
  _id: Types.ObjectId;
  parentCompany: Types.ObjectId;
  passwordChangeCycle?: number;
}

const issueJWT = async (ctx: Koa.Context) => {
  const tenantFlag = ctx.response.get('tenantFlag');
  const headers = ctx.headers;

  try {
    const body: any = ctx.request.body;
    let {
      password, deviceId, companyId, deviceType, encParam,
    }: {
      password: string, deviceId: string, companyId: string, deviceType: string, encParam: string
    } = body;
    let emailId: string = (body.emailId ?? '').toLowerCase();

    if (!!encParam) {
      const decryptRes = decryptBodyParams(encParam, ENCKEYFORPARAM);

      if (!decryptRes.success) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'code': '',
          'message': 'login failure 0',
        };
        return;
      }
      password = decryptRes.params['password'];
      deviceId = decryptRes.params['deviceId'];
      companyId = decryptRes.params['companyId'];
      deviceType = decryptRes.params['deviceType'];
      emailId = (decryptRes.params['emailId'] ?? '').toLowerCase();
    }

    const versionInfo = headers['version-info'] as string ?? '';
    deviceType = deviceType ?? headers['device-type'] as string ?? '';


    if (!emailId || !password || !deviceId || !companyId) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': '',
        'error': 'login failure 0',
      };

      return;
    }

    const targetUserModel = userInfoModel({tenantFlag});
    const targetUserStatusModel = userStatusModel({tenantFlag});
    const userInfo = await targetUserModel
      .findOne({
        emailId: emailId, parentCompany: companyId,
        $or: [{isDeleted: false}, {isDeleted: {$exists: false}}],
      })
      .select('_id passwordSalt hashedPassword role childSignInfos lastSignedMobileId loginFailCount agreePrivacyPolicyVersion mfa changePasswordDate lastLoginDate parentCompany europeCorp agreeGDPRVersion');

    if (userInfo === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': '',
        'error': 'login failure 1',
      };
      return;
    }

    const duration4pw = await getPasswordChangeCycle(tenantFlag, userInfo.parentCompany);

    // 유플러스(GUC001) 유저는 헤더상의 클라이언트 IP가 Internal NLB IP만 허용 - 권오중
    // 유플러스 지정된 6개IP 추가 허용(외부망?)
    const companyInfo = await companyInfoModel({tenantFlag})
      .findOne({companyCode: 'GUC001'})
      .select('_id');
    // console.log('typeof companyOid = ', typeof companyInfo);
    if (deviceType === 'win32' && typeof companyInfo === 'object') {
      let isAllowed = false;
      if (String(userInfo.parentCompany) === String(companyInfo._id)) {
        const [lbIpInfo, isAllowedIpList] = await Promise.all([
          lbipModelPrimaryOnly({tenantFlag})
            .findOne({enable: true, isExt: false})
            .select('ip1 ip2'),
          uplusAllowedIpModel({tenantFlag})
            .find({isEnable: true})
            .select('ipRangeStart ipRangeEnd isInternal').lean(),
        ]);
        const lbIP = String(ctx.request.socket.remoteAddress || '');
        const decLBIP = convertIpToDecimal(lbIP);
        const internalAllowedIp = isAllowedIpList.filter((info) => info?.isInternal);
        const externalAllowedIp = isAllowedIpList.filter((info) => !info?.isInternal);

        console.log('U-Plus login ip - ', emailId, ' - x-forwarded-for :', ctx.request.headers['x-forwarded-for']);
        let tmpHeaderIp = ctx.request.headers['x-forwarded-for'] || '';
        if (tmpHeaderIp.includes(',') && typeof tmpHeaderIp === 'string') {
          tmpHeaderIp = tmpHeaderIp.split(',');
        }
        const ipArr = Array.isArray(tmpHeaderIp) ? tmpHeaderIp : [tmpHeaderIp];
        const decIpArr: number[] = ipArr.map((ipVal) => convertIpToDecimal(ipVal));

        if (lbIpInfo.ip1 === decLBIP || lbIpInfo.ip2 === decLBIP) {
          decIpArr.forEach((decClientIP) => {
            internalAllowedIp.forEach((range: any) => {
              if ((range.ipRangeStart <= Number(decClientIP) && range.ipRangeEnd >= Number(decClientIP)) ||
                range.ipRangeStart === 0) {
                isAllowed = true;
              }
            });
          });
        } else if (externalAllowedIp.length > 0) { // 외부망 6개 IP 허용
          decIpArr.forEach((decClientIP) => {
            externalAllowedIp.forEach((range: any) => {
              if ((range.ipRangeStart <= Number(decClientIP) && range.ipRangeEnd >= Number(decClientIP)) ||
                range.ipRangeStart === 0) {
                isAllowed = true;
              }
            });
          });
        }
      } else {
        isAllowed = true;
      }
      if (!isAllowed) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'code': '',
          'error': 'login failure 2',
        };
        return;
      }
    } else if (!(deviceType === 'ios' || deviceType === 'android') && typeof companyInfo === 'object') {
      // 유플러스 중에 win32 / ios / android가 아닌 경우 접근제한
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': '',
        'error': 'login failure 2',
      };
      return;
    }

    if (userInfo.loginFailCount === null) {
      userInfo.loginFailCount = 0;
    }

    if (userInfo.loginFailCount > 4) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': 'PF',
        'failCount': 5,
        'error': 'login failure 3',
      };

      return;
    }

    // [M-2] 패스워드 정책 관리 - LG유플러스 모의해킹 결과 - 보완 조치.
    if (!validatePassword(password)) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Password must include at least two of the following: letters, numbers, special characters.',
      };
      return;
    }

    // password hashing
    const hashedPassword = getHashedPassword(password, userInfo['passwordSalt']);
    if (hashedPassword !== userInfo['hashedPassword']) {
      await targetUserModel.updateOne({emailId: emailId, parentCompany: companyId}, {
        $inc: {
          loginFailCount: 1,
        },
      });

      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': 'PF',
        'failCount': userInfo.loginFailCount + 1,
        'error': 'login failure 4',
      };
      return;
    }

    const userId: any = userInfo['_id'];
    const currentDate = new Date().getTime();
    const lastLoginDate = userInfo.lastLoginDate || currentDate;
    const changePasswordDate = userInfo.changePasswordDate || currentDate;
    const europeCorp = userInfo.europeCorp;

    if (currentDate - changePasswordDate > (duration4pw * DATE_TO_MILLISEC)) {
      console.log(`Password expired. Duration: ${duration4pw} Set ${ ((currentDate-changePasswordDate)/DATE_TO_MILLISEC).toFixed(1)} Days ago.` );
      ctx.status = 200;
      ctx.body = {
        success: true,
        data: {
          authInfo: null,
          userId: userInfo._id,
          shouldChangePassword: true,
        },
      };

      await targetUserModel.updateOne({emailId: emailId, parentCompany: companyId}, {
        loginFailCount: 0,
      });

      return;

    } else {
      await targetUserModel.updateOne({emailId: emailId, parentCompany: companyId}, {
        loginFailCount: 0,
        lastLoginDate: currentDate,
      });
    }

    const userInfoObj = userInfo.toObject();
    if (deviceType === 'android' || deviceType === 'ios') {
      if ((userInfoObj.hasOwnProperty('lastSignedMobileId') && deviceId !== userInfoObj.lastSignedMobileId)
        || !userInfo.mfa
        || !userInfo.mfa.isVerified
        || (!!userInfo.mfa && !userInfoObj.hasOwnProperty('lastSignedMobileId')
        ) // PC로 인증 및 로그인을 거쳤더라도 새 모바일 기기에 대해서는 본인인증 다시 함.
      ) {
        const bodyObj = {
          success: true,
          data: {
            authInfo: null,
            userId: userInfo._id,
            initChangePassword: true,
          },
        };
        if (userInfoObj.hasOwnProperty('changePasswordDate')) {
          bodyObj.data.initChangePassword = userInfoObj.changePasswordDate <= 0;
        }
        ctx.status = 200;
        ctx.body = bodyObj;

        return;
      }
    } else if (deviceType === 'win32' && (!userInfo.mfa || !userInfo.mfa.isVerified)) {
      // PC로 최초로그인 하는 경우에 본인인증 단계로 보내기위한 처리
      const bodyObj = {
        success: true,
        data: {
          authInfo: null,
          userId: userInfo._id,
          initChangePassword: true,
        },
      };
      if (userInfoObj.hasOwnProperty('changePasswordDate')) {
        bodyObj.data.initChangePassword = userInfoObj.changePasswordDate <= 0;
      }
      ctx.status = 200;
      ctx.body = bodyObj;

      return;
    }

    const [
      {
        accessToken,
        refreshToken,
      },
      policyVersion,
      policyGDPRVersion,
    ] = await Promise.all([
      issueToken({
        tenantFlag,
        userId,
        deviceId,
        deviceType,
        versionInfo,
        role: userInfo['role'] ?? 'user',
      }),
      policyVersionModel({tenantFlag}).findOne({}),
      policyGDPRVersionModel({tenantFlag}).findOne({})
    ]);

    // [성능튜닝] 하기 소스는 성능향상을 위해 수정됨.
    const signInfos = await userSignModel({tenantFlag}).find({parentUser: userId}).select('_id');

    const originArr = JSON.stringify(userInfo.childSignInfos.sort());
    // string Object -> Object으로 변환하여 childSignInfos 저장
    const newArr = signInfos.map((si: any) => si._id).sort();
    const newArrStr = JSON.stringify(newArr);

    if (originArr !== newArrStr) {
      await targetUserModel.updateOne({_id: userId}, {
        childSignInfos: newArr,
      });
    }

    // PC 로그아웃 후 재로그인 시 stream 발생타이밍 문제로 OFFLINE 상태 표출이슈 처리
    if (deviceType === 'win32') {
      await targetUserStatusModel.updateOne({
        $and: [{
          parentUser: userId,
        }, {
          $or: [{pcStatus: UserStatusCode.OFFLINE}, {pcStatus: 'offline'}, {pcStatus: UserStatusCode.AWAY}, {pcStatus: null}],
        }]}, {$set: {
          pcStatus: UserStatusCode.ONLINE,
        }});
    }

    createApiAccessLog({
      api: ctx.url,
      ip: String(ctx.request.headers['x-forwarded-for'] || ''),
      userId,
      deviceType: deviceType
    });
    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        userId,
        accessToken,
        refreshToken,
        role: userInfo['role'] ?? 'user',
        policyVersion: userInfo.agreePrivacyPolicyVersion === policyVersion.version ? '' : policyVersion.version,
        europeCorp,
        policyGDPRVersion: userInfo.agreeGDPRVersion === policyGDPRVersion.ver ? '' : policyGDPRVersion.ver,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
    };
  }
};

export default issueJWT;
