import Koa from 'koa';
import userInfoModel from 'models/account/user_info';

const agreeGdprPolicy = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    console.log(tenantFlag, userId);

    const { gdprVersion, europeCorp } = ctx.request.body as any;

    console.log(gdprVersion, europeCorp);

    const targetUserModel = userInfoModel({tenantFlag});

    if (europeCorp !== undefined) {
      if (europeCorp) {
        await targetUserModel.updateOne({_id: userId}, {
          agreeGDPRVersion: gdprVersion,
          agreeGDPRDate: new Date().getTime(),
        });
      }
      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          europeCorp,
          gdprVersion,
        },
      };
    }
  } catch (err) {
    ctx.status = 500;
    ctx.body = {'success': false, 'error': 'internal server error'};
  }
};

export default agreeGdprPolicy;
