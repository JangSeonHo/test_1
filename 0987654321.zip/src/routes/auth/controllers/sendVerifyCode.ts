/* eslint-disable max-len */
import Koa from 'koa';
import mongoose from 'mongoose';

import userInfoModel from 'models/account/user_info';
import userVerifyCodeCheckModel from 'models/account/user_verify_code_check';
import maskEmail from 'utils/masking/maskEmail';
import maskPhoneNumber from 'utils/masking/maskPhoneNumber';
import sendEmail from 'utils/email/sendEmail';
import sendSMS from 'utils/sms/sendSMS';
import isNewerOrEqualVersion from 'utils/account/getClientVersionCompare';

const NEW_VERSION_INFO = '0.5.95';

const sendVerifyCode = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {authType, userId}: {authType: string, userId: string} = body;

    const headers = ctx.headers;
    const versionInfo = headers['version-info'] as string ?? '';
    const deviceType = headers['device-type'] as string ?? '';

     //버전 정보 비교
     const isNewVersion = isNewerOrEqualVersion(versionInfo, NEW_VERSION_INFO);

    if ((authType !== 'email' && authType !== 'phone') ||
      !mongoose.Types.ObjectId.isValid(userId)) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: 'bad request',
      };
      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');
    const targetUserModel = userInfoModel({tenantFlag});
    // eslint-disable-next-line max-len
    const targetUserVerifyCodeCheckModel = userVerifyCodeCheckModel({tenantFlag});

    const userInfo = await targetUserModel.findOne({_id: userId}).select('_id personalPhoneNumber email mfa');

    if (userInfo == null) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: 'bad request',
      };
      return;
    }

    // 클라이언트 버전이 0.5.95 이상이면 해당 로직을 수행한다.
    if (isNewVersion) {
      const now = Date.now();

      let errorCode = '';
      let errorMsg = '';

      const failCount = userInfo.mfa?.failCount || 0;
      const lockUntil = userInfo.mfa?.lockUntil || 0;

      if (failCount >= 3 && lockUntil && lockUntil > now) {
        errorCode = '-E9991';
        errorMsg = 'Too many failed attempts. Please try again after 30 minutes.';
        ctx.status = 429;
        ctx.body = {
          success: false,
          errorCode,
          errorMsg,
        };
        return;
      }

      // 제한 횟수 설정: authType별로 다르게 적용
      const dailyLimit = authType === 'phone' ? 30 : 100;
      const minuteLimit = authType === 'phone' ? 10 : 30;

      const oneDayAgo = now - (24 * 60 * 60 * 1000);
      const oneMinuteAgo = now - (60 * 1000);

      // 하루 제한
      const dailySendCount = await targetUserVerifyCodeCheckModel.countDocuments({
        verifyId: userId,
        authType,
        createdAtMs: { $gte: oneDayAgo },
      });

      if (dailySendCount >= dailyLimit) {
        errorCode = '-E9992';
        errorMsg = 'Exceeded daily request limit. Please try again later.';
        ctx.status = 429;
        ctx.body = {
          success: false,
          errorCode,
          errorMsg,
        };
        return;
      }

      // 분당 제한
      const verifyCodeCount = await targetUserVerifyCodeCheckModel.countDocuments({
        verifyId: userId,
        authType,
        createdAtMs: { $gte: oneMinuteAgo },
      });

      if (verifyCodeCount >= minuteLimit) {
        errorCode = '-E9993';
        errorMsg = 'Too many requests. Please try again later.';
        ctx.status = 429;
        ctx.body = {
          success: false,
          errorCode,
          errorMsg,
        };
        return;
      }

      // 기록 저장
      await targetUserVerifyCodeCheckModel.create({
        verifyId: userId,
        authType, // 추가!
        createdAtMs: now,
      });
    }

    // 인증번호 생성
    const dateTimeString = new Date().getTime().toString();
    const code = dateTimeString.substring(dateTimeString.length - 6, dateTimeString.length);
    const validateTime =
      authType === 'email' ?
        new Date().getTime() + ((300 + 10) * 1000) :
        new Date().getTime() + ((180 + 10) * 1000); // 10초는 sever latency 보정값

    const {personalPhoneNumber, email} = userInfo;

    if (authType === 'email') {
      sendEmail({
        to: email,
        subject: 'mMessenger 로그인 인증번호입니다',
        text: `메신저 인증번호는 [${code}]입니다`,
      });
    } else if (authType === 'phone') {
      sendSMS({
        to: personalPhoneNumber,
        text: `메신저 인증번호는 [${code}]입니다`,
      });
    }

    await targetUserModel.updateOne({_id: userId}, {
      mfa: {
        type: authType,
        code,
        validateTime,
        isVerified: false,
      },
    });

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        userInfo: {
          email: maskEmail(email),
          personalPhoneNumber: maskPhoneNumber(personalPhoneNumber),
          personalPhoneNumber2: personalPhoneNumber,
        },
        authInfo: {
          validateTime,
        },
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default sendVerifyCode;