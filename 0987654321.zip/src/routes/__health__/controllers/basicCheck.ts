import Koa from 'koa';

const basicCheck = async (ctx: Koa.Context) => {
  try {
    ctx.status = 200;
    ctx.body = {
      state: 'normal',
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = 'error';
  }
};

export default basicCheck;
