import Router from '@koa/router';

const router = new Router();

import basicCheck from './controllers/basicCheck';
router.get('/basicCheck', basicCheck);

import emailCheck from './controllers/emailCheck';
router.get('/emailCheck', emailCheck);

export default router;
