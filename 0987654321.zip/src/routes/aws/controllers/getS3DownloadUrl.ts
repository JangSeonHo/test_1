/* eslint-disable max-len */
import Koa from 'koa';
import {GetObjectCommand, S3Client} from '@aws-sdk/client-s3';
import {
  getSignedUrl,
} from '@aws-sdk/s3-request-presigner';

import {ENCKEYFORPARAM} from 'constants/commonConstants';
import {s3Bucket} from 'configs/s3';
import userInfoModel from 'models/account/user_info';
import companyInfoModel from 'models/company/company_company_info';
import companyDetailModel from 'models/company/company_detail';
// import downloadInfo from 'models/system/download_info';
import whitelistIpModel from 'models/system/whitelist_ip_file_transmit';
import blockedIpRangeModel from 'models/system/blocked_ip_range_file_transmit';
import {lbipModelPrimaryOnly} from 'models/system/loadbalancer_ip';
import fileShareGroupIpModel from 'models/system/fileshare_group_ip_range';
import fileShareGroupEmailModel from 'models/system/fileshare_group_email';
import createDownloadHistory from 'utils/log/create_download_history';
import convertIpToDecimal from 'utils/string/convertIpToDecimal';
import {decryptBodyParams, decryptURL} from 'utils/cipher';
// import {encryptBodyParams} from 'utils/cipher';

const REGION = 'ap-northeast-2';
const s3Client = new S3Client({region: REGION});

const getS3DownloadUrl = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    let deviceType = ctx.response.get('deviceType');

    // if (!!ctx.request.body.test) {
    //   console.log('URL 복호화 테스트 ', decryptURL(ctx.request.body.test, ENCKEYFORPARAM));
    // }
    console.log('[getS3DownloadUrl] Request from port :', ctx.request.socket.localPort);

    let {key, fileOwner, parentMessageId, encParam} =
      ctx.request.body as {key: string, fileOwner: string, parentMessageId: string, encParam: string};
    // console.log('[getS3DownloadUrl]$$$$$$$$ enc test :', encryptBodyParams(ctx.request.body, ENCKEYFORPARAM));

    if (!!encParam) {
      const decryptRes = decryptBodyParams(encParam, ENCKEYFORPARAM);

      if (!decryptRes.success) {
        ctx.status = 403;
        ctx.body = {
          'success': true,
          'code': -4,
          'error': 'permission denied',
        };
        return;
      }
      key = decryptRes.params['key'];
      deviceType = decryptRes.params['deviceType'];
      // versionInfo = decryptRes.params['versionInfo'];
    }

    console.log("[getS3DownloadUrl][deviceType] >>> ", tenantFlag, userId, deviceType);

    const companyIds = await companyInfoModel({tenantFlag})
      .find({}).select('_id').lean();
    const companyId = key.split('/')[0];

    // 요청 key에서 companyId값이 유효한지 여부
    const matchedCompany = companyIds.filter((d) => String(d._id) == companyId);
    if (matchedCompany.length < 1) {
      ctx.status = 403;
      ctx.body = {
        'success': true,
        'code': -4,
        'error': 'permission denied',
      };
      return;
    }

    let downloadCheck = false;
    let isFileShareGrp = false;
    let userInfos;
    console.log('[getS3DownloadUrl][key] :', key);
    console.log('[getS3DownloadUrl][companyId] :', companyId);
    const versionInfo = ctx.headers['version-info'] as string ?? '';
    console.log('[getS3DownloadUrl][versionInfo] :', versionInfo);

    const decIpArr: number[] = []; // 클라이언트 IP - decimal
    let tmpClientIP: any = String(ctx.request.headers['x-forwarded-for'] || '');
    // let tmpClientIP: any = '10.62.1.1, 10.65.83.68';
    if (tmpClientIP.includes(',') && typeof tmpClientIP === 'string') {
      tmpClientIP = tmpClientIP.split(',');
    }
    const ipArr = Array.isArray(tmpClientIP) ? tmpClientIP : [tmpClientIP];
    ipArr.forEach((ipVal, i) => {
      let clientIP = ipVal.trim();
      clientIP = clientIP.replace(/^.*:/, '');
      console.log('[getS3DownloadUrl][ClientIP][', i, '] :', clientIP);
      decIpArr.push(convertIpToDecimal(ipVal));
    });

    // fileshare group 조건에 해당하면 이후 '회사간 파일전송 허용' 체크는 무시한다.
    if (userId != fileOwner && !!fileOwner) {
      // 파일 오너와 다운로드 요청자의 email이 같은 셰어그룹에 있으면,
      // 요청자가 해당 셰어그룹에 등록된 IP대역 해당하는지 체크
      userInfos = await userInfoModel({tenantFlag})
        .find({_id: {$in: [userId, fileOwner]}})
        .select('email parentCompany').lean();
      if (userInfos.length === 2) {
        console.log('[getS3DownloadUrl] NERP TEST - email 0 :', userInfos[0].email, ' / email 1 :', userInfos[1].email);

        const shareGrpEmail = await fileShareGroupEmailModel({tenantFlag})
          .find({email: {$in: userInfos.map((i: any) => i.email)}})
          .select('email groupName').lean();

        let isSameGrpUser = false;
        shareGrpEmail.length === 2 ?
          shareGrpEmail[0].email !== shareGrpEmail[1].email &&
          shareGrpEmail[0].groupName === shareGrpEmail[1].groupName ? isSameGrpUser = true : isSameGrpUser = false : isSameGrpUser = false;

        if (isSameGrpUser) {
          if (deviceType == 'win32') {
            const shareGrpIpInfo = await fileShareGroupIpModel({tenantFlag})
              .find({
                $or: decIpArr.map((ip: number) => ({
                  ipRangeStart: {$lte: ip},
                  ipRangeEnd: {$gte: ip},
                })),
                groupName: shareGrpEmail[0].groupName,
                isEnable: true,
              })
              .select('groupName').lean();

            if (shareGrpIpInfo.length > 0) {
              console.log('[getS3DownloadUrl] FileShare Grp : ', shareGrpIpInfo[0].groupName);
              isFileShareGrp = true;
            } else {
              console.log('[getS3DownloadUrl] No FileShare Grp');
            }
          } else {
            console.log('[getS3DownloadUrl] FileShare Grp(Mobile) : ', shareGrpEmail[0].groupName);
            isFileShareGrp = true;
          }
        }
      }
    } else {
      userInfos = await userInfoModel({tenantFlag})
        .find({_id: userId})
        .select('parentCompany').lean();
    }
    const reqUser = userInfos.filter((user) => user._id == userId);
    const reqUserCompany = String(reqUser[0].parentCompany);
    // 타회사 사용자가 업로드한 파일 다운로드 금지
    // 회사간 파일 다운로드 기능 개발전 임시구현 - A64611
    // if (!isFileShareGrp) {
    //   if (companyId != reqUserCompany) {
    //     ctx.status = 403;
    //     ctx.body = {
    //       'success': true,
    //       'code': -2,
    //       'error': 'permission denied',
    //     };
    //
    //     return;
    //   }
    // }

    const [lbIpInfo, blockInfo, whiteIpInfo, companyInfo, companyDetail] = await Promise.all([
      lbipModelPrimaryOnly({tenantFlag})
        .findOne({enable: true, isExt: false})
        .select('ip1 ip2'),
      blockedIpRangeModel({tenantFlag})
        .find({download: true})
        .select('ipRangeStart ipRangeEnd description'),
      whitelistIpModel({tenantFlag})
        .find({
          isEnable: true,
        })
        .select('ipRangeStart ipRangeEnd'),
      companyInfoModel({tenantFlag})
        .findOne({_id: reqUserCompany})
        .select('fileAllowedCompanies'),
      companyDetailModel({tenantFlag})
        .findOne({parentCompany: reqUserCompany})
        .select('fileControlAuthorityPc fileControlAuthorityMobile'),
    ]);

    if (!isFileShareGrp && companyId !== reqUserCompany && !companyInfo.fileAllowedCompanies.includes(companyId)) {
      console.log('[getS3DownloadUrl][Unauthorized Req] another company user file.');
      ctx.status = 403;
      ctx.body = {
        'success': true,
        'code': -2,
        'error': 'permission denied',
      };

      return;
    }

    // 임시 ::: 모바일은 다 해제한다. by shjaang74
    if ((deviceType === 'android' || deviceType === 'ios') &&
      companyDetail.fileControlAuthorityMobile.includes('D')) {
      downloadCheck = true;
    }

    //-----------------------------------------------------------------------------------------------------
    // 임시로 다운로드 허용된 IP에 한해서만 다운로드 가능하도록 한다. by shjang74
    //-----------------------------------------------------------------------------------------------------
    // if (deviceType === 'win32') {
    //   const connectN = await companyInfoModel({tenantFlag}).findOne({companyCode: 'GUC102'})
    //     .select('_id').lean();
    // 임시 - 화이트/블랙리스트 정책 적용 전까지 헬로커넥트앤 사용자에 대해 다운로드 허용IP 체크 skip
    // if (String(userInfos[0].parentCompany) != String(connectN._id)) {
    // 임시 ::: 허용된 IP정보를 조회한다. - 임시 by shjang74..
    // const targetDownloadInfo = downloadInfo({tenantFlag});
    // const reqIp: string = ctx.request.ip ?? '';
    // const isUser = await targetDownloadInfo.findOne({ipAddr: reqIp});
    // if (isUser) {
    //   downloadCheck = true;
    // }
    //   } else {
    //     downloadCheck = true;
    //   }
    // }

    // 다운로드 블랙리스트 IP대역 테스트 중 - 권오중
    if (deviceType === 'win32' &&
      companyDetail.fileControlAuthorityPc.includes('D')) {
      // 외부망 클라이언트 필터링
      // TODO - 회사별 대역 조건 추가필요
      const lbIP = String(ctx.request.socket.remoteAddress || '');
      // let lbIP = '10.2.146.25';
      const decLBIP = convertIpToDecimal(lbIP);
      if (lbIpInfo.ip1 === decLBIP || lbIpInfo.ip2 === decLBIP) {
        downloadCheck = true;
      }

      if (!downloadCheck) {
        console.log('[getS3DownloadUrl][외부망] User ID >>> ', userId);
      }
      // let tmpClientIP = String(ctx.request.headers['x-forwarded-for'] || '');
      // if (tmpClientIP.includes(',') && typeof tmpClientIP === 'string') {
      // @ts-ignore
      // tmpClientIP = tmpClientIP.split(',');
      // }
      // const ipArr = Array.isArray(tmpClientIP) ? tmpClientIP : [tmpClientIP];

      if (downloadCheck) {
        downloadCheck = false;
        let isWhite = false;
        let isBlack = false;
        let blackDesc = '';
        decIpArr.forEach((decClientIP) => {
          // 화이트리스트 필터링
          whiteIpInfo.forEach((range: any) => {
            if (range.ipRangeStart <= Number(decClientIP) && range.ipRangeEnd >= Number(decClientIP)) {
              downloadCheck = true;
              isWhite = true;
            }
          });

          // 블랙리스트 필터링
          blockInfo.forEach((range: any) => {
            if (range.ipRangeStart <= Number(decClientIP) && range.ipRangeEnd >= Number(decClientIP)) {
              downloadCheck = false;
              isBlack = true;
              blackDesc = range.description;
            }
          });
        });
        if (!isWhite) {
          console.log("[getS3DownloadUrl] Not included in whitelist");
        }
        if (isBlack) {
          console.log("[getS3DownloadUrl] Included in blacklist : ", blackDesc);
        }
      }

      const connectN = await companyInfoModel({tenantFlag}).findOne({companyCode: 'GUC102'})
        .select('_id');
      if (String(reqUserCompany) == String(connectN._id) &&
        companyId == String(reqUserCompany)) {
        downloadCheck = true;
      }
    }
    console.log("[getS3DownloadUrl][downloadCheck] >>> ", downloadCheck);

    if (downloadCheck) {
      const command = new GetObjectCommand({Bucket: s3Bucket, Key: key});
      const url = await getSignedUrl(s3Client, command, {expiresIn: 600});
      // TODO - CloundFront signed url로 변경

      const fileType = key.split('/')[1];
      const messageId = parentMessageId ?? '';

      createDownloadHistory({type: fileType, parentMessageId: messageId, userId});

      console.log("[getS3DownloadUrl][signedUrl] >>> ", url);
      ctx.status = 200;
      ctx.body = {
        'success': true,
        'code': 0,
        'data': {
          url,
          isFileShareGrp,
        },
      };
    } else {
      ctx.status = 403;
      ctx.body = {
        'success': true,
        'code': -3,
        'error': 'permission denied',
      };
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'code': -1,
      'error': 'internal server error',
    };
  }
};

export default getS3DownloadUrl;
