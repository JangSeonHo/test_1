import Router from '@koa/router';

import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

import getRecentAppVersion from './controllers/getRecentAppVersion';
import getRecentPrivacyVersion from './controllers/getRecentPrivacyVersion';
import takeHeapdump from './controllers/takeHeapdump';
import setTraceGc from './controllers/setTraceGc';
import setDebugMode from './controllers/setDebugMode';
import createMsgLogAuditFile from './controllers/createMsgLogAuditFile';

const router = new Router();

router.get('/getRecentAppVersion', getRecentAppVersion);
router.get('/getRecentPrivacyVersion', getRecentPrivacyVersion);

router.post('/takeHeapdump', isLoggedIn, logApiAccess, takeHeapdump);
router.post('/setTraceGc', isLoggedIn, logApiAccess, setTraceGc);
router.post('/setDebugMode', isLoggedIn, logApiAccess, setDebugMode);

router.post('/createMsgLogAuditFile', isLoggedIn, createMsgLogAuditFile);
export default router;
