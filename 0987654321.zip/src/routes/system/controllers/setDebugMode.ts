import Koa from 'koa';

import {ecsTaskId} from '../../../server';
import {debugMode} from 'configs/server';

const setDebugMode = async (ctx: Koa.Context) => {
  try {
    const body: any = ctx.request.body;
    const {any, socket} = body;

    if (any !== undefined) {
      debugMode.any = !!any;
      console.log(`[setDebugMode]${ecsTaskId.value} : All debugMode ${!!any ? 'ON' : 'OFF'}`);
    }
    if (socket !== undefined) {
      debugMode.socket = !!socket;
      console.log(`[setDebugMode]${ecsTaskId.value} : Socket debugMode ${!!socket ? 'ON' : 'OFF'}`);
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'error': 'interneal server error',
    };
  }
};

export default setDebugMode;
