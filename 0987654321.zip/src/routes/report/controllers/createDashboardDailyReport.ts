import Koa from 'koa';

const { ObjectId } = require("mongodb");
import companyCompanyModel from 'models/company/company_company_info';
import companyGroupModel from 'models/company/company_group_info';
import userInfoModel from 'models/account/user_info';
import chattingRoomMessageModel from 'models/message/chatting_room_message';
import systemAlarmInfoModel from 'models/push/system_alarm_info';
import noteModel from 'models/note/note_info';
import dashboardDailyRecordModel from 'models/report/dashboard_daily_record';
import {USER_SIGN_INFO, USER_INFO} from 'models/collection_names';

const createDashboardDailyReport = async (tenantFlag: string) => {

  try {

    const now = new Date();
    const koreaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));

    const ONE_DAY_IN_MS = 24 * 60 * 60 * 1000;

    const CompanyGroupModel = companyGroupModel({ tenantFlag });
    const CompanyCompanyModel = companyCompanyModel({ tenantFlag });
    const UserInfoModel = userInfoModel({ tenantFlag });
    const ChattingRoomMessageModel = chattingRoomMessageModel({ tenantFlag });
    const SystemAlarmInfoModel = systemAlarmInfoModel({ tenantFlag });
    const NoteModel = noteModel({ tenantFlag });
    const DashboardDailyRecordModel = dashboardDailyRecordModel({ tenantFlag });

    const companyList = await CompanyCompanyModel.find({
        useYn: 'Y'
    })
    .populate('parentGroup', '-childCompanyIds');

    for (const company of companyList) {
      const companyGroupName = company.parentGroup.groupName.ko;
      const companyId = company._id;


      const latestReportInfo = await DashboardDailyRecordModel.aggregate([
        {
          $match: {
            "parentCompany": new ObjectId(companyId)
          }
        },
        {
          $sort: {
            "year": -1,
            "month": -1,
            "day": -1
          }
        },
        {
          $limit: 1
        },
        {
          $project: {
            _id: 0,
            year: "$year",
            month: "$month",
            day: "$day"
          }
        }
      ]);

      let startDate = 1;
      if(latestReportInfo.length > 0) {
        const latestReportDate = new Date(`${latestReportInfo[0].year}-${latestReportInfo[0].month}-${latestReportInfo[0].day}`);
        startDate = Math.floor((koreaTime.getTime() - latestReportDate.getTime()) / (ONE_DAY_IN_MS)) - 1;
      }

      for(let i = startDate; i > 0; i--) {

        const toDate = new Date(koreaTime.getFullYear(), koreaTime.getMonth(), koreaTime.getDate()).getTime() - ((i-1) * ONE_DAY_IN_MS);
        const fromDate = toDate - (ONE_DAY_IN_MS);
        const thirtyDaysAgo = toDate - (30 * ONE_DAY_IN_MS);
        const year = new Date(fromDate).getFullYear().toString();
        const month = (new Date(fromDate).getMonth() + 1).toString().padStart(2, '0');
        const day = new Date(fromDate).getDate().toString().padStart(2, '0');

        await DashboardDailyRecordModel.deleteMany({
          parentCompany: new ObjectId(companyId),
          year: year,
          month: month,
          day: day
        });

        // 등록자수 (registeredUserCounts)
        const registeredUserCounts = await UserInfoModel.countDocuments({
          parentCompany: new ObjectId(companyId),
          isDeleted: { $ne: true }
        });

        // 실사용자수 (totalUserCounts)
        const userCountInfo = await UserInfoModel.aggregate([
          {
            $match: {
              "parentCompany": new ObjectId(companyId),
              "isDeleted": { $ne: true }
            }
          },
          {
            $lookup: {
              from: `${tenantFlag}_${USER_SIGN_INFO}s`,
              localField: "_id",
              foreignField: "parentUser",
              as: "userSignInfo"
            }
          },
          {
            $unwind: "$userSignInfo"
          },
          {
            $match: {
              "userSignInfo.lastRefreshedAt": { $gte: thirtyDaysAgo }
            }
          },
          {
            $group: {
              _id: "$_id"
            }
          },
          {
            $count: "totalUserCounts"
          }
        ]);

        // 디바이스, 버전별 실사용자수 (userRecord)
        const userRecord = await UserInfoModel.aggregate([
          {
            $match: {
              "parentCompany": new ObjectId(companyId),
              "isDeleted": { $ne: true }
            }
          },
          {
            $lookup: {
              from: `${tenantFlag}_${USER_SIGN_INFO}s`,
              localField: "_id",
              foreignField: "parentUser",
              as: "userSignInfo"
            }
          },
          {
            $unwind: "$userSignInfo"
          },
          {
            $match: {
              "userSignInfo.lastRefreshedAt": { $gte: thirtyDaysAgo }
            }
          },
          {
            $group: {
              _id: { device: "$userSignInfo.deviceType", version: "$userSignInfo.versionInfo" },
              activeUserCounts: { $sum: 1 }
            }
          },
          {
            $project: {
              _id: 0,
              deviceType: {
                $cond: {
                  if: { $eq: ["$_id.device", "android"] },
                  then: "android",
                  else: {
                    $cond: {
                      if: { $eq: ["$_id.device", "ios"] },
                      then: "iOS",
                      else: "windows"
                    }
                  }
                }
              },
              versionInfo: "$_id.version",
              activeUserCounts: 1
            }
          }
        ]);

        // 채팅건수 (dailyRecord.chatCounts)
        const chatInfo = await ChattingRoomMessageModel.aggregate([
          {
            $match: {
              "createdAt": { "$gte": fromDate, "$lt": toDate }
            }
          },
          {
            $lookup: {
              from: `${tenantFlag}_${USER_INFO}s`,
              localField: "parentUser",
              foreignField: "_id",
              as: "userInfo"
            }
          },
          {
            $unwind: "$userInfo"
          },
          {
            $match: {
              "userInfo.parentCompany": new ObjectId(companyId),
            }
          },
          {
            $count: "chatCounts"
          }
        ]);

        // 시스템 알림 건수 (dailyRecord.alarmCounts, dailyRecord.pushCountRecord)
        const alarmInfo = await SystemAlarmInfoModel.aggregate([
          {
            $match: {
              parentCompany: new ObjectId(companyId),
              createdAt: {
                $gte: fromDate,
                $lte: toDate
              }
            }
          },
          { $unwind: "$receiveInfo" },
          // NON-INSTALLER 제외
          {
            $match: {
              "receiveInfo.sendDivision": { $in: ["SMS", "LMS", "FCM"] }
            }
          },
          {
            $group: {
              _id: "$receiveInfo.sendDivision",
              counts: { $sum: 1 }
            }
          },
          {
            $group: {
              _id: null,
              alarmCounts: { $sum: "$counts" },
              pushCountRecord: {
                $push: {
                  sendDivision: "$_id",
                  counts: "$counts"
                }
              }
            }
          },
          {
            $project: {
              _id: 0,
              alarmCounts: 1,
              pushCountRecord: 1
            }
          }
        ]);

        // 쪽지건수 (dailyRecord.noteCounts)
        const noteInfo = await NoteModel.aggregate([
          {
            $match: {
              "createdAt": { "$gte": fromDate, "$lt": toDate }
            }
          },
          {
            $lookup: {
              from: `${tenantFlag}_${USER_INFO}s`,
              localField: "sender",
              foreignField: "_id",
              as: "userInfo"
            }
          },
          {
            $unwind: "$userInfo"
          },
          {
            $match: {
              "userInfo.parentCompany": new ObjectId(companyId)
            }
          },
          {
            $count: "noteCounts"
          }
        ]);

        const nm = new DashboardDailyRecordModel({
          groupCode: companyGroupName,
          parentCompany: new ObjectId(companyId),
          year,
          month,
          day,
          registeredUserCounts,
          totalUserCounts: userCountInfo[0]?.totalUserCounts ?? 0,
          userRecord,
          dailyRecord: {
            chatCounts: chatInfo[0]?.chatCounts ?? 0,
            alarmCounts: alarmInfo[0]?.alarmCounts ?? 0,
            pushCountRecord: alarmInfo[0]?.pushCountRecord ?? [],
            noteCounts: noteInfo[0].noteCounts ?? 0,
          }
        });
        await nm.save();
      }
    }

    return {
      success: true,
      message: "success",
    };
  } catch (err) {
    throw err;
  }
};

export default createDashboardDailyReport;
