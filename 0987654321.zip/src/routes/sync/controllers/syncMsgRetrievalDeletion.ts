import Koa from 'koa';

import syncSummarySyncdataLogModel from 'models/log/sync_summary_syncdata_log';
import syncMsgRetrievalDeletionSchedule from './syncMsgRetrievalDeletionSchedule';

const syncMsgRetrievalDeletion = async (ctx: Koa.Context) => {
	try {
		// const userId = ctx.response.get('userId');
		// const tenantFlag = ctx.response.get('tenantFlag');
		// const verificationKey = ctx.headers['verification-key'] ?? ctx.query.verificationKey;

		if (process.env.DEVELOPMENT_MODE === 'local') {
			console.log("[syncMsgRetrievalDeletion] local");
		}
		await syncMsgRetrievalDeletionSchedule();
		ctx.status = 200;
		ctx.body = {
			'success': true,
			'code': 200,
			'message': 'invoke ok'
		};
		return;
	} catch (err) {
		ctx.status = 500;
		ctx.body = {
			'success': false,
      		'code': 500,
			'message': 'internal server error',
		};
	}
};
export default syncMsgRetrievalDeletion;