import mongoose from 'mongoose';
import pLimit from 'p-limit';

import companyCompanyModel from 'models/company/company_company_info';
import companyDepartmentModel from 'models/company/company_department_info';
import syncSummaryLogModel from 'models/log/sync_summary_log';
import syncErrorLogModel from 'models/log/sync_error_log';
import syncHeaderModel from 'models/log/sync_header_info';
import syncSummarySyncdataLogModel from 'models/log/sync_summary_syncdata_log';
import { ecsTaskId } from '../../../server';

const ObjectId = mongoose.Types.ObjectId;

const TENANT_FLAG = 'nmp';

const syncDepartmentCore = async (execDepartMap: Map<string, any>) => {
	try {
		const { unixTimestamp, formattedDate } = getFormattedKoreaTime();
		if (process.env.DEVELOPMENT_MODE === 'local') {
			console.log(`[syncDepartmentCore] - Core ---- 스케쥴을 실행한다................................... ${unixTimestamp} ::: ${formattedDate}`);

			console.log("===============================================================================================================================");
			console.log("[syncDepartmentCore] 수행정보 값들 ==============================================================================================");
			console.log("===============================================================================================================================");
			execDepartMap.forEach((value, key) => {
				if (key !== 'syncDecData') {
					console.log(`${key}: ${value}`);
				} else {
					console.log(`${key}: (syncDecData 확인 필요: 길이가 길어서 생략 가능)`);
				}
			});
			console.log("===========================================================================================================");
		}

		const syncDataId = execDepartMap.get('_id');
		const companyCode = execDepartMap.get('companyCode');
    const fileName = execDepartMap.get('syncFileName');
    const syncDecData = execDepartMap.get('syncDecData');

    if (syncDecData) {
			if (process.env.DEVELOPMENT_MODE === 'local') {
      	console.log(`[syncDepartmentCore] syncDecData 데이터 처리 중.................................`);
			}

      // 정규표현식을 사용해 데이터를 개행 단위로 분리
      const tempRows = syncDecData.split(/\r?\n/);

      // 빈 행(공백 또는 엔터만 있는 행) 제거
			const resultRows = tempRows.filter((row: string) => row.trim() !== '');

			if (resultRows.length <= 1) {
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[syncDepartmentCore][resultRows.length <= 1] ---- No Data............................!!!!!!!!!!!!!!!!!!`);
        }
      }

			if (process.env.DEVELOPMENT_MODE === 'local') {
      	console.log(`[syncDepartmentCore][resultRows.length - 1] ---- ${resultRows.length - 1}`);
			}

      const spliter = resultRows[0][12];
			if (process.env.DEVELOPMENT_MODE === 'local') {
      	console.log(`[syncDepartmentCore][spliter] -----||${spliter}||-------`);
			}

      let createSuccessCounts = 0;
      let updateSuccessCounts = 0;
      let deleteSuccessCounts = 0;
      let createErrorCounts = 0;
      let updateErrorCounts = 0;
      let deleteErrorCounts = 0;

      const targetCompanyCompanyModel = companyCompanyModel({ tenantFlag : TENANT_FLAG });
      const targetCompanyDepartmentModel = companyDepartmentModel({ tenantFlag : TENANT_FLAG });
      const targetSyncSummaryLogModel = syncSummaryLogModel({ tenantFlag : TENANT_FLAG });
      const targetSyncErrorLogModel = syncErrorLogModel({ tenantFlag : TENANT_FLAG });
      const targetSyncHeaderModel = syncHeaderModel({ tenantFlag : TENANT_FLAG });
      const targetSyncSummarySyncdataLogModel = syncSummarySyncdataLogModel({ tenantFlag : TENANT_FLAG });
			const targetUserInfo = syncHeaderModel({ tenantFlag : TENANT_FLAG });

			//========================================================================================================
			//========================================================================================================
			// 복호화된 데이터를 기반으로 위상 정렬을 사용해 재정렬하는 함수
			// PARENT_ID가 항상 먼저 존재하도록 Tree를 생성한다.
			//========================================================================================================
			//========================================================================================================
			const buildTreeAndSort = (rows: string[], spliter: string): string[] => {
				// 첫 번째 행은 헤더이므로 분리
				const header = rows[0];
				const dataRows = rows.slice(1);

				// 각 행을 객체 형태로 파싱
				const parsedRows = dataRows.map(row => {
					const cols = row.split(spliter);
					return {
						original: row,
						deptId: cols[1],     // DEPT_ID
						parentId: cols[3],   // PARENT_ID
					};
				});

				// 각 DEPT_ID를 키로 저장하는 Map
				const deptMap = new Map<string, any>();
				const inDegree = new Map<string, number>(); // 부모 참조 수 (in-degree) 기록
				const result: string[] = [];

				// Map 초기화
				parsedRows.forEach(row => {
					deptMap.set(row.deptId, row);
					inDegree.set(row.deptId, 0);
				});

				// 부모-자식 관계 설정 및 in-degree 계산
				parsedRows.forEach(row => {
					if (row.parentId && deptMap.has(row.parentId)) {
						inDegree.set(row.deptId, (inDegree.get(row.deptId) ?? 0) + 1);
					}
				});

				// in-degree가 0인 노드(최상위 부서)를 큐에 추가
				const queue: any[] = parsedRows.filter(row => (inDegree.get(row.deptId) ?? 0) === 0);

				// BFS를 사용하여 위상 정렬 수행
				while (queue.length > 0) {
					const current = queue.shift();
					result.push(current.original);

					// 자식 노드들의 in-degree 감소
					parsedRows.forEach(row => {
						if (row.parentId === current.deptId) {
							inDegree.set(row.deptId, (inDegree.get(row.deptId) ?? 0) - 1);
							if ((inDegree.get(row.deptId) ?? 0) === 0) {
								queue.push(row);
							}
						}
					});
				}

				// 헤더를 포함하여 최종 정렬된 rows 반환
				return [header, ...result];
			};

			const rows = buildTreeAndSort(resultRows, spliter);
			//========================================================================================================
			//========================================================================================================



      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      // START - 조직도 연동
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

      //조직 정보를 담는다.
			const departments = [];

			const awsEcsTaskId = ecsTaskId?.value || '';

			//통계 정보 생성.
      const summaryLog = new targetSyncSummaryLogModel({
        syncFileName: fileName,
        startedAt: new Date().getTime(),
        transDivision: 'D',
				ecsTaskId: awsEcsTaskId,
				executionDivision: "SCHEDULE",
      });

      try {
				//첫행의 COMPANY_CODE에 설정되어 있는 구분자를 전체 구분자로 설정한다. 해당 구분자로 문서의 정보들이 구분되어져 있어야 한다.
				//  으로 정하였다. <0X7f>, 추후 어떤 구분자로 해도 무방하나, 원문데이타와는 별개로 유니크해야 한다. 별도 설정될수 있다. §
				const spliter = rows[0][12];

				//헤더 문자열은 무조건 대문자로 변경한다.
        const tmpHeaderArray = rows[0].split(spliter);
        const headerString = tmpHeaderArray.map((item: string) => item.toUpperCase());
        rows[0] = headerString.join(spliter);

				//========================================================================================================
				// 헤더 정보 가져오기 ::: 헤더정보를 디비로 관리한다.
				//========================================================================================================
				let headerArray: string[] = rows[0].split(spliter); // rows의 첫 번째 행을 헤더로 사용
				let headerIndex: { [key: string]: number } = {};

				// 헤더 인덱스를 저장할 객체 생성
				headerArray.forEach((header: string, index: number) => {
					headerIndex[header] = index;
				});
				if (process.env.DEVELOPMENT_MODE === 'local') {
					console.log("headerIndex >>>>>>>>>>>>>>>>> ", headerIndex);
				}
				//========================================================================================================


 			  //========================================================================================================
				// 유효한 부서와 매핑되는 정보만 departments에 저장
				//========================================================================================================
				for (let i = 1; i < rows.length; i++) {
					const cols = rows[i].split(spliter);
					departments.push({
						companyCode: cols[headerIndex['COMPANY_CODE']],
						departmentCode: cols[headerIndex['DEPT_ID']],
						parentDepartmentCode: cols[headerIndex['PARENT_ID']] === '' ? null : cols[headerIndex['PARENT_ID']],
						departmentName: {
							ko: cols[headerIndex['DEPT_NAME']],
							en: cols[headerIndex['DEPT_NAME_EN']],
						},
						siblingOrders: cols[headerIndex['LIST_ORDER']],
						flag: cols[headerIndex['IF_FLAG']],
						siblingDepth: cols[headerIndex['LIST_DEPTH']],
						deptType: cols[headerIndex['DEPT_TYPE']],
						locationCode: cols[headerIndex['LOCATION_CODE']],
					});
				}
				//========================================================================================================

				if (process.env.DEVELOPMENT_MODE === 'local') {
					console.log("[syncDepartmentCore] rows.length 로우 갯수 :", rows.length);
					console.log("[syncDepartmentCore] departments.length 로우 갯수 :", departments.length);
				}

				//총 레코드수 - 통계정보 업데이트
				const totalCounts = departments.length;
				summaryLog.totalCounts = totalCounts;
				await summaryLog.save();

				interface DepartmentAttempt {
					depart: typeof departments[0];
					attempts: number;
				}

				const AtomicCounter = {
					processChkCount: 0,
					totalCounts: rows.length,
					incrementProcessChkCount() {
							this.processChkCount += 1;
					},
					decrementTotalCounts() {
							this.totalCounts -= 1;
					},
				};

				// 회사 정보를 캐싱하기 위한 Map
				const companyCache = new Map<string, any>();

				// 회사 정보 조회 및 캐싱 함수
				const getCompany = async (companyCode: string) => {
					if (companyCache.has(companyCode)) {
						return companyCache.get(companyCode);
					}

					const company = await targetCompanyCompanyModel.findOne({ companyCode }).select('_id');
					if (company) {
						companyCache.set(companyCode, company);
					}
					return company;
				};

				// 동시에 최대 10개의 작업만 실행
				const limit = pLimit(10);


				// 모든 작업을 동기적으로 처리 - 데이타 정합성을 위하여...속도보다는...
				for (const row of rows.slice(1)) {
					await limit(async () => {
						AtomicCounter.incrementProcessChkCount();
						AtomicCounter.decrementTotalCounts();

						const cols = row.split(spliter);
						const companyCode = cols[headerIndex['COMPANY_CODE']];
						const departmentCode = cols[headerIndex['DEPT_ID']];
						const parentDepartmentCode = cols[headerIndex['PARENT_ID']] || null;
						const flag = cols[headerIndex['IF_FLAG']];
						const deptType = cols[headerIndex['DEPT_TYPE']];

						if (deptType === 'R') return;

						// depart 객체 생성
						const depart = {
							companyCode,
							departmentCode,
							parentDepartmentCode,
							departmentName: {
								ko: cols[headerIndex['DEPT_NAME']],
								en: cols[headerIndex['DEPT_NAME_EN']],
							},
							siblingOrders: cols[headerIndex['LIST_ORDER']],
							flag,
							siblingDepth: cols[headerIndex['LIST_DEPTH']],
							deptType,
							locationCode: cols[headerIndex['LOCATION_CODE']],
						};

						try {
							const company = await getCompany(companyCode);
							if (!company) throw new Error('[syncDepartmentCore] NO_COMPANY_DATA');

							// 신규등록 및 수정
							if (flag === 'I' || flag === 'U') {
								const preData = await targetCompanyDepartmentModel.findOne({originCode: depart.departmentCode, parentCompany: company._id});

								// 신규 등록
								if (!preData) {
									let parentDepart;

									try {
										parentDepart = await targetCompanyDepartmentModel.findOne({originCode: depart.parentDepartmentCode, parentCompany: company._id});

										if (process.env.DEVELOPMENT_MODE === 'local') {
											console.log(companyCode+' [syncDepartmentCore][100.신규등록 - 정상처리] ->>>>>>>>>>>>>>>>>>>>>>>>>>>>> ',
											  AtomicCounter.processChkCount,
												AtomicCounter.totalCounts,
												totalCounts,
												depart.departmentCode,
												depart.departmentName,
												depart.parentDepartmentCode,
												company._id,
												createErrorCounts,
											);
										}

										const parentDepartments = parentDepart? [...parentDepart.parentDepartments, parentDepart._id] : [];

										const newDepart = new targetCompanyDepartmentModel({
											originCode: depart.departmentCode,
											departmentName: depart.departmentName,
											parentGroup: company.parentGroup,
											parentCompany: company._id,
											parentDepartments,
											childDepartments: [],
											childUsers: [],
											totalChildUsers: 0,
											lastModifiedAt: new Date().getTime(),
											siblingOrders: depart.siblingOrders,
											siblingDepth: depart.siblingDepth,
										});

										const updateCompany = {$inc: { totalChildDepartments: 1 }} as any;

										if (parentDepartments.length === 0) {
											updateCompany['$push'] = {childDepartments: newDepart._id};

											await newDepart.save();

											await targetCompanyCompanyModel.updateOne(
												{ _id: company._id },
												updateCompany
											);
										} else if (parentDepartments.length > 0 && parentDepartments[parentDepartments.length - 1]) {
											const pd = parentDepartments[parentDepartments.length - 1];

											await newDepart.save();

											await targetCompanyCompanyModel.updateOne(
												{ _id: company._id },
												updateCompany
											);

											await targetCompanyDepartmentModel.updateOne(
												{ _id: pd },
												{
													$push: { childDepartments: newDepart._id },
												}
											);
										}

										createSuccessCounts += 1;
									} catch (err) {
										createErrorCounts += 1;
									  if (process.env.DEVELOPMENT_MODE === 'local') {
											console.log(companyCode+' [syncDepartmentCore][199-EEE.신규등록 처리시 에러] >>>>>>>>>>>>> ',
												AtomicCounter.processChkCount,
												AtomicCounter.totalCounts,
											rows.length,
												depart.departmentCode,
												depart.departmentName,
												depart.parentDepartmentCode,
												company._id,
												createErrorCounts,
												err
											);
										}

										const errorLog = new targetSyncErrorLogModel({
											parentLog: summaryLog._id,
											originData: depart,
											error:`[syncDepartmentCore][199-EEE.신규등록 처리시 에러] >>>>>>>>> ${companyCode} , departmentCode : ${depart.departmentCode} , parentDepartmentCode : ${depart.parentDepartmentCode}, companyId: ${company._id} ::: `+err,
											createdAt: new Date().getTime(),
										});
										await errorLog.save();
									}
								}
								// 수정
								else {
									if (process.env.DEVELOPMENT_MODE === 'local') {
										console.log(companyCode+" [syncDepartmentCore][200.수정처리] >>>>> ", AtomicCounter.processChkCount, AtomicCounter.totalCounts, totalCounts, depart.parentDepartmentCode, depart.departmentCode, depart.departmentName);
									}
									try {
										const parentDepart = await targetCompanyDepartmentModel.findOne({originCode: depart.parentDepartmentCode,parentCompany: company._id});

										const parentDepartments = parentDepart ? [...parentDepart.parentDepartments, parentDepart._id] : [];

										const updateDepart = await targetCompanyDepartmentModel.findOneAndUpdate({originCode: depart.departmentCode, parentCompany: company._id}, {
											departmentName: depart.departmentName,
											parentDepartments,
											siblingOrders: depart.siblingOrders,
											siblingDepth: depart.siblingDepth,
											lastModifiedAt: new Date().getTime(),
										});

										if (JSON.stringify(parentDepartments) !== JSON.stringify(preData.parentDepartments)) {
											await targetCompanyDepartmentModel.updateOne({_id: parentDepartments[parentDepartments.length - 1]._id}, {
												$push: {
														childDepartments: preData._id,
													},
											});

											await targetCompanyDepartmentModel.updateOne({_id: preData.parentDepartments[preData.parentDepartments.length - 1]._id}, {
												$pull: {
														childDepartments: preData._id,
													},
											});
										}
										//현재 부모부서들의 정보하고, 이전 부모부서들의 정보가 같더라도 업데이트를 한다. addToSet
										else{
											await targetCompanyDepartmentModel.updateOne({_id: parentDepart._id}, {
												$addToSet: {
														childDepartments: updateDepart._id,
													},
											});
										}
										updateSuccessCounts += 1;
									} catch (err) {
										if (process.env.DEVELOPMENT_MODE === 'local') {
											console.log(companyCode+` [syncDepartmentCore][299-EEE.수정처리시 에러] Error during department update: ${depart.parentDepartmentCode} ${depart.departmentCode} ${depart.departmentName}`, err);
										}
										updateErrorCounts += 1;

										const errorLog = new targetSyncErrorLogModel({
											parentLog: summaryLog._id,
											originData: depart,
											error: `[syncDepartmentCore][299-EEE.수정처리시 에러] Error during department update: ${companyCode} ${depart.departmentCode} ${depart.parentDepartmentCode} ${depart.departmentName} ::: `+err,
											createdAt: new Date().getTime(),
										});
										await errorLog.save();
									}
								}
							}
							// 삭제
							else if (flag === 'D') {
								if (process.env.DEVELOPMENT_MODE === 'local') {
									console.log(companyCode+" [syncDepartmentCore][300.삭제처리] >>>>> ", AtomicCounter.processChkCount, AtomicCounter.totalCounts, totalCounts, depart.parentDepartmentCode, depart.departmentCode, depart.departmentName);
								}
								try {
									const d = await targetCompanyDepartmentModel.findOne({ originCode: depart.departmentCode, parentCompany: company._id }).select('_id');

									if (d && d._id) {
										//해당부서의 삭제여부(isDeleted)를 true 설정한다.
										await targetCompanyDepartmentModel.updateOne(
											{ _id: d._id },
											{ isDeleted: true }
										);

										//부서가 속해있던 회사의 childDepartments에서 해당 부서 _id를 제거한다.
										await targetCompanyDepartmentModel.updateOne(
											{ originCode: depart.parentDepartmentCode, parentCompany: company._id },
											{
												$pull: {
													childDepartments: d._id,
												},
											}
										);

										//부서가 속했던 회사의 totalChildDepartments값 업데이트
										await targetCompanyDepartmentModel.countDocuments({ parentCompany: new ObjectId(company._id), isDeleted: false })
										.then((count) =>
										targetCompanyCompanyModel.updateOne(
												{ _id: new ObjectId(company._id) },
												{ $set: { totalChildDepartments: count } }
											)
										);

										deleteSuccessCounts += 1;
									} else {
										if (process.env.DEVELOPMENT_MODE === 'local') {
											console.log(companyCode+` [syncDepartmentCore][301 - 삭제처리][삭제할 부서정보가 존재하지 않습니다. >>>>>>> ${depart.departmentCode} ${depart.parentDepartmentCode} ${company._id}`);
										}
									}
								} catch (err) {
									if (process.env.DEVELOPMENT_MODE === 'local') {
										console.log(`${err} ::: [syncDepartmentCore][399-EEE.삭제처리시 에러].....${companyCode} ${depart.departmentCode} ${depart.parentDepartmentCode} ${company._id}`);
									}
									deleteErrorCounts += 1;

								const errorLog = new targetSyncErrorLogModel({
									parentLog: summaryLog._id,
									originData: depart,
									error: `${err} ::: [syncDepartmentCore][399-EEE.삭제처리시 에러].....${companyCode} ${depart.departmentCode} ${depart.parentDepartmentCode} ${company._id}`,
									createdAt: new Date().getTime(),
								});
								await errorLog.save();
								}
							}
						} catch (err) {
							const errorLog = new targetSyncErrorLogModel({
								parentLog: summaryLog._id,
								originData: depart,
								error: err + ` ::: [syncDepartmentCore] ---- Error processing department`,
								createdAt: new Date().getTime(),
							});
							await errorLog.save();
						}
					});
				}

				//최종적으로 회사의 totalChildDepartments, totalChildUsers값을 다시 한번 총 업데이트 한다.
      	//회사의 totalChildDepartments 업데이트 - 해당 회사의 부서(nmp_company_department_infos) isDeleted = false인 갯수.
				//회사의 totalChildUsers 업데이트 - 해당 회사의 사용자(nmp_user_infos) isDeleted = false인 갯수.
				await targetCompanyCompanyModel.findOne({ companyCode: companyCode })
				.then(async (company) => {
						// totalChildDepartments 카운트
						const departmentCount = await targetCompanyDepartmentModel.countDocuments({
							parentCompany: company._id,
							isDeleted: false
						});

						// totalChildUsers 카운트
						const userCount = await targetUserInfo.countDocuments({
							parentCompany: company._id,
							isDeleted: false
						});

						// totalChildDepartments와 totalChildUsers 업데이트
						return targetCompanyCompanyModel.updateOne(
							{ _id: company._id },
							{
									$set: {
											totalChildDepartments: departmentCount,
											totalChildUsers: userCount
									}
							}
						);
				})
				.then(() => {
					if (process.env.DEVELOPMENT_MODE === 'local') {
							console.log(`${companyCode} >>> [syncDepartmentCore][900-조직도 작업마무리 완료...최종적으로 회사의 totalChildDepartments 및 totalChildUsers 값을 다시 한번 총 업데이트 완료...]`);
					}
				})
				.catch((err) => {
					if (process.env.DEVELOPMENT_MODE === 'local') {
							console.log(`${companyCode} ::: [syncDepartmentCore][900-EEE.최종적으로 회사의 totalChildDepartments 및 totalChildUsers 값 업데이트 에러].....${err}`);
					}
				});

			}catch(err){
				const errorLog = new targetSyncErrorLogModel({
					parentLog: summaryLog._id,
					originData: 'BROKEN_FILE',
					error: err,
					createdAt: new Date().getTime(),
				});
				await errorLog.save();
			}

			//통계 정보 업데이트 항목 설정
      summaryLog.endedAt = new Date().getTime();
			summaryLog.successCounts = {
				create: createSuccessCounts,
				update: updateSuccessCounts,
				delete: deleteSuccessCounts,
			};
			summaryLog.errorCounts = {
				create: createErrorCounts,
				update: updateErrorCounts,
				delete: deleteErrorCounts,
			};

			//통계 정보 업데이트
			const duration = (summaryLog.endedAt - summaryLog.startedAt) / 1000; // 초 단위 변환

			await targetSyncSummaryLogModel.updateOne(
				{ _id: summaryLog._id },
				{
					$set: {
						successCounts: summaryLog.successCounts,
						errorCounts: summaryLog.errorCounts,
						endedAt: summaryLog.endedAt,
						duration: duration,
					},
				}
			);

			//연동데이타 정보 업데이트
      await targetSyncSummarySyncdataLogModel.updateOne(
        { _id: syncDataId },
        {
          parentSummary: summaryLog._id,
          updatedAt: new Date().getTime(),
          processDivision: 'Y',
        }
      );


      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      // END - 조직도 연동
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
      //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

    } else {
			if (process.env.DEVELOPMENT_MODE === 'local') {
      	console.log("[syncDepartmentCore]................syncDecData가 존재하지 않습니다.");
			}
    }

		return {
      success: true,
    };
	} catch (err) {
		console.log(err);
    return {
      success: false,
      error: 'internal server error',
    };
	}

};

//---------------------------------------------------------------------------------------------------------
// 시간을 포맷팅하는 함수
//---------------------------------------------------------------------------------------------------------
function getFormattedKoreaTime() {
  const now = new Date();
  const unixTimestamp = now.getTime();
  const koreaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));

  const year = koreaTime.getFullYear();
  const month = String(koreaTime.getMonth() + 1).padStart(2, '0');
  const day = String(koreaTime.getDate()).padStart(2, '0');

  const hours = koreaTime.getHours();
  const minutes = String(koreaTime.getMinutes()).padStart(2, '0');
  const seconds = String(koreaTime.getSeconds()).padStart(2, '0');
  const ampm = hours >= 12 ? '오후' : '오전';
  const formattedHour = hours % 12 || 12; // 12시간제로 변환

  const formattedDate = `${year}-${month}-${day} ${ampm} ${formattedHour}:${minutes}:${seconds}`;

  return { unixTimestamp, formattedDate };
}
//---------------------------------------------------------------------------------------------------------

export default syncDepartmentCore;