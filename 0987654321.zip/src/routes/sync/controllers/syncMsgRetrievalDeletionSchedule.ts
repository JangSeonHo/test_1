import Koa from 'koa';
import mongoose from 'mongoose';

const ObjectId = mongoose.Types.ObjectId;

import schedulerLockModel from 'models/sync/scheduler_lock';
import syncSummarySyncdataLogModel from 'models/log/sync_summary_syncdata_log';


import companyInfoModel from 'models/company/company_company_info';
import companyDetailModel from 'models/company/company_detail';
import userInfoModel from 'models/account/user_info';
import chattingMessageModel from 'models/message/chatting_room_message';

import fs from 'fs';

const TENANT_FLAG = 'nmp';
const LOCK_ID = 'syncDepartmentScheduleLock';

const targetSyncSummarySyncdataLogModel = syncSummarySyncdataLogModel({ tenantFlag : TENANT_FLAG });
const targetSchedulerLockModel = schedulerLockModel({ tenantFlag: TENANT_FLAG });

const syncMsgRetrievalDeletionSchedule = async () => {
	try {
		
    // 비동기 처리
    setImmediate(async () => {
      const { unixTimestamp, formattedDate } = getFormattedKoreaTime();
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`[syncMsgRetrievalDeletionSchedule][대화 정리 처리]. ${unixTimestamp} ::: ${formattedDate}`);
      }
      // 회사별 대화 유지 기간 조회
      const targetCompanyDetailModel = companyDetailModel({tenantFlag : TENANT_FLAG  });
      const targetChattingMessageModel =  chattingMessageModel({tenantFlag : TENANT_FLAG  })

      // 회사전체 최대 대화 유지기간 조회
      const result = await targetCompanyDetailModel.aggregate([
        { $match: { msgSavePeriod : { $exists : true } } },
        {
          $group: {
            _id: null,
            maxMsgSavePeriod: { $max: "$msgSavePeriod" }
          }
        }
      ]);
      // const now = new Date(Date.now());
      // const formatted = now.toLocaleString('ko-KR', {
      //   timeZone: 'Asia/Seoul',
      //   year: 'numeric',
      //   month: '2-digit',
      //   day: '2-digit',
      //   hour: '2-digit',
      //   minute: '2-digit',
      //   second: '2-digit'
      // });
      // console.log(formatted); // 예: "2025.04.23. 15:03:07"
      // console.log("[syncMsgRetrievalDeletionSchedule] result : ", result, ", type of reulst : ", typeof result);
      let maxMsgSavePeriod = result[0]?.maxMsgSavePeriod;
      console.log("[syncMsgRetrievalDeletionSchedule] maxMsgSavePeriod : ", maxMsgSavePeriod);

      //////////////////// start : delete chattinge message result ///////////////////////////////
      if (true) { // 기능만 확인하고 일단 막아둠.
        // maxMsgSavePeriod=0;
        if (maxMsgSavePeriod < 60) {
            maxMsgSavePeriod = 60;
        }
        const criteriaDaysAgoToDelete = Date.now() - ((maxMsgSavePeriod+1) * 24 * 60 * 60 * 1000);  //
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log("[syncMsgRetrievalDeletionSchedule]# criteriaDaysAgoToDelete : "
            , criteriaDaysAgoToDelete);
        }
        // const msgDataResultCount: any = await targetChattingMessageModel.aggregate([
        //   {
        //       $match: {
        //         createdAt : {
        //            $lte: criteriaDaysAgoToDelete
        //         }
        //       }
        //   },
        //   {
        //     $count: "totalCount"
        //   }
        // ]);
        // if (process.env.DEVELOPMENT_MODE === 'local') {
        //   console.log(msgDataResultCount);
        // }
        const deletedMsgCountResult = await targetChattingMessageModel.deleteMany({
          createdAt: { $lte: criteriaDaysAgoToDelete }
        });
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[syncMsgRetrievalDeletionSchedule]########## deleted chattinge message count :  ${deletedMsgCountResult.deletedCount}`);
        }
      }
      //////////////////// end : delete chattinge message result ///////////////////////////////
      const companyDetail = await targetCompanyDetailModel.find({
          msgSavePeriod : { $exists : true, $gt : 0 },
          useYn : 'Y'
        })
        .select('msgSavePeriod')
        .populate('parentCompany', '_id companyName companyCode useYn');
      const userIdBatchSize = 500;
      for (const company of companyDetail) {
          // console.log("### company info : %s", company);
          // console.log("### companyCode: %s, companyName.ko : %s, useYn : %s", 
          //   company.parentCompany.companyCode
          //   , company.parentCompany.companyName.ko
          //   , company.parentCompany.useYn
          //   );
          // console.log("### company msgSavePeriod: ", company.msgSavePeriod);

        // if (process.env.NODE_ENV === "development") {
        // if (process.env.DEVELOPMENT_MODE === 'local') {
        //   // console.log("#### entered here");
        //   continue;
        // }
          
        // if (company.parentCompany.useYn==='Y' &&
        //     company.parentCompany.companyCode==='GUC006') {
        if (company.parentCompany.useYn==='Y') {
          // console.log("### company info : %s", company);
          // console.log("### company msgSavePeriod: ", company.msgSavePeriod);
          
          // 사용자 목록 조회.
          const userIdArr = await userInfoModel({tenantFlag : TENANT_FLAG  })
                      .find({parentCompany: company.parentCompany._id})
                      .select('_id');

          try {
            // if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log("[syncMsgRetrievalDeletionSchedule] ### START message update :: userIdArr length : ", userIdArr.length
                          , ", companyCode : ", company.parentCompany.companyCode, ", company.msgSavePeriod : ", company.msgSavePeriod);
            // }
            let totalUpdateCnt = 0;
            if (userIdArr.length > 0) {
              let idx = 0;
              for (let i = 0; i < userIdArr.length; i += userIdBatchSize) {
                const batch = userIdArr.slice(i, i + userIdBatchSize);
                // console.log("### batch index : %d, len : %d",  idx++, batch.length);
                // const results = await db.collection.find({ _id: { $in: batch } }).toArray();
                // update delete nmp_chatting_room_message, isExpired => Y 처리

                const criteriaDaysAgo = Date.now() - (company.msgSavePeriod * 24 * 60 * 60 * 1000);
                // const criteriaDaysAgo = Date.now() - (2 * 24 * 60 * 60 * 1000);
                const result = await targetChattingMessageModel
                      .updateMany(
                          { 
                            parentUser: { $in: batch } 
                            , createdAt: { $lt: criteriaDaysAgo } 
                            , $nor: [{ isExpired : true }]
                          },
                          {
                            $set: { isExpired: true }
                          }
                        );
                if (process.env.DEVELOPMENT_MODE === 'local') {
                //  console.log("[syncMsgRetrievalDeletionSchedule] ### update result matched count:", result.matchedCount);
                //  console.log("[syncMsgRetrievalDeletionSchedule] ### update result modified count:", result.modifiedCount);
                }
                totalUpdateCnt += result.modifiedCount;
                await delay(100);
              }
              console.log(`[syncMsgRetrievalDeletionSchedule] ### total update count : ${totalUpdateCnt}, \t\tcompany code : ${company.parentCompany.companyCode}`);
            }
          } catch (err1) {
            console.log(err1);
          }
        }
      }
      console.log(`[syncMsgRetrievalDeletionSchedule][대화 정리 처리]. ${unixTimestamp} ::: ${formattedDate}`);
      const data = '[syncMsgRetrievalDeletionSchedule]\n';
      const filePath = 'D:\\WorkspaceNewMessenger\\syncMsgRetrievalDeletionScheduleResult.txt';
      fs.appendFileSync(filePath, data, 'utf8');
      fs.appendFileSync(filePath, data, 'utf8');

    });
    

    function delay(ms: number) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }
		return {
			success: true,
			message: "success",
		};
	} catch (err) {
    // await targetSchedulerLockModel.deleteOne({ _id: LOCK_ID });
		console.log(err);
		return {
			success: false,
			message: 'internal server error',
		};
	}
}

//---------------------------------------------------------------------------------------------------------
// 시간을 포맷팅하는 함수
//---------------------------------------------------------------------------------------------------------
function getFormattedKoreaTime() {
  const now = new Date();
  const unixTimestamp = now.getTime();
  const koreaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));

  const year = koreaTime.getFullYear();
  const month = String(koreaTime.getMonth() + 1).padStart(2, '0');
  const day = String(koreaTime.getDate()).padStart(2, '0');

  const hours = koreaTime.getHours();
  const minutes = String(koreaTime.getMinutes()).padStart(2, '0');
  const seconds = String(koreaTime.getSeconds()).padStart(2, '0');
  const ampm = hours >= 12 ? '오후' : '오전';
  const formattedHour = hours % 12 || 12; // 12시간제로 변환

  const formattedDate = `${year}-${month}-${day} ${ampm} ${formattedHour}:${minutes}:${seconds}`;

  return { unixTimestamp, formattedDate };
}
//---------------------------------------------------------------------------------------------------------

export default syncMsgRetrievalDeletionSchedule;
