import Koa from 'koa';
import { decrypt_iv, encrypt_iv } from 'utils/cipher';
import fs from 'fs';

import syncSummarySyncdataLogModel from 'models/log/sync_summary_syncdata_log';
import encryptionKeyModel from 'models/encryption/encryption_key';

const TRANS_USER_DIVISION = "U";
const CONDITION_NO_STR = 'N';

const syncUser = async (ctx: Koa.Context, ) => {
  try{
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');
    const verificationKey = ctx.headers['verification-key'] ?? ctx.query.verificationKey;

    //========================================================================================================
    // 암복호화 키 및 iv 조회
    //========================================================================================================
    const targetEncryptionKeyModel = encryptionKeyModel({tenantFlag});
    const key = await targetEncryptionKeyModel.findOne({ tenantFlag: tenantFlag });
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("[syncUser][DB 조회 - enc key 및 iv] :::::::::::::::::::::: ", key);
    }

    let paramEncKey;
    let paramIv;

    // encryptionKey와 lv 값이 있는지 확인
    if (key && key.encryptionKey && key.iv) {
      paramEncKey = key.encryptionKey;
      paramIv = key.iv;
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("[syncUser] paramEncKey >>>>>>>>>>>> ", paramEncKey);
        console.log("[syncUser] paramIv >>>>>>>>>>>> ", paramIv);
      }
    } else {
      paramEncKey = '';
      paramIv = '';
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log("[syncUser] Encryption key 또는 iv 값을 찾을 수 없습니다.");
      }
    }
    //========================================================================================================


    //========================================================================================================
    // API 호출 권한 체크 - 암호화키의 앞부분 5자리, 뒷부분5자리를 뺀 나머지 정보를 가지고 비교한다.
    //========================================================================================================
    if(verificationKey != paramEncKey.slice(5,-5)){
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'code': 403,
        'message': 'permission denied',
      };
      return;
    }
    //========================================================================================================


    const targetSyncSummarySyncdataLogModel = syncSummarySyncdataLogModel({ tenantFlag });

    let { flag, data, fileName, companyCode } = ctx.request.body as any;


    //========================================================================================================
    // 복호화
    //========================================================================================================
    let decoded: string;

    try {
      decoded = decrypt_iv(data, paramEncKey, paramIv);
    } catch (err) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'code': 400,
        'message': 'BROKEN_DATA',
      };
      return;
    }
    //========================================================================================================


    //개행처리를 정규표현식으로 처리한다. \r이 있을수도 없을수도 있다.
    const rows = decoded.split(/\r?\n/);


    //해당 조건의 정보가 있으면, 업데이트를 하고 없으면 신규등록을 한다.
    const existingLog = await targetSyncSummarySyncdataLogModel.findOne({
      transDivision : TRANS_USER_DIVISION,
      companyCode: companyCode,
      syncFileName: fileName,
      processDivision: CONDITION_NO_STR,
    });

    const MAX_SIZE_MB = 14; // 최대 크기 14MB
    const MAX_SIZE_BYTES = MAX_SIZE_MB * 1024 * 1024; // 바이트로 변환

    // data와 decoded의 데이터 크기 계산
    const dataSize = Buffer.byteLength(data, 'utf-8'); // 데이터 크기 계산 (UTF-8 기준)
    const decodedSize = Buffer.byteLength(decoded, 'utf-8');
    const totalSize = dataSize + decodedSize;

    // 데이터 크기 초과 여부 확인
    if (totalSize > MAX_SIZE_BYTES) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`데이타 양이 16MB가 넘어감.>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>`);
      }
      data = '16MB가 넘어가므로 데이터 저장 안됨';
      decoded = '16MB가 넘어가므로 데이터 저장 안됨';
    }

    if(existingLog){
      existingLog.syncEncData = data;
      existingLog.syncDecData = decoded;
      existingLog.totalCount = rows.length - 1;
      existingLog.updatedAt = new Date().getTime();
      await existingLog.save();
    }else{
      const summarySyncdataLog = new targetSyncSummarySyncdataLogModel({
        createdAt: new Date().getTime(),
        syncEncData: data,
        syncDecData: decoded,
        transDivision: TRANS_USER_DIVISION,
        processDivision: CONDITION_NO_STR,
        totalCount: rows.length - 1,
        syncFileName: fileName,
        companyCode: companyCode,
      });
      await summarySyncdataLog.save();
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'code': 200,
      'message': 'Data was transmitted successfully. Please contact the administrator for the results.',
    };

  }catch(err){
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'code': 500,
      'message': 'internal server error',
    };
  }
};

export default syncUser;