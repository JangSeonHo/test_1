import Koa from 'koa';
import { decrypt_iv, encrypt_iv } from 'utils/cipher';
import mongoose from 'mongoose';
import pLimit from 'p-limit';
import { ecsTaskId } from '../../../server';

const ObjectId = mongoose.Types.ObjectId;

import companyCompanyModel from 'models/company/company_company_info';
import companyDepartmentModel from 'models/company/company_department_info';
import syncSummaryLogModel from 'models/log/sync_summary_log';
import syncErrorLogModel from 'models/log/sync_error_log';
import syncHeaderModel from 'models/log/sync_header_info';
import syncSummarySyncdataLogModel from 'models/log/sync_summary_syncdata_log';
import userSchema from 'models/account/user_info';
import {json} from 'express';
import encryptionKeyModel from 'models/encryption/encryption_key';

const syncDepartment = async (ctx: Koa.Context) => {
	try {
		const userId = ctx.response.get('userId');
		const tenantFlag = ctx.response.get('tenantFlag');
		const verificationKey = ctx.headers['verification-key'] ?? ctx.query.verificationKey;

		const { unixTimestamp, formattedDate } = getFormattedKoreaTime();
    let tempStartedAt = unixTimestamp;
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("[syncUserNew][tempStartedAt][formattedDate] :::::::::::::::::::::: ", tempStartedAt, formattedDate);
    }

		//========================================================================================================
		// 암복호화 키 및 IV 조회
		//========================================================================================================
		const targetEncryptionKeyModel = encryptionKeyModel({tenantFlag});
		const key = await targetEncryptionKeyModel.findOne({ tenantFlag: tenantFlag });

		if (process.env.DEVELOPMENT_MODE === 'local') {
			console.log("[syncDepartmentNew][DB 조회 - enc key 및 IV] :::::::::::::::::::::: ", key);
		}

		let paramEncKey;
		let paramIv;

		// encryptionKey와 IV 값이 있는지 확인
		if (key && key.encryptionKey && key.iv) {
			paramEncKey = key.encryptionKey;
			paramIv = key.iv;
			if (process.env.DEVELOPMENT_MODE === 'local') {
				console.log("[syncDepartmentNew] paramEncKey >>>>>>>>>>>> ", paramEncKey);
				console.log("[syncDepartmentNew] paramIv >>>>>>>>>>>> ", paramIv);
			}
		} else {
			paramEncKey = '';
			paramIv = '';
			if (process.env.DEVELOPMENT_MODE === 'local') {
				console.log("[syncDepartmentNew] Encryption key 또는 iv 값을 찾을 수 없습니다.");
			}
		}
    //========================================================================================================



		//========================================================================================================
		// API 호출 권한 체크 - 암호화키의 앞부분 5자리, 뒷부분5자리를 뺀 나머지 정보를 가지고 비교한다.
		//========================================================================================================
		if (process.env.DEVELOPMENT_MODE === 'local') {
			console.log('[syncDepartmentNew] 3KJTKTKDLXTBE1MK25AY3I');
			console.log("[syncDepartmentNew] verificationKey >>> ",verificationKey);
			console.log("[syncDepartmentNew] paramEncKey.slice(5,-5) >>> ", paramEncKey.slice(5,-5));
		}

		if(verificationKey != paramEncKey.slice(5,-5)){
			ctx.status = 403;
			ctx.body = {
				'success': false,
				'code': 403,
				'message': 'permission denied',
			};
			return;
		}
		//========================================================================================================

		let createSuccessCounts = 0;
		let updateSuccessCounts = 0;
		let deleteSuccessCounts = 0;
		let createErrorCounts = 0;
		let updateErrorCounts = 0;
		let deleteErrorCounts = 0;


		const targetCompanyCompanyModel = companyCompanyModel({ tenantFlag });
		const targetCompanyDepartmentModel = companyDepartmentModel({ tenantFlag });
		const targetSyncSummaryLogModel = syncSummaryLogModel({ tenantFlag });
		const targetSyncErrorLogModel = syncErrorLogModel({ tenantFlag });
		const targetSyncHeaderModel = syncHeaderModel({ tenantFlag });
		const targetSyncSummarySyncdataLogModel = syncSummarySyncdataLogModel({ tenantFlag });
		const targetUserInfo = userSchema({tenantFlag});

		let { flag, data, fileName, companyCode } = ctx.request.body as any;

		const awsEcsTaskId = ecsTaskId?.value || '';

		const summaryLog = new targetSyncSummaryLogModel({
			syncFileName: fileName,
			startedAt: tempStartedAt,
			transDivision: 'D',
			ecsTaskId: awsEcsTaskId,
			executionDivision: "MANUAL_IF",
		});


		//========================================================================================================
		// 복호화
		//========================================================================================================
		let decoded: string;

		try {
			decoded = decrypt_iv(data, paramEncKey, paramIv);
		} catch (err) {
      ctx.status = 400;
       ctx.body = {
        'success': false,
        'code': 400,
				'message': 'BROKEN_DATA',
      };
      return;
		}
		//========================================================================================================



		// 개행처리를 정규표현식으로 처리한다. \r이 있을수도 없을수도 있다.
		const tempRows = decoded.split(/\r?\n/);

		// 빈 행(공백 또는 엔터만 있는 행) 제거
		const resultRows = tempRows.filter((row: string) => row.trim() !== '');

		if (resultRows.length <= 1) {
			ctx.status = 400;
			ctx.body = {
				success: false,
				code: 400,
				message: 'EMPTY_FILE_OR_NO_VALID_DATA',
			};
			return;
		}


		//========================================================================================================
		//========================================================================================================
		// 복호화된 데이터를 기반으로 위상 정렬을 사용해 재정렬하는 함수
		// PARENT_ID가 항상 먼저 존재하도록 Tree를 생성한다.
		//========================================================================================================
		//========================================================================================================
		const buildTreeAndSort = (rows: string[], spliter: string): string[] => {
			// 첫 번째 행은 헤더이므로 분리
			const header = rows[0];
			const dataRows = rows.slice(1);

			// 각 행을 객체 형태로 파싱
			const parsedRows = dataRows.map(row => {
				const cols = row.split(spliter);
				return {
					original: row,
					deptId: cols[1],     // DEPT_ID
					parentId: cols[3],   // PARENT_ID
				};
			});

			// 각 DEPT_ID를 키로 저장하는 Map
			const deptMap = new Map<string, any>();
			const inDegree = new Map<string, number>(); // 부모 참조 수 (in-degree) 기록
			const result: string[] = [];

			// Map 초기화
			parsedRows.forEach(row => {
				deptMap.set(row.deptId, row);
				inDegree.set(row.deptId, 0);
			});

			// 부모-자식 관계 설정 및 in-degree 계산
			parsedRows.forEach(row => {
				if (row.parentId && deptMap.has(row.parentId)) {
					inDegree.set(row.deptId, (inDegree.get(row.deptId) ?? 0) + 1);
				}
			});

			// in-degree가 0인 노드(최상위 부서)를 큐에 추가
			const queue: any[] = parsedRows.filter(row => (inDegree.get(row.deptId) ?? 0) === 0);

			// BFS를 사용하여 위상 정렬 수행
			while (queue.length > 0) {
				const current = queue.shift();
				result.push(current.original);

				// 자식 노드들의 in-degree 감소
				parsedRows.forEach(row => {
					if (row.parentId === current.deptId) {
						inDegree.set(row.deptId, (inDegree.get(row.deptId) ?? 0) - 1);
						if ((inDegree.get(row.deptId) ?? 0) === 0) {
							queue.push(row);
						}
					}
				});
			}

			// 헤더를 포함하여 최종 정렬된 rows 반환
			return [header, ...result];
		};

		const spliter = resultRows[0][12]; // 구분자 추출
		const rows = buildTreeAndSort(resultRows, spliter);
		//========================================================================================================
    //========================================================================================================


		const MAX_SIZE_MB = 14; // 최대 크기 14MB
    const MAX_SIZE_BYTES = MAX_SIZE_MB * 1024 * 1024; // 바이트로 변환

    // data와 decoded의 데이터 크기 계산
    const dataSize = Buffer.byteLength(data, 'utf-8'); // 데이터 크기 계산 (UTF-8 기준)
    const decodedSize = Buffer.byteLength(decoded, 'utf-8');
    const totalSize = dataSize + decodedSize;

    // 데이터 크기 초과 여부 확인
    if (totalSize > MAX_SIZE_BYTES) {
      if (process.env.DEVELOPMENT_MODE === 'local') {
        console.log(`데이타 양이 16MB가 넘어감.>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>`);
      }
      data = '16MB가 넘어가므로 데이터 저장 안됨';
      decoded = '16MB가 넘어가므로 데이터 저장 안됨';
    }

		const summarySyncdataLog = new targetSyncSummarySyncdataLogModel({
			createdAt: new Date().getTime(),
			syncEncData: data,
			syncDecData: decoded,
			transDivision: 'D',
			companyCode: companyCode,
			totalCount: rows.length - 1,
			processDivision: 'Y',
			syncFileName: fileName,
		});

		summarySyncdataLog.parentSummary = summaryLog._id;
		await summarySyncdataLog.save();

		ctx.status = 200;
		ctx.body = {
			'success': true,
			'code': 200,
			'message': 'Data was transmitted successfully. Please contact the administrator for the results.',
		};


		// 동시에 최대 10개의 작업만 실행
		const limit = pLimit(10);

		// 비동기로 나머지 로직을 처리
		setImmediate(async () => {
			const departments = [];

			//프로세스 체크 카운트
			let processChkCount = 0;

			//프로세스 에러체크 카운트
			let processErrorChkCount = 0;

			let createSuccessCounts = 0;
			let updateSuccessCounts = 0;
			let deleteSuccessCounts = 0;
			let createErrorCounts = 0;
			let updateErrorCounts = 0;
			let deleteErrorCounts = 0;

			try {
				const spliter = rows[0][12];

				//헤더 문자열은 무조건 대문자로 변경한다.
        const tmpHeaderArray = rows[0].split(spliter);
        const headerString = tmpHeaderArray.map((item: string) => item.toUpperCase());
        rows[0] = headerString.join(spliter);


				//========================================================================================================
				// 헤더 정보 가져오기 ::: 헤더정보를 디비로 관리한다.
				//========================================================================================================
				const headerArray = rows[0].split(spliter).map(item => item.toUpperCase());
				rows[0] = headerArray.join(spliter);

				const headerIndex: { [key: string]: number } = {};
				headerArray.forEach((header: string, index: number) => {
					headerIndex[header] = index;
				});
				if (process.env.DEVELOPMENT_MODE === 'local') {
					console.log("[syncDepartmentNew] headerIndex >>>>>>>>>>>>>>>>> ", headerIndex);
				}
				//========================================================================================================


				//========================================================================================================
				// 유효한 부서와 매핑되는 정보만 departments에 저장
				//========================================================================================================
				for (let i = 1; i < rows.length; i++) {
					const cols = rows[i].split(spliter);
					departments.push({
						companyCode: cols[headerIndex['COMPANY_CODE']],
						departmentCode: cols[headerIndex['DEPT_ID']],
						parentDepartmentCode: cols[headerIndex['PARENT_ID']] === '' ? null : cols[headerIndex['PARENT_ID']],
						departmentName: {
							ko: cols[headerIndex['DEPT_NAME']],
							en: cols[headerIndex['DEPT_NAME_EN']],
						},
						siblingOrders: cols[headerIndex['LIST_ORDER']],
						flag: cols[headerIndex['IF_FLAG']],
						siblingDepth: cols[headerIndex['LIST_DEPTH']],
						deptType: cols[headerIndex['DEPT_TYPE']],
						locationCode: cols[headerIndex['LOCATION_CODE']],
					});
				}
				//========================================================================================================

				if (process.env.DEVELOPMENT_MODE === 'local') {
					console.log("[syncDepartmentNew] rows.length 로우 갯수 :", rows.length);
					console.log("[syncDepartmentNew] departments.length 로우 갯수 :", departments.length);
				}

				const totalCounts = departments.length;
				summaryLog.totalCounts = totalCounts;
				await summaryLog.save();

				interface DepartmentAttempt {
					depart: typeof departments[0];
					attempts: number;
				}


				const AtomicCounter = {
					processChkCount: 0,
					totalCounts: rows.length,
					incrementProcessChkCount() {
							this.processChkCount += 1;
					},
					decrementTotalCounts() {
							this.totalCounts -= 1;
					},
				};

				// 회사 정보를 캐싱하기 위한 Map
				const companyCache = new Map<string, any>();

				// 회사 정보 조회 및 캐싱 함수
				const getCompany = async (companyCode: string) => {
					if (companyCache.has(companyCode)) {
						return companyCache.get(companyCode);
					}

					const company = await targetCompanyCompanyModel.findOne({ companyCode }).select('_id');
					if (company) {
						companyCache.set(companyCode, company);
					}
					return company;
				};


				// 모든 작업을 동기적으로 처리 - 데이타 정합성을 위하여...속도보다는...
				for (const row of rows.slice(1)) {
					await limit(async () => {
						AtomicCounter.incrementProcessChkCount();
						AtomicCounter.decrementTotalCounts();

						const cols = row.split(spliter);
						const companyCode = cols[headerIndex['COMPANY_CODE']];
						const departmentCode = cols[headerIndex['DEPT_ID']];
						const parentDepartmentCode = cols[headerIndex['PARENT_ID']] || null;
						const flag = cols[headerIndex['IF_FLAG']];
						const deptType = cols[headerIndex['DEPT_TYPE']];

						if (deptType === 'R') return;

						// depart 객체 생성
						const depart = {
							companyCode,
							departmentCode,
							parentDepartmentCode,
							departmentName: {
								ko: cols[headerIndex['DEPT_NAME']],
								en: cols[headerIndex['DEPT_NAME_EN']],
							},
							siblingOrders: cols[headerIndex['LIST_ORDER']],
							flag,
							siblingDepth: cols[headerIndex['LIST_DEPTH']],
							deptType,
							locationCode: cols[headerIndex['LOCATION_CODE']],
						};

						try {
							const company = await getCompany(companyCode);
							if (!company) throw new Error('[syncDepartmentNew] NO_COMPANY_DATA');

							// 신규등록 및 수정
							if (flag === 'I' || flag === 'U') {
								const preData = await targetCompanyDepartmentModel.findOne({originCode: depart.departmentCode, parentCompany: company._id});

								// 신규 등록
								if (!preData) {
									let parentDepart;

									try {
										parentDepart = await targetCompanyDepartmentModel.findOne({originCode: depart.parentDepartmentCode, parentCompany: company._id});

										if (process.env.DEVELOPMENT_MODE === 'local') {
											console.log(companyCode+' [syncDepartmentNew][100.신규등록 - 정상처리] ->>>>>>>>>>>>>>>>>>>>>>>>>>>>> ',
											  AtomicCounter.processChkCount,
												AtomicCounter.totalCounts,
												totalCounts,
												depart.departmentCode,
												depart.departmentName,
												depart.parentDepartmentCode,
												company._id,
												createErrorCounts,
											);
										}

										const parentDepartments = parentDepart? [...parentDepart.parentDepartments, parentDepart._id] : [];

										const newDepart = new targetCompanyDepartmentModel({
											originCode: depart.departmentCode,
											departmentName: depart.departmentName,
											parentGroup: company.parentGroup,
											parentCompany: company._id,
											parentDepartments,
											childDepartments: [],
											childUsers: [],
											totalChildUsers: 0,
											lastModifiedAt: new Date().getTime(),
											siblingOrders: depart.siblingOrders,
											siblingDepth: depart.siblingDepth,
										});

										const updateCompany = {$inc: { totalChildDepartments: 1 }} as any;

										if (parentDepartments.length === 0) {
											updateCompany['$push'] = {childDepartments: newDepart._id};

											await newDepart.save();

											await targetCompanyCompanyModel.updateOne(
												{ _id: company._id },
												updateCompany
											);
										} else if (parentDepartments.length > 0 && parentDepartments[parentDepartments.length - 1]) {
											const pd = parentDepartments[parentDepartments.length - 1];

											await newDepart.save();

											await targetCompanyCompanyModel.updateOne(
												{ _id: company._id },
												updateCompany
											);

											await targetCompanyDepartmentModel.updateOne(
												{ _id: pd },
												{
													$push: { childDepartments: newDepart._id },
												}
											);
										}

										createSuccessCounts += 1;
									} catch (err) {
										createErrorCounts += 1;
									  if (process.env.DEVELOPMENT_MODE === 'local') {
											console.log(companyCode+' [syncDepartmentNew][199-EEE.신규등록 처리시 에러] >>>>>>>>>>>>> ',
												AtomicCounter.processChkCount,
												AtomicCounter.totalCounts,
												rows.length,
												depart.departmentCode,
												depart.departmentName,
												depart.parentDepartmentCode,
												company._id,
												createErrorCounts,
												err
											);
										}

										const errorLog = new targetSyncErrorLogModel({
											parentLog: summaryLog._id,
											originData: depart,
											error:`[syncDepartmentNew][199-EEE.신규등록 처리시 에러] >>>>>>>>> ${companyCode} , departmentCode : ${depart.departmentCode} , parentDepartmentCode : ${depart.parentDepartmentCode}, companyId: ${company._id} ::: `+err,
											createdAt: new Date().getTime(),
										});
										await errorLog.save();
									}
								}
								// 수정
								else {
									if (process.env.DEVELOPMENT_MODE === 'local') {
										console.log(companyCode+" [syncDepartmentNew][200.수정처리] >>>>> ", AtomicCounter.processChkCount, AtomicCounter.totalCounts, totalCounts, depart.parentDepartmentCode, depart.departmentCode, depart.departmentName);
									}
									try {
										const parentDepart = await targetCompanyDepartmentModel.findOne({originCode: depart.parentDepartmentCode,parentCompany: company._id});

										const parentDepartments = parentDepart ? [...parentDepart.parentDepartments, parentDepart._id] : [];

										const updateDepart = await targetCompanyDepartmentModel.findOneAndUpdate({originCode: depart.departmentCode, parentCompany: company._id}, {
											departmentName: depart.departmentName,
											parentDepartments,
											siblingOrders: depart.siblingOrders,
											siblingDepth: depart.siblingDepth,
											lastModifiedAt: new Date().getTime(),
											isDeleted: false,
										});

										if (JSON.stringify(parentDepartments) !== JSON.stringify(preData.parentDepartments)) {
											await targetCompanyDepartmentModel.updateOne({_id: parentDepartments[parentDepartments.length - 1]._id}, {
												$push: {
														childDepartments: preData._id,
													},
											});

											await targetCompanyDepartmentModel.updateOne({_id: preData.parentDepartments[preData.parentDepartments.length - 1]._id}, {
												$pull: {
														childDepartments: preData._id,
													},
											});
										}
										//현재 부모부서들의 정보하고, 이전 부모부서들의 정보가 같더라도 업데이트를 한다. addToSet
										else{
											await targetCompanyDepartmentModel.updateOne({_id: parentDepart._id}, {
												$addToSet: {
														childDepartments: updateDepart._id,
													},
											});
										}
										updateSuccessCounts += 1;
									} catch (err) {
										if (process.env.DEVELOPMENT_MODE === 'local') {
											console.log(companyCode+` [syncDepartmentNew][299-EEE.수정처리시 에러] Error during department update: ${depart.parentDepartmentCode} ${depart.departmentCode} ${depart.departmentName}`, err);
										}
										updateErrorCounts += 1;

										const errorLog = new targetSyncErrorLogModel({
											parentLog: summaryLog._id,
											originData: depart,
											error: `[syncDepartmentNew][299-EEE.수정처리시 에러] Error during department update: ${companyCode} ${depart.departmentCode} ${depart.parentDepartmentCode} ${depart.departmentName} ::: `+err,
											createdAt: new Date().getTime(),
										});
										await errorLog.save();
									}
								}
							}
							// 삭제
							else if (flag === 'D') {
								if (process.env.DEVELOPMENT_MODE === 'local') {
									console.log(companyCode+" [syncDepartmentNew][300.삭제처리] >>>>> ", AtomicCounter.processChkCount, AtomicCounter.totalCounts, totalCounts, depart.parentDepartmentCode, depart.departmentCode, depart.departmentName);
								}
								try {
									const d = await targetCompanyDepartmentModel.findOne({ originCode: depart.departmentCode, parentCompany: company._id }).select('_id');

									if (d && d._id) {
										//해당부서의 삭제여부(isDeleted)를 true 설정한다.
										await targetCompanyDepartmentModel.updateOne(
											{ _id: d._id },
											{ isDeleted: true }
										);

										//부서가 속해있던 회사의 childDepartments에서 해당 부서 _id를 제거한다.
										await targetCompanyDepartmentModel.updateOne(
											{ originCode: depart.parentDepartmentCode, parentCompany: company._id },
											{
												$pull: {
													childDepartments: d._id,
												},
											}
										);

										//부서가 속했던 회사의 totalChildDepartments값 업데이트
										await targetCompanyDepartmentModel.countDocuments({ parentCompany: new ObjectId(company._id), isDeleted: false })
										.then((count) =>
										targetCompanyCompanyModel.updateOne(
												{ _id: new ObjectId(company._id) },
												{ $set: { totalChildDepartments: count } }
											)
										);

										deleteSuccessCounts += 1;
									} else {
										if (process.env.DEVELOPMENT_MODE === 'local') {
											console.log(companyCode+` [syncDepartmentNew][301 - 삭제처리][삭제할 부서정보가 존재하지 않습니다. >>>>>>> ${depart.departmentCode} ${depart.parentDepartmentCode} ${company._id}`);
										}
									}
								} catch (err) {
									if (process.env.DEVELOPMENT_MODE === 'local') {
										console.log(`${err} ::: [syncDepartmentNew][399-EEE.삭제처리시 에러].....${companyCode} ${depart.departmentCode} ${depart.parentDepartmentCode} ${company._id}`);
									}
									deleteErrorCounts += 1;

								const errorLog = new targetSyncErrorLogModel({
									parentLog: summaryLog._id,
									originData: depart,
									error: `${err} ::: [syncDepartmentNew][399-EEE.삭제처리시 에러].....${companyCode} ${depart.departmentCode} ${depart.parentDepartmentCode} ${company._id}`,
									createdAt: new Date().getTime(),
								});
								await errorLog.save();
								}
							}
						} catch (err) {
							const errorLog = new targetSyncErrorLogModel({
								parentLog: summaryLog._id,
								originData: depart,
								error: err + ` ::: [syncDepartmentNew] ---- Error processing department`,
								createdAt: new Date().getTime(),
							});
							await errorLog.save();
						}
					});
				}

				//최종적으로 회사의 totalChildDepartments, totalChildUsers값을 다시 한번 총 업데이트 한다.
      	//회사의 totalChildDepartments 업데이트 - 해당 회사의 부서(nmp_company_department_infos) isDeleted = false인 갯수.
				//회사의 totalChildUsers 업데이트 - 해당 회사의 사용자(nmp_user_infos) isDeleted = false인 갯수.
				await targetCompanyCompanyModel.findOne({ companyCode: companyCode })
				.then(async (company) => {
						// totalChildDepartments 카운트
						const departmentCount = await targetCompanyDepartmentModel.countDocuments({
							parentCompany: company._id,
							isDeleted: false
						});

						// totalChildUsers 카운트
						const userCount = await targetUserInfo.countDocuments({
							parentCompany: company._id,
							isDeleted: false
						});

						// totalChildDepartments와 totalChildUsers 업데이트
						return targetCompanyCompanyModel.updateOne(
							{ _id: company._id },
							{
									$set: {
											totalChildDepartments: departmentCount,
											totalChildUsers: userCount
									}
							}
						);
				})
				.then(() => {
					if (process.env.DEVELOPMENT_MODE === 'local') {
							console.log(`${companyCode} >>> [syncDepartmentNew][900-조직도 작업마무리 완료...최종적으로 회사의 totalChildDepartments 및 totalChildUsers 값을 다시 한번 총 업데이트 완료...]`);
					}
				})
				.catch((err) => {
					if (process.env.DEVELOPMENT_MODE === 'local') {
							console.log(`${companyCode} ::: [syncDepartmentNew][900-EEE.최종적으로 회사의 totalChildDepartments 및 totalChildUsers 값 업데이트 에러].....${err}`);
					}
				});

			} catch (err) {
				const errorLog = new targetSyncErrorLogModel({
					parentLog: summaryLog._id,
					originData: 'BROKEN_FILE',
					error: err,
					createdAt: new Date().getTime(),
				});
				await errorLog.save();
			}

			// 로그 요약 저장
			summaryLog.endedAt = new Date().getTime();
			summaryLog.successCounts = {
				create: createSuccessCounts,
				update: updateSuccessCounts,
				delete: deleteSuccessCounts,
			};
			summaryLog.errorCounts = {
				create: createErrorCounts,
				update: updateErrorCounts,
				delete: deleteErrorCounts,
			};

			const duration = (summaryLog.endedAt - summaryLog.startedAt) / 1000; // 초 단위 변환

			await targetSyncSummaryLogModel.updateOne(
				{ _id: summaryLog._id },
				{
					$set: {
						successCounts: summaryLog.successCounts,
						errorCounts: summaryLog.errorCounts,
						endedAt: summaryLog.endedAt,
						duration: duration,
					},
				}
			);
		});

	} catch (err) {
		ctx.status = 500;
		ctx.body = {
			'success': false,
      		'code': 500,
			'message': 'internal server error',
		};
	}

};


//--------------------------------------------------------------------------------------------------
// 시간을 포맷팅하는 함수
//--------------------------------------------------------------------------------------------------
function getFormattedKoreaTime() {
  const now = new Date();
  const unixTimestamp = now.getTime();
  const koreaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Seoul" }));

  const year = koreaTime.getFullYear();
  const month = String(koreaTime.getMonth() + 1).padStart(2, '0');
  const day = String(koreaTime.getDate()).padStart(2, '0');

  const hours = koreaTime.getHours();
  const minutes = String(koreaTime.getMinutes()).padStart(2, '0');
  const seconds = String(koreaTime.getSeconds()).padStart(2, '0');
  const ampm = hours >= 12 ? '오후' : '오전';
  const formattedHour = hours % 12 || 12;

  const formattedDate = `${year}-${month}-${day} ${ampm} ${formattedHour}:${minutes}:${seconds}`;
  return { unixTimestamp, formattedDate };
}

export default syncDepartment;