/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import {Types} from 'mongoose';

const searchUsersFromCompany = async (ctx: Koa.Context) => {
  try {
    const {keyword, page = 1, itemsPerPage = 999, includeMe = 'Y', companyId} = ctx.query;

    if (!keyword || keyword.length === 0) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Bad Request',
      };
    }

    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    // compile before populate
    userStatusInfoModel({tenantFlag});
    //

    const requestPage = Number(page);
    const requestItemsPerPage = Number(itemsPerPage);

    const targetModel = userInfoModel({tenantFlag});

    const query: any = {
      'isDeleted': false,
      'parentCompany': companyId,
      '$or': [
        {
          'userName.ko': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'userName.en': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'email': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'personalPhoneNumber': {
            $regex: keyword, $options: 'i',
          },
        },
        {
          'officePhoneNumber': {
            $regex: keyword, $options: 'i',
          },
        },
      ],
    };

    if (includeMe !== 'Y') {
      query['_id'] = {$ne: new Types.ObjectId(userId)};
    }

    const users = await targetModel.find(query)
      .skip((requestPage - 1) * requestItemsPerPage)
      .limit(requestItemsPerPage)
      .select('userName jobTitle email personalPhoneNumber officePhoneNumber profileImage childStatusInfo useMessenger parentCompany parentDepartment role')
      .lean()
      .populate('parentCompany', 'companyName _id')
      .populate('parentDepartment', 'departmentName _id')
      .populate('childStatusInfo', '-_id -_v');

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        users: includeMe === 'Y' ?
          users :
          users.filter((_id) => _id.toString() !== userId),
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default searchUsersFromCompany;
