/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import departmentModel from 'models/company/company_department_info';

import noteInfoModel from 'models/note/note_info';
import noteMemberModel from 'models/note/note_member';
import bookedNoteModel from 'models/note/booked_note';

const searchNotesByKeyword = async (ctx: Koa.Context) => {
  try {
    const {type, keyword, page = 1, itemsPerPage = 20} = ctx.query as any;

    if (type !== 'B' && type !== 'S' && type !== 'R') {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Bad Request',
      };
    }

    const decodedKeyword = decodeURI(keyword);
    if (!decodedKeyword || decodedKeyword.length === 0) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'Bad Request',
      };
    }

    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    // population
    userInfoModel({tenantFlag});
    departmentModel({tenantFlag});
    //

    const requestPage = Number(page);
    // const requestItemsPerPage = Number(itemsPerPage);
    const requestItemsPerPage = 999;

    const orQuery: any = [
      {
        'title': {
          $regex: decodedKeyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i',
        },
      },
      {
        'content': {
          $regex: decodedKeyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i',
        },
      },
    ];

    if (type === 'R') {
      orQuery.push({
        'senderUserName.ko': {
          $regex: decodedKeyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i',
        },
      });
      orQuery.push({
        'senderUserName.en': {
          $regex: decodedKeyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i',
        },
      });
    } else {
      orQuery.push({
        'receiverUserNames.ko': {
          $regex: decodedKeyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i',
        },
      });
      orQuery.push({
        'receiverUserNames.en': {
          $regex: decodedKeyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i',
        },
      });
    }

    const commonQuery: any = {
      '$or': orQuery,
    };

    const notePopulate: Array<any> = [
      {
        path: 'sender',
        select: '_id userName jobTitle parentDepartment profileImage parentCompany',
        populate: [{
          path: 'parentDepartment',
          select: 'departmentName',
        }, {
          path: 'parentCompany',
          select: 'companyName',
        }],
      },
    ];

    if (type === 'B') {
      commonQuery['sender'] = userId;
      notePopulate.push({
        path: 'receivers',
        select: '_id userName jobTitle parentDepartment profileImage parentCompany',
        populate: [{
          path: 'parentDepartment',
          select: 'departmentName',
        }, {
          path: 'parentCompany',
          select: 'companyName',
        }],
      });

      const notes = await bookedNoteModel({tenantFlag}).find(commonQuery)
        .sort({createdAt: 'desc'})
        .skip((requestPage - 1) * requestItemsPerPage)
        .limit(requestItemsPerPage)
        .populate(notePopulate);

      ctx.status = 200;
      ctx.body = {
        success: true,
        data: {notes},
      };

      return;
    }

    let notes: Array<any> = [];
    let dnotes: Array<any> = [];
    if (type === 'R') {
      commonQuery['receivers'] = {$in: [userId]};
      notes = await noteInfoModel({tenantFlag}).find(commonQuery)
        .sort({createdAt: 'desc'})
        .skip((requestPage - 1) * requestItemsPerPage)
        .limit(requestItemsPerPage)
        .select('_id');

      dnotes = await Promise.all(notes.map(async (note: any) => {
        return await noteMemberModel({tenantFlag})
          .findOne({
            parentNote: note._id, type, parentUser: userId,
            $or: [
              {isCanceled: {$ne: true}},
              {isCanceled: {$exists: false}},
            ],
          })
          .populate({
            path: 'parentNote',
            populate: notePopulate,
          });
      }));
    }

    if (type === 'S') {
      commonQuery['sender'] = userId;
      notes = await noteInfoModel({tenantFlag}).find(commonQuery)
        .sort({createdAt: 'desc'})
        .skip((requestPage - 1) * requestItemsPerPage)
        .limit(requestItemsPerPage)
        .select('_id');

      notePopulate.push({
        path: 'receivers',
        select: '_id userName jobTitle parentDepartment profileImage parentCompany',
        populate: [{
          path: 'parentDepartment',
          select: 'departmentName',
        }, {
          path: 'parentCompany',
          select: 'companyName',
        }],
      });

      dnotes = await Promise.all(notes.map(async (note: any) => {
        return await noteMemberModel({tenantFlag})
          .findOne({
            parentNote: note._id, type, parentUser: userId,
          })
          .populate({
            path: 'parentNote',
            populate: notePopulate,
          });
      }));
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        notes: dnotes.filter((d: any) => d !== null && d !== undefined),
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default searchNotesByKeyword;
