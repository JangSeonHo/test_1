import Router from '@koa/router';
const router = new Router();

import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

import searchUsersByKeyword from './controllers/searchUsersByKeyword';
// router.get('/searchUsersByKeyword', searchUsersByKeyword);
// eslint-disable-next-line max-len
router.get('/searchUsersByKeyword', isLoggedIn, searchUsersByKeyword);

import searchUsersByKeywordForSMS from './controllers/searchUsersByKeywordForSMS';
router.post('/searchUsersByKeywordForSMS', searchUsersByKeywordForSMS);

import searchCompanyUsersByKeyword from './controllers/searchCompanyUsersByKeyword';
router.get('/searchCompanyUsersByKeyword', isLoggedIn, searchCompanyUsersByKeyword);

import searchNotesByKeyword from './controllers/searchNotesByKeyword';
// eslint-disable-next-line max-len
router.get('/searchNotesByKeyword', isLoggedIn, searchNotesByKeyword);

import searchUserByPhoneNumber from './controllers/searchUsersByPhoneNumber';
// eslint-disable-next-line max-len
router.get('/searchUserByPhoneNumber', isLoggedIn, searchUserByPhoneNumber);

import searchUsersFromCompany from './controllers/searchUsersFromCompany';
// router.get('/searchUsersByKeyword', searchUsersByKeyword);
// eslint-disable-next-line max-len
router.get('/searchUsersFromCompany', isLoggedIn, searchUsersFromCompany);

export default router;
