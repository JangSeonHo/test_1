/* eslint-disable max-len */
import Koa from 'koa';

import noteMemberModel from 'models/note/note_member';
import userInfoModel from 'models/account/user_info';
import departmentModel from 'models/company/company_department_info';
import companyModel from 'models/company/company_company_info';

const getNoteReadMembers = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const {noteId} = ctx.query;

    const targetNoteMemberModel = noteMemberModel({tenantFlag});

    // population
    userInfoModel({tenantFlag});
    departmentModel({tenantFlag});
    companyModel({tenantFlag});
    //

    const members = await targetNoteMemberModel.find(
      {parentNote: noteId, type: 'R'},
    )
    .select('parentUser isRead readAt isCanceled')
    .populate({
      path: 'parentUser',
      select: '_id profileImage userName jobTitle parentDepartment parentCompany childStatusInfo',
      populate: [
        {
          path: 'childStatusInfo',
          select: 'statusCode pcStatus mobileStatus',
        },
        {
          path: 'parentDepartment',
          select: 'departmentName',
        },
        {
          path: 'parentCompany',
          select: 'companyName',
        },
      ],
    });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {members},
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getNoteReadMembers;
