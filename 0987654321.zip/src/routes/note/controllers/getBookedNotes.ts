/* eslint-disable max-len */
import Koa from 'koa';
import bookedNoteInfoModel from 'models/note/booked_note';
import noteInfoModel from 'models/note/note_info';
import userInfoModel from 'models/account/user_info';
import departmentModel from 'models/company/company_department_info';

const getBookedNotes = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const {page = 1, itemsPerPage = 20} = ctx.query;

    // population
    userInfoModel({tenantFlag});
    departmentModel({tenantFlag});
    noteInfoModel({tenantFlag});
    //

    const requestPage = Number(page);
    const requestItemsPerPage = Number(itemsPerPage);

    const notes = await bookedNoteInfoModel({tenantFlag})
      .find({sender: userId})
      .sort({createdAt: 'desc'})
      .skip((requestPage - 1) * requestItemsPerPage)
      .limit(requestItemsPerPage)
      .populate([
        {
          path: 'receivers',
          select: '_id userName jobTitle parentDepartment profileImage',
          populate: [{
            path: 'parentDepartment',
            select: 'departmentName',
          }],
        },
      ]);

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {notes},
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getBookedNotes;
