import Koa from 'koa';

import bookedNoteInfoModel from 'models/note/booked_note';

const deleteBookedNotes = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {noteIds} = ctx.request.body as any;

    const targetModel = bookedNoteInfoModel({tenantFlag});

    await Promise.all(noteIds.map(async (noteId: string) => {
      await targetModel.deleteOne({_id: noteId, sender: userId});
    }));

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default deleteBookedNotes;
