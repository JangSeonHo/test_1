/* eslint-disable new-cap */
import Koa from 'koa';

import bookedNoteInfoModel from 'models/note/booked_note';
import noteInfoModel from 'models/note/note_info';
import noteMemberModel from 'models/note/note_member';

const modifyBookedNote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {
      bookedNoteId,
      title,
      content,
      receivers,
      bookedAt,
      fileFolderId = '',
      attachedFiles = [],
      attachedImages = [],
    } = ctx.request.body;

    const targetNoteInfoModel = noteInfoModel({tenantFlag});
    const targetNoteMemberModel = noteMemberModel({tenantFlag});

    if (bookedAt < new Date().getTime()) {
      // 즉시 전송 후 삭제
      const createdAt = new Date().getTime();

      const note = new targetNoteInfoModel({
        'sender': userId,
        receivers,
        title,
        content,
        attachedFiles,
        attachedImages,
        createdAt,
        fileFolderId,
      });

      const senderMember = new targetNoteMemberModel({
        parentUser: userId,
        type: 'S',
        parentNote: note._id,
        createdAt,
      });

      await Promise.all([
        note.save(),
        senderMember.save(),
        bookedNoteInfoModel({tenantFlag}).deleteOne({_id: bookedNoteId}),
      ]);

      await Promise.all(receivers.map(async (uid: string) => {
        const nm: any = new targetNoteMemberModel({
          parentNote: note._id,
          type: 'R',
          parentUser: uid,
          createdAt,
        });

        await nm.save();
      }));


      ctx.status = 200;
      ctx.body = {
        success: true,
      };

      return;
    }

    await bookedNoteInfoModel({tenantFlag}).updateOne(
      {_id: bookedNoteId},
      {
        title,
        content,
        fileFolderId,
        attachedFiles,
        attachedImages,
        bookedAt,
        receivers,
      },
    );

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default modifyBookedNote;
