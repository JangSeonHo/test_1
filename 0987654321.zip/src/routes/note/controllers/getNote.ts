import Koa from 'koa';
import noteInfoModel from 'models/note/note_info';
import userInfoModel from 'models/account/user_info';
import departmentModel from 'models/company/company_department_info';
import companyModel from 'models/company/company_company_info';
import noteMemberModel from 'models/note/note_member';
import mongoose from 'mongoose';
import compareVersions from '../../../utils/string/compareVersions';
import {
  ENCKEYFORPARAM,
  ENCRYPT_APPVERSION,
} from '../../../constants/commonConstants';
import {decryptURL} from '../../../utils/cipher';

const getNote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    const versionInfo = ctx.headers['version-info'] as string ?? '';

    const {noteId = ''} = ctx.query;
    // console.log('getNote values - userId :', userId, ' / noteId :', noteId);
    // population
    userInfoModel({tenantFlag});
    departmentModel({tenantFlag});
    noteInfoModel({tenantFlag});
    companyModel({tenantFlag});
    //

    let note = await noteInfoModel({tenantFlag}).findOne({
      _id: new mongoose.mongo.ObjectId(noteId.toString()),
      $or: [
        {sender: new mongoose.mongo.ObjectId(userId)},
        {receivers: {$in: [new mongoose.mongo.ObjectId(userId)]}},
      ],
    })
      .populate([
        {
          path: 'sender',
          // eslint-disable-next-line max-len
          select: '_id userName jobTitle parentDepartment parentCompany profileImage isDeleted',
          populate: [
            {
              path: 'parentDepartment',
              select: 'departmentName',
            },
            {
              path: 'parentCompany',
              select: 'companyName',
            },
            // {
            //   path: 'childStatusInfo',
            //   select: 'statusCode',
            // },
          ],
        },
        {
          path: 'receivers',
          select: '_id userName jobTitle parentDepartment profileImage isDeleted',
          populate: [{
            path: 'parentDepartment',
            select: 'departmentName',
          }, {
            path: 'parentCompany',
            select: 'companyName',
          }],
        },
      ]).lean();

    // TODO - 추후 압호화 버전으로 모든 사용자가 바뀌면 제거할 코드
    if (compareVersions(versionInfo, ENCRYPT_APPVERSION) < 0) {
      if (!!note) {
        note = {
          ...note,
          // @ts-ignore
          attachedFiles: note['attachedFiles'].map((file: any) => ({
            ...file,
            url: decryptURL(file.url, ENCKEYFORPARAM).success ? decryptURL(file.url, ENCKEYFORPARAM).url : file.url
          })),
        };
      }
    }

    const noteMember = await noteMemberModel({tenantFlag}).findOne({parentNote: noteId, parentUser: userId}).lean();
    // console.log('getNote note :', note);
    // console.log('getNote noteMember :', noteMember);

    if (noteMember === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'Deleted or non-existent message.',
      };
      return;
    } else if (noteMember!.hasOwnProperty('isDeleted')) {
      // @ts-ignore
      if (!!noteMember['isDeleted']) {
        ctx.status = 403;
        ctx.body = {
          'success': false,
          'error': 'Deleted or non-existent message.',
        };
        return;
      }
      // @ts-ignore
    } if (noteMember['isCanceled']) {
      ctx.status = 402;
      ctx.body = {
        'success': false,
        'error': 'This messages has been deleted or canceled.',
      };
      return;
    }

    // if (note !== null) {
    //   const nrms = note.receivers.map(({_id}: any) => _id.toString());
    //   if (nrms.includes(userId)) {
    //     const nm = await noteMemberModel({tenantFlag})
    //       .findOne({parentUser: userId, parentNote: noteId})
    //       .select('isRead');
    //
    //     if (!nm.isRead) {
    //       await Promise.all([
    //         noteMemberModel({tenantFlag})
    //           .updateOne({parentUser: userId, parentNote: noteId},
    //               {isRead: true, readAt: new Date().getTime()}),
    //         userBadgeModel({tenantFlag})
    //           .updateOne({parentUser: userId}, {PP09260314-17
    //             $inc: {unreadNotes: -1},
    //           }),
    //       ]);
    //     }
    //   }
    // }
    // readNote와 중복된 처리
    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {note},
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getNote;
