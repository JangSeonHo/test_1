import Koa from 'koa';

import bookedNoteInfoModel from 'models/note/booked_note';
import userInfoModel from 'models/account/user_info';

const bookNote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const TargetUserModel = userInfoModel({tenantFlag});

    const {
      title,
      content,
      sendTo,
      bookedAt,
      fileFolderId = '',
      attachedFiles = [],
      attachedImages = [],
    } = ctx.request.body as any;

    const targetNoteInfoModel = bookedNoteInfoModel({tenantFlag});

    const createdAt = new Date().getTime();

    const me = await TargetUserModel.findOne({_id: userId}).select('userName');
    const us = await Promise.all(sendTo.map(async (st: string) => {
      const u = await TargetUserModel.findOne({_id: st}).select('userName');
      return u.userName;
    }));

    const usko = us.map((u: any) => u['ko']).join(' ');
    const usen = us.map((u: any) => u['en']).join(' ');

    // eslint-disable-next-line new-cap
    const note = new targetNoteInfoModel({
      'sender': userId,
      'receivers': sendTo,
      'senderUserName': me.userName,
      'receiverUserNames': {
        ko: usko,
        en: usen,
      },
      title,
      content,
      fileFolderId,
      attachedFiles,
      attachedImages,
      createdAt,
      bookedAt,
    });

    await note.save();

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        bookedNote: {_id: note._id},
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default bookNote;
