/* eslint-disable max-len */
import Koa from 'koa';

import noteMemberModel from 'models/note/note_member';
import userBadgeModel from 'models/account/user_badge';

const cancelUnreadNote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const {cancelIds} = ctx.request.body;

    const targetNoteMemberModel = noteMemberModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    await Promise.all(cancelIds.map(async (id: string) => {
      const {parentUser} = await targetNoteMemberModel.findOne({_id: id})
        .select('parentUser');

      await Promise.all([
        targetNoteMemberModel.updateOne({_id: id}, {isCanceled: true}),
        TargetUserBadgeModel.updateOne({parentUser}, {
          $inc: {unreadNotes: -1},
        }),
      ]);
    }));

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default cancelUnreadNote;
