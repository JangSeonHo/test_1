/* eslint-disable new-cap */
import Koa from 'koa';

import bookedNoteInfoModel from 'models/note/booked_note';
import noteInfoModel from 'models/note/note_info';
import noteMemberModel from 'models/note/note_member';
import userSignInfo from 'models/account/user_sign_info';
import userBadgeModel from 'models/account/user_badge';
import userStatusInfoModel from '../../../models/account/user_status_info';
import isValidAlarmTime from '../../../utils/alarm/isValidAlarmTime';
import {getUserBadgePrimaryOnly} from '../../../utils/account/getUserBadge';
import userInfoModel from '../../../models/account/user_info';
import admin from 'firebase-admin';
import {UserStatusCode} from '../../../constants/commonConstants';

import pushIntegration from 'utils/push/pushIntegration';

const sendBookedNote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {
      bookedNoteId,
    } = ctx.request.body as any;

    // eslint-disable-next-line max-len
    const {title, content, receivers, attachedFiles, attachedImages, fileFolderId} =
      await bookedNoteInfoModel({tenantFlag}).findOne({_id: bookedNoteId});

    const createdAt = new Date().getTime();

    const targetNoteInfoModel = noteInfoModel({tenantFlag});
    const targetNoteMemberModel = noteMemberModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});
    const TargetUserSignInfo = userSignInfo({tenantFlag});

    const note = new targetNoteInfoModel({
      'sender': userId,
      receivers,
      title,
      content,
      attachedFiles,
      attachedImages,
      createdAt,
      fileFolderId,
    });

    const senderMember = new targetNoteMemberModel({
      parentUser: userId,
      type: 'S',
      parentNote: note._id,
      createdAt,
    });

    await Promise.all([
      note.save(),
      senderMember.save(),
      bookedNoteInfoModel({tenantFlag}).deleteOne({_id: bookedNoteId}),
    ]);

    await Promise.all(receivers.map(async (uid: string) => {
      const nm: any = new targetNoteMemberModel({
        parentNote: note._id,
        type: 'R',
        parentUser: uid,
        createdAt,
      });

      await Promise.all([
        nm.save(),
        TargetUserBadgeModel.updateOne({parentUser: uid}, {
          $inc: {unreadNotes: 1},
        }),
      ]);
    }));


    const tokens: Array<string> = [];
    const locales: any = [];
    const os: any = [];
    const badges: any = [];

    await Promise.all(receivers.map(async (member: any) => {
      const pushTargets = await TargetUserSignInfo
        .find({
          parentUser: member,
          $or: [{deviceType: 'android'}, {deviceType: 'ios'}],
          usePushAlarm: true,
          useAlarmNote: true,
        }).select('pushToken useAlarmAllowedTime useEnUserInfo deviceType onlyAlarmWhenPCIsAbsence timezoneOffset alarmAllowedTime');
      const userStatus = await userStatusInfoModel({tenantFlag})
        .findOne({parentUser: member.parentUser})
        .select('pcStatus mobileStatus').lean();

      await Promise.all(pushTargets.map(async ({pushToken, useAlarmAllowedTime, useEnUserInfo, deviceType, onlyAlarmWhenPCIsAbsence, timezoneOffset, alarmAllowedTime}) => {
        if (onlyAlarmWhenPCIsAbsence && userStatus!.hasOwnProperty('pcStatus') && userStatus!.hasOwnProperty('mobileStatus')) {
          // if (userStatus.pcStatus === 'online' && (userStatus.statusCode === '온라인' || userStatus.statusCode === '재택')) {
          // @ts-ignore
          if ((userStatus['pcStatus'] === UserStatusCode.ONLINE || userStatus['pcStatus'] === 'online') && userStatus['mobileStatus'] === UserStatusCode.ONLINE) {
            return;
          }
        }

        if (useAlarmAllowedTime) {
          if (!isValidAlarmTime(timezoneOffset, alarmAllowedTime.start, alarmAllowedTime.end)) {
            return;
          }
        }

        if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
          const badge = await getUserBadgePrimaryOnly(member, tenantFlag);
          badges.push(badge);
          tokens.push(pushToken);
          locales.push(useEnUserInfo ? 'en' : 'ko');
          os.push(deviceType);
        }
      }));
    }));


    if (tokens.length !== 0) {
      const user: any = await userInfoModel({tenantFlag}).findOne({_id: userId})
        .select('userName jobTitle');

      tokens.forEach((token: string, i: number) => {
        const notification = {
          title: `${user.userName[locales[i] ?? 'ko']} ${user.jobTitle[locales[i] ?? 'ko']}`,
          body: '쪽지가 도착했습니다',
        };

        const msg: any = {
          data: {type: 'note', id: note._id.toString(), ...notification, badge: badges[i].toString()},
          token: token,
        };

        if (os[i] === 'android') {
          msg.android = {
            priority: 'HIGH',
          };
        }

        if (os[i] === 'ios') {
          msg.notification = notification;
          msg.apns = {
            payload: {
              aps: {
                sound: 'default',
                badge: badges[i],
              },
            },
          };
        }

        //admin.messaging().send(msg);
        pushIntegration(msg, false);
      });
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default sendBookedNote;
