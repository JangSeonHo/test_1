/* eslint-disable max-len */
import Koa from 'koa';
import noteInfoModel from 'models/note/note_info';
import noteMemberModel from 'models/note/note_member';
import userInfoModel from 'models/account/user_info';
import departmentModel from 'models/company/company_department_info';

const getNotes = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const {type, page = 1, itemsPerPage = 20} = ctx.query;

    // population
    userInfoModel({tenantFlag});
    departmentModel({tenantFlag});
    noteInfoModel({tenantFlag});
    //

    const requestPage = Number(page);
    const requestItemsPerPage = Number(itemsPerPage);

    const notePopulate = [
      {
        path: 'sender',
      select: '_id userName jobTitle parentDepartment profileImage childStatusInfo parentCompany isDeleted',
      populate: [{
      path: 'parentDepartment',
      select: 'departmentName',
    }, {
      path: 'parentCompany',
      select: 'companyName',
    }],
  },
  ];

    const query: any = {type, parentUser: userId};

    if (type === 'S') {
      notePopulate.push({
        path: 'receivers',
        select: '_id userName jobTitle parentDepartment profileImage isDeleted',
        populate: [{
          path: 'parentDepartment',
          select: 'departmentName',
        }],
      });
    } else {
      query['isCanceled'] = false;
      query['isDeleted'] = false;
    }

    const notes = await noteMemberModel({tenantFlag})
      .find(query)
      .sort({createdAt: 'desc'})
      .skip((requestPage - 1) * requestItemsPerPage)
      .limit(requestItemsPerPage)
      .populate({
        path: 'parentNote',
        populate: notePopulate,
      });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {notes},
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getNotes;
