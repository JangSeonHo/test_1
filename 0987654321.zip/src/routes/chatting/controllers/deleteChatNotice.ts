import Koa from 'koa';
import chatNoticeModel from 'models/message/chatting_room_message_notice';
import chatRoomInfoModel from 'models/message/chatting_room_info';

const deleteChatNotice = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {noticeId} = ctx.request.body as any;

    const TargetMessageModel = chatNoticeModel({tenantFlag});

    await TargetMessageModel.deleteOne({
      _id: noticeId, parentUser: userId});

    await chatRoomInfoModel({tenantFlag})
      .updateOne({childNoticeMessage: noticeId},
        {childNoticeMessage: null});

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default deleteChatNotice;
