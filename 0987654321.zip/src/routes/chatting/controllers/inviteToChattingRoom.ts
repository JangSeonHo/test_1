/* eslint-disable new-cap */
/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import chattingRoomMessageModel from 'models/message/chatting_room_message';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import chatRoomCounterModel from 'models/message/chatting_counter';
import chattingRoomMessageVoteModel from 'models/message/chatting_room_message_vote';
import { CHAT_ROOM_MAX_MEMBERS } from '../../../constants/commonConstants';

const inviteToChattingRoom = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const body: any = ctx.request.body;
    const {userIds, roomId} = body;

    const targetUserModel = userInfoModel({tenantFlag});
    const targetChattingMessageModel = chattingRoomMessageModel({tenantFlag});
    const targetChattingRoomModel = chattingRoomInfoModel({tenantFlag});
    const targetChattingMemberModel = chattingRoomMemberModel({tenantFlag});
    const targetChatVoteModel = chattingRoomMessageVoteModel({tenantFlag});

    const [currentRoom, hasPermission] = await Promise.all([
      targetChattingRoomModel.findOne({_id: roomId}),
      targetChattingMemberModel.findOne({
        parentUser: userId,
        parentChattingRoom: roomId,
        isDeleted: false,
      }),
    ]);
    if (!currentRoom || !hasPermission) {
      ctx.status = 404;
      ctx.body = {
        'success': false,
        'error': 'Chat room not found',
      };
      return;
    }

    if (currentRoom.totalRoomMembers + userIds.length > CHAT_ROOM_MAX_MEMBERS) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': `${CHAT_ROOM_MAX_MEMBERS}`,
      };
      return;
    }

    const tus = userIds.length > 10 ? userIds.slice(0, 10) : [...userIds];
    const users = await Promise.all([
      targetUserModel.findOne({_id: userId}).select('userName'),
      ...tus.map(async (tu: string) => await targetUserModel.findOne({_id: tu}).select('userName')),
    ]);

    let content = `${users[0]['userName']['ko']}님이 `;
    let contentEn = `${users[0]['userName']['en']}님이 `;
    for (let i = 1; i < users.length; i++) {
      content += `${users[i]['userName']['ko']}님`;
      contentEn += `${users[i]['userName']['en']}님`;
      if (i !== users.length - 1) {
        content += ', ';
        contentEn += ', ';
      }
    }

    if (userIds.length > 10) {
      content += ` 외 ${userIds.length - 10}명을 초대했습니다`;
      contentEn += ` 외 ${userIds.length - 10}명을 초대했습니다`;
    } else {
      content += '을 초대했습니다';
      contentEn += '을 초대했습니다';
    }

    const newSystemMessage = new targetChattingMessageModel({
      systemMessageType: 'join',
      content,
      isSystemMessage: true,
      parentChattingRoom: roomId,
      messageSeq: -1,
      createdAt: new Date().getTime(),
      translate: [
        {
          locale: 'en',
          text: contentEn,
        },
      ],
    });

    const counter = await chatRoomCounterModel({tenantFlag}).findOne({childChattingRoom: roomId});

    await Promise.all([
      targetChattingRoomModel.updateOne({_id: roomId}, {
        $inc: {
          totalRoomMembers: userIds.length,
        },
      }),
      ...userIds.map(async (userId: string) => {
        const newDoc = {
          parentUser: userId,
          parentChattingRoom: roomId,
          isDeleted: false,
          isGroupChat: true,
          joinedAt: new Date().getTime(),
          lastCheckedMessageSeq: counter.messageSeq,
          deletedMessageSeq: counter.messageSeq,
        };

        await targetChattingMemberModel.findOneAndUpdate(
          { parentUser: userId, parentChattingRoom: roomId},
          { $set: newDoc },
          { upsert: true, new: true }
        );
        //newDoc.save();
      }),
      newSystemMessage.save(),
    ]);

    // 진행중인 투표 권한부여
    const currentTime = new Date().getTime();
    const votes = await targetChatVoteModel.find({parentChattingRoom: roomId, deadline: {
      $gt: currentTime,
    }});

    await Promise.all(votes.map(async (vote: any) => {
      const rc = {...vote.voteRecords};

      userIds.forEach((uid: string) => {
        rc[uid] = [];
      });

      await targetChatVoteModel.updateOne({_id: vote._id}, {
        voteRecords: rc,
      });
    }));

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default inviteToChattingRoom;
