/* eslint-disable max-len */
import Koa from 'koa';

import chattingMessageModel from 'models/message/chatting_room_message';
import chatVoteModel from 'models/message/chatting_room_message_vote';
import chatMemberModel from 'models/message/chatting_room_member';

const getChatMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {messageId, roomId} = ctx.request.query;

    // before populate
    chatVoteModel({tenantFlag});

    const member = await chatMemberModel({tenantFlag})
      .findOne({parentUser: userId, parentChattingRoom: roomId, isDeleted: false})
      .select('deletedMessages');

    if (!member) {
      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          chatMessage: null,
          msg: 'DELETE_ROOM',
        },
      };

      return;
    }

    if (member.deletedMessages.includes(messageId)) {
      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          chatMessage: null,
          msg: 'DELETE_MESSAGE',
        },
      };

      return;
    }

    const chatMessage = await chattingMessageModel({tenantFlag})
      .findOne({
        _id: messageId,
      })
      .populate([{
        path: 'replyOrigin',
        select: 'content parentUser isEmoticon files translate recvTranslate messageSeq',
      }, {
        path: 'mentionedUsers',
        select: 'userName jobTitle',
      }, {
        path: 'parentUser',
        select: 'userName jobTitle parentCompany parentDepartment profileImage',
        populate: [
          {
            path: 'parentDepartment',
            select: 'departmentName',
          },
          {
            path: 'parentCompany',
            select: 'companyName',
          },
        ],
      }, {
        path: 'childVote',
      }]);

    if (chatMessage.isDeleted) {
      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          chatMessage: null,
          msg: 'DELETE_MESSAGE',
        },
      };

      return;
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        chatMessage,
        msg: 'success',
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getChatMessage;
