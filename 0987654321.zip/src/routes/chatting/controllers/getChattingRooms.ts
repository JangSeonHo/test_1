/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyGroupInfoModel from 'models/company/company_group_info';
import companyInfoModel from 'models/company/company_company_info';
import companyDepartmentInfoModel from 'models/company/company_department_info';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import chatNoticeModel from 'models/message/chatting_room_message_notice';
import userBadgeModel from 'models/account/user_badge';
import chattingRoomMessageModel from 'models/message/chatting_room_message';
import updateUserBadge from '../../../utils/user/updateUserBadge';

const getChattingRooms = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    // before populate
    companyGroupInfoModel({tenantFlag});
    companyInfoModel({tenantFlag});
    companyDepartmentInfoModel({tenantFlag});
    userInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    chattingRoomInfoModel({tenantFlag});
    chatNoticeModel({tenantFlag});

    let chattingRooms: any = await chattingRoomMemberModel({tenantFlag}).find({
      parentUser: userId,
      isDeleted: false,
    })
      .populate({
        path: 'parentChattingRoom',
        populate: [
          {
            path: 'childUsers',
            select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
            populate: [{
              path: 'childStatusInfo',
              select: '-parentUser -__v -_id',
            }, {
              path: 'parentCompany',
              select: 'companyName',
            }, {
              path: 'parentDepartment',
              select: 'departmentName',
            }],
          },
          {
            path: 'childLastMessage',
          },
          {
            path: 'childNoticeMessage',
          },
        ],
      });
    chattingRooms = chattingRooms.filter((room: any) => room.parentChattingRoom !== null);
    // chatting_room_info에 데이터가 없는 케이스 방어로직

    // let count = 0;

    await Promise.all(
      chattingRooms.map(async (room: any) => {
        if (!room.parentChattingRoom.isMyChat && room.parentChattingRoom.childLastMessage && room.parentChattingRoom.childLastMessage.messageSeq > 0) {
          if (room.parentChattingRoom.childLastMessage.messageSeq - room.deletedMessageSeq < 1) {
            room.parentChattingRoom.childLastMessage = null;
          }
        }

        // if (!room.parentChattingRoom.isMyChat && room.parentChattingRoom.childLastMessage && room.parentChattingRoom.childLastMessage.messageSeq > 0) {
        //   if (room.parentChattingRoom.childLastMessage.messageSeq - room.lastCheckedMessageSeq > 0) {
        //     count += (room.parentChattingRoom.childLastMessage.messageSeq - room.lastCheckedMessageSeq);
        //   }
        // }

        // 삭제한 메세지가 있는 경우 마지막 메세지 가져오직 추가
        let lastDeletedMsgId = '';
        let lastMessage;

        // 삭제된 마지막 메세지
        if (room.deletedMessages && Array.isArray(room.deletedMessages) && room.deletedMessages.length > 0) {
          lastDeletedMsgId = room.deletedMessages[room.deletedMessages.length - 1];
        }

        if (lastDeletedMsgId !== '') {
          const lastDeletedMessage = await chattingRoomMessageModel({tenantFlag}).findOne({_id: lastDeletedMsgId});

          // lastDeletedMessage가 null이거나 messageSeq가 없는 경우 처리
          const lastDeletedMsgSeq = lastDeletedMessage ? lastDeletedMessage.messageSeq : 0;

          // 삭제한 메세지 뒤에 삭제되지 않은 메세지가 있으면 메세지를 보내지 않는다.
          const preDeletedMsg = await chattingRoomMessageModel({tenantFlag})
          .findOne({
            parentChattingRoom: room.parentChattingRoom._id, // parentChattingRoom 조회 조건
            isDeleted: false, // 삭제되지 않은 메시지
            _id: {$nin: room.deletedMessages}, // chattingRoom.deletedMessages 배열에 없는 메시지
            messageSeq: {$gt: lastDeletedMsgSeq}, // lastDeletedMesId 이후 메시지
          })
          .sort({messageSeq: -1}) // messageSeq 내림차순으로 정렬하여 가장 높은 값을 찾음
          .exec();

          if (!preDeletedMsg && !!lastDeletedMessage) {
            const chattingMember = await chattingRoomMemberModel({tenantFlag}).findOne({
              parentUser: lastDeletedMessage.parentUser,
              parentChattingRoom: room.parentChattingRoom._id,
            }).exec();

            lastMessage = await chattingRoomMessageModel({tenantFlag})
            .findOne({
              parentChattingRoom: room.parentChattingRoom._id, // parentChattingRoom 조회 조건
              isDeleted: false, // 삭제되지 않은 메시지
              isSystemMessage: false,
              _id: {$nin: room.deletedMessages}, // chattingRoom.deletedMessages 배열에 없는 메시지
              messageSeq: {$lt: lastDeletedMsgSeq, $gt: chattingMember.deletedLastCheckedMessageSeq}, // lastDeletedMesId 이후 메시지
            })
            .sort({messageSeq: -1}) // messageSeq 내림차순으로 정렬하여 가장 높은 값을 찾음
            .exec();
            room.parentChattingRoom.childLastMessage = JSON.parse(JSON.stringify(lastMessage));
          }
        }
      }),
    );


    // await userBadgeModel({tenantFlag}).updateOne({parentUser: userId}, {
    //   unreadChatMessages: count,
    // });

    // [성능튜닝] 하기 소스는 성능향상을 위해 수정됨.
    // userBadgeModel({tenantFlag}).updateOne({parentUser: userId}, {unreadChatMessages: count < 0 ? 0 : count});

    const crs = await Promise.all(chattingRooms.map((async (room: any) => {
      if (room['isGroupChat'] == true) {
        const roomThumbnails = await chattingRoomMemberModel({tenantFlag}).find({parentChattingRoom: room['parentChattingRoom']['_id'], isDeleted: false})
          .select('parentUser')
          .populate({
            path: 'parentUser',
            select: 'profileImage userName jobTitle',
          }).lean();

        const c = room;

        return {
          ...c.toObject(),
          roomThumbnails: roomThumbnails
            .filter((t) => 'parentUser' in t)
            .map((m: any) => m.parentUser?.profileImage ?? ''),
          participants: roomThumbnails
            .filter((t) => 'parentUser' in t)
            .map((m: any) => {
              return {...m.parentUser?.userName ?? '', 'jobTitle': m.parentUser?.jobTitle ?? ''};
          }),
        };
      }

      return room;
    })));

    const sortedChattingRooms = crs.sort((a, b) => {
      const b2 = b['parentChattingRoom']['childLastMessage'] === '' || !b['parentChattingRoom']['childLastMessage'] ? 0 : b['parentChattingRoom']['childLastMessage']['createdAt'];
      const a2 = a['parentChattingRoom']['childLastMessage'] === '' || !a['parentChattingRoom']['childLastMessage'] ? 0 : a['parentChattingRoom']['childLastMessage']['createdAt'];
      return b2 - a2;
    });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        chattingRooms: sortedChattingRooms,
      },
    };

    setImmediate(() => {
      updateUserBadge(tenantFlag, userId);
    });
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getChattingRooms;
