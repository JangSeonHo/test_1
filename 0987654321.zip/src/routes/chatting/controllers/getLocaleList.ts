/* eslint-disable max-len */
import Koa from 'koa';

import chattingTranslationLanguageModel from 'models/message/chatting_translation_language';

const getLocaleList = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const localeList = await chattingTranslationLanguageModel({tenantFlag})
      .find({
        useYn: 'Y'
      })
      .select('-_id langCd langNmKo langNmEn langNmCn langNmJp');

    ctx.status = 200;
    ctx.body = {
      'success': true,
      localeList
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getLocaleList;
