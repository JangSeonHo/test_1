import Koa from 'koa';

import chatMessageVoteModel from 'models/message/chatting_room_message_vote';

function renameKeys(obj: any, keyMap: any) {
  return Object.keys(obj).reduce((acc, key) => {
    const newKey = keyMap[key] || key;
    // @ts-ignore
    acc[newKey] = obj[key];
    return acc;
  }, {});
}

const getVotes = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {roomId, page, pageSize} = ctx.query;

    const p = Number(page ?? 1);
    const ps = Number(pageSize ?? 20);

    const MessageVoteModel = chatMessageVoteModel({tenantFlag});

    const votes = await MessageVoteModel.find({parentChattingRoom: roomId})
      .populate({
        path: 'parentUser',
        // eslint-disable-next-line max-len
        select: 'userName profileImage jobTitle parentCompany parentDepartment',
        populate: [{
          path: 'parentCompany',
          select: 'companyName',
        }, {
          path: 'parentDepartment',
          select: 'departmentName',
        }],
      })
      .sort({createdAt: 'desc'})
      .skip((p - 1) * ps)
      .limit(ps)
      .lean();


    const voteRes = votes.map((d) => {
      if (!!d.anonymousVote) {
        const keyMap = {};
        Object.entries(d.voteRecords).forEach(([uid, record], idx) => {
          if (String(uid) !== userId) {
            // @ts-ignore
            keyMap[String(uid)] = `anonymous${idx}`;
          }
        });
        // console.log('keyMap :', keyMap);
        d.voteRecords = renameKeys(d.voteRecords, keyMap);
      }
      return d;
    });

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        votes: voteRes,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default getVotes;
