/* eslint-disable max-len */
import Koa from 'koa';

import userStatusInfoModel from 'models/account/user_status_info';
import companyInfoModel from 'models/company/company_company_info';
import companyDepartmentInfoModel from 'models/company/company_department_info';
import chattingCounterModel from 'models/message/chatting_counter';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import chattingMessageModel from 'models/message/chatting_room_message';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import bookedChatMessageModel from 'models/message/chatting_room_booked_message';
import chatMessageSPModel from 'models/message/chatting_room_message_sp';
import chatMessageEgModel from 'models/message/chatting_room_message_eg';
import chatVoteModel from 'models/message/chatting_room_message_vote';
import alarmModel from 'models/alarm/alarm';
import userBadgeModel from 'models/account/user_badge';
import userInfoModel from 'models/account/user_info';
import updateUserBadge from 'utils/user/updateUserBadge';
import compareVersions from 'utils/string/compareVersions';
import {ENCRYPT_APPVERSION, ENCKEYFORPARAM} from 'constants/commonConstants';
import {decryptURL} from 'utils/cipher';

const enterChattingRoom = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    const versionInfo = ctx.headers['version-info'] as string ?? '';

    const {roomId} = ctx.request.query;

    const hasPermission = await chattingRoomMemberModel({tenantFlag})
      .findOne({parentUser: userId, parentChattingRoom: roomId});

    if (hasPermission === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'permission denied',
      };

      return;
    } else {

      if (hasPermission.isEntered !== null && !hasPermission.isEntered) {
        hasPermission.isEntered = true;
        await hasPermission.save();
      }

    }



    // before populate
    companyInfoModel({tenantFlag});
    companyDepartmentInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    chatMessageEgModel({tenantFlag});
    chatVoteModel({tenantFlag});
    userInfoModel({tenantFlag});

    const [
      chattingMembersTmp,
      chattingRoom,
      bookedMessage,
      bookmarkedMessages,
      reminderMessages,
      roomMemberInfo,
      chattingCounter,
    ] = await Promise.all([
      chattingRoomMemberModel({tenantFlag})
        .find({parentChattingRoom: roomId})
        //.sort({'joinedAt': 'asc'}) // 채팅방 참여일시로 정렬 주석처리함. by shjang74 2024.08.26 [PP09260314-1004]
        .select('parentUser lastCheckedMessageSeq isDeleted deletedMessageSeq deletedLastCheckedMessageSeq isEntered')
        .populate({
          path: 'parentUser',
          select: 'userName profileImage jobTitle childStatusInfo parentCompany parentDepartment personalPhoneNumber isDeleted emailId hashedPassword',
          //options: { sort: { 'userName.ko': 1 } }, //해당 부분이 잘 처리되지 않아서, 하단에 별도 정렬로직을 추가하였다.  by shjang74 2024.08.26 [PP09260314-1004]
          populate: [{
            path: 'childStatusInfo',
            select: '-parentUser -__v -_id',
          }, {
            path: 'parentCompany',
            select: 'companyName',
          }, {
            path: 'parentDepartment',
            select: 'departmentName',
          }],
        }), // [성능튜닝] 하기 소스는 성능향상을 위해 수정됨.
      // .then(members => { //개인1:1 대화 중 멤버가 나간 경우 메세지count 처리하기 위함
      //   return members.map(member => {
      //       if (!member.isGroupChat && member.isDeleted) {
      //           member.isDeleted = false;
      //       }
      //       return member;
      //   });
      // }),
      chattingRoomInfoModel({tenantFlag})
        .findOne({_id: roomId})
        .select('childNoticeMessage')
        .populate({
          path: 'childNoticeMessage',
          populate: {
            path: 'parentUser',
            select: 'jobTitle userName parentDepartment',
            populate: {
              path: 'parentDepartment',
              select: 'departmentName',
            },
          },
        }),
      bookedChatMessageModel({tenantFlag})
        .findOne({parentUser: userId, parentChattingRoom: roomId})
        .select('_id'),
      chatMessageSPModel({tenantFlag}).findOne({
        type: 'bookmark',
        parentUser: userId,
        parentChattingRoom: roomId,
      }).select('messages'),
      alarmModel({tenantFlag}).find({
        type: 'reminder',
        parentUser: userId,
        chatRoomId: roomId,
      }),
      chattingRoomMemberModel({tenantFlag})
        .findOne({parentChattingRoom: roomId, parentUser: userId, isDeleted: false})
        .select('deletedMessages lastCheckedMessageSeq'),
      chattingCounterModel({tenantFlag})
        .findOne({childChattingRoom: roomId})
        .select('messageSeq'),
    ]);

    const chattingMembers = chattingMembersTmp.filter((member) => member.parentUser);
    const deletedMessages = roomMemberInfo?.deletedMessages ?? [];
    const lastCheckedMessageSeq = roomMemberInfo?.lastCheckedMessageSeq ?? 0;
    let messageCnt = 50;
    if (hasPermission.deletedMessageSeq != null && hasPermission.deletedMessageSeq > 0) {
      messageCnt = chattingCounter.messageSeq - hasPermission.deletedMessageSeq;

      //메세지 최대 50개
      if (messageCnt > 50) messageCnt = 50;

    }

    // 메신저 사용중인 사용자에 대한 사용여부 표시 - isUse = true : 사용자, isUse = false : 미사용자
    const processedChattingMembers = chattingMembers.map(member => {
      const memberData = member.toObject();
      const isEqual = typeof memberData.parentUser.emailId == 'string' &&
        memberData.parentUser.emailId.length > 0 &&
        memberData.parentUser.emailId === memberData.parentUser.hashedPassword;
      memberData.parentUser.isUse = isEqual ? false : true;
      delete memberData.parentUser.hashedPassword;
      return memberData;
    });


    //채팅방 나가기 한 유저의 경우 나간 시점 이후의 대화부터 조회한다.

    let chattingMessages: any = [];

    if (messageCnt > 0) {
      //   chattingMessages = await chattingMessageModel({tenantFlag})
      //     .find({parentChattingRoom: roomId})
      //     .sort({createdAt: 'desc'})
      //     .populate([{
      //       path: 'childEngagement',
      //       select: 'R1 R2 R3 R4 R5 R6 R7 R8 R9',
      //     }, {
      //       path: 'replyOrigin',
      //       select: 'content parentUser isEmoticon files isNotice',
      //     }, {
      //       path: 'childVote',
      //     }])
      //  .limit(messageCnt)
      //   ;

      chattingMessages = await chattingMessageModel({ tenantFlag })
        .find({ parentChattingRoom: roomId })
        .sort({ createdAt: 'desc' })
        .populate([{
          path: 'childEngagement',
          select: 'R1 R2 R3 R4 R5 R6 R7 R8 R9',
        }, {
          path: 'replyOrigin',
          select: 'content parentUser isEmoticon files isNotice',
        }, {
          path: 'childVote',
        }]);

      // 일반 메세지만 필터링하여 count에 맞추기
      const filteredMessages = [];
      let count = 0;

      for (let message of chattingMessages) {
        // 모든 메세지를 필터링된 배열에 추가 (시스템 메세지도 포함됨)
        filteredMessages.push(message);

        // 시스템 메세지('-1'인 메세지)를 제외한 일반 메세지 카운트 증가
        if (message.messageSeq !== -1) {
          count++;
        }

        // 일반 메세지의 개수가 messageCnt에 도달하면 루프 종료
        if (count === messageCnt) {
          break;
        }
      }

      // 최종 출력할 메세지 목록
      chattingMessages = filteredMessages;


    } else {
      chattingMessages = [];
    }

    if (chattingMessages.length !== 0) {
      // const TargetUserBadgeModel = userBadgeModel({tenantFlag});
      //
      // let index = 0;
      // while (index < chattingMessages.length) {
      //   if (chattingMessages[index].messageSeq !== -1) {
      //     Promise.all([
      //       chattingRoomMemberModel({tenantFlag}).updateOne({parentUser: userId, parentChattingRoom: roomId, isDeleted: false}, {
      //         lastCheckedMessageSeq: chattingMessages[index].messageSeq,
      //         isEntered: true,
      //       }),
      //       TargetUserBadgeModel.updateOne({parentUser: userId}, {
      //         $inc: {unreadChatMessages: -1 * (chattingMessages[index].messageSeq - lastCheckedMessageSeq)},
      //       }),
      //     ]);
      //
      //     break;
      //   }
      //   index++;
      // }
      // const {unreadChatMessages} = await TargetUserBadgeModel.findOne({parentUser: userId})
      //   .select('unreadChatMessages');
      // if (unreadChatMessages < 0) {
      //   await TargetUserBadgeModel.updateOne({parentUser: userId}, {unreadChatMessages: 0});
      // }

      // lastCheckedMessageSeq를 chattingCounter(마지막 seq)로 한번만 update
      await chattingRoomMemberModel({tenantFlag}).updateOne({parentUser: userId, parentChattingRoom: roomId, isDeleted: false}, {
        lastCheckedMessageSeq: chattingCounter.messageSeq,
        isEntered: true,
      });

      // 0.5.94보다 이전 버전이면 암호화URL에 대해 대체 메시지로 치환
      // TODO - 추후 압호화 버전으로 모든 사용자가 바뀌면 제거할 코드
      if (compareVersions(versionInfo, ENCRYPT_APPVERSION) < 0) { // 0.5.94보다 이전 버전이면 암호화URL에 대해 대체 메시지로 치환
        chattingMessages = chattingMessages.map((msg: any) => {
          if (msg.files.length > 0) {
            const urlTmp = msg.files[0].url;
            // const mimeType = msg.files[0].mimeType;

            if (!urlTmp.startsWith('https:')) {
              const filesTmp: any[] = [];
              msg.files.forEach((file: any) => {
                filesTmp.push({
                  ...file,
                  url: decryptURL(file.url, ENCKEYFORPARAM).url,
                });
              });
              msg.files = filesTmp;
              // msg.files[0].url = 'https://dev-file.lgmtalk.com/65a3799263f86d9c9023799d/chatting/67847617754004ae6a0e4fdc/images/1744874453455/blank.jpg';
              // msg.hasFiles = false;
              // if (msg.isEmoticon) {
              //   msg.content = msg.content + '\n<알림>\n해당 대화의 이모티콘은 현재 버전에서 표시할 수 없으므로, 최신 버전으로 업데이트해 주세요';
              //   msg.isEmoticon = false;
              // } else if (msg.isNotice) {
              //   msg.content = msg.content + '\n<알림>\n해당 공지에 첨부된 파일은 현재 버전에서 표시할 수 없으므로, 최신 버전으로 업데이트해 주세요';
              // } else if (mimeType.startsWith('image') || mimeType.startsWith('video')) {
              //   msg.content = '<알림>\n해당 이미지/비디오 파일은 현재 버전에서 표시할 수 없으므로, 최신 버전으로 업데이트해 주세요';
              // } else {
              //   msg.content = '<알림>\n해당 파일은 현재 버전에서 표시할 수 없으므로, 최신 버전으로 업데이트해 주세요';
              // }
              // msg.files = [];
            }
          }
          return msg;
        });
      }
    }

    //---------------------------------------------------------------------------------------------------------------------
    // 조회된 chattingMembers 정렬 by shjang74 2024.08.26 [PP09260314-1004]
    //---------------------------------------------------------------------------------------------------------------------
    const sortedChattingMembers = processedChattingMembers.sort((a, b) => {
      const nameA = a.parentUser?.userName?.ko ?? '';
      const nameB = b.parentUser?.userName?.ko ?? '';
      return nameA.localeCompare(nameB, 'ko-KR');
    });
    //console.log(JSON.stringify(sortedChattingMembers, null, 2));
    //---------------------------------------------------------------------------------------------------------------------

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        noticeMessage: chattingRoom.childNoticeMessage,
        chattingMembers: sortedChattingMembers, //정렬된 사용자 정보 대입. by shjang74 2024.08.26 [PP09260314-1004]
        chattingMessages,
        hasBookedMessage: bookedMessage !== null,
        bookmarkedMessages: bookmarkedMessages === null ? [] : bookmarkedMessages.messages,
        reminderMessages,
        deletedMessages,
      },
    };

    setImmediate(() => {
      if (chattingMessages.length !== 0) {
        updateUserBadge(tenantFlag, userId);
      }
    });
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default enterChattingRoom;
