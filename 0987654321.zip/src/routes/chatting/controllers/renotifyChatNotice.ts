/* eslint-disable max-len */
import Koa from 'koa';
import admin from 'firebase-admin';

import chatNoticeModel from 'models/message/chatting_room_message_notice';
import chatMessageModel from 'models/message/chatting_room_message';
import chattingCounterModel from 'models/message/chatting_counter';
import userInfoModel from 'models/account/user_info';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import userBadgeModel from 'models/account/user_badge';
import chattingMemberModel from 'models/message/chatting_room_member';
import userSignInfoModel from 'models/account/user_sign_info';
import {getUserBadgePrimaryOnly} from 'utils/account/getUserBadge';
import isValidAlarmTime from 'utils/alarm/isValidAlarmTime';
import userStatusInfoModel from '../../../models/account/user_status_info';
import {UserStatusCode} from '../../../constants/commonConstants';
import chatRoomInfoModel from '../../../models/message/chatting_room_info';

import pushIntegration from 'utils/push/pushIntegration';

const renotifyChatNotice = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {noticeId} = ctx.request.body;

    const UserInfoModel = userInfoModel({tenantFlag});
    const TargetNoticeModel = chatNoticeModel({tenantFlag});
    const TargetMessageModel = chatMessageModel({tenantFlag});
    const targetCounterModel = chattingCounterModel({tenantFlag});
    const targetRoomModel = chatRoomInfoModel({tenantFlag});
    const targetMemberModel = chattingMemberModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    const notice = await TargetNoticeModel.findOne({_id: noticeId});
    const roomId = notice.parentChattingRoom;
    const content = notice.content;
    const files = notice.files;

    const counter = await targetCounterModel
      .findOneAndUpdate({childChattingRoom: roomId}, {
        $inc: {messageSeq: 1},
      });

    const newMessage = new TargetMessageModel({
      content,
      files,
      hasFiles: files.length > 0,
      isEmoticon: false,
      isImportant: false,
      parentUser: userId,
      isReply: false,
      parentChattingRoom: roomId,
      mentionedUsers: [],
      messageSeq: counter.messageSeq + 1,
      isNotice: true,
      childNotice: noticeId,
      createdAt: new Date().getTime(),
    });

    const userInfo = await userInfoModel({tenantFlag})
      .findOne({_id: userId}).select('userName jobTitle');
    const sysContent = `${userInfo.userName['ko']}님이 공지를 등록했습니다.`;
    const newSystemMessage = new TargetMessageModel({
      systemMessageType: 'notice',
      content: sysContent,
      isSystemMessage: true,
      parentChattingRoom: roomId,
      messageSeq: -1,
      createdAt: new Date().getTime(),
      translate: [
        {
          locale: 'en',
          text: `${userInfo.userName['en']}님이 공지를 등록했습니다.`,
        },
      ],
    });

    await newMessage.save();

    await Promise.all([
      newSystemMessage.save(),
      chattingRoomInfoModel({tenantFlag}).updateOne({_id: roomId}, {
        childNoticeMessage: noticeId,
        childLastMessage: newMessage._id,
      }),
      chattingMemberModel({tenantFlag}).updateOne({
        parentUser: userId, parentChattingRoom: roomId, isDeleted: false}, {
        lastCheckedMessageSeq: newMessage.messageSeq,
      }),
      // await TargetUserBadgeModel.updateOne({parentUser: userId}, {
      //   $inc: {unreadAlarms: 1},
      // }),
    ]);

    const [
      {roomName, isGroupChat, reName},
      members,
      {userName, jobTitle},
    ] = await Promise.all([
      targetRoomModel.findOne({_id: roomId})
        .select('roomName isGroupChat reName'),
      targetMemberModel
        .find({
          parentChattingRoom: roomId,
          $or: [
            {isDeleted: false},
            {isDeleted: true, isGroupChat: false},
          ],
        })
        .select('parentUser isGroupChat isDeleted roomName'),
      UserInfoModel.findOne({_id: userId})
        .select('userName jobTitle'),
    ]);
    const chattingRoomName = roomName;

    const tokens: any = [];
    const locales: any = [];
    const os: any = [];
    const roomNames: any = [];
    const badges: any = [];

    const memberInfo = members.map((participant: any) => {
      return participant.parentUser;
    });
    const memberInfoTmp = await userInfoModel({tenantFlag})
      .find({_id: {$in: memberInfo}})
      .select('userName.ko userName.en')
      .lean();

    const roomNameKo = memberInfoTmp.map((info: any) => {
      return info.userName.ko;
    }).join(',');
    const roomNameEn = memberInfoTmp.map((info: any) => {
      return info.userName.en;
    }).join(',');

    await Promise.all(members.map(async (member) => {
      if (member.parentUser.toString() !== userId) {
        if (!member.isGroupChat && member.isDeleted) {
          await chattingMemberModel({tenantFlag}).updateOne({parentUser: member.parentUser, parentChattingRoom: roomId}, {
            isDeleted: false,
          });
          // 나간 대화방 상대를 방에 입장 처리 - create_chatting_room 스트림 발생용
        }

        const pushTargets = await userSignInfoModel({tenantFlag})
          .find({
            parentUser: member.parentUser,
            $or: [{deviceType: 'android'}, {deviceType: 'ios'}],
            alarmOffChattingRooms: {
              $nin: [roomId],
            },
            usePushAlarm: true,
            useAlarmChatNotice: true,
          });
        const userStatus = await userStatusInfoModel({tenantFlag})
          .findOne({parentUser: member.parentUser})
          .select('pcStatus mobileStatus').lean();

        await TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
          $inc: {unreadChatMessages: 1},
        });

        // eslint-disable-next-line max-len
        await Promise.all(pushTargets.map(async ({pushToken, useAlarmAllowedTime, useEnUserInfo, deviceType, onlyAlarmWhenPCIsAbsence, timezoneOffset, alarmAllowedTime}) => {
          if (onlyAlarmWhenPCIsAbsence && userStatus!.hasOwnProperty('pcStatus') && userStatus!.hasOwnProperty('mobileStatus')) {
            // if (userStatus.pcStatus === 'online' && (userStatus.statusCode === '온라인' || userStatus.statusCode === '재택')) {
            // @ts-ignore
            if ((userStatus['pcStatus'] === UserStatusCode.ONLINE || userStatus['pcStatus'] === 'online') && userStatus['mobileStatus'] === UserStatusCode.ONLINE) {
              return;
            }
          }

          if (useAlarmAllowedTime) {
            if (!isValidAlarmTime(timezoneOffset, alarmAllowedTime.start, alarmAllowedTime.end)) {
              return;
            }
          }

          if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
            const badge = await getUserBadgePrimaryOnly(member.parentUser, tenantFlag);
            badges.push(badge);
            tokens.push(pushToken);
            const l = useEnUserInfo ? 'en' : 'ko';
            locales.push(l);
            os.push(deviceType);
            const rn = !isGroupChat ? `${userName[l]} ${jobTitle[l]}` :
              member.roomName.toString() === '' && !reName ? (useEnUserInfo ? roomNameEn : roomNameKo) :
                member.roomName.toString() !== '' ? member.roomName.toString() : chattingRoomName;

            roomNames.push(rn);
          }
        }));
      }

      // PP09260314-1503 알림센터 기획변경 반영
      //   const nam = new TargetAlarmModel({
      //     'type': 'chatting_notice',
      //     'parentUser': member.parentUser,
      //     'actionUser': userId,
      //     'detailId': noticeId,
      //     'chatRoomId': roomId,
      //     'chatMessageId': newMessage._id,
      //     'content': content,
      //     'createdAt': new Date().getTime(),
      //     'isRead': true,
      //   });
      //   await nam.save();
    }));

    if (tokens.length !== 0) {
      tokens.forEach((token: string, i: number) => {
        const notification = {
          title: roomNames[i]?.substring(0, 100),
          body: isGroupChat ? `${userName[locales[i] ?? 'ko']} ${jobTitle[locales[i] ?? 'ko']}: 공지사항을 등록하였습니다` : '공지사항을 등록하였습니다',
        };

        const msg: any = {
          data: {type: 'chatting_room', id: roomId.toString(), ...notification, badge: badges[i].toString()},
          token: token,
        };

        if (os[i] === 'android') {
          msg.android = {
            priority: 'HIGH',
          };
        }

        if (os[i] === 'ios') {
          msg.notification = notification;
          msg.apns = {
            payload: {
              aps: {
                sound: 'default',
                badge: badges[i],
              },
            },
          };
        }

        //admin.messaging().send(msg);
        pushIntegration(msg, false);
      });
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default renotifyChatNotice;
