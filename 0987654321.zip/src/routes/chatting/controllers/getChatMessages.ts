/* eslint-disable max-len */
import Koa from 'koa';

import chattingMessageModel from 'models/message/chatting_room_message';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import chatMessageEgModel from 'models/message/chatting_room_message_eg';
import chatVoteModel from 'models/message/chatting_room_message_vote';
import compareVersions from 'utils/string/compareVersions';
import mime from 'mime-types';
import {ENCKEYFORPARAM, ENCRYPT_APPVERSION} from 'constants/commonConstants';
import {decryptURL} from '../../../utils/cipher';

const getChatMessages = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    const versionInfo = ctx.headers['version-info'] as string ?? '';

    const {roomId, lastMessageId, reqMessageSeq} = ctx.request.query;

    // before populate
    chatMessageEgModel({tenantFlag});
    chatVoteModel({tenantFlag});


    //채팅방 나가기 했던 사용자는 나가기 했던 메세지 까지만 조회되도록
    const roomMemInfo = await chattingRoomMemberModel({tenantFlag})
      .findOne({parentUser: userId, parentChattingRoom: roomId});

    let messageSeq: number = (reqMessageSeq as any) | 0;
    let messageCnt: number = (messageSeq - parseInt(roomMemInfo.deletedMessageSeq)) - 1;
    // let messageCnt = 200;
    //메세지 최대 50개
    if (messageCnt > 50) messageCnt = 50;

    let chatMessages: any;

    if (messageCnt > 0) {
      chatMessages = await chattingMessageModel({tenantFlag})
        .find({
          parentChattingRoom: roomId,
          _id: {
            $lt: lastMessageId,
          },
        })
        .sort({createdAt: 'desc'})
        .limit(messageCnt)
        .populate([{
          path: 'childEngagement',
          select: 'R1 R2 R3 R4 R5 R6 R7 R8 R9',
        }, {
          path: 'replyOrigin',
          select: 'content parentUser isEmoticon files isNotice',
        }, {
          path: 'childVote',
          select: '-voteRecords',
        }]).lean();
      // console.log(`chatMessages  ${chatMessages}`);

      // 0.5.94보다 이전 버전이면 암호화URL에 대해 대체 메시지로 치환
      // TODO - 추후 압호화 버전으로 모든 사용자가 바뀌면 제거할 코드
      if (compareVersions(versionInfo, ENCRYPT_APPVERSION) < 0) {
        chatMessages = chatMessages.map((msg: any) => {
          if (msg.files.length > 0) {
            const urlTmp = msg.files[0].url;
            // const mimeType = msg.files[0].mimeType;

            if (!urlTmp.startsWith('https:')) {
              const filesTmp: any[] = [];
              msg.files.forEach((file: any) => {
                filesTmp.push({
                  ...file,
                  url: decryptURL(file.url, ENCKEYFORPARAM).url,
                });
              });
              msg.files = filesTmp;
              // msg.files[0].url = 'https://dev-file.lgmtalk.com/65a3799263f86d9c9023799d/chatting/67847617754004ae6a0e4fdc/images/1744874453455/blank.jpg';
              // msg.hasFiles = false;
              // if (msg.isEmoticon) {
              //   msg.content = msg.content + '\n<알림>\n해당 대화의 이모티콘은 현재 버전에서 표시할 수 없으므로, 최신 버전으로 업데이트해 주세요';
              //   msg.isEmoticon = false;
              // } else if (msg.isNotice) {
              //   msg.content = msg.content + '\n<알림>\n해당 공지에 첨부된 파일은 현재 버전에서 표시할 수 없으므로, 최신 버전으로 업데이트해 주세요';
              // } else if (mimeType.startsWith('image') || mimeType.startsWith('video')) {
              //   msg.content = '<알림>\n해당 이미지/비디오 파일은 현재 버전에서 표시할 수 없으므로, 최신 버전으로 업데이트해 주세요';
              // } else {
              //   msg.content = '<알림>\n해당 파일은 현재 버전에서 표시할 수 없으므로, 최신 버전으로 업데이트해 주세요';
              // }
              // msg.files = [];
            }
          }
          return msg;
        });
      }
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        chatMessages,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getChatMessages;
