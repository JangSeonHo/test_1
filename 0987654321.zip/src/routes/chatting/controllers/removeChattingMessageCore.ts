import mongoose, { CallbackError } from 'mongoose';
import { DeleteResult } from 'mongodb'; // mongodb 모듈에서 DeleteResult를 가져옵니다.
import chatMessageModel from 'models/message/chatting_room_message';

const removeChattingMessageCore = async () => {
  try {
    const targetChatMessageModel = chatMessageModel({ tenantFlag: "nmp" });

    const nowDate = new Date().getTime();

    // Date 객체 생성
    const currentDate = new Date(nowDate);

    // 3개월 전으로 이동
    currentDate.setMonth(currentDate.getMonth() - 3);

    // 3개월 전의 유닉스 타임스탬프
    const threeMonthsAgoTimestamp = currentDate.getTime();

    let deleteCount = 0;

    //대화내용 컬렉션(디비정보) 데이터 삭제
    // targetChatMessageModel.deleteMany(
    //   { createdAt: { $lt: threeMonthsAgoTimestamp } },
    //   (err: CallbackError, result: DeleteResult) => {
    //     if (err) {
    //       console.error('[removeChattingMessage] >>> 데이터 삭제 중 오류 발생:', err);
    //     } else {
    //       const currentTime = new Date().toLocaleString('ko-KR', {
    //         year: 'numeric',
    //         month: 'long',
    //         day: 'numeric',
    //         hour: 'numeric',
    //         minute: 'numeric',
    //         second: 'numeric',
    //       });
    //       deleteCount = result.deletedCount;
    //       console.log(`[removeChattingMessage] ::: ${currentTime} - ${result.deletedCount} 개의 데이터가 삭제되었습니다.`);
    //     }
    // });

    return {
      success: true,
      deletedCount: deleteCount,
    };
  } catch (err) {
    console.log(err);
    return {
      success: false,
      error: 'internal server error',
    };
  }
}

export default removeChattingMessageCore;