import Koa from 'koa';
import chatNoticeModel from 'models/message/chatting_room_message_notice';
import compareVersions from '../../../utils/string/compareVersions';
import {
  ENCKEYFORPARAM,
  ENCRYPT_APPVERSION,
} from '../../../constants/commonConstants';
import {decryptURL} from '../../../utils/cipher';

const getChatNotice = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const versionInfo = ctx.headers['version-info'] as string ?? '';

    const {noticeId} = ctx.query;

    const TargetMessageModel = chatNoticeModel({tenantFlag});

    let notice = await TargetMessageModel.findOne({_id: noticeId})
      .populate({
        path: 'parentUser',
        // eslint-disable-next-line max-len
        select: 'userName profileImage jobTitle parentCompany parentDepartment',
        populate: [{
          path: 'parentCompany',
          select: 'companyName',
        }, {
          path: 'parentDepartment',
          select: 'departmentName',
        }],
      }).lean();

    // TODO - 추후 압호화 버전으로 모든 사용자가 바뀌면 제거할 코드
    if (compareVersions(versionInfo, ENCRYPT_APPVERSION) < 0) {
      if (!!notice) {
        notice = {
          ...notice,
          // @ts-ignore
          files: notice['files'].map((file: any) => ({
            ...file,
            url: !file.url.startsWith('https:') ? decryptURL(file.url, ENCKEYFORPARAM).url : file.url
          })),
        };
      }
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        notice,
      },
    };
  } catch (err) {
    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  }
};

export default getChatNotice;
