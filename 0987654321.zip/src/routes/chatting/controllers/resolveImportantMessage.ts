import Koa from 'koa';

import chatMessageModel from 'models/message/chatting_room_message';

const resolveImportantMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const {messageId} = ctx.request.body;

    const TargetChatMessageModel = chatMessageModel({tenantFlag});

    const updatedAt = new Date().getTime();
    await TargetChatMessageModel.updateOne({
      _id: messageId,
    }, {
      isImportant: false,
      updatedAt,
    });

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default resolveImportantMessage;
