import Koa from 'koa';
import crypto from 'crypto';
import userInfoModel from 'models/account/user_info';
import encryptionKeyModel from 'models/encryption/encryption_key';
import { publicKey, privateKey } from '../../../utils/cipher'

const getEncKey = async (ctx: Koa.Context) => {
  try {

    const {email, pubKey, authKey} = ctx.request.body;
    const tenantFlag = ctx.response.get('tenantFlag');

    const encryptByClientPubKey = (message: string) => {
      return crypto.publicEncrypt(pubKey, Buffer.from(message, 'utf8')).toString('base64');
    };
         
    const decryptByPubKey = (message: string) => {
      return crypto.publicDecrypt(pubKey, Buffer.from(message, 'base64')).toString();
    };

    const targetUserModel = userInfoModel({tenantFlag});
    // Step1.Get random stored in the userInfo collection.

    const serverAuthKey = await targetUserModel.findOne({email: email}).select('authKey');

    // Step2.Decrypts the random encrypted with the private key.
    const clientAuthKey = decryptByPubKey(authKey);

    // Compares whether data of a Step1 and Step2 match
    if(serverAuthKey.authKey !== clientAuthKey) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        errorCode: '0001',
        errorMsg: 'authKey does not match.',
      };
      return;
    }

    // Get AES-CBC Encryption Key, IV
    const targetEncryptionKeyModel = encryptionKeyModel({tenantFlag});
    const encKey = await targetEncryptionKeyModel.findOne({ tenantFlag: tenantFlag });
    const key = `${encKey.encryptionKey}${encKey.iv}`;

    // The symmetric key for AES-CBC encryption and decryption is encrypted with the public key transfered from the client.
    const symmetricKey = encryptByClientPubKey(key);

    ctx.status = 200;
    ctx.body = {
      success: true,
      symmetricKey : symmetricKey
    };

  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default getEncKey;
