/* eslint-disable new-cap */
/* eslint-disable max-len */
import Koa from 'koa';

import chattingRoomMessageModel, {chatRoomMsgModelPrimaryOnly} from 'models/message/chatting_room_message';
import chattingCounterModel from 'models/message/chatting_counter';
import chattingRoomMemberModel, {roomMemberModelPrimaryOnly} from 'models/message/chatting_room_member';
import chattingRoomInfoModel, {roomInfoModelPrimaryOnly} from 'models/message/chatting_room_info';
import companyInfoModel, {companyModelPrimaryOnly} from 'models/company/company_company_info';
import departmentInfoModel, {deptModelPrimaryOnly} from 'models/company/company_department_info';
import userInfoModel, {userInfoModelPrimaryOnly} from 'models/account/user_info';
import {userStatusModelPrimaryOnly} from 'models/account/user_status_info';
import {console} from 'inspector';

const UCAPChattingRoomTransfer = async (ctx: Koa.Context) => {
  try {

    const tenantFlag = ctx.response.get('tenantFlag');
    const body: any = ctx.request.body;
    const {members: uids, roomId, roomName, creator} = body;
    let {reName} = body;

    const userModel = userInfoModel({tenantFlag});

    // 채팅방 생성자 creator ID 조회
    const userDoc = await userModel.findOne({ email: creator }).select('_id');
    const userId = userDoc._id.toString();

    const emailList: any = [];
    uids.forEach((id: string) => {
      if (!emailList.includes(id)) {
        emailList.push(id.toLocaleLowerCase());
      }
    });

    const userIdArrayList = await userModel.aggregate([ { $match: { email: { $in: emailList } } },
                                                        { $sort: { _id: 1 } },
                                                        { $group: { _id: '$email', doc: { $first: '$$ROOT' } }},
                                                        { $project: { _id: 0 } }]);

    const userIdList = userIdArrayList.map(item => ({ _id: item.doc._id }));

    console.log("userIdList : " + JSON.stringify(userIdList))

    if(userIdList.length < 2) {
      ctx.status = 200;
      ctx.body = {
        'success': false,
        'data': {
          'error':'대화방 참여자는 2명이상 이어야 합니다.',
        },
      };
      return;
    }

    // ucapRoomId 체크
    if(!roomId || roomId.trim() === '') {
      ctx.status = 200;
      ctx.body = {
        'success': false,
        'data': {
          'error':'roomId가 존재하지 않습니다.',
        },
      };
      return;
    }

    const userIds: any = [];
    userIdList.map((user: any) => {
      userIds.push(user._id.toString());
    })

    if (reName == "undefined" || reName == null) {
      reName = false;
    }

    const ucapRoomId = roomId;

    const isGroupChat = userIds.length > 1;

    const targetChattingRoomModel = chattingRoomInfoModel({tenantFlag});
    const targetChattingRoomMemberModel = chattingRoomMemberModel({tenantFlag});

    // 내 채팅방
    const isMyChat = userIds.length === 1 && userIds[0] === userId;

    // 이미 New메신저로 이관된 대화방인지 체크
    const mMessengerRoomId = await targetChattingRoomModel.findOne({ ucapRoomId: ucapRoomId }).select('_id');

    if(mMessengerRoomId) {

      // get existing members in the chat room
      const existingMembers = await targetChattingRoomMemberModel
        .find({ parentChattingRoom:  mMessengerRoomId })
        .select('parentUser')
        .lean();

      let memberCnt = existingMembers.length;

      // existingMembers에서 parentUser 값을 추출하여 Set으로 변환
      const parentUserIds = new Set(existingMembers.map(item => item.parentUser.toString()));

      // userIdList에서 parentUserIds에 없는 값만 필터링
      const newMembers = userIdList.filter(item => !parentUserIds.has(item._id.toString()));  

      // add new member 
     if (newMembers.length > 0) {
        // 신규 멤버 추가
        await targetChattingRoomMemberModel.insertMany(
          newMembers.map(id => ({
            parentUser: id,
            parentChattingRoom: mMessengerRoomId,
            isMyChat,
            isGroupChat,
            joinedAt: new Date().getTime(),
          }))
        );
        // 추가된 신규 멤버 수 Update
        memberCnt += newMembers.length;
        await targetChattingRoomModel.updateOne({ ucapRoomId: ucapRoomId }, {'totalRoomMembers': memberCnt} );
      }

      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          'roomId': mMessengerRoomId._id ,
          'msg':'이미 New메신저로 이관된 대화방입니다. 새로운 멥버가 있다면 추가되었습니다.',
        },
      };
      return;
    }

    // 개인 채팅방 만약에 이미 있으면
    if (!isGroupChat) {
      const beforeRoom: any = await targetChattingRoomModel.findOne({
        isMyChat,
        totalRoomMembers: isMyChat ? 1 : 2,
        $and: [
          {
            childUsers: {
              $in: [userId],
            },
          },
          {
            childUsers: {
              $in: [userIds[0]],
            },
          },
        ],
      }).select('_id');

      if (beforeRoom !== null) {
        await chattingRoomMemberModel({tenantFlag}).updateOne({parentUser: userId, parentChattingRoom: beforeRoom._id.toString()}, {
          isDeleted: false,
        });
        const newRoom = await chattingRoomMemberModel({tenantFlag}).findOne({parentUser: userId, parentChattingRoom: beforeRoom._id.toString()})
          .populate({
            path: 'parentChattingRoom',
            populate: [
              {
                path: 'childUsers',
                select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
                populate: [{
                  path: 'childStatusInfo',
                  select: '-parentUser -__v -_id',
                }, {
                  path: 'parentCompany',
                  select: 'companyName',
                }, {
                  path: 'parentDepartment',
                  select: 'departmentName',
                }],
              },
              {
                path: 'childLastMessage',
              },
              {
                path: 'childNoticeMessage',
              },
            ],
          });

        ctx.status = 200;
        ctx.body = {
          'success': true,
          'data': {
            newChattingRoom: newRoom,
          },
        };

        return;
      }
    }

    const totalRoomMembers = isMyChat ?
      1 :
      userIds.length; // mtalk@lgcns.com 삭제

    // 새로운 채팅방 생성
    const newChattingRoom: any = new targetChattingRoomModel({
      ucapRoomId,
      isGroupChat,
      isMyChat,
      totalRoomMembers,
      createdAt: new Date().getTime(),
      reName,
    });

    if (isGroupChat) {
      newChattingRoom.roomName = roomName;
    } else if (isMyChat) {
      newChattingRoom.childUsers = [userId];
    } else {
      newChattingRoom.childUsers = [...userIds, userId];
    }

    const targetChattingCounterModel = chattingCounterModel({tenantFlag});
    const newChattingCounter: any = new targetChattingCounterModel({
      childChattingRoom: newChattingRoom._id,
      messageSeq: 0,
    });

    newChattingRoom.childChattingCounter = newChattingCounter._id;

    // 내 채팅방 예외 처리
    const users = [...userIds];
    if (!users.includes(userId)) {
      users.push(userId);
    }

    await Promise.all([
      newChattingRoom.save(),
      newChattingCounter.save(),
      targetChattingRoomMemberModel.insertMany(users.map((id) => ({
        parentUser: id,
        parentChattingRoom: newChattingRoom._id,
        isMyChat,
        isGroupChat,
        joinedAt: new Date().getTime(),
      }))),
    ]);

    // M-메신저의 채팅룸명과 동일한 이름으로 New메신저에 이관
    reName = true; 
    await Promise.all([
      // 1. chatting_room_infos 컬렉션에 채팅룸명 변경
      targetChattingRoomModel.updateOne({_id: newChattingRoom._id}, {
        roomName, 
        reName,
      }),

      // 2. chatting_room_members 컬렉션에 채팅룸명 변경
      targetChattingRoomMemberModel.updateOne({parentChattingRoom: newChattingRoom._id}, {
        roomName,
      }),
    ]);

    if (isGroupChat) {
      const targetUserModel = userInfoModel({tenantFlag});
      const tus = userIds.length > 10 ? userIds.slice(0, 10) : [...userIds];
      const users = await Promise.all([
        targetUserModel.findOne({_id: userId}).select('userName'),
        ...tus.map(async (tu: string) => await targetUserModel.findOne({_id: tu}).select('userName')),
      ]);

      let content = `${users[0]['userName']['ko']}님이 `;
      let contentEn = `${users[0]['userName']['en']}님이 `;
      for (let i = 1; i < users.length; i++) {
        content += `${users[i]['userName']['ko']}님`;
        contentEn += `${users[i]['userName']['en']}님`;
        if (i !== users.length - 1) {
          content += ', ';
          contentEn += ', ';
        }
      }

      if (userIds.length > 10) {
        content += ` 외 ${userIds.length - 10}명을 초대했습니다`;
        contentEn += ` 외 ${userIds.length - 10}명을 초대했습니다`;
      } else {
        content += '을 초대했습니다';
        contentEn += '을 초대했습니다';
      }

      const targetMessageModel = chattingRoomMessageModel({tenantFlag});
      const systemMessage = new targetMessageModel({
        systemMessageType: 'join',
        content,
        isSystemMessage: true,
        parentChattingRoom: newChattingRoom._id,
        messageSeq: -1,
        createdAt: new Date().getTime(),
        translate: [
          {
            locale: 'en',
            text: contentEn,
          },
        ],
      });

      // [성능튜닝] 하기 소스는 성능향상을 위해 수정됨. 
      // await systemMessage.save();
      systemMessage.save();
    }

    // for populate
    companyInfoModel({tenantFlag});
    departmentInfoModel({tenantFlag});
    //

    chatRoomMsgModelPrimaryOnly({tenantFlag});
    roomInfoModelPrimaryOnly({tenantFlag});
    companyModelPrimaryOnly({tenantFlag});
    deptModelPrimaryOnly({tenantFlag});
    userInfoModelPrimaryOnly({tenantFlag});
    userStatusModelPrimaryOnly({tenantFlag});
    const newRoom = await roomMemberModelPrimaryOnly({tenantFlag}).findOne({parentUser: userId, parentChattingRoom: newChattingRoom._id})
      .populate({
        path: 'parentChattingRoom',
        populate: [
          {
            path: 'childUsers',
            select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
            populate: [{
              path: 'childStatusInfo',
              select: '-parentUser -__v -_id',
            }, {
              path: 'parentCompany',
              select: 'companyName',
            }, {
              path: 'parentDepartment',
              select: 'departmentName',
            }],
          },
          {
            path: 'childLastMessage',
          },
          {
            path: 'childNoticeMessage',
          },
        ],
      });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        'roomId': newChattingRoom._id ,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default UCAPChattingRoomTransfer;