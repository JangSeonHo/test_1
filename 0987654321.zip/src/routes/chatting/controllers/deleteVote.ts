import Koa from 'koa';

import chatMessageVoteModel from 'models/message/chatting_room_message_vote';

const deleteVote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const {voteId} = ctx.request.body;

    const MessageVoteModel = chatMessageVoteModel({tenantFlag});

    await MessageVoteModel.deleteOne({_id: voteId});

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default deleteVote;
