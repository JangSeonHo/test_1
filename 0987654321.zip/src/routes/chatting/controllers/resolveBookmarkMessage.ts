import Koa from 'koa';

import messageSpModel from 'models/message/chatting_room_message_sp';

const resolveBookmarkMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {roomId, messageId} = ctx.request.body;

    const MessageSpModel = messageSpModel({tenantFlag});

    await MessageSpModel.updateOne({
      parentUser: userId,
      parentChattingRoom: roomId,
      type: 'bookmark',
    }, {
      $pullAll: {
        messages: [messageId],
      },
    });

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 200;
    ctx.body = {
      success: false,
    };
  }
};

export default resolveBookmarkMessage;
