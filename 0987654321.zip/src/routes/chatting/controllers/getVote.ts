import Koa from 'koa';

import chatMessageVoteModel from 'models/message/chatting_room_message_vote';
import compareVersions from '../../../utils/string/compareVersions';
import {
  ENCKEYFORPARAM,
  ENCRYPT_APPVERSION,
} from '../../../constants/commonConstants';
import {decryptURL} from '../../../utils/cipher';

function renameKeys(obj: any, keyMap: any) {
  return Object.keys(obj).reduce((acc, key) => {
    const newKey = keyMap[key] || key;
    // @ts-ignore
    acc[newKey] = obj[key];
    return acc;
  }, {});
}

const getVote = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    const versionInfo = ctx.headers['version-info'] as string ?? '';

    const {voteId} = ctx.query;

    const MessageVoteModel = chatMessageVoteModel({tenantFlag});

    let vote = await MessageVoteModel
      .findOne({_id: voteId})
      .populate({
        path: 'parentUser',
        select: 'userName jobTitle parentDepartment',
        populate: [
          {
            path: 'parentDepartment',
            select: 'departmentName',
          },
        ],
      }).lean();

    // @ts-ignore
    if (!!vote && !!vote['anonymousVote']) {
      const keyMap = {};
      // @ts-ignore
      Object.entries(vote['voteRecords']).forEach(([uid, record], idx) => {
        if (String(uid) !== userId) {
          // @ts-ignore
          keyMap[String(uid)] = `anonymous${idx}`;
        }
      });
      // @ts-ignore
      vote['voteRecords'] = renameKeys(vote['voteRecords'], keyMap);
    }

    // TODO - 추후 압호화 버전으로 모든 사용자가 바뀌면 제거할 코드
    if (compareVersions(versionInfo, ENCRYPT_APPVERSION) < 0) {
      if (!!vote) {
        vote = {
          ...vote,
          // @ts-ignore
          voteItems: vote['voteItems'].map((voteItem: any) => {
            if (!!voteItem.image) {
              return {
                ...voteItem,
                image: {
                  ...voteItem.image,
                  url: !voteItem.image.url.startsWith('https:') ? decryptURL(voteItem.image.url, ENCKEYFORPARAM).url : voteItem.image.url
                }
              };
            } else {
              return voteItem;
            }
          }),
        };
      }
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        vote,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default getVote;
