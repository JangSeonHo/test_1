/* eslint-disable max-len */
import Koa from 'koa';

import userSignInfoModel from 'models/account/user_sign_info';

const offChattingAlarm = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const accessToken = ctx.headers['access-token'];

    const body: any = ctx.request.body;
    const {roomId, useAlarm} = body;

    const targetModel = userSignInfoModel({tenantFlag});

    if (!useAlarm) {
      await targetModel.updateOne({parentUser: userId, accessToken}, {
        $push: {
          'alarmOffChattingRooms': roomId,
        },
      });
    } else {
      await targetModel.updateOne({parentUser: userId, accessToken}, {
        $pull: {
          'alarmOffChattingRooms': roomId,
        },
      });
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default offChattingAlarm;
