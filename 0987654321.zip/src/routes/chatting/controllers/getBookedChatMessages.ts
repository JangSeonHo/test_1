/* eslint-disable max-len */
import Koa from 'koa';

import bookedMessageModel from 'models/message/chatting_room_booked_message';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import userStatusInfoModel from 'models/account/user_status_info';
import userInfoModel from 'models/account/user_info';
import departmentModel from 'models/company/company_department_info';
import companyModel from 'models/company/company_company_info';



const getBookedChatMessages = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {page = 1, itemsPerPage = 20, roomId} = ctx.query;

    const requestPage = Number(page);
    const requestItemsPerPage = Number(itemsPerPage);

    const TargetBookedMessageModel = bookedMessageModel({tenantFlag});

    const query: any = {parentUser: userId};
    if (roomId !== '') {
      query['parentChattingRoom'] = roomId;
    }

    // for population
    userStatusInfoModel({tenantFlag});
    userInfoModel({tenantFlag});
    departmentModel({tenantFlag});
    companyModel({tenantFlag});
    //

    const bookedMessages: any = await TargetBookedMessageModel
      .find(query)
      .sort({createdAt: 'desc'})
      .skip((requestPage - 1) * requestItemsPerPage)
      .limit(requestItemsPerPage)
      .populate({
        path: 'parentChattingRoom',
        populate: [{
          path: 'childUsers',
          select: 'childStatusInfo parentDepartment parentCompany userName jobTitle _id profileImage',
          populate: [
            {path: 'childStatusInfo', select: 'statusCode pcStatus mobileStatus'},
            {path: 'parentDepartment', select: 'departmentName'},
            {path: 'parentCompany', select: 'companyName'},
          ],
        }],
      });

    const bookedMessagesAdded = await Promise.all(bookedMessages.map(async (m: any) => {
      if (m['parentChattingRoom']['isGroupChat']) {
        const roomThumbnails = await chattingRoomMemberModel({tenantFlag}).find({parentChattingRoom: m['parentChattingRoom']['_id'], isDeleted: false})
          .select('parentUser')
          .populate({
            path: 'parentUser',
            select: 'profileImage',
          })
          .limit(4);

        const {roomName} = await chattingRoomMemberModel({tenantFlag})
          .findOne({parentChattingRoom: m['parentChattingRoom']['_id'], isDeleted: false, parentUser: userId})
          .select('roomName');

        return {...m.toObject(), roomThumbnails: roomThumbnails.map((m: any) => m['parentUser']['profileImage']), roomName};
      }

      return m;
    }));

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {bookedMessages: bookedMessagesAdded},
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default getBookedChatMessages;
