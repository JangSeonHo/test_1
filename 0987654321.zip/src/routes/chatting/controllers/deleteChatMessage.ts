import Koa from 'koa';

import chatMessageModel from 'models/message/chatting_room_message';
// eslint-disable-next-line max-len
import chatMemberModel from 'models/message/chatting_room_member';

const deleteChatMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {messageId, onlyMe = false, roomId = ''} = ctx.request.body;

    const TargetChatMessageModel = chatMessageModel({tenantFlag});
    const TargetChatMemberModel = chatMemberModel({tenantFlag});

    if (onlyMe) {
      await TargetChatMemberModel.updateOne(
        {parentUser: userId, parentChattingRoom: roomId, isDeleted: false},
        {$push: {deletedMessages: messageId}},
      );
    } else {
      const updatedAt = new Date().getTime();
      await TargetChatMessageModel.updateOne({
        parentUser: userId,
        _id: messageId,
      }, {
        isDeleted: true,
        updatedAt,
      });
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default deleteChatMessage;
