import Koa from 'koa';
import mime from 'mime-types';

const uploadVoteImages = async (ctx: Koa.Context) => {
  try {
    const originFiles = Array.prototype.slice.call(ctx.files);
    const files: any = [];
    originFiles.forEach((f: any) => {
      const fn = Buffer.from(f.originalname, 'latin1').toString('utf-8');

      const path = process.env.SERVER_ENV === 'LG_BETA' ?
        f.path.replaceAll('/mnt/efs/static/', '') :
        f.path.substring(7);

      files.push({
        url: path, // static/ 제거
        fileName: fn,
        size: f.size,
        mimeType: mime.lookup(fn),
      });
    });

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        files,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
    };
  }
};

export default uploadVoteImages;
