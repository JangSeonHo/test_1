import Koa from 'koa';

import alarmModel from 'models/alarm/alarm';
import chatMessageModel from 'models/message/chatting_room_message';
import userBadgeModel from 'models/account/user_badge';

const setReminderMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {roomId, messageId, alertTime} = ctx.request.body;

    const AlarmModel = alarmModel({tenantFlag});
    const ChatMessageModel = chatMessageModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    const {content, parentUser} = await ChatMessageModel
      .findOne({_id: messageId});

    const nm = new AlarmModel({
      type: 'reminder',
      chatRoomId: roomId,
      chatMessageId: messageId,
      parentUser: userId,
      actionUser: parentUser,
      content,
      createdAt: new Date().getTime(),
      alertTime,
    });

    await Promise.all([
      TargetUserBadgeModel.updateOne({parentUser: userId}, {
        $inc: {unreadAlarms: 1},
      }),
      nm.save(),
    ]);

    ctx.status = 200;
    ctx.body = {
      success: true,
      data: {
        reminder: nm,
      },
    };
  } catch (err) {
    ctx.status = 200;
    ctx.body = {
      success: false,
    };
  }
};

export default setReminderMessage;
