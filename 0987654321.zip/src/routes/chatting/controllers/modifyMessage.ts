/* eslint-disable max-len */
import Koa from 'koa';

import chattingMessageModel from 'models/message/chatting_room_message';

const modifyMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const body: any = ctx.request.body;
    const {content, roomId, messageId} = body;

    const targetMessageModel = chattingMessageModel({tenantFlag});

    const message = targetMessageModel.findOne({parentChattingRoom: roomId, parentUser: userId, _id: messageId});

    if (message === null) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        error: 'internal server error',
      };
    }

    await targetMessageModel.updateOne({parentChattingRoom: roomId, parentUser: userId, _id: messageId}, {
      content,
      updatedAt: new Date().getTime(),
    });

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default modifyMessage;
