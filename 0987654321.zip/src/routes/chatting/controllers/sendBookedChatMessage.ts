/* eslint-disable max-len */
import Koa from 'koa';
import admin from 'firebase-admin';

// eslint-disable-next-line max-len
import bookedChatMessageModel from 'models/message/chatting_room_booked_message';
import chatMessageModel from 'models/message/chatting_room_message';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import chattingCounterModel from 'models/message/chatting_counter';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';
import userBadgeModel from 'models/account/user_badge';
import userStatusModel from 'models/account/user_status_info';
import getUserBadge, {getUserBadgePrimaryOnly} from 'utils/account/getUserBadge';
import isValidAlarmTime from 'utils/alarm/isValidAlarmTime';
import userStatusInfoModel from '../../../models/account/user_status_info';
import {UserStatusCode} from '../../../constants/commonConstants';
import { getMessageTranslations } from 'utils/translate/getMessageTranslations';

import pushIntegration from 'utils/push/pushIntegration';
import chatRoomInfoModel from '../../../models/message/chatting_room_info';

const sendBookedChatMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {bookedMessageId} = ctx.request.body;

    const TargetBookedMessageModel = bookedChatMessageModel({tenantFlag});
    const TargetChatMessageModel = chatMessageModel({tenantFlag});
    const TargetCounterModel = chattingCounterModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    const {
      content,
      mentionedUsers,
      parentChattingRoom,
    } = await TargetBookedMessageModel.findOne({
      _id: bookedMessageId,
      parentUser: userId});

    const counter = await TargetCounterModel.findOneAndUpdate(
      {childChattingRoom: parentChattingRoom},
      {
        $inc: {messageSeq: 1},
      });

    const newMessage = new TargetChatMessageModel({
      parentChattingRoom,
      parentUser: userId,
      content,
      mentionedUsers,
      messageSeq: counter.messageSeq + 1,
      createdAt: new Date().getTime(),
    });

    if (!!content) {
      const translations = await getMessageTranslations(content, parentChattingRoom, userId, tenantFlag);
      newMessage.translate = translations.translate;
      newMessage.recvTranslate = translations.recvTranslate;
    } else {
      newMessage.translate = [];
      newMessage.recvTranslate = [];
    } // 빈 content일 경우 번역API 호출 skip

    await Promise.all([
      newMessage.save(),
      chattingRoomInfoModel({tenantFlag}).updateOne({_id: parentChattingRoom}, {
        childLastMessage: newMessage._id,
      }),
      TargetBookedMessageModel.deleteOne({_id: bookedMessageId,
        parentUser: userId}),
      chattingRoomMemberModel({tenantFlag}).updateOne({parentChattingRoom, parentUser: userId, isDeleted: false}, {
        lastCheckedMessageSeq: newMessage.messageSeq,
      }),
    ]);

    const [
      {roomName, isGroupChat, reName},
      members,
      {userName, jobTitle},
    ] = await Promise.all([
      chatRoomInfoModel({tenantFlag}).findOne({_id: parentChattingRoom})
        .select('roomName isGroupChat reName'),
      chattingRoomMemberModel({tenantFlag})
        .find({
          parentChattingRoom: parentChattingRoom,
          $or: [
            {isDeleted: false},
            {isDeleted: true, isGroupChat: false},
          ],
        })
        .select('parentUser isGroupChat isDeleted roomName'),
      userInfoModel({tenantFlag})
        .findOne({_id: userId})
        .select('userName jobTitle'),
    ]);
    const chattingRoomName = roomName;

    const tokens: any = [];
    const locales: any = [];
    const os: any = [];
    const roomNames: any = [];
    const badges: any = [];

    const memberInfo = members.map((participant: any) => {
      return participant.parentUser;
    });
    const memberInfoTmp = await userInfoModel({tenantFlag})
      .find({_id: {$in: memberInfo}})
      .select('userName.ko userName.en')
      .lean();

    const roomNameKo = memberInfoTmp.map((info: any) => {
      return info.userName.ko;
    }).join(',');
    const roomNameEn = memberInfoTmp.map((info: any) => {
      return info.userName.en;
    }).join(',');

    await Promise.all(members.map(async (member) => {
      if (member.parentUser.toString() !== userId) {
        if (!member.isGroupChat && member.isDeleted) {
          await chattingRoomMemberModel({tenantFlag}).updateOne({parentUser: member.parentUser, parentChattingRoom: parentChattingRoom}, {
            isDeleted: false,
          });
        }

        await TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
          $inc: {unreadChatMessages: 1},
        });

        const pushTargets = await userSignInfoModel({tenantFlag})
          .find({
            parentUser: member.parentUser,
            $or: [{deviceType: 'android'}, {deviceType: 'ios'}],
            alarmOffChattingRooms: {
              $nin: [parentChattingRoom],
            },
          });
        const userStatus = await userStatusInfoModel({tenantFlag})
          .findOne({parentUser: member.parentUser})
          .select('pcStatus mobileStatus').lean();

        await Promise.all(pushTargets.map(async ({pushToken, usePushAlarm, useAlarmChatMessage, useAlarmAllowedTime,
                                                   useEnUserInfo, deviceType, onlyAlarmWhenPCIsAbsence, timezoneOffset, alarmAllowedTime}) => {
          if (onlyAlarmWhenPCIsAbsence && userStatus!.hasOwnProperty('pcStatus') && userStatus!.hasOwnProperty('mobileStatus')) {
            // if (userStatus.pcStatus === 'online' && (userStatus.statusCode === '온라인' || userStatus.statusCode === '재택')) {
            // @ts-ignore
            if ((userStatus['pcStatus'] === UserStatusCode.ONLINE || userStatus['pcStatus'] === 'online') && userStatus['mobileStatus'] === UserStatusCode.ONLINE) {
              return;
            }
          }

          if (!usePushAlarm) {
            return;
          }

          if (!useAlarmChatMessage) {
            return;
          }

          if (useAlarmAllowedTime) {
            if (!isValidAlarmTime(timezoneOffset, alarmAllowedTime.start, alarmAllowedTime.end)) {
              return;
            }
          }

          if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
            const badge = await getUserBadgePrimaryOnly(member.parentUser, tenantFlag);
            badges.push(badge);
            tokens.push(pushToken);
            const l = useEnUserInfo ? 'en' : 'ko';
            locales.push(l);
            os.push(deviceType);
            const rn = !isGroupChat ? `${userName[l]} ${jobTitle[l]}` :
              member.roomName.toString() === '' && !reName ? (useEnUserInfo ? roomNameEn : roomNameKo) :
                member.roomName.toString() !== '' ? member.roomName.toString() : chattingRoomName;

            roomNames.push(rn);
          }
        }));

        if (tokens.length !== 0) {
          tokens.forEach((token: string, i: number) => {
            const body = isGroupChat ? `${userName[locales[i] ?? 'ko']} ${jobTitle[locales[i] ?? 'ko']}: ${content}` : content;
            const notification = {
              title: roomNames[i]?.substring(0, 100),
              body: body.substring(0, 100),
            };

            const msg: any = {
              data: {
                type: 'chatting_room',
                id: parentChattingRoom.toString(),
                ...notification,
                badge: badges[i].toString(),
              },
              token: token,
            };

            if (os[i] === 'android') {
              msg.android = {
                priority: 'HIGH',
              };
            }

            if (os[i] === 'ios') {
              msg.notification = notification;
              msg.apns = {
                payload: {
                  aps: {
                    sound: 'default',
                    badge: badges[i],
                  },
                },
              };
            }

            //admin.messaging().send(msg);
            pushIntegration(msg, false);
          });
        }
      }
    }));

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      suces: false,
    };
  }
};

export default sendBookedChatMessage;
