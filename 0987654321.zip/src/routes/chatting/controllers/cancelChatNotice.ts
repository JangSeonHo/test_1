import Koa from 'koa';
import chatRoomModel from 'models/message/chatting_room_info';

const cancelChatNotice = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const {roomId, messageId} = ctx.request.body as any;

    const TargetRoomModel = chatRoomModel({tenantFlag});

    const roomInfo = await TargetRoomModel.findOne({_id: roomId});
    if (roomInfo.childNoticeMessage !== null) {
      if (String(roomInfo.childNoticeMessage) === messageId) {
        roomInfo.childNoticeMessage = null;
        await roomInfo.save();
      }
    }

    ctx.status = 200;
    ctx.body = {
      success: false,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default cancelChatNotice;
