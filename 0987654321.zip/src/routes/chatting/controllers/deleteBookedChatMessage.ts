import Koa from 'koa';

import bookedMessageModel from 'models/message/chatting_room_booked_message';

const deleteBookedChatMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {bookedMessageId} = ctx.request.body;

    const TargetBookedMessageModel = bookedMessageModel({tenantFlag});

    await TargetBookedMessageModel.deleteOne({
      _id: bookedMessageId,
      parentUser: userId,
    });

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default deleteBookedChatMessage;
