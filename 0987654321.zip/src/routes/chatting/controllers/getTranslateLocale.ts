/* eslint-disable max-len */
import Koa from 'koa';
import mongoose from 'mongoose';
import chattingTranslationLanguageModel from 'models/message/chatting_translation_language';
import chattingRoomTranslationInfoModel from 'models/message/chatting_room_translation_info';

const getTranslateLocale = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const {userId, roomId} = ctx.request.body;
    const currentTime = new Date().getTime();

    if (!mongoose.Types.ObjectId.isValid(userId) || !mongoose.Types.ObjectId.isValid(roomId)) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };
      return;
    }

    const chattingRoomTranslationInfo = await chattingRoomTranslationInfoModel({tenantFlag})
      .findOne({
        parentUser: userId,
        parentChattingRoom: roomId,
      })
      .select('-_id sendLocale isSendEnable recvLocale isRecvEnable lastMessageSeq');

    ctx.status = 200;
    ctx.body = {
      success: true,
      sendLocale: chattingRoomTranslationInfo?.sendLocale ?? '',
      isSendEnable: chattingRoomTranslationInfo?.isSendEnable ?? false,
      recvLocale: chattingRoomTranslationInfo?.recvLocale ?? '',
      isRecvEnable: chattingRoomTranslationInfo?.isRecvEnable ?? false,
      lastMessageSeq: chattingRoomTranslationInfo?.lastMessageSeq ?? -1,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getTranslateLocale;
