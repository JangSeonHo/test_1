/* eslint-disable max-len */
import Koa from 'koa';
import mime from 'mime-types';
import admin from 'firebase-admin';

import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';

import chatMessageModel from 'models/message/chatting_room_message';
import chatCounterModel from 'models/message/chatting_counter';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import userBadgeModel from 'models/account/user_badge';
import getUserBadge from 'utils/account/getUserBadge';
import isValidAlarmTime from 'utils/alarm/isValidAlarmTime';
import { getMessageTranslations } from 'utils/translate/getMessageTranslations';
import userStatusInfoModel from '../../../models/account/user_status_info';
import {UserStatusCode, ENCKEYFORPARAM} from '../../../constants/commonConstants';

import pushIntegration from 'utils/push/pushIntegration';
import createMsgLogForAuditfile from '../../../utils/log/create_msg_log_for_auditfile';
import {decryptURL} from 'utils/cipher';

const passChatMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {originMessageId, targetRoomId} = ctx.request.body;

    const TargetChatMessageModel = chatMessageModel({tenantFlag});
    const TargetCounterModel = chatCounterModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});
    const TargetChattingRoomMemberModel = chattingRoomMemberModel({tenantFlag});

    const [message, counter, hasPermission] = await Promise.all([
      TargetChatMessageModel
        .findOne({_id: originMessageId}),
      TargetCounterModel.findOneAndUpdate(
        {childChattingRoom: targetRoomId}, {
          $inc: {messageSeq: 1},
        }),
      TargetChattingRoomMemberModel.findOne({
        parentUser: userId,
        parentChattingRoom: targetRoomId,
        isDeleted: false,
      }),
    ]);

    if (!hasPermission) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'permission denied',
      };
      return;
    }

    const messageContent = message.content.replaceAll('@GPT 봇', '');

    const newMessage = new TargetChatMessageModel({
      content: messageContent,
      isEmoticon: message.isEmoticon,
      isImportant: false,
      parentUser: userId,
      isReply: false,
      parentChattingRoom: targetRoomId,
      hasFiles: message.hasFiles,
      files: message.files,
      messageSeq: counter.messageSeq + 1,
      createdAt: new Date().getTime(),
      mentionedUsers: [],
    });

    if (!!messageContent) {
      const translations = await getMessageTranslations(messageContent, targetRoomId, userId, tenantFlag);
      newMessage.translate = translations.translate;
      newMessage.recvTranslate = translations.recvTranslate;
    } else {
      newMessage.translate = [];
      newMessage.recvTranslate = [];
    } // 빈 content일 경우 번역API 호출 skip

    await Promise.all([
      newMessage.save(),
      chattingRoomInfoModel({tenantFlag})
        .updateOne({_id: targetRoomId}, {childLastMessage: newMessage._id}),
      chattingRoomMemberModel({tenantFlag})
        .updateOne({parentChattingRoom: targetRoomId, parentUser: userId, isDeleted: false}, {
          lastCheckedMessageSeq: counter.messageSeq + 1,
        }),
    ]);

    const [
      {userName, jobTitle, emailId, empNo, email, parentCompany, parentDepartment},
      {roomName, isGroupChat, reName},
      members,
    ] = await Promise.all([
      userInfoModel({tenantFlag}).findOne({_id: userId})
        .select('userName jobTitle emailId empNo email parentCompany parentDepartment'),
      chattingRoomInfoModel({tenantFlag}).findOne({_id: targetRoomId})
        .select('roomName isGroupChat reName'),
      chattingRoomMemberModel({tenantFlag})
        .find({
          parentChattingRoom: targetRoomId,
          $or: [
            {isDeleted: false},
            {isDeleted: true, isGroupChat: false},
          ],
        })
        .select('parentUser isGroupChat isDeleted roomName'),
    ]);
    const chattingRoomName = roomName;

    const tokens: any = [];
    const locales: any = [];
    const os: any = [];
    const badges: any = [];
    const roomNames: any = [];

    const memberInfo = members.map((participant: any) => {
      return participant.parentUser;
    });
    const memberInfoTmp = await userInfoModel({tenantFlag})
      .find({_id: {$in: memberInfo}})
      .select('userName');
    // console.log('memberInfoTmp :', memberInfoTmp);
    const roomNameKo = memberInfoTmp.map((info: any) => {
      return info.userName.ko;
    }).join(',');
    const roomNameEn = memberInfoTmp.map((info: any) => {
      return info.userName.en;
    }).join(',');

    await Promise.all(members.map(async (member: any) => {
      if (member.parentUser.toString() !== userId) {
        if (!member.isGroupChat && member.isDeleted) {
          await chattingRoomMemberModel({tenantFlag})
            .updateOne({
              parentUser: member.parentUser,
              parentChattingRoom: targetRoomId}, {
              isDeleted: false,
            });
        }

        await TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
          $inc: {unreadChatMessages: 1},
        });

        const pushTargets = await userSignInfoModel({tenantFlag})
          .find({
            parentUser: member.parentUser,
            $or: [{deviceType: 'android'}, {deviceType: 'ios'}],
            alarmOffChattingRooms: {
              $nin: [targetRoomId],
            },
          });
        const userStatus = await userStatusInfoModel({tenantFlag})
          .findOne({parentUser: member.parentUser})
          .select('pcStatus mobileStatus').lean();

        // eslint-disable-next-line max-len
        await Promise.all(pushTargets.map(async ({pushToken, usePushAlarm, useAlarmChatMessage, useAlarmAllowedTime,
                                                   useEnUserInfo, deviceType, onlyAlarmWhenPCIsAbsence, timezoneOffset, alarmAllowedTime}) => {
          if (onlyAlarmWhenPCIsAbsence && userStatus!.hasOwnProperty('pcStatus') && userStatus!.hasOwnProperty('mobileStatus')) {
            // if (userStatus.pcStatus === 'online' && (userStatus.statusCode === '온라인' || userStatus.statusCode === '재택')) {
            // @ts-ignore
            if ((userStatus['pcStatus'] === UserStatusCode.ONLINE || userStatus['pcStatus'] === 'online') && userStatus['mobileStatus'] === UserStatusCode.ONLINE) {
              return;
            }
          }

          if (!usePushAlarm) {
            return;
          }

          if (!useAlarmChatMessage) {
            return;
          }

          if (useAlarmAllowedTime) {
            if (!isValidAlarmTime(timezoneOffset, alarmAllowedTime.start, alarmAllowedTime.end)) {
              return;
            }
          }

          if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
            const badge = await getUserBadge(member.parentUser, tenantFlag);
            badges.push(badge);
            tokens.push(pushToken);
            const l = useEnUserInfo ? 'en' : 'ko';
            locales.push(l);
            os.push(deviceType);
            const rn = !isGroupChat ? `${userName[l]} ${jobTitle[l]}` :
              member.roomName.toString() === '' && !reName ? (useEnUserInfo ? roomNameEn : roomNameKo) :
                member.roomName.toString() !== '' ? member.roomName.toString() : chattingRoomName;
            roomNames.push(rn);
          }
        }));
      }
    }));

    if (tokens.length !== 0) {
      let m = '';
      if (message.files.length > 0) {
        const decObj = decryptURL(message.files[0]['url'], ENCKEYFORPARAM);
        const targetFile = !!decObj.success ? decObj.url : message.files[0]['url'];
        const mimeType: any = mime.lookup(targetFile) ? mime.lookup(targetFile) : '';
        const isImage = mimeType.includes('image');
        const isVideo = mimeType.includes('video');

        if (message.isEmoticon) {
          m = '(이모티콘)';
        } else if (isImage) {
          m = '(이미지)';
        } else if (isVideo) {
          m = '(비디오)';
        } else {
          m = '(파일)';
        }
      } else {
        m = message.content.substring(0, 100);
      }

      // 파일 종류에 따라 다른 푸쉬
      // const fcm = {
      //   data: {type: 'chatting_room', id: targetRoomId},
      //   notification: {
      //     title: `${userName['ko']} ${jobTitle['ko']}`,
      //     body: m,
      //   },
      //   tokens,
      // };

      // admin.messaging()
      //   .sendMulticast(fcm as admin.messaging.MulticastMessage);

      tokens.forEach((token: string, i: number) => {
        const body = isGroupChat ? `${userName[locales[i] ?? 'ko']} ${jobTitle[locales[i] ?? 'ko']}: ${m}` : m;
        const notification = {
          title: roomNames[i]?.substring(0, 100),
          body: body.substring(0, 100),
        };

        const msg: any = {
          data: {type: 'chatting_room', id: targetRoomId, ...notification, badge: badges[i].toString()},
          token: token,
        };

        if (os[i] === 'android') {
          msg.android = {
            priority: 'HIGH',
          };
        }

        if (os[i] === 'ios') {
          msg.notification = notification;
          msg.apns = {
            payload: {
              aps: {
                sound: 'default',
                badge: badges[i],
              },
            },
          };
        }

        //admin.messaging().send(msg);
        pushIntegration(msg, false);
      });
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };

    setImmediate(() => {
      if (!newMessage.hasFiles && !newMessage.isEmoticon && !!messageContent) {
        createMsgLogForAuditfile({logType: 'chat', data: {
            roomId: targetRoomId,
            userId,
            content: messageContent,
            eventSeq: newMessage.messageSeq,
            regDate: newMessage.createdAt,
            userName: userName.ko ?? '',
            jobTitle: jobTitle.ko ?? '',
            emailId: emailId ?? '',
            email: email ?? '',
            empNo: empNo ?? '',
            parentCompany: parentCompany.toString(),
            parentDepartment: parentDepartment.toString(),
          }});
      }
    });
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
    };
  }
};

export default passChatMessage;
