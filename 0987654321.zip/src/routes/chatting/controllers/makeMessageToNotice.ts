/* eslint-disable new-cap */
/* eslint-disable max-len */
import Koa from 'koa';
import admin from 'firebase-admin';

import chatNoticeModel from 'models/message/chatting_room_message_notice';
import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chattingMemberModel from 'models/message/chatting_room_member';
import chattingMessageModel from 'models/message/chatting_room_message';
import alarmModel from 'models/alarm/alarm';
import userBadgeModel from 'models/account/user_badge';
import chattingCounterModel from 'models/message/chatting_counter';
import getUserBadge, {getUserBadgePrimaryOnly} from 'utils/account/getUserBadge';
import isValidAlarmTime from 'utils/alarm/isValidAlarmTime';
import userStatusInfoModel from '../../../models/account/user_status_info';
import chattingRoomMemberModel from '../../../models/message/chatting_room_member';
import {UserStatusCode} from '../../../constants/commonConstants';

import pushIntegration from 'utils/push/pushIntegration';

const makeMessageToNotice = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const body: any = ctx.request.body;
    const {roomId, messageId} = body;

    const UserInfoModel = userInfoModel({tenantFlag});
    const TargetNoticeModel = chatNoticeModel({tenantFlag});
    const targetRoomModel = chattingRoomInfoModel({tenantFlag});
    const targetMessageModel = chattingMessageModel({tenantFlag});
    const targetMemberModel = chattingMemberModel({tenantFlag});
    const TargetAlarmModel = alarmModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});
    const targetCounterModel = chattingCounterModel({tenantFlag});

    const member = targetMemberModel.findOne({parentChattingRoom: roomId, parentUser: userId, isDeleted: false});

    if (member === null) {
      ctx.status = 403;
      ctx.body = {
        success: false,
        error: 'internal server error',
      };
    }

    const beforeMessage = await targetMessageModel.findOne({_id: messageId});

    const counter = await targetCounterModel
      .findOneAndUpdate({childChattingRoom: roomId}, {
        $inc: {messageSeq: 1},
      });

    const newNotice = new TargetNoticeModel({
      parentUser: userId,
      parentChattingRoom: roomId,
      parentChattingMessage: messageId,
      title: '공지합니다',
      content: beforeMessage.content,
      fileFolderId: new Date().getTime(),
      files: [],
      createdAt: new Date().getTime(),
    });

    const newMessage = new targetMessageModel({
      content: beforeMessage.content,
      files: [],
      hasFiles: false,
      isEmoticon: false,
      isImportant: false,
      parentUser: userId,
      isReply: false,
      parentChattingRoom: roomId,
      mentionedUsers: [],
      messageSeq: counter.messageSeq + 1,
      isNotice: true,
      childNotice: newNotice._id,
      createdAt: new Date().getTime(),
    });

    await Promise.all([
      newNotice.save(),
      newMessage.save(),
      chattingMemberModel({tenantFlag}).updateOne({
        parentUser: userId, parentChattingRoom: roomId, isDeleted: false}, {
        lastCheckedMessageSeq: newMessage.messageSeq,
      }),
    ]);

    const userInfo = await userInfoModel({tenantFlag}).findOne({_id: userId}).select('userName jobTitle');
    const content = `${userInfo.userName['ko']}님이 공지를 등록했습니다.`;

    const newSystemMessage = new targetMessageModel({
      systemMessageType: 'notice',
      content,
      isSystemMessage: true,
      parentChattingRoom: roomId,
      messageSeq: -1,
      createdAt: new Date().getTime(),
      translate: [
        {
          locale: 'en',
          text: `${userInfo.userName['en']}님이 공지를 등록했습니다.`,
        },
      ],
    });

    await Promise.all([
      newSystemMessage.save(),
      targetRoomModel.updateOne({_id: roomId}, {
        childNoticeMessage: newNotice._id,
        childLastMessage: newMessage._id,
      }),
    ]);

    const originMessage = await targetMessageModel.findOne({_id: messageId}).select('content');

    const [
      {roomName, isGroupChat, reName},
      members,
      {userName, jobTitle},
    ] = await Promise.all([
      targetRoomModel.findOne({_id: roomId})
        .select('roomName isGroupChat reName'),
      targetMemberModel
        .find({
          parentChattingRoom: roomId,
          $or: [
            {isDeleted: false},
            {isDeleted: true, isGroupChat: false},
          ],
        })
        .select('parentUser isGroupChat isDeleted roomName'),
      UserInfoModel.findOne({_id: userId})
        .select('userName jobTitle'),
    ]);
    const chattingRoomName = roomName;

    const tokens: any = [];
    const locales: any = [];
    const os: any = [];
    const roomNames: any = [];
    const badges: any = [];

    const memberInfo = members.map((participant: any) => {
      return participant.parentUser;
    });
    const memberInfoTmp = await userInfoModel({tenantFlag})
      .find({_id: {$in: memberInfo}})
      .select('userName.ko userName.en')
      .lean();

    const roomNameKo = memberInfoTmp.map((info: any) => {
      return info.userName.ko;
    }).join(',');
    const roomNameEn = memberInfoTmp.map((info: any) => {
      return info.userName.en;
    }).join(',');

    await Promise.all(members.map(async (member) => {
      if (member.parentUser.toString() !== userId) {
        if (!member.isGroupChat && member.isDeleted) {
          await chattingMemberModel({tenantFlag}).updateOne({parentUser: member.parentUser, parentChattingRoom: roomId}, {
            isDeleted: false,
          });
          // 나간 대화방 상대를 방에 입장 처리 - create_chatting_room 스트림 발생용
        }

        await TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
          $inc: {unreadChatMessages: 1},
        });

        const pushTargets = await userSignInfoModel({tenantFlag})
          .find({
            parentUser: member.parentUser,
            $or: [{deviceType: 'android'}, {deviceType: 'ios'}],
            alarmOffChattingRooms: {
              $nin: [roomId],
            },
            usePushAlarm: true,
            useAlarmChatNotice: true,
          });
        const userStatus = await userStatusInfoModel({tenantFlag})
          .findOne({parentUser: member.parentUser})
          .select('pcStatus mobileStatus').lean();

        // TargetUserBadgeModel.updateOne({parentUser: member.parentUser}, {
        //   $inc: {unreadAlarms: 1},
        // });

        await Promise.all(pushTargets.map(async ({pushToken, useAlarmAllowedTime, useEnUserInfo,
                                                   deviceType, onlyAlarmWhenPCIsAbsence, timezoneOffset, alarmAllowedTime}) => {
          if (onlyAlarmWhenPCIsAbsence && userStatus!.hasOwnProperty('pcStatus') && userStatus!.hasOwnProperty('mobileStatus')) {
            // if (userStatus.pcStatus === 'online' && (userStatus.statusCode === '온라인' || userStatus.statusCode === '재택')) {
            // @ts-ignore
            if ((userStatus['pcStatus'] === UserStatusCode.ONLINE || userStatus['pcStatus'] === 'online') && userStatus['mobileStatus'] === UserStatusCode.ONLINE) {
              return;
            }
          }

          if (useAlarmAllowedTime) {
            if (!isValidAlarmTime(timezoneOffset, alarmAllowedTime.start, alarmAllowedTime.end)) {
              return;
            }
          }

          if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
            const badge = await getUserBadgePrimaryOnly(member.parentUser, tenantFlag);
            badges.push(badge);
            tokens.push(pushToken);
            const l = useEnUserInfo ? 'en' : 'ko';
            locales.push(l);
            os.push(deviceType);
            const rn = !isGroupChat ? `${userName[l]} ${jobTitle[l]}` :
              member.roomName.toString() === '' && !reName ? (useEnUserInfo ? roomNameEn : roomNameKo) :
                member.roomName.toString() !== '' ? member.roomName.toString() : chattingRoomName;

            roomNames.push(rn);
          }
        }));
      }

      // PP09260314-1503 알림센터 기획변경 반영
      // const nam = new TargetAlarmModel({
      //   'type': 'chatting_notice',
      //   'parentUser': member.parentUser,
      //   'actionUser': userId,
      //   'chatRoomId': roomId,
      //   'detailId': newNotice._id,
      //   'chatMessageId': messageId,
      //   'content': originMessage.content,
      //   'createdAt': new Date().getTime(),
      //   'isRead': true,
      // });
      // await nam.save();
    }));

    if (tokens.length !== 0) {
      // 파일 종류에 따라 다른 푸쉬
      // const message = {
      //   data: {type: 'chatting_room', id: roomId},
      //   notification: {
      //     title: `${userInfo.userName['ko']} ${userInfo.jobTitle['ko']}`,
      //     body: '공지사항을 등록하였습니다',
      //   },
      //   tokens,
      // };

      // admin.messaging().sendMulticast(message as admin.messaging.MulticastMessage);

      tokens.forEach((token: string, i: number) => {
        const notification = {
          title: roomNames[i]?.substring(0, 100),
          body: isGroupChat ? `${userName[locales[i] ?? 'ko']} ${jobTitle[locales[i] ?? 'ko']}: 공지사항을 등록하였습니다` : '공지사항을 등록하였습니다',
        };

        const msg: any = {
          data: {
            type: 'chatting_room',
            id: roomId,
            ...notification,
            badge: badges[i].toString(),
          },
          token: token,
        };

        if (os[i] === 'android') {
          msg.android = {
            priority: 'HIGH',
          };
        }

        if (os[i] === 'ios') {
          msg.notification = notification;
          msg.apns = {
            payload: {
              aps: {
                sound: 'default',
                badge: badges[i],
              },
            },
          };
        }

        //admin.messaging().send(msg);
        pushIntegration(msg, false);
      });
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default makeMessageToNotice;
