/* eslint-disable max-len */
import Koa from 'koa';

import chattingRoomMemberModel from 'models/message/chatting_room_member';
import userInfoModel from 'models/account/user_info';

const getUserUsingMessenger = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {roomId} = ctx.request.query;

    const hasPermission = await chattingRoomMemberModel({tenantFlag})
      .findOne({parentUser: userId, parentChattingRoom: roomId});

    if (hasPermission === null) {
      ctx.status = 403;
      ctx.body = {
        'success': false,
        'error': 'permission denied',
      };

      return;
    } 

    // before populate
    userInfoModel({tenantFlag});

    const chattingMembers = await Promise.all([
      chattingRoomMemberModel({tenantFlag})
        .find({parentChattingRoom: roomId})
        .select('parentUser')
        .populate({
          path: 'parentUser',
          select: 'userName  emailId hashedPassword',
        }) 
    ]);

    // 메신저를 사용하지 않는 사용자를 가나다 순으로 소팅
    const inactiveUser = chattingMembers
    .flatMap(member => member)
    .filter(member => {
      const memberData = member.toObject();
      const isEqual = memberData.parentUser.emailId === memberData.parentUser.hashedPassword;
      delete memberData.parentUser.hashedPassword;
      if(isEqual)
      return memberData;
    })
    .map(member => member.parentUser?.userName?.ko)
    .filter(name => name) // undefined나 null 제거
    .sort((a, b) => a.localeCompare(b, 'ko-KR')); // 한글 가나다순 정렬

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        inactiveUser: inactiveUser
      },
    };

  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getUserUsingMessenger;
