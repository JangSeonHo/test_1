/* eslint-disable new-cap */
/* eslint-disable max-len */
import Koa from 'koa';
import mime from 'mime-types';

import userInfoModel from 'models/account/user_info';
import chattingRoomInfoModel from 'models/message/chatting_room_info';
import chatCounterModel from 'models/message/chatting_counter';
import chattingRoomMessageModel from 'models/message/chatting_room_message';
import chattingRoomMemberModel from 'models/message/chatting_room_member';
import alarmModel from 'models/alarm/alarm';
import userBadgeModel from 'models/account/user_badge';
// import {getUserListBadgePrimaryOnly} from 'utils/account/getUserBadge';
import isValidAlarmTime from 'utils/alarm/isValidAlarmTime';
import createMsgLogForAuditfile from 'utils/log/create_msg_log_for_auditfile';
import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs';
import path from 'path';
import {
  USER_SIGN_INFO,
  USER_STATUS_INFO,
} from 'models/collection_names';

import mongoose from 'mongoose';
const {ObjectId} = mongoose.Types;
import {ecsTaskId} from '../../../server';

import {PutObjectCommand, S3Client} from '@aws-sdk/client-s3';

import {s3Bucket} from 'configs/s3';
import {UserStatusCode, ENCKEYFORPARAM} from 'constants/commonConstants';
const REGION = 'ap-northeast-2';
const s3Client = new S3Client({region: REGION});
import {getMessageTranslations} from 'utils/translate/getMessageTranslations';

import pushIntegration from 'utils/push/pushIntegration';
import updateUserBadge from 'utils/user/updateUserBadge';
import {decryptURL, encryptURL, encryptCdnToken} from 'utils/cipher';

const getVideoData = (url: string, roomId: string) => {
  return new Promise((resolve: any, reject: any) => {
    const folderPath = '/svc/engn001/nmp/temp';
    const fn = decodeURIComponent(url.split('/')[url.split('/').length - 1]);
    const thumbName = `${fn}.thumb.jpeg`;
    ffmpeg(url + '?cdnToken=' + encodeURIComponent(encryptCdnToken(url, ENCKEYFORPARAM))).screenshots({
      filename: thumbName,
      folder: folderPath,
      count: 1,
      size: '250x250',
    }).on('end', async () => {
      const tk = url.replace('https://', '').split('/');
      let key = '';
      for (let i = 1; i < tk.length - 1; i++) {
        if (i === 1) {
          key += tk[i];
        } else {
          key += `/${tk[i]}`;
        }
      }

      key += `/${thumbName}`;

      const fileStream = fs.createReadStream(path.join(folderPath, thumbName));
      const uploadParams = {
        Bucket: s3Bucket,
        Key: key,
        Body: fileStream,
        ContentType: 'image/jpeg',
      };
      // console.log('video thumbnail key :', key);
      const command = new PutObjectCommand(uploadParams);
      await s3Client.send(command);
      fileStream.close(() => {
        fs.unlinkSync(`${folderPath}/${thumbName}`);
      });
    });

    ffmpeg.ffprobe(url + '?cdnToken=' + encodeURIComponent(encryptCdnToken(url, ENCKEYFORPARAM)), (err: any, metadata: any) => {
      resolve(metadata.format.duration);
    });
  });
};

const createChattingMessage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    // counter
    const body: any = ctx.request.body;
    const {
      roomId,
      content,
      isReply,
      replyOrigin,
      isEmoticon,
      isImportant,
      mentionedUsers = JSON.stringify([]),
      // isGptRoom = false,
      noticeTitle,
      isNotice,
      useTopNotice,
      uuid,
      files = [],
    } = body;

    // file url 외부 url 요청시 예외처리
    let invalidFileUrl = false;
    let isEncFiles = false;
    const decryptedFiles: any[] = [];

    files.forEach((f: any) => {
      const decObj = decryptURL(f.url, ENCKEYFORPARAM);
      if (decObj.success) {
        isEncFiles = true;
        decryptedFiles.push({
          url: decObj.url,
        });

        if (decObj.url.split('https://file.lgmtalk.com')[0] !== '' &&
          decObj.url.split('https://dev-file.lgmtalk.com')[0] !== '' &&
          decObj.url.split('https://stg-file.lgmtalk.com')[0] !== '') {
          invalidFileUrl = true;
        }
      } else if (f.url.split('https://file.lgmtalk.com')[0] !== '' &&
        f.url.split('https://dev-file.lgmtalk.com')[0] !== '' &&
        f.url.split('https://stg-file.lgmtalk.com')[0] !== '') {
        invalidFileUrl = true;
      }
    });

    if (!mongoose.Types.ObjectId.isValid(roomId) || invalidFileUrl) {
      ctx.status = 400;
      return;
    }

    const targetCounterModel = chatCounterModel({tenantFlag});
    const targetMessageModel = chattingRoomMessageModel({tenantFlag});
    const TargetAlarmModel = alarmModel({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});
    const TargetChattingRoomMemberModel = chattingRoomMemberModel({tenantFlag});

    const hasPermission = await TargetChattingRoomMemberModel.findOne({
      parentUser: userId,
      parentChattingRoom: roomId,
      isDeleted: false,
    });
    if (!hasPermission) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'permission denied',
      };
      return;
    }

    // const counter = await targetCounterModel.findOneAndUpdate({childChattingRoom: roomId}, {$inc: {messageSeq: 1},});
    // findOneAndUpdate => findOne로 수정(index추가)하여 빠르게 counter 조회하고 다음 로직 실행하도록 수정
    // updateOne {messageSeq: 1} 로직은 아래 Promise.all에서 비동기 처리함

    const boolIsReply = typeof isReply === 'string' ? isReply === 'true' : isReply;
    const boolIsEmoticon = typeof isEmoticon === 'string' ? isEmoticon === 'true' : isEmoticon;
    const boolIsImportant = typeof isImportant === 'string' ? isImportant === 'true' : isImportant;
    let arrayMentionedUsers = typeof mentionedUsers === 'string' ? JSON.parse(mentionedUsers) : mentionedUsers;
    arrayMentionedUsers = arrayMentionedUsers.map((v: string) => {
      if (v === 'GPT_BOT') {
        return 'GPTBOTGPTBOT';
      }

      return v;
    });
    // const boolIsGptRoom = typeof isGptRoom === 'string' ? isGptRoom === 'true' : isGptRoom;
    const boolIsNotice = typeof isNotice === 'string' ? isNotice === 'true' : isNotice;
    const boolUseTopNotice = typeof useTopNotice === 'string' ? useTopNotice === 'true' : useTopNotice;

    const hasFiles = files.length > 0;

    let fs = [...files];
    if (hasFiles) {
      if (fs.length === 1 && fs[0].mimeType.includes('video')) {
        let videoUrl = fs[0].url;
        videoUrl = isEncFiles ? decryptedFiles[0].url : videoUrl;

        videoUrl = videoUrl.slice(0, videoUrl.lastIndexOf('/') + 1) + encodeURIComponent(videoUrl.slice(videoUrl.lastIndexOf('/') + 1, videoUrl.length));
        // 특수문자 파일명 encodeURI 처리
        fs = [{
          ...fs[0],
          'url': isEncFiles ? encryptURL(videoUrl, ENCKEYFORPARAM).url : videoUrl,
          'duration': await getVideoData(videoUrl, roomId),
        }];
      }
    }

    const newMessage = new targetMessageModel({
      content,
      isEmoticon: boolIsEmoticon === true,
      isImportant: boolIsImportant === true,
      parentUser: userId,
      isReply: boolIsReply === true,
      parentChattingRoom: roomId,
      hasFiles,
      files: fs,
      mentionedUsers: arrayMentionedUsers,
      uuid,
    });

    if (boolIsReply === true) {
      newMessage.replyOrigin = replyOrigin;
    }

    if (boolIsNotice) {
      newMessage.isNotice = true;
      newMessage.noticeTitle = noticeTitle ?? '';
    }

    if (!!content) {
      const translations = await getMessageTranslations(content, roomId, userId, tenantFlag);
      newMessage.translate = translations.translate;
      newMessage.recvTranslate = translations.recvTranslate;
    } else {
      newMessage.translate = [];
      newMessage.recvTranslate = [];
    } // 빈 content일 경우 번역API 호출 skip

    const roomUpdateData: any = {childLastMessage: newMessage._id};
    if (boolUseTopNotice) {
      roomUpdateData.childNoticeMessage = newMessage._id;
    }

    // 1.조회하여 변수에 할당하는 부분만 await 처리함
    const [
      {userName, jobTitle, emailId, empNo, email, parentCompany, parentDepartment},
      {roomName, isGroupChat, reName},
      members,
    ] = await Promise.all([
      userInfoModel({tenantFlag})
        .findOne({_id: userId})
        .select('userName jobTitle emailId empNo email parentCompany parentDepartment'),
      chattingRoomInfoModel({tenantFlag})
        .findOne({_id: roomId})
        .select('roomName isGroupChat reName'),
      TargetChattingRoomMemberModel
        .find({
          parentChattingRoom: roomId,
          $or: [
            {isDeleted: false},
            {isDeleted: true, isGroupChat: false},
          ],
        })
        .select('parentUser isGroupChat isDeleted roomName'),
    ]);
    const chattingRoomName = roomName;

    const session = await mongoose.startSession();
    const maxRetries = 5; // 트랜잭션 최대 재시도 횟수
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        session.startTransaction();
        const counter = await targetCounterModel.findOneAndUpdate(
          {childChattingRoom: roomId},
          {$inc: {messageSeq: 1}},
          {new: true, returnDocument: 'after', session},
        );

        await chattingRoomInfoModel({tenantFlag})
          .updateOne({_id: roomId}, roomUpdateData, {session});
        await TargetChattingRoomMemberModel
          .updateOne({parentChattingRoom: roomId, parentUser: userId, isDeleted: false}, {
            lastCheckedMessageSeq: counter.messageSeq,
          }, {session});
        newMessage.messageSeq = counter.messageSeq;
        newMessage.createdAt = new Date().getTime();
        await newMessage.save({session});

        await session.commitTransaction();
        break;
      } catch (error) {
        await session.abortTransaction();
        console.log(`createChattingMessage Transaction failed (attempt ${attempt} / userId ${userId} / task ${ecsTaskId.value})`);

        if (attempt === maxRetries) {
          await session.endSession();
          console.log(`createChattingMessage Transaction Error: ${error}`);
          throw error;
        }
        const gap = newMessage.messageSeq % 4 * 100;
        await new Promise((res) => setTimeout(res, Math.pow(2, attempt) * 100 + gap));
        // Exponential Backoff (100ms > 200ms > 400ms)
      }
    }
    await session.endSession();

    /* ************************************************************ */
    /* createChattingMessage AP Server CPU/Mem & DB CPU 성능 튜닝  */
    /* ************************************************************ */

    const memberInfo = members.map((participant: any) => {
      return participant.parentUser;
    });
    // 전체 채팅 참여자 중 메신지 발신자 userId를 제거함
    const strMemberInfo = memberInfo.toString();
    const exceptMe = userId;
    let chattingMembers = strMemberInfo.split(',');
    chattingMembers = chattingMembers.filter((item) => item !== exceptMe);

    // 성능 #1 : 전체 채팅 참여자의 배지 unRead Count를 +1 증가 시킴 : in 절을 이용한 1 Query로 실행
    await TargetUserBadgeModel.updateMany({parentUser: {$in: chattingMembers}}, {
      $inc: {unreadChatMessages: 1},
    });

    let tokens: any = [];
    let locales: any = [];
    let os: any = [];
    let roomNames: any = [];
    // let badges: any = [];
    const userIds: any = [];

    const memberInfoTmp = await userInfoModel({tenantFlag})
      .find({_id: {$in: memberInfo}})
      .select('userName.ko userName.en')
      .lean();

    const roomNameKo = memberInfoTmp.map((info: any) => {
      return info.userName.ko;
    }).join(',');
    const roomNameEn = memberInfoTmp.map((info: any) => {
      return info.userName.en;
    }).join(',');

    // 성능 #2 : chatting_room_member_infos, user_sign_infos, user_status_infos 3개 컬렉션을 Join 함
    const pushMembers = await TargetChattingRoomMemberModel.aggregate([
      {
        $match: {
          parentChattingRoom: new ObjectId(roomId),
          $or: [
            {isDeleted: false},
            {isDeleted: true, isGroupChat: false},
          ],
        },
      },
      {
        $lookup: {
          from: `${tenantFlag}_${USER_SIGN_INFO}s`,
          localField: 'parentUser',
          foreignField: 'parentUser',
          as: 'user_sign_infos',
        },
      },
      {
        $unwind: '$user_sign_infos',
      },
      {
        $match: {
          'user_sign_infos.deviceType': {$in: [/^android$/i, /^ios$/i, /^ipad$/i]},
          'user_sign_infos.alarmOffChattingRooms': {$nin: [roomId]},
          'user_sign_infos.usePushAlarm': true,
        },
      },
      {
        $lookup: {
          from: `${tenantFlag}_${USER_STATUS_INFO}s`,
          localField: 'parentUser',
          foreignField: 'parentUser',
          as: 'user_status_infos',
        },
      },
      {
        $unwind: '$user_status_infos',
      },
      {
        $project: {
          parentUser: 1,
          isGroupChat: 1,
          isDeleted: 1,
          roomName: 1,

          pushToken: '$user_sign_infos.pushToken',
          useAlarmChatMessage: '$user_sign_infos.useAlarmChatMessage',
          useAlarmImportantMessage: '$user_sign_infos.useAlarmImportantMessage',
          useAlarmAllowedTime: '$user_sign_infos.useAlarmAllowedTime',
          useAlarmChatMention: '$user_sign_infos.useAlarmChatMention',
          useAlarmChatNotice: '$user_sign_infos.useAlarmChatNotice',
          useEnUserInfo: '$user_sign_infos.useEnUserInfo',
          deviceType: '$user_sign_infos.deviceType',
          onlyAlarmWhenPCIsAbsence: '$user_sign_infos.onlyAlarmWhenPCIsAbsence',
          timezoneOffset: '$user_sign_infos.timezoneOffset',
          alarmAllowedTime: '$user_sign_infos.alarmAllowedTime',

          pcStatus: '$user_status_infos.pcStatus',
          mobileStatus: '$user_status_infos.mobileStatus',
        },
      },
      {
        $sort: {
          parentUser: 1,
        },
      },
    ]);

    // const pushMemberInfo = pushMembers.map((participant: any) => {
    //   return participant.parentUser;
    // });

    // 성능 #4 : 전체 채팅 참여자의 배지 Count 조회 : in 절을 이용한 1 Query로 실행
    // const memberBadges = await getUserListBadgePrimaryOnly(pushMemberInfo, tenantFlag);

    // let badgeIndex = 0; // badge array index
    await Promise.all(pushMembers.map(async ({isGroupChat, isDeleted, roomName, pushToken, useAlarmChatMessage, useAlarmImportantMessage, useAlarmAllowedTime, parentUser,
                                               useAlarmChatMention, useAlarmChatNotice, useEnUserInfo, deviceType, onlyAlarmWhenPCIsAbsence, timezoneOffset, alarmAllowedTime, pcStatus, mobileStatus}) => {
      if (parentUser.toString() !== userId) {
        if (!isGroupChat && isDeleted) {
          await TargetChattingRoomMemberModel.updateOne({parentUser: parentUser, parentChattingRoom: roomId}, {
            isDeleted: false,
          });
          // 나간 대화방 상대를 방에 입장 처리 - create_chatting_room 스트림 발생용
        }

        if (onlyAlarmWhenPCIsAbsence ) {
          if ((pcStatus === UserStatusCode.ONLINE || pcStatus === 'online') && mobileStatus === UserStatusCode.ONLINE) {
            return;
          }
        }

        if (arrayMentionedUsers.includes(parentUser.toString()) && useAlarmChatMention) {
          if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
            // const badge = memberBadges[badgeIndex];
            // badges.push(badge);
            const l = useEnUserInfo ? 'en' : 'ko';
            tokens.push(pushToken);
            locales.push(l);
            os.push(deviceType);
            const rn = !isGroupChat ? `${userName[l]} ${jobTitle[l]}` :
              roomName === '' && !reName ? (useEnUserInfo ? roomNameEn : roomNameKo) :
                roomName !== '' ? roomName : chattingRoomName;
            roomNames.push(rn);
            userIds.push(parentUser);
          }

          return;
        }

        if (!boolIsNotice && !boolIsImportant && !useAlarmChatMessage) {
          return;
        }

        if (boolIsImportant && !useAlarmImportantMessage) {
          return;
        }

        if (boolIsNotice && !useAlarmChatNotice) {
          return;
        }

        if (!boolIsImportant) {
          if (useAlarmAllowedTime) {
            if (!isValidAlarmTime(timezoneOffset, alarmAllowedTime.start, alarmAllowedTime.end)) {
              return;
            }
          }
        }

        if (pushToken !== '' && tokens.indexOf(pushToken) === -1) {
          // const badge = memberBadges[badgeIndex];
          // badges.push(badge);
          const l = useEnUserInfo ? 'en' : 'ko';
          tokens.push(pushToken);
          locales.push(l);
          os.push(deviceType);
          const rn = !isGroupChat ? `${userName[l]} ${jobTitle[l]}` :
            roomName === '' && !reName ? (useEnUserInfo ? roomNameEn : roomNameKo) :
              roomName !== '' ? roomName : chattingRoomName;

          roomNames.push(rn);
          userIds.push(parentUser);
        }
      }

      // 중요메시지는 알림도 만들어야함
      if (boolIsImportant === true) {
        const nam = new TargetAlarmModel({
          'type': 'chatting_important',
          'parentUser': parentUser,
          'actionUser': userId,
          'chatRoomId': roomId,
          'chatMessageId': newMessage._id,
          'content': content,
          'createdAt': new Date().getTime(),
          'isRead': true,
        });

        Promise.all([
          nam.save(),
        ]);
      }

      if (boolIsNotice === true) {
        const nam = new TargetAlarmModel({
          'type': 'chatting_notice',
          'parentUser': parentUser,
          'actionUser': userId,
          'chatRoomId': roomId,
          'chatMessageId': newMessage._id,
          'content': content,
          'createdAt': new Date().getTime(),
          'isRead': true,
        });

        Promise.all([
          nam.save(),
        ]);
      }

      // badgeIndex++;
    })).then(() => {
      if (tokens.length !== 0) {
        let m = '';
        if (hasFiles) {
          let mimeType: any;
          if (isEncFiles) {
            mimeType = mime.lookup(decryptedFiles[0]['url']) ? mime.lookup(decryptedFiles[0]['url']) : '';
          } else {
            mimeType = mime.lookup(decryptedFiles[0]['url']) ? mime.lookup(decryptedFiles[0]['url']) : '';
          }
          const isImage = mimeType.includes('image');
          const isVideo = mimeType.includes('video');

          if (boolIsEmoticon) {
            m = '(이모티콘)';
          } else if (isImage) {
            m = '(이미지)';
          } else if (isVideo) {
            m = '(비디오)';
          } else {
            m = '(파일)';
          }
        } else {
          m = content;
        }

        let messages = tokens.map((token: string, i: number) => {
          const body = isGroupChat ? `${userName[locales[i] ?? 'ko']} ${jobTitle[locales[i] ?? 'ko']}: ${m}` : m;
          const notification = {
            title: roomNames[i]?.substring(0, 100),
            body: body.substring(0, 100),
          };
          const msg: any = {
            data: {
              type: 'chatting_room',
              id: roomId,
              ...notification,
              // badge: badges[i].toString(),
            },
            token: token,
            userId: userIds[i],
          };

          if (os[i] === 'android') {
            msg.android = {
              priority: 'HIGH',
            };
          }

          if (['ios', 'ipad'].includes(os[i].toLowerCase())) {
            msg.notification = notification;
            msg.apns = {
              payload: {
                aps: {
                  sound: 'default',
                  // badge: badges[i],
                },
              },
            };
          }
          return msg;
        });

        // // 100개씩 나누어 배치 전송
        // const batchSize = 100;
        // for (let i = 0; i < messages.length; i += batchSize) {
        //   const batch = messages.slice(i, i + batchSize);
        //   try {
        //     const response = await admin.messaging().sendEach(batch);
        //     if(response.failureCount > 0) {
        //       response.responses.forEach((res, index) => {
        //         if (!res.success) {
        //           const error = res.error;
        //           if (error) {
        //             if (error.code === 'messaging/registration-token-not-registered') {
        //               console.log('Token not registered - token : ', batch[index].token);
        //             } else {
        //               console.log(error);
        //             }
        //           } else {
        //             console.log(error);
        //           }
        //         }
        //       });
        //     }
        //   } catch (error) {
        //     console.error('Error sending notifications batch:', error);
        //   }
        // }
        pushIntegration([...messages], true, true);
        messages = null;
      }
      tokens = null;
      locales = null;
      os = null;
      roomNames = null;
      // badges = null;
    });

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        newMessage,
      },
    };
    setImmediate(() => {
      if (!hasFiles && !boolIsEmoticon && !!content) {
        createMsgLogForAuditfile({logType: 'chat', data: {
            roomId,
            userId,
            content,
            eventSeq: newMessage.messageSeq,
            regDate: newMessage.createdAt,
            userName: userName.ko ?? '',
            jobTitle: jobTitle.ko ?? '',
            emailId: emailId ?? '',
            email: email ?? '',
            empNo: empNo ?? '',
            parentCompany: parentCompany.toString(),
            parentDepartment: parentDepartment.toString(),
          }});
      }
      updateUserBadge(tenantFlag, userId);
    });
  } catch (err) {
    console.log(`createChattingMessage error: ${err}`);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default createChattingMessage;
