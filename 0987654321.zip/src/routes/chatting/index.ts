/* eslint-disable max-len */
import Router from '@koa/router';
const router = new Router();

import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

import createChattingRoom from './controllers/createChattingRoom';
router.post('/createChattingRoom', isLoggedIn, createChattingRoom);

// LG전자 웹에서 메신저 호출을 위한 상호인증 로직 #1 : authKey 획득
import lgeLogin from './controllers/lgeLogin';
router.post('/lgeLogin', lgeLogin);

// LG전자 사용자 토큰 조회
import getLgeUserInfo from './controllers/getLgeUserInfo';
router.post('/getLgeUserInfo', getLgeUserInfo);

// M-메신저 대화이력 조회 API
import getChattingHistory from './controllers/getChattingHistory';
router.post('/getChattingHistory', isLoggedIn, getChattingHistory);

// 웹에서 메신저 호출을 위한 상호인증 로직 #1 : authKey 획득
import getPubKey from './controllers/getPubKey';
router.post('/getPubKey', getPubKey);

// 웹에서 메신저 호출을 위한 상호인증 로직 #2 : authKey 검증
import getEncKey from './controllers/getEncKey';
router.post('/getEncKey', getEncKey);

// 대화 상대자의 _id 조회
import getUserInfo from './controllers/getUserInfo';
router.post('/getUserInfo', getUserInfo);

// M-메신저 대화방 및 구성원 -> New 메신저 이관을 위한 API
// JWT 인증 제외시킴
import ucapChattingRoomTransfer from './controllers/ucapChattingRoomTransfer';
router.post('/ucapChattingRoomTransfer', ucapChattingRoomTransfer);

import getChattingRooms from './controllers/getChattingRooms';
router.get('/getChattingRooms', isLoggedIn, logApiAccess, getChattingRooms);

// *check s3 //
import createChattingMessage from './controllers/createChattingMessage';
// router.post('/createChattingMessage', isLoggedIn, logApiAccess, createChattingMessage);
// logApiAccess middleware에서 제거 : access 로그는 주요 API만 남기도록 수정
router.post('/createChattingMessage', isLoggedIn, createChattingMessage);

import enterChattingRoom from './controllers/enterChattingRoom';
router.get('/enterChattingRoom', isLoggedIn, enterChattingRoom);

import getInactiveUser from './controllers/getInactiveUser';
router.get('/getInactiveUser', isLoggedIn, getInactiveUser);

import updateChattingRoomAlarm from './controllers/updateChattingRoomAlarm';
router.post('/updateChattingRoomAlarm', isLoggedIn, updateChattingRoomAlarm);

import deleteChattingRoom from './controllers/deleteChattingRoom';
router.post('/deleteChattingRoom', isLoggedIn, deleteChattingRoom);

import inviteToChattingRoom from './controllers/inviteToChattingRoom';
router.post('/inviteToChattingRoom', isLoggedIn, inviteToChattingRoom);

import modifyMessage from './controllers/modifyMessage';
router.post('/modifyMessage', isLoggedIn, modifyMessage);

import makeMessageToNotice from './controllers/makeMessageToNotice';
router.post('/makeMessageToNotice', isLoggedIn, makeMessageToNotice);

import renameChattingRoom from './controllers/renameChattingRoom';
router.post('/renameChattingRoom', isLoggedIn, renameChattingRoom);

import bookChatMessage from './controllers/bookChatMessage';
router.post('/bookChatMessage', isLoggedIn, bookChatMessage);

import deleteChatMessage from './controllers/deleteChatMessage';
router.post('/deleteChatMessage', isLoggedIn, deleteChatMessage);

import setImportantMessage from './controllers/setImportantMessage';
router.post('/setImportantMessage', isLoggedIn, setImportantMessage);

import resolveImportantMessage from './controllers/resolveImportantMessage';
router.post('/resolveImportantMessage', isLoggedIn, resolveImportantMessage);

import sendBookedChatMessage from './controllers/sendBookedChatMessage';
router.post('/sendBookedChatMessage', isLoggedIn, sendBookedChatMessage);

import deleteBookedChatMessage from './controllers/deleteBookedChatMessage';
router.post('/deleteBookedChatMessage', isLoggedIn, deleteBookedChatMessage);

import setBookmarkMessage from './controllers/setBookmarkMessage';
router.post('/setBookmarkMessage', isLoggedIn, setBookmarkMessage);

import resolveBookmarkMessage from './controllers/resolveBookmarkMessage';
router.post('/resolveBookmarkMessage', isLoggedIn, resolveBookmarkMessage);

import setReminderMessage from './controllers/setReminderMessage';
router.post('/setReminderMessage', isLoggedIn, setReminderMessage);

import getBookedChatMessages from './controllers/getBookedChatMessages';
router.get('/getBookedChatMessages', isLoggedIn, getBookedChatMessages);

import getBookmarkMessages from './controllers/getBookmarkMessages';
router.get('/getBookmarkMessages', isLoggedIn, getBookmarkMessages);

import engageMessage from './controllers/engageMessage';
router.post('/engageMessage', isLoggedIn, engageMessage);

import getMessageAllEngagement from './controllers/getMessageAllEngagements';
router.get('/getMessageAllEngagement', isLoggedIn, getMessageAllEngagement);

import passChatMessage from './controllers/passChatMessage';
router.post('/passChatMessage', isLoggedIn, passChatMessage);

import getChatNotices from './controllers/getChatNotices';
router.get('/getChatNotices', isLoggedIn, getChatNotices);

import cancelChatNotice from './controllers/cancelChatNotice';
router.post('/cancelChatNotice', isLoggedIn, cancelChatNotice);

import getChatMessage from './controllers/getChatMessage';
router.get('/getChatMessage', isLoggedIn, getChatMessage);

import getChatMessages from './controllers/getChatMessages';
router.get('/getChatMessages', isLoggedIn, getChatMessages);

import createVote from './controllers/createVote';
router.post('/createVote', isLoggedIn, createVote);

import vote from './controllers/vote';
router.post('/vote', isLoggedIn, vote);

import deleteVote from './controllers/deleteVote';
router.post('/deleteVote', isLoggedIn, deleteVote);

import getVotes from './controllers/getVotes';
router.get('/getVotes', isLoggedIn, getVotes);

import getVote from './controllers/getVote';
router.get('/getVote', isLoggedIn, getVote);

// *check s3 //
// import uploadVoteImages from './controllers/uploadVoteImages';
// router.post('/uploadVoteImages', isLoggedIn, uploadMessageVoteImages, uploadVoteImages);

import updateBookedChatMessage from './controllers/updateBookedChatMessage';
router.post('/updateBookedChatMessage', isLoggedIn, updateBookedChatMessage);

import isGroupChatRoomExists from './controllers/isGroupChatRoomExists';
router.post('/isGroupChatRoomExists', isLoggedIn, isGroupChatRoomExists);

import createChatNotice from './controllers/createChatNotice';
router.post('/createChatNotice', isLoggedIn, createChatNotice);

import getChatNotice from './controllers/getChatNotice';
router.get('/getChatNotice', isLoggedIn, getChatNotice);

import deleteChatNotice from './controllers/deleteChatNotice';
router.post('/deleteChatNotice', isLoggedIn, deleteChatNotice);

import updateChatNotice from './controllers/updateChatNotice';
router.post('/updateChatNotice', isLoggedIn, updateChatNotice);

// *check s3 //
// import uploadChatNoticeFiles from './controllers/uploadChatNoticeFiles';
// router.post('/uploadChatNoticeFiles', isLoggedIn, uploadChatNoticeFilesMD, uploadChatNoticeFiles);

import renotifyChatNotice from './controllers/renotifyChatNotice';
router.post('/renotifyChatNotice', isLoggedIn, renotifyChatNotice);

import updateChatVote from './controllers/updateChatVote';
router.post('/updateChatVote', isLoggedIn, updateChatVote);

import getFileMessage from './controllers/getFileMessage';
router.get('/getFileMessage', isLoggedIn, getFileMessage);

import kickMember from './controllers/kickMember';
router.post('/kickMember', isLoggedIn, kickMember);

//채팅 메세지 생성시점으로 부터 금일기준 3개월이 지난 대화는 삭제한다.
import removeChattingMessage from './controllers/removeChattingMessage';
router.post('/removeChattingMessage', removeChattingMessage);

import getLocaleList from './controllers/getLocaleList';
router.post('/getLocaleList', isLoggedIn, getLocaleList);

import setSendTranslateLocale from './controllers/setSendTranslateLocale';
router.post('/setSendTranslateLocale', isLoggedIn, setSendTranslateLocale);

import setRecvTranslateLocale from './controllers/setRecvTranslateLocale';
router.post('/setRecvTranslateLocale', isLoggedIn, setRecvTranslateLocale);

import getTranslateLocale from './controllers/getTranslateLocale';
router.post('/getTranslateLocale', isLoggedIn, getTranslateLocale);

import chattingRoomMemberInvite from './controllers/chattingRoomMemberInvite';
router.post('/chattingRoomMemberInvite', chattingRoomMemberInvite);

export default router;