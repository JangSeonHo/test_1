import Koa from 'koa';
import mongoose from 'mongoose';

// import companyCompanyModel from 'models/company/company_company_info';
import distributionModel from 'models/system/distribution_management';
import companyDistributionModel from 'models/system/company_distribution_management';

const getVersionUpdateYn = async (ctx: Koa.Context) => {
  try {
    const {
      companyId,
      currentVersion,
    } = ctx.request.body as any;

    const tenantFlag = ctx.response.get('tenantFlag');
    const headers = ctx.headers;
    const deviceType = headers['device-type'] as string ?? '';

    // compile before populate
    // const companyModel = companyCompanyModel({tenantFlag});
    const distModel = distributionModel({tenantFlag});
    const companyDistModel = companyDistributionModel({tenantFlag});
    const deviceCd = deviceType === 'android' ? 'Android' : deviceType === 'ios' ? 'IOS' : 'PC';

    const lastVersionByCompany = await companyDistModel.aggregate([
      {
        $match: {
          company: new mongoose.mongo.ObjectId(companyId),
          device: deviceCd,
        },
      }, {
        $sort: {
          distributionDate: -1,
        },
      }, {
        $limit: 1,
      }, {
        $project: {
          _id: 0,
          version: '$version',
          companyGroup: '$companyGroup',
        },
      },
    ]);

    let updateType = 0;
    let lastVerStr = '';
    let updateUrl = '';
    if (lastVersionByCompany.length > 0) {
      lastVerStr = lastVersionByCompany[0].version;
      const distData = await distModel.aggregate([
        {
          $match: {
            companyGroup: new mongoose.mongo.ObjectId(lastVersionByCompany[0].companyGroup),
            device: deviceCd,
            version: lastVerStr,
          },
        }, {
          $project: {
            _id: 0,
            files: '$files',
          },
        },
      ]);
      if (distData.length > 0) {
        updateUrl = encodeURI(distData[0].files[0].path);
      }

      const lastVer = lastVerStr.substring(1).split('.', 3);
      const currentVer = currentVersion.substring(1).split('.', 3);
      if (
        (Number(lastVer[0]) > Number(currentVer[0])) ||
        (Number(lastVer[0]) >= Number(currentVer[0]) && Number(lastVer[1]) > Number(currentVer[1]))
      ) { // 자동 업데이트
        updateType = 2;
      } else if (
        (Number(lastVer[0]) === Number(currentVer[0])) && (Number(lastVer[1]) === Number(currentVer[1])) &&
        (Number(lastVer[2]) > Number(currentVer[2]))
      ) { // 선택 업데이트
        updateType = 1;
      }
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        updateType,
        'updateVersion': lastVerStr,
        updateUrl,
      },
    };
  } catch (err) {
    console.log(err);

    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getVersionUpdateYn;
