import Koa from 'koa';

import companyCompanyModel from 'models/company/company_company_info';
import companyDepartmentModel from 'models/company/company_department_info';

import accountUserInfoModel from 'models/account/user_info';
import accountUserInfoStatusModel from 'models/account/user_status_info';
import badgeModel from 'models/account/user_badge';

import generatePasswordSalt from 'utils/account/generatePasswordSalt';
import getHashedPassword from 'utils/account/getHashedPassword';

const createUser = async (ctx: Koa.Context) => {
  try {
    const {
      userName,
      jobTitle,
      email,
      personalPhoneNumber,
      officePhoneNumber,
      parentDepartment,
    } = ctx.request.body as any;

    const tenantFlag = ctx.response.get('tenantFlag');

    const paramEmailId = (email.split('@')[0] ?? '').toLowerCase();

    // compile before populate
    const companyModel = companyCompanyModel({tenantFlag});
    const departmentModel = companyDepartmentModel({tenantFlag});
    const userInfoModel = accountUserInfoModel({tenantFlag});
    const userStatusInfoModel = accountUserInfoStatusModel({tenantFlag});
    const targetBadgeModel = badgeModel({tenantFlag});
    //

    const pdepartment = await departmentModel.findOne({_id: parentDepartment});

    const passwordSalt: string = generatePasswordSalt();
    //const hashedPassword: string = getHashedPassword(personalPhoneNumber, passwordSalt);
    const hashedPassword: string = getHashedPassword(paramEmailId, passwordSalt); // 암호를 emailId로 함. by shjang74 2024.07.30

    // eslint-disable-next-line new-cap
    const userInfo = new userInfoModel({
      userName,
      jobTitle,
      email,
      emailId: (email.split('@')[0] ?? '').toLowerCase(),
      personalPhoneNumber: personalPhoneNumber,
      officePhoneNumber: officePhoneNumber,
      parentDepartment,
      parentGroup: pdepartment.parentGroup,
      parentCompany: pdepartment.parentCompany,
      useMessenger: false,
      profileImage: '',
      hashedPassword,
      passwordSalt,
    });

    // eslint-disable-next-line new-cap
    const userStatus = new userStatusInfoModel({
      statusCode: '',
      statusString: '',
      parentUser: userInfo._id,
    });

    // eslint-disable-next-line new-cap
    const newBadge = new targetBadgeModel({
      'parentUser': userInfo._id,
    });

    userInfo.childStatusInfo = userStatus._id;

    await Promise.all([
      newBadge.save(),
      userInfo.save(),
      userStatus.save(),
      departmentModel.updateOne({_id: parentDepartment}, {
        $push: {childUsers: userInfo._id},
      }),
      companyModel.updateOne({_id: pdepartment.parentCompany}, {
        $inc: {totalChildUsers: 1},
      }),
    ]);

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        userInfo,
      },
    };
  } catch (err) {
    console.log(err);

    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default createUser;
