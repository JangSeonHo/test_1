/* eslint-disable max-len */
/* eslint-disable indent */
import Koa from 'koa';
import userSignInfoModel from 'models/account/user_sign_info';

const getSignInfo = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const userSignInfo = await userSignInfoModel({tenantFlag})
      .findOne({'accessToken': ctx.headers['access-token']});

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {userSignInfo},
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getSignInfo;
