/* eslint-disable max-len */
import Koa from 'koa';
import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyInfoModel from 'models/company/company_company_info';
import departmentInfoModel from 'models/company/company_department_info';

const addFromMyDepartment = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const targetDepartmentModel = departmentInfoModel({tenantFlag});

    const userInfo = await targetUserModel.findOne({_id: userId})
      .select('parentDepartment childPrivateContacts');

    const departmentId = userInfo.parentDepartment;
    const departmentInfo = await targetDepartmentModel.findOne({_id: departmentId}).select('childUsers');

    // eslint-disable-next-line new-cap
    const addIds = departmentInfo.childUsers.filter((id: any) => id.toString() !== userId);

    const childPrivateContacts = userInfo.childPrivateContacts;
    const childNewContactIds: Array<string> = [];
    addIds.forEach((id: string) => {
      if (childPrivateContacts.indexOf(id) === -1) {
        childNewContactIds.push(id);
      }
    });

    //
    companyInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    //

    await targetUserModel.updateOne({_id: userId}, {childPrivateContacts: [...childPrivateContacts, ...childNewContactIds]});
    // eslint-disable-next-line max-len
    const newPrivateMembers = await Promise.all(childNewContactIds.map(async (id: string) => {
      return await targetUserModel.findOne({_id: id})
        .select('userName jobTitle email personalPhoneNumber officePhoneNumber profileImage childStatusInfo useMessenger parentCompany parentDepartment')
        .populate('parentCompany', 'companyName _id')
        .populate('parentDepartment', 'departmentName _id')
        .populate('childStatusInfo', '-_id -_v');
    }));

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        newPrivateMembers,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default addFromMyDepartment;
