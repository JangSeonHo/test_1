/* eslint-disable max-len */
import Koa from 'koa';

import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyInfoModel from 'models/company/company_company_info';
import departmentInfoModel from 'models/company/company_department_info';

const addMembersFromUserIds = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const targetUserModel = userInfoModel({tenantFlag});
    const userInfo = await targetUserModel.findOne({_id: userId})
      .select('childPrivateContacts');

    const body: any = ctx.request.body;
    const {userIds} = body;

    //
    departmentInfoModel({tenantFlag});
    companyInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    //

    const beforeUserIds = userInfo.childPrivateContacts.map((id: string) => id.toString());
    const addIds = userIds.filter((id: any) => (id !== userId) && beforeUserIds.indexOf(id) === -1);

    await targetUserModel.updateOne({_id: userId},
      {
        childPrivateContacts: [
          ...userInfo.childPrivateContacts,
          ...addIds,
        ],
      });
    const newPrivateMembers = await Promise.all(addIds.map(async (id: string) => {
      return await targetUserModel.findOne({_id: id})
        .select('userName jobTitle email personalPhoneNumber officePhoneNumber profileImage childStatusInfo useMessenger parentCompany parentDepartment')
        .populate('parentCompany', 'companyName _id')
        .populate('parentDepartment', 'departmentName _id')
        .populate('childStatusInfo', '-_id -_v');
    }));

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        newPrivateMembers,
      },
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default addMembersFromUserIds;
