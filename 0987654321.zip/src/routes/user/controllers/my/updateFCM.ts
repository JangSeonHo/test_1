import Koa from 'koa';
import userSignInfoModel from 'models/account/user_sign_info';

const updateFCM = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const body: any = ctx.request.body;
    const {pushToken} = body;

    await userSignInfoModel({tenantFlag})
      .updateOne({
        parentUser: userId,
        accessToken: ctx.headers['access-token'],
      }, {
        pushToken,
        isChina: false,
        pushType: 'fcm'
      });

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default updateFCM;
