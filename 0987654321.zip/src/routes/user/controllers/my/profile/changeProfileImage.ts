import Koa from 'koa';

import {cdnHost} from 'configs/server';
import userInfoModel from 'models/account/user_info';

const changeProfileImage = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const {url} = ctx.request.body;

    const TargetUserModel = userInfoModel({tenantFlag});

    if (url.length == 0) {
      await TargetUserModel.updateOne({_id: userId}, {
        profileImage: '',
      });

      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          userInfo: {
            profileImage: '',
          },
        },
      };
    } else {
      // eslint-disable-next-line max-len
      const uInfo = await TargetUserModel.findOne({_id: userId}).select('parentCompany');

      await TargetUserModel.updateOne({_id: userId}, {
        profileImage: `${cdnHost}/${uInfo.parentCompany}/${url}`,
      });

      ctx.status = 200;
      ctx.body = {
        'success': true,
        'data': {
          userInfo: {
            profileImage: `${cdnHost}/${uInfo.parentCompany}/${url}`,
          },
        },
      };
    }
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default changeProfileImage;
