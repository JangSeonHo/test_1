/* eslint-disable max-len */
// group, bookmark, private memeber 등등
import Koa from 'koa';
import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyGroupInfoModel from 'models/company/company_group_info';
import companyInfoModel from 'models/company/company_company_info';
import companyDetailModel from 'models/company/company_detail';
import companyDepartmentInfoModel from 'models/company/company_department_info';
import userGroupInfoModel from 'models/account/user_group_info';
import userBadgeModel from 'models/account/user_badge';
import syncNoteBadge from 'utils/note/syncNoteBadge';
import mongoose from 'mongoose';
import {ALLOWED_EXTS} from 'constants/commonConstants';

const getMyData = async (ctx: Koa.Context) => {
  try {
    // define
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const accessToken = ctx.request.headers['access-token'];

    // before populate
    companyGroupInfoModel({tenantFlag});
    companyInfoModel({tenantFlag});
    companyDepartmentInfoModel({tenantFlag});
    userGroupInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});

    syncNoteBadge(tenantFlag, userId);

    const targetUserModel = userInfoModel({tenantFlag});
    const [userInfo, signInfo, badgeInfo] = await Promise.all([targetUserModel
      .findOne({_id: userId})
      .select(
        '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v')
      .populate('childStatusInfo', '-parentUser -__v -_id')
      .populate('parentGroup', '-childCompanies -__v')
      .populate('parentCompany', '-childDepartments -__v -parentGroup')
      .populate('parentDepartment', '-parentGroup -parentCompany -parentDepartments -childDepartments -childUsers -__v')
      .populate({
        path: 'childUserGroups',
        populate: {
          path: 'childGroupUsers',
          match: { isDeleted: false },
          select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -childUserGroups -childPrivateContacts -childBookmarkUsers',
          populate: [{
            path: 'childStatusInfo',
            select: '-parentUser -__v -_id',
          }, {
            path: 'parentCompany',
            select: 'companyName',
          }, {
            path: 'parentDepartment',
            select: 'departmentName',
          }],
        },
      })
      .populate({
        path: 'childBookmarkUsers',
        match: { isDeleted: false },
        select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -parentGroup -childUserGroups -childPrivateContacts -childBookmarkUsers',
        populate: [{
          path: 'childStatusInfo',
          select: '-parentUser -__v -_id',
        }, {
          path: 'parentCompany',
          select: 'companyName',
        }, {
          path: 'parentDepartment',
          select: 'departmentName',
        }],
      })
      .populate({
        path: 'childPrivateContacts',
        match: { isDeleted: false },
        select: '-hashedPassword -passwordSalt -childSignInfos -useMessenger -mfa -__v -parentGroup -childUserGroups -childPrivateContacts -childBookmarkUsers',
        populate: [{
          path: 'childStatusInfo',
          select: '-parentUser -__v -_id',
        }, {
          path: 'parentCompany',
          select: 'companyName',
        }, {
          path: 'parentDepartment',
          select: 'departmentName',
        }],
      }),
      userSignInfoModel({tenantFlag}).findOne({parentUser: userId, accessToken}).select('alarmOffChattingRooms'),
      userBadgeModel({tenantFlag}).findOne({'parentUser': userId}),
    ]);

    const companyDetail = await companyDetailModel({tenantFlag})
      .findOne({parentCompany: new mongoose.mongo.ObjectId(userInfo.parentCompany._id)})
      .select('waterMarkUseYn privacyFilterYn useCompanyOnlyYn sentFileSizePc sentFileSizeMobile fileServerSavePeriod isDisableNoCapturing orgReadAuthorityPc orgReadAuthorityMobile fileControlAuthorityPc fileControlAuthorityMobile');

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        userInfo,
        alarmOffChattingRooms: signInfo.alarmOffChattingRooms || [],
        badgeInfo,
        companyDetail,
        allowedExts: ALLOWED_EXTS,
      },
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
    };
  }
};

export default getMyData;
