import Koa from 'koa';
import userSignInfoModel from 'models/account/user_sign_info';
import {UserStatusCode} from '../../../../../constants/commonConstants';

const getSignedPC = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');
    const signInfo = await userSignInfoModel({tenantFlag})
      .findOne({
        parentUser: userId,
        $or: [
          {deviceType: 'darwin'},
          {deviceType: 'win32'},
        ],
        pcStatus: {$ne: UserStatusCode.OFFLINE},
      });
    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        pc: signInfo,
      },
    };
  } catch (err) {
    console.log('getSignedPC error :', err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getSignedPC;
