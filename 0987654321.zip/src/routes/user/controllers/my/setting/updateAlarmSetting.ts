import Koa from 'koa';
import userSignInfoModel from 'models/account/user_sign_info';
import userInfoModel from 'models/account/user_info';

const updateAlarmSetting = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const userId = ctx.response.get('userId');

    const body: any = ctx.request.body;
    const {updateValues} = body;

    await userSignInfoModel({tenantFlag})
      .updateMany({
        parentUser: userId,
        // accessToken: ctx.headers['access-token'],
      }, updateValues);

    if (updateValues.hasOwnProperty('onlyAlarmWhenPCIsAbsence')) {
      const val = updateValues['onlyAlarmWhenPCIsAbsence'];
      await userInfoModel({tenantFlag}).updateOne({
        '_id': userId,
      }, {
        'useAlarmWhenPCIsUnfocused': val,
      });
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default updateAlarmSetting;
