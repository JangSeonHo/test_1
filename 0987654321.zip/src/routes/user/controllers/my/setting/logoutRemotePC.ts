import Koa from 'koa';
import userSignInfoModel from 'models/account/user_sign_info';

const logoutRemotePC = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');

    const {signId} = ctx.request.body as any;

    await userSignInfoModel({tenantFlag})
      .updateOne({_id: signId}, {sendStream: true});

    ctx.status = 200;
    ctx.body = {
      'success': true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default logoutRemotePC;
