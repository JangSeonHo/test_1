/* eslint-disable max-len */
/* eslint-disable indent */
import Koa from 'koa';
import mongoose from 'mongoose';
import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyInfoModel from 'models/company/company_company_info';
import companyDepartmentInfoModel from 'models/company/company_department_info';

const getUserInfoByPhoneNo = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const {phoneNo} = ctx.request.body;

    if (!phoneNo) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request - phoneNo',
      };

      return;
    }

    // before populate
    companyInfoModel({tenantFlag});
    companyDepartmentInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});

    const users = await userInfoModel({ tenantFlag })
      .find({ personalPhoneNumber: phoneNo })
      .select('userName jobTitle email personalPhoneNumber profileImage parentCompany parentDepartment')
      .populate('parentDepartment', 'departmentName')
      .populate('parentCompany', 'companyName');

    if (users.length === 1) {
      const user = users[0];

      const userResponse = {
        userName: user.userName?.ko || '',
        grade: user.jobTitle?.ko || '',
        companyName: user.parentCompany?.companyName?.ko || '',
        imageFile: user.profileImage || '',
        deptName: user.parentDepartment?.departmentName?.ko || ''
      };

      ctx.status = 200;
      ctx.body = {
        responseMsg: '',
        responseCode: 200,
        user: userResponse
      };
    } else if (users.length > 1) {
      ctx.status = 200;
      ctx.body = {
        responseMsg: '여러명의 사용자가 존재합니다.',
        responseCode: 409,
        user: {
          userName: '',
          grade: '',
          companyName: '',
          imageFile: '',
          deptName: ''
        }
      };
    } else {
      ctx.status = 200;
      ctx.body = {
        responseMsg: '사용자를 찾을 수 없습니다.',
        responseCode: 204,
        user: {
          userName: '',
          grade: '',
          companyName: '',
          imageFile: '',
          deptName: ''
        }
      };
    }

  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getUserInfoByPhoneNo;
