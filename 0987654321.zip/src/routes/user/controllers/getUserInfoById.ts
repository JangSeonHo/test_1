/* eslint-disable max-len */
/* eslint-disable indent */
import Koa from 'koa';
import mongoose from 'mongoose';
import userInfoModel from 'models/account/user_info';
import userStatusInfoModel from 'models/account/user_status_info';
import companyInfoModel from 'models/company/company_company_info';
import companyDepartmentInfoModel from 'models/company/company_department_info';
import userWorkingStatusModel from 'models/account/user_working_status';
import { HR_WORKING_STATUS_COMPANIES } from '../../../constants/commonConstants';

interface WorkingStatus {
  attend?: string;
}

const getUserInfoById = async (ctx: Koa.Context) => {
  try {
    const {id} = ctx.query;

    if (!id || !mongoose.Types.ObjectId.isValid(id.toString())) {
      ctx.status = 400;
      ctx.body = {
        'success': false,
        'error': 'bad request',
      };

      return;
    }

    const tenantFlag = ctx.response.get('tenantFlag');

    // before populate
    companyInfoModel({tenantFlag});
    companyDepartmentInfoModel({tenantFlag});
    userStatusInfoModel({tenantFlag});
    userWorkingStatusModel({tenantFlag});

    const userInfo = await userInfoModel({tenantFlag}).findOne({_id: id})
      .select('userName jobTitle email personalPhoneNumber officePhoneNumber profileImage useMessenger parentCompany parentDepartment childStatusInfo baseContactNumber agreeProfileImagePolicy emailId')
      .populate('childStatusInfo', '-_id -__v')
      .populate('parentDepartment', 'departmentName')
      .populate('parentCompany', 'companyName companyCode');

    if (!userInfo) {
      ctx.status = 404;
      ctx.body = {
        'success': false,
        'error': 'user not found',
      };
      return;
    }

    let workingStatus = null;
    // 근태 정보 조회 - 이노텍 
    if (userInfo.parentCompany && HR_WORKING_STATUS_COMPANIES.includes(userInfo.parentCompany.companyCode)) {
      const status = await userWorkingStatusModel({tenantFlag})
        .findOne({
          company_code: userInfo.parentCompany.companyCode,
          user_id: userInfo.emailId,
        })
        .sort({date: -1})
        .select('attend')
        .lean() as WorkingStatus;
      
      workingStatus = status?.attend || null;
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'data': {
        userInfo: {
          ...userInfo.toObject(),
          workingStatus,
        }
      }
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getUserInfoById;
