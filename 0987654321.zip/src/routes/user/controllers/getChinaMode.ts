/* eslint-disable max-len */
/* eslint-disable indent */
import Koa from 'koa';
import userSignInfoModel from 'models/account/user_sign_info';

const getChinaMode = async (ctx: Koa.Context) => {
  try {
    //const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');
    const accessToken = ctx.headers["access-token"] ?? ctx.query.accessToken;

    const body: any = ctx.request.body;
    const {userId} = body;

    const targetUserSignInfoModel = userSignInfoModel({tenantFlag});

    const singInfo = await targetUserSignInfoModel
    .findOne({ parentUser: userId, accessToken: accessToken })
    .select("_id parentUser isChina pushToken pushType");

    let returnIsChina = false;
    let returnPushToken = null;
    let returnPushType = null;
    if (singInfo) {
      returnIsChina = singInfo.isChina;
      returnPushToken = singInfo.pushToken;
      returnPushType = singInfo.pushType;
    } else {
      ctx.status = 404;
      ctx.body = {
        'success': false,
        'error': 'User not found',
      };
      return;
    }

    ctx.status = 200;
    ctx.body = {
      'success': true,
      'isEnable' : returnIsChina,
      'pushToken' : returnPushToken,
      'pushType': returnPushType
    };
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      'success': false,
      'error': 'internal server error',
    };
  }
};

export default getChinaMode;
