/* eslint-disable max-len */
import Router from '@koa/router';

const router = new Router();

// middlewares
import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

// 북마크 api
import addBookmark from './controllers/my/bookmark/addBookmark';
router.post('/addBookmarkMember', isLoggedIn, addBookmark);

import removeBookmark from './controllers/my/bookmark/removeBookmark';
router.post('/removeBookmarkMember', isLoggedIn, removeBookmark);


// 그룹 api
import addGroup from './controllers/my/group/addGroup';
router.post('/addUserGroup', isLoggedIn, addGroup);

import renameGroup from './controllers/my/group/renameGroup';
router.put('/renameUserGroup', isLoggedIn, renameGroup);

import copyGroup from './controllers/my/group/copyGroup';
router.post('/copyUserGroup', isLoggedIn, copyGroup);

import deleteGroup from './controllers/my/group/deleteGroup';
router.post('/deleteUserGroup', isLoggedIn, deleteGroup);

import addMembersToGroup from './controllers/my/group/addMembersToGroup';
router.post('/addMembersToGroup', isLoggedIn, addMembersToGroup);

import removeMemberInGroup from './controllers/my/group/removeMemberInGroup';
router.post('/removeMemberInGroup', isLoggedIn, removeMemberInGroup);

import updateAllMembersInGroup from './controllers/my/group/updateAllMemberInGroup';
router.post('/updateAllMembersInGroup', isLoggedIn, updateAllMembersInGroup);


// 맴버 api
import addFromMyDepartment from './controllers/my/privateMember/addMembersFromMyDepartment';
router.post('/addMembersFromMyDepartment', isLoggedIn, addFromMyDepartment);

import addFromPhoneNumbers from './controllers/my/privateMember/addMembersFromPhoneNumbers';
router.post('/addMembersFromPhoneNumbers', isLoggedIn, addFromPhoneNumbers);

import addFromUserIds from './controllers/my/privateMember/addMembersFromUserIds';
router.post('/addMembersFromUserIds', isLoggedIn, addFromUserIds);

import removeMemberFromUserIds from './controllers/my/privateMember/removeMembersFromUserIds';
router.post('/removeMembersFromUserIds', isLoggedIn, removeMemberFromUserIds);

// 설정 api
import getSignInfo from './controllers/my/getSignInfo';
router.get('/getSignInfo', isLoggedIn, getSignInfo);

import updateAlarmSetting from './controllers/my/setting/updateAlarmSetting';
router.post('/updateAlarmSetting', isLoggedIn, updateAlarmSetting);

// 프로필 api
import changeStatus from './controllers/my/profile/changeStatus';
router.put('/changeStatus', isLoggedIn, changeStatus);
import updateUserStatus from './controllers/my/profile/updateUserStatus';
router.post('/updateUserStatus', isLoggedIn, updateUserStatus);

// *check s3 //
import changeProfileImage from './controllers/my/profile/changeProfileImage';
router.post('/changeProfileImage', isLoggedIn, changeProfileImage);

import changeProfileMessage from './controllers/my/profile/changeProfileMessage';
router.put('/changeProfileMessage', isLoggedIn, changeProfileMessage);

import updateFCM from './controllers/my/updateFCM';
router.put('/updatePushToken', isLoggedIn, updateFCM);

import changeBaseContactNumber from './controllers/my/profile/changeBaseContactNumber';
router.post('/changeBaseContactNumber', isLoggedIn, changeBaseContactNumber);

// 초기 내 정보 로딩 api
import getMyData from './controllers/my/profile/getMyData';
router.get('/getMyData', isLoggedIn, getMyData);


// 유저 profile
import getUserInfoById from './controllers/getUserInfoById';
router.get('/getUserInfoById', isLoggedIn, getUserInfoById);

// 유저 해지 컬렉션 3개월 지난 데이타 삭제처리.
import removeUserCancelInfo from './controllers/removeUserCancelInfo';
router.post('/removeUserCancelInfo', removeUserCancelInfo);

import updateMyInfo from './controllers/my/updateMyInfo';
router.post('/updateMyInfo', isLoggedIn, updateMyInfo);

import getSignedPC from './controllers/my/setting/getSignedPC';
router.get('/getSignedPC', isLoggedIn, logApiAccess, getSignedPC);

// pc
import logoutRemotePC from './controllers/my/setting/logoutRemotePC';
router.post('/logoutRemotePC', isLoggedIn, logApiAccess, logoutRemotePC);

import alertPCStatus from './controllers/my/setting/alertPCStatus';
router.post('/alertPCStatus', isLoggedIn, alertPCStatus);

// badge
import getBadge from './controllers/my/getBadge';
router.get('/getBadge', isLoggedIn, getBadge);

//중국 內 사용모드 설정 API
import setChinaMode from './controllers/setChinaMode';
router.post('/setChinaMode', isLoggedIn, setChinaMode);

//중국 內 사용모드 조회 API
import getChinaMode from './controllers/getChinaMode';
router.post('/getChinaMode', isLoggedIn, getChinaMode);

//전화번호로 사용자 검색
import getUserInfoByPhoneNo from './controllers/getUserInfoByPhoneNo';
router.post('/getUserInfoByPhoneNo', getUserInfoByPhoneNo);

export default router;
