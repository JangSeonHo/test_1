import Router from '@koa/router';
const router = new Router();

import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

import getCompanyById from './controllers/getCompanyById';
router.get('/getCompanyById', getCompanyById);

import getDepartmentById from './controllers/getDepartmentById';
router.get('/getDepartmentById', isLoggedIn, getDepartmentById);

import getGroupByKoName from './controllers/getGroupByKoName';
router.get('/getGroupByKoName', getGroupByKoName);

export default router;
