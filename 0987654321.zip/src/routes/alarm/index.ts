import isLoggedIn from 'middlewares/isLoggedIn';
import logApiAccess from 'middlewares/logAPIAccess';

import Router from '@koa/router';
const router = new Router();

import getAlarms from './controllers/getAlarms';
router.get('/getAlarms', isLoggedIn, logApiAccess, getAlarms);

import readAlarm from './controllers/readAlarm';
router.post('/readAlarm', isLoggedIn, readAlarm);

import deleteAlarms from './controllers/deleteAlarms';
router.post('/deleteAlarms', isLoggedIn, deleteAlarms);

import resolveReminder from './controllers/resolveReminder';
router.post('/resolveReminder', isLoggedIn, resolveReminder);

import transSystemAlarm from './controllers/transSystemAlarm';
router.post('/transSystemAlarm', transSystemAlarm);

export default router;
