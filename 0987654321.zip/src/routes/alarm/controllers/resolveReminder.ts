import Koa from 'koa';

import {alarmModelPrimaryOnly} from 'models/alarm/alarm';
import userBadgeModel from 'models/account/user_badge';

const resolveReminder = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const {alarmId} = ctx.request.body;

    const TargetAlarmModel = await alarmModelPrimaryOnly({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    const isNotRead = await TargetAlarmModel.find({_id: alarmId, parentUser: userId, isRead: false}).lean();
    if (isNotRead.length > 0) {
      await TargetUserBadgeModel.updateOne({parentUser: userId}, {
        $inc: {unreadAlarms: -1},
      });
    }
    await TargetAlarmModel.deleteOne({
      _id: alarmId,
      parentUser: userId,
      type: 'reminder',
    });

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default resolveReminder;
