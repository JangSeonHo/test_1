import Koa from 'koa';

import {alarmModelPrimaryOnly} from 'models/alarm/alarm';
import userBadgeModel from 'models/account/user_badge';

const readAlarm = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const {alarmId} = ctx.request.body;

    const TargetAlarmModel = alarmModelPrimaryOnly({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    const isNotRead = await TargetAlarmModel.find({_id: alarmId, parentUser: userId, isRead: false}).lean();
    if (isNotRead.length > 0) {
      await Promise.all([
        TargetAlarmModel.updateOne({_id: alarmId, parentUser: userId}, {
          isRead: true,
        }),
        TargetUserBadgeModel.updateOne({parentUser: userId}, {
          $inc: {unreadAlarms: -1},
        }),
      ]);
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default readAlarm;
