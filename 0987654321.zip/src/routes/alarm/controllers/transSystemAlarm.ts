import Koa from 'koa';

import alarmModel from 'models/alarm/alarm';
import userInfoModel from 'models/account/user_info';
import companyCompanyModel from 'models/company/company_company_info';
import companyDepartmentModel from 'models/company/company_department_info';

const transSystemAlarm = async (ctx: Koa.Context) => {
  try {
		const tenantFlag = ctx.response.get('tenantFlag');

		const {alarmCode, alarmType, receiver, title, content, sender, companyCode} = ctx.request.body;

		console.log(alarmCode);
		console.log(alarmType);
		console.log(receiver);
		console.log(title);
		console.log(content);
		console.log(companyCode);


		/*
		alarmCode : 알림 식별 코드
		alarmType : 알림유형
		receiver : 수신자 - 배열형태로 받음.
		title : 타이틀
		content : 메세지
		companyCode : 회사코드 -- 임시로 추가함. 삭제할것임.
		*/

		// 등록항목 : type, parentUser, actionUser, content, isRead, createAt
		const TargetAlarmModel = await alarmModel({tenantFlag});


		if (!Array.isArray(receiver)) {
			ctx.status = 400;
			ctx.body = {
			  success: false,
			  error: 'Receiver must be an array',
			};
			return;
		}

		//alarmCode : 알림 식별 코드로 시스템알림 API에 등록되어 있는 회사코드와 일치하는 정보들을 가져온다(추후..... 현재는 아직 하지 않는다.)



		await Promise.all(
			receiver.map(async (email) => {
				console.log("sender >>>>", sender);
				//우선 이메일만 하고, 회사 _id 조회해서 parentCompany도 조건에 추가하도록 하자.
			  const actionUser = await userInfoModel({tenantFlag}).findOne({ email: sender});
				if (!actionUser) {
					console.warn(`111.Parent User not found for email: ${sender}, companyCode: ${companyCode}`);
					ctx.status = 500;
					ctx.body = {
						success: false,
						error: `111.Parent User not found for email: ${sender}, companyCode: ${companyCode}`
					};
					return;
			  }

				console.log("receiver >>> ", email);
			  const parentUser = await userInfoModel({tenantFlag}).findOne({ email: email});
				if (!parentUser) {
					console.warn(`222.Action User not found for email: ${email}, companyCode: ${companyCode}`);
					ctx.status = 500;
					ctx.body = {
						success: false,
						error: `222.Action User not found for email: ${email}, companyCode: ${companyCode}`
					}
					return;
			  }


			  const nam = new TargetAlarmModel({
				'type': "system_alarm",
				'parentUser': parentUser._id,
				'actionUser': actionUser._id,
				'content': content,
				'isRead' : false,
				'createdAt': new Date().getTime(),
			  });
			  await nam.save();
			})
		);

		ctx.status = 200;
		ctx.body = {
			success: true,
		};
  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
      err,
    };
  }
};

export default transSystemAlarm;