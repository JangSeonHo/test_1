import Koa from 'koa';

import {alarmModelPrimaryOnly} from 'models/alarm/alarm';
import userBadgeModel from 'models/account/user_badge';

const deleteAlarms = async (ctx: Koa.Context) => {
  try {
    const userId = ctx.response.get('userId');
    const tenantFlag = ctx.response.get('tenantFlag');

    const {alarmIds} = ctx.request.body;

    const TargetAlarmModel = alarmModelPrimaryOnly({tenantFlag});
    const TargetUserBadgeModel = userBadgeModel({tenantFlag});

    await Promise.all(alarmIds.map(async (alarmId: string) => {
      const {isRead, type} = await TargetAlarmModel.findOne({_id: alarmId})
        .select('isRead type');

      await TargetAlarmModel.deleteOne({_id: alarmId, parentUser: userId});

      if (!isRead && (type === 'reminder' || type === 'system_alarm')) {
        await TargetUserBadgeModel.updateOne({parentUser: userId}, {
          $inc: {unreadAlarms: -1},
        });
      }
    }));
    const {unreadAlarmCnt} = await TargetUserBadgeModel.findOne({parentUser: userId})
      .select('unreadAlarms');
    if (unreadAlarmCnt < 0) {
      await TargetUserBadgeModel.updateOne({parentUser: userId}, {unreadAlarms: 0});
    }

    ctx.status = 200;
    ctx.body = {
      success: true,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: 'internal server error',
    };
  }
};

export default deleteAlarms;
