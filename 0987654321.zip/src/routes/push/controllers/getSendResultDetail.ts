import Koa from 'koa';
import pushAuthTokenInfoModel from 'models/push/push_auth_token_info';
import systemAlarmInfoModel from 'models/push/system_alarm_info';
import userInfoModel from 'models/account/user_info';


const getSendResultDetail = async (ctx: Koa.Context) => {
  try {
    const tenantFlag = ctx.response.get('tenantFlag');
    const authToken = ctx.headers['auth-token'] ?? ctx.query.authToken;
    const { uid, companyCode } = ctx.request.body;

    const targetSystemAlarmInfoModel = systemAlarmInfoModel({ tenantFlag });

    // AuthToken 정보 확인
    const targetPushAuthTokenInfoModel = pushAuthTokenInfoModel({ tenantFlag });
    const resultAuthToken = await targetPushAuthTokenInfoModel.findOne({
      tenantFlag: tenantFlag,
      companyCode: { $eq: companyCode },
      authToken: authToken,
    });

    let paramAuthToken;
    if (resultAuthToken && resultAuthToken.authToken) {
      paramAuthToken = resultAuthToken.authToken;
    } else {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0001",
        resultMsg: "authKey mismatch",
      };
      return;
    }

    const targetUserInfoModel = userInfoModel({ tenantFlag });
    const result: any = await targetSystemAlarmInfoModel
      .findOne({ _id: uid, companyCode: companyCode })
      .populate({
        path: 'receiveInfo.receiveUser',
        model: targetUserInfoModel,
        select: {
          'userName.ko': 1,
          personalPhoneNumber: 1,
          email: 1,
        },
      });

    //수신자(receiveInfo)
    const receiveInfo = Array.isArray(result?.receiveInfo)
      ? result.receiveInfo.map((item: any) => ({
          resultCode: item.receiveResultCode === 'OK' ? '0000' : 'FAIL',
          userName: item.receiveUser?.userName || '',
          mobile: item.receiveUser?.personalPhoneNumber || '',
          email: item.receiveUser?.email || '',
          senderType: item.sendDivision,
        }))
      : [];

    // 첨부파일(attachedFiles)
    const attachedFiles = Array.isArray(result?.attachedFiles)
    ? result.attachedFiles.map((file: any) => ({
        originalName: file.originalName,
        fileName: file.fileName,
        path: file.path,
        size: file.size,
      }))
    : [];

    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(JSON.stringify(result, null, 2));
    }

    ctx.status = 200;
    ctx.body = {
      resultCode: "0000",
      resultMsg: "success",
      title: result.title,
      message: result.message,
      budalMode: result.budalMode,
      sender: result.sender,
      senderMobile: result.senderMobile,
      resultList: receiveInfo,
      attachedFiles,
    };
  } catch (err) {
    ctx.status = 500;
    ctx.body = {
      resultCode: "0500",
      resultMsg: "internal server error",
      resultList: [],
    };
  }
};

export default getSendResultDetail;
