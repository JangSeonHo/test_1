import Koa from 'koa';


import pushAuthTokenInfoModel from 'models/push/push_auth_token_info';
import systemAlarmInfoModel from 'models/push/system_alarm_info';

const getSendResult = async (ctx: Koa.Context) => {
  try{
    const tenantFlag = ctx.response.get('tenantFlag');
    const authToken = ctx.headers['auth-token'] ?? ctx.query.authToken;

    const {uidList, companyCode} = ctx.request.body;
    console.log(companyCode, uidList);

    const targetSystemAlarmInfoModel = systemAlarmInfoModel({tenantFlag});


    //========================================================================================================
    // 회사별 AuthToken정보가 있는지 조회한다. 존재하지 않으면 리턴한다.
    // 0001: authKey mismatch
    //========================================================================================================
    const targetPushAuthTokenInfoModel = pushAuthTokenInfoModel({tenantFlag});
    const resultAuthToken = await targetPushAuthTokenInfoModel.findOne({
      tenantFlag: tenantFlag,
      companyCode: { $eq: companyCode },
      authToken: authToken
    });

    let paramAuthToken;

    // companyCode에 해당하는 authToken 값이 있는지 확인
    if (resultAuthToken && resultAuthToken.authToken) {
      paramAuthToken = resultAuthToken.authToken;
    } else {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0001",
        resultMsg: "authKey mismatch"
      };
      return;
    }
    //========================================================================================================

    const result = await targetSystemAlarmInfoModel
      .find({ _id: { $in: uidList }, companyCode: companyCode })
      .select("_id sendResultCode");

    // 메시지 코드에 따른 메시지 매핑
    const codeMessages: { [key: string]: string } = {
        "0000": "success",
        "0001": "delay",
        "0002": "error",
        "0003": "data not found",
        "0004": "SMS send",
        "0005": "LMS send",
    };

    // 결과를 원하는 형식으로 포맷
    const resultList = result.map((item) => ({
        uid: item._id.toString(),
        resultCode: item.sendResultCode,
        resultMsg: codeMessages[String(item.sendResultCode)] || "UNKNOWN",
    }));


    ctx.status = 200;
    ctx.body = {
        resultCode: "0000",
        resultMsg: "success",
        resultList: resultList,
    };

  }catch(err){
    ctx.status = 500;
    ctx.body = {
      resultCode: "0500",
      resultMsg: "internal server error",
      resultList: []
    };
  }
}

export default getSendResult;