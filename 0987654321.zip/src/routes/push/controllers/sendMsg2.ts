/* eslint-disable max-len */
import Koa from 'koa';
import admin from 'firebase-admin';
import axios from 'axios';
import pushy from 'pushy';
const { ObjectId } = require('mongodb');

import pushAuthTokenInfoModel from 'models/push/push_auth_token_info';
import companyCompanyInfoModel from 'models/company/company_company_info';
import userInfoModel from 'models/account/user_info';
import userSignInfoModel from 'models/account/user_sign_info';
import userAlarmModel from 'models/alarm/alarm';
import systemAlarmInfoModel from 'models/push/system_alarm_info';
import userBadgeModel from 'models/account/user_badge';

const mongoose = require("mongoose");

// Pushy API 초기화 (API Key 필요) -- 현재 작업안함....
const pushyAPI = new pushy('431b11499e3ade8f0df11896c8d8c4a1cfabd60c7f77241ac24fd80fde32fc68');

/*
-------------------------------------------------------------
■ 알림톡 알림서비스 등록 정보
-------------------------------------------------------------
서비스 ID : 2400105696
API ServerName : mTalk
API 인증 토큰 :  5I0uE5LbZ7aTY4WDw08LeA==
-------------------------------------------------------------
*/

const TENANT_FLAG = "tenantFlag";
const AUTH_TOKEN = "auth-token";
const TALK_SERVICE_ID = "2400105696";
const SEND_TYPE_NAME = "system_alarm";
const SEND_TYPE_FCM = "FCM";
const SEND_TYPE_SMS = "SMS";
const SEND_TYPE_LMS = "LMS";
const SMS_URL = "https://talkapi.lgcns.com/request/sms.json";
const LMS_URL = "https://talkapi.lgcns.com/request/lms.json";
const MSG_SUCCESS = "success";
const MSG_OK = "OK";
const MSG_FAIL = "FAIL";
const MSG_ERROR = "error";
const MSG_FCM_ERROR_INFO = "messaging/registration-token-not-registered";
const RESULT_CODE_SUCCESS = "0000";
const RESULT_CODE_SERVER_ERROR = "0500";
const RESULT_CODE_SERVER_ERROR_MSG = "internal server error";



const sendMsg = async (ctx: Koa.Context) => {
  try {
    const reqIp: string = ctx.request.ip ?? '';
    const tenantFlag = ctx.response.get(TENANT_FLAG);
    const authToken = ctx.headers[AUTH_TOKEN] ?? ctx.query.authToken;

    const {companyCode, title, message, budalMode, sender, senderMobile, email} = ctx.request.body;

    const targetSystemAlarmInfoModel = systemAlarmInfoModel({tenantFlag});
    //========================================================================================================
    // 회사별 AuthToken정보가 있는지 조회한다. 존재하지 않으면 리턴한다.
    // 0001: authKey mismatch
    //========================================================================================================
    const targetPushAuthTokenInfoModel = pushAuthTokenInfoModel({tenantFlag});
    const resultAuthToken = await targetPushAuthTokenInfoModel.findOne({
      tenantFlag: tenantFlag,
      companyCode: { $eq: companyCode },
      authToken: authToken
    });

    let paramAuthToken;

    // companyCode에 해당하는 authToken 값이 있는지 확인
    if (resultAuthToken && resultAuthToken.authToken) {
      paramAuthToken = resultAuthToken.authToken;
    } else {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0001",
        resultMsg: "authKey mismatch"
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 회사코드 존재여부 조회.
    // 0002: companyCode not found
    //========================================================================================================
    const targetCompanyCompanyInfoModel = companyCompanyInfoModel({ tenantFlag }) as any;
    const company = await targetCompanyCompanyInfoModel.findOne({ companyCode: companyCode }).select("companyCode");

    if (!company) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0002",
        resultMsg: "companyCode not found"
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 이메일 파라미터의 값이 없는 경우
    // 0004: email is empty
    //========================================================================================================
    if (!Array.isArray(email) || email.length === 0 || email.every((num) => !num.trim())) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0004",
        resultMsg: "email is empty"
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 이메일 정보가 존재하지 않는 경우 -- 파라미터 email로 변경함. - 11.01
    // 0005: user email does not exist.["이메일", "이메일1", "이메일2", ...,"이메일n"]
    //========================================================================================================
    const targetUserInfoModel = userInfoModel({tenantFlag});

    // sender
    const actionUser = await userInfoModel({ tenantFlag }).findOne({ email: sender }).select("_id email");
    let actionUserId = actionUser ? actionUser._id : sender;


    const users = await targetUserInfoModel.find(
      { email: { $in: email } },
      { _id: 1, email: 1, userName: 1, personalPhoneNumber: 1, parentCompany: 1 }
    );

    // 존재하는 이메일 목록 추출
    const existingEmails = users.map(user => user.email);

    // 없는 이메일 필터링
    const nonExistingEmails = email.filter(e => !existingEmails.includes(e));

    if (nonExistingEmails.length > 0) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0005",
        resultMsg: `This email does not exist for that company. [${nonExistingEmails}]`
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 타이틀이 빈값인 경우.
    // 0006: title is empty
    //========================================================================================================
    if (typeof title !== 'string' || !title.trim()) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0006",
        resultMsg: "title is empty"
      };
      return;
    }
    //========================================================================================================




    const getByteLength = (str: string): number => Buffer.byteLength(str, 'utf8');
    //========================================================================================================
    // title 유효성 검사: 길이 제한 (50자 / 100바이트)
    // 0007: title length exceeded
    //========================================================================================================
    if (title.length > 50 || getByteLength(title) > 100) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0007",
        resultMsg: "title length exceeded"
      };
      return;
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 컨텐츠가 빈값인 경우.
    // 0008: content is empty
    //========================================================================================================
    if (typeof message !== 'string' || !message.trim()) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0008",
        resultMsg: "content is empty"
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // content 유효성 검사: 길이 제한 (50자 / 100바이트).
    // 0009: content length exceeded
    //========================================================================================================
    let messageType = "";

    if (message.length <= 40 && getByteLength(message) <= 90) {
      messageType = SEND_TYPE_SMS;
    }else if (message.length > 40 && message.length <= 1000 && getByteLength(message) <= 2000) {
      messageType = SEND_TYPE_LMS;
    }

    if (message.length > 1000 || getByteLength(message) > 2000) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0009",
        resultMsg: "content length exceeded"
      };
      return;
    }
    //========================================================================================================




    //========================================================================================================
    // 발신가 빈값인 경우.
    // 0010: sender is empty
    //========================================================================================================
    if (typeof sender !== 'string' || !sender.trim()) {
      ctx.status = 500;
      ctx.body = {
        uid: "",
        resultCode: "0010",
        resultMsg: "sender is empty"
      };
      return;
    }
    //========================================================================================================



    //========================================================================================================
    // 부달기능이 true인 경우, senderMobile은 필수 항목이다.
    // 0012: sender mobile is empty
    //========================================================================================================
    if(budalMode){
      if (typeof senderMobile !== 'string' || !senderMobile.trim()) {
        ctx.status = 500;
        ctx.body = {
          uid: "",
          resultCode: "0012",
          resultMsg: "[budalMode === true], sender mobile is empty"
        };
        return;
      }
    }

    //========================================================================================================








    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //
    // START - FCM, Pusy.me, 문자(SMS, LMS)
    //
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

    const targetUserAlarmModel = await userAlarmModel({tenantFlag});
    const targetUserSignInfoModel = userSignInfoModel({ tenantFlag });

    let finalResults: any[] = [];

    let totalCount = 0;
    let successCount = 0;
    let failCount = 0;
    let delayCount = 0;


    // UserInfo 데이터 가져오기
    const userinfos = await targetUserInfoModel.find(
      { email: { $in: email } },
      {
        _id: 1,
        userName: 1,
        email: 1,
        personalPhoneNumber: 1
      }
    ).lean();
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log("");
      console.log(`[push/sendMsg][budalMode === FALSE][FCM]푸시전송 >>>>>>>>>> userinfos >>>>> ${JSON.stringify(userinfos, null, 2)}`);
      console.log("");
    }

    const userIds = userinfos.map(user => user._id);
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`userIds >>>> ${userIds}`);
    }

    // nmp_user_sign_inf에 유효한 토큰 정보가 있는지 확인한다.
    const userSignInfos = await targetUserSignInfoModel.find({
      parentUser: { $in: userIds },
      deviceType: { $in: ['android', 'ios'] },
      usePushAlarm: true,
      pushToken: { $exists: true, $ne: '' }
    }).select('parentUser deviceType pushToken isChina').lean();

    userinfos.forEach(user => {
      // 해당 사용자의 signInfo 데이터를 찾음
      const signInfo = userSignInfos.find(sign => String(sign.parentUser) === String(user._id));

      // signInfo가 있는 경우 deviceType과 pushToken 필드를 user에 추가
      if (signInfo) {
        user.deviceType = signInfo.deviceType;
        user.pushToken = signInfo.pushToken;
        user.isChina = signInfo.isChina;
      } else {
        user.deviceType = null;
        user.pushToken = null;
        user.isChina = null;
      }
    });
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log(`userinfos >>>> ${JSON.stringify(userinfos, null, 2)}`);
    }

    totalCount = userinfos.length;



    // 결과를 저장할 배열
    const results: { mobile: string, status: string, response?: any, userId?: string, userEmail?: string, pushToken?: string, sendType?: string }[] = [];


    //--------------------------------------------------------------------------------------------------------------------------------------------
    // 각 사용자에 대해 푸시 메시지 생성 및 전송
    //--------------------------------------------------------------------------------------------------------------------------------------------
    const sendPromises = userinfos.map(async (user) => {
      const { deviceType, pushToken, isChina, _id, email, personalPhoneNumber } = user;

      //FCM 전송
      if(!isChina){
        // notification 기본 설정
        const notification = {
          title: title,
          body: message,
        };

        // FCM 메시지 생성
        const msg: any = {
          data: {
            type: 'chatting_room',
            id: "1234567890123456789",
            ...notification,
            badge: "0",
          },
          token: pushToken,
        };

        // Android용 메시지 설정
        if (deviceType === 'android') {
          msg.android = {
            priority: 'HIGH',
          };
        }

        // iOS용 메시지 설정
        if (deviceType === 'ios') {
          msg.notification = notification;
          msg.apns = {
            payload: {
              aps: {
                sound: 'default',
                badge: 0,
              },
            },
          };
        }

        try {
          const response = await admin.messaging().send(msg);
          successCount++;

          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log(`[push/sendMsg][FCM] Firebase response Send OK >>>>>> ${email} ::: ${response}`);
            console.log(`[push/sendMsg][FCM] Firebase response Send OK [pushToken] >>>>>> ${successCount} ::: ${pushToken}`);
          }

          //---------------------------------------------------------------------------------
          // nmp_user_alarm 컬렉션에 정보 저장
          //---------------------------------------------------------------------------------
          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log(`[push/sendMsg][FCM] nmp_user_alarm 컬렉션에 정보 저장 >>>>>> ${email} ::: ${_id} ::: ${actionUserId}`);
          }

          const userAlarm = new targetUserAlarmModel({
            type: SEND_TYPE_NAME,
            parentUser: _id,
            content: message,
            isRead: false,
            createdAt: new Date().getTime(),
          });

          // actionUserId가 ObjectId이면 actionUser 필드를 추가합니다.
          if (mongoose.Types.ObjectId.isValid(actionUserId)) {
            userAlarm.actionUser = actionUserId;
          }

          const TargetUserBadgeModel = userBadgeModel({tenantFlag});
          await Promise.all([
            userAlarm.save(),
            TargetUserBadgeModel.updateOne({parentUser: user._id}, {
              $inc: {unreadAlarms: 1},
            }),
          ]);
          //---------------------------------------------------------------------------------


          // 전송 성공 결과 저장
          results.push({
            mobile: personalPhoneNumber,
            status: MSG_SUCCESS,
            response: response,
            userId: String(_id),
            userEmail: email,
            pushToken: pushToken,
            sendType: "FCM"
          });

        } catch (err) {
          if(user.pushToken != null && user.pushToken != ""){
            failCount++;
          }
          const error = err as { errorInfo?: { code: string } };

          if (error.errorInfo?.code === MSG_FCM_ERROR_INFO) {
            if (process.env.DEVELOPMENT_MODE === 'local') {
              console.warn(`[ERROR][push/sendMsg][FCM][user._id] ${email} , ${_id} ::: Invalid token: ${pushToken}, skipping...`);
            }
            // 유효하지 않은 토큰에 대한 실패 결과 저장
            if(user.pushToken != null && user.pushToken != ""){
              results.push({
                mobile: personalPhoneNumber,
                status: "failed",
                response: "Invalid token",
                userId: String(_id),
                userEmail: email,
                pushToken: pushToken,
                sendType: "FCM"
              });
            }
          } else {
            if (process.env.DEVELOPMENT_MODE === 'local') {
              console.error(`[ERROR][push/sendMsg][FCM][user._id] ${email} , ${_id} ::: Unexpected error >>>> `,String(err));
            }
            // 다른 오류에 대한 실패 결과 저장
            if(user.pushToken != null && user.pushToken != ""){
              results.push({
                mobile: personalPhoneNumber,
                status: MSG_ERROR,
                response: String(err),
                userId: String(_id),
                userEmail: email,
                pushToken: pushToken,
                sendType: "FCM"
              });
            }
          }
        }
      }
      //pushy.me 전송
      else if(isChina){

      }



      const byteLength = getByteLength(message);
      const charLength = message.length;

      let url = "";
      let conditionStr = "";
      let isLMS = false;
      let userMobile = user.personalPhoneNumber;

      // budalMode === true 이면서, nmp_user_sign_infos에 정보가 없으면 문자(SMS, LMS)를 보낸다.
      // 현재, nmp_user_sign_infos에 정보가 없으면, 앱 미설치자로 한다.
      if(budalMode && (user.pushToken === null || user.pushToken === "")){
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[push/sendMsg][SMS/LMS]...문자 발송을 한다.......... >>>> ${JSON.stringify(user, null, 2)}`);
        }

        // 메시지 길이에 따라 API 구분
        if (charLength <= 40 && byteLength <= 90) {
          url = SMS_URL;
          conditionStr = SEND_TYPE_SMS;
        } else if (charLength <= 1000 && byteLength <= 2000) {
          url = LMS_URL;
          conditionStr = SEND_TYPE_LMS;
          isLMS = true; // LMS 발송 여부 플래그 설정
        } else {
          results.push({ mobile: "", status: MSG_ERROR, response: "메시지가 너무 깁니다." });
          return results;
        }


        try {
          // 요청 바디 생성 (LMS일 때만 subject 포함)
          const requestBody: any = {
            service: TALK_SERVICE_ID,
            message,
            mobile: userMobile,
            callbackNo: senderMobile,
          };

          if (isLMS) {
            requestBody.subject = title; // LMS인 경우 subject 추가
          }
          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.log(`[push/sendMsg][budalMode === true] ${requestBody}`);
          }


          const response = await axios.post(url, requestBody, {
            headers: {
              "Content-Type": "application/json",
              "authToken": "5I0uE5LbZ7aTY4WDw08LeA==",
              "serverName": "mTalk",
            },
          });


          if (response.status === 200) {
            successCount++;

            if (process.env.DEVELOPMENT_MODE === 'local') {
              console.log(`[push/sendMsg][budalMode === true] ${conditionStr} - [${userMobile}] - 문자발송 성공 >>> `, response.data);
            }

            // // nmp_user_alarm 컬렉션에 정보 저장 - 알림센터 목록에 조회되기 위함.
            // const tmpUser = await targetUserInfoModel.findOne(
            //   { email: user.email },
            //   { _id: 1, email: 1, userName: 1, personalPhoneNumber: 1, parentCompany: 1 }
            // ).limit(1);
            // if (process.env.DEVELOPMENT_MODE === 'local') {
            //   console.log("[push/sendMsg][budalMode === true] nmp_user_alarm 컬렉션에 정보 저장 >>> ", tmpUser._id, actionUserId, tmpUser.email, tmpUser.personalPhoneNumber);
            // }

            //---------------------------------------------------------------------------------
            // nmp_user_alarm 컬렉션에 정보 저장
            //---------------------------------------------------------------------------------
            // const userAlarm = new targetUserAlarmModel({
            //   type: SEND_TYPE_NAME,
            //   parentUser: tmpUser._id,
            //   content: message,
            //   isRead: false,
            //   createdAt: new Date().getTime(),
            // });

            // // actionUserId가 ObjectId이면 actionUser 필드를 추가합니다.
            // if (mongoose.Types.ObjectId.isValid(actionUserId)) {
            //   userAlarm.actionUser = actionUserId;
            // }
            // const TargetUserBadgeModel = userBadgeModel({tenantFlag});
            // await Promise.all([
            //   userAlarm.save(),
            //   TargetUserBadgeModel.updateOne({parentUser: tmpUser._id}, {
            //     $inc: {unreadAlarms: 1},
            //   }),
            // ]);

            results.push({
              mobile: userMobile,
              status: MSG_SUCCESS,
              response: response.data.uid,
              userId: String(user._id),
              userEmail: user.email,
              pushToken: "",
              sendType: conditionStr
            });



          }else{
            failCount++;
            if (process.env.DEVELOPMENT_MODE === 'local') {
              console.log(`[push/sendMsg][budalMode === true] ${conditionStr} - ${userMobile} - 발송 실패 >>>`, response);
            }

            results.push({
              mobile: userMobile,
              status: "failed",
              response: "failed",
              userId: undefined,
              userEmail: undefined,
              pushToken: "",
              sendType: conditionStr
            });
          }
        }catch(error){
          failCount++;
          if (process.env.DEVELOPMENT_MODE === 'local') {
            console.error(`[push/sendMsg][budalMode === true] ${conditionStr} - ${userMobile} - API 호출 오류 >>>`, error);
          }

          if (axios.isAxiosError(error)) {
            results.push({
              mobile: userMobile,
              status: MSG_ERROR,
              response: error.response?.data || error.message,
              userId: undefined,
              userEmail: undefined,
              pushToken: "",
              sendType: conditionStr
            });
          } else if (error instanceof Error) {
            results.push({
              mobile: userMobile,
              status: MSG_ERROR,
              response: error.message,
              userId: undefined,
              userEmail: undefined,
              pushToken: "",
              sendType: conditionStr
            });
          } else {
            results.push({
              mobile: userMobile,
              status: MSG_ERROR,
              response: String(error),
              userId: undefined,
              userEmail: undefined,
              pushToken: "",
              sendType: conditionStr
            });
          }
        }
        if (process.env.DEVELOPMENT_MODE === 'local') {
          console.log(`[push/sendMsg][budalMode === true] ${conditionStr} - [ ${userMobile} ] - [ ${user.email} ] >>> END >>>`);
        }
      }


      // budalMode === false 이면서, nmp_user_sign_infos에 정보가 없으면 아무것도 하지 않는다.
      // 현재, nmp_user_sign_infos에 정보가 없으면, 앱 미설치자로 한다.
      if(!budalMode && (user.pushToken === null || user.pushToken === "")){
        failCount++;

        results.push({
          mobile: userMobile,
          status: '0006',
          response: "앱 미설치자...budalMode === true인 경우 문자발송이 된다.",
          userId: String(user._id),
          userEmail: user.email,
          pushToken: "",
          sendType: "NON-INSTALLER"
        });
      }


    });
    //--------------------------------------------------------------------------------------------------------------------------------------------


    //--------------------------------------------------------------------------------------------------------------------------------------------
    // 모든 메시지 전송 완료 대기
    //--------------------------------------------------------------------------------------------------------------------------------------------
    await Promise.all(sendPromises);
    //--------------------------------------------------------------------------------------------------------------------------------------------




    // 최종 결과 출력 및 반환
    finalResults = results.map(item => ({
      sendDivision: item.sendType,
      receiveResult: String(item.response),
      receiveUser: new ObjectId(item.userId),
      receiveResultCode: item.status === MSG_SUCCESS ? MSG_OK : MSG_FAIL
    }));
    if (process.env.DEVELOPMENT_MODE === 'local') {
      console.log('[push/sendMsg][budalMode === FALSE][FCM] finalResults>>>', finalResults);
    }




    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //
    // END - FCM, Pusy.me, 문자(SMS, LMS)
    //
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
    //★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★






    //알림발송 컬렉션에 정보 저장
    const companyId = await targetCompanyCompanyInfoModel.findOne({ companyCode: companyCode }).select("_id");
    const systemAlarm = new targetSystemAlarmInfoModel({
      parentCompany: companyId._id,
      companyCode: companyCode,
      title: title,
      message: message,
      budalMode: budalMode,
      sender: sender,
      senderMobile: senderMobile,
      sendResultCode: RESULT_CODE_SUCCESS,
      receiveInfo: finalResults,
      createdAt: new Date().getTime(),
      updatedAt: new Date().getTime(),
    });
    await systemAlarm.save();


    let returnCount = {
      totalCount : totalCount,
      successCount : successCount,
      failCount : failCount,
    }

    ctx.status = 200;
    ctx.body = {
      uid : systemAlarm._id,
      resultCode: RESULT_CODE_SUCCESS,
      resultMsg: MSG_SUCCESS,
      returnCount
    };

  } catch (err) {
    console.log(err);
    ctx.status = 500;
    ctx.body = {
      uid: "",
      resultCode: RESULT_CODE_SERVER_ERROR,
      resultMsg: RESULT_CODE_SERVER_ERROR_MSG
    };
  }
};

// 문자 메시지의 바이트 길이를 계산하는 함수
function getByteLength(message: string): number {
  let byteLength = 0;
  for (const char of message) {
    // 유니코드 값에 따라 바이트 계산 (이모지와 특수문자 고려)
    const codePoint = char.codePointAt(0) ?? 0;
    if (codePoint <= 0x007f) {
      byteLength += 1; // 아스키 문자 (영어, 숫자 등)
    } else if (codePoint <= 0x07ff) {
      byteLength += 2; // 한글 등 2바이트 문자
    } else {
      byteLength += 3; // 이모지나 복잡한 문자 (UTF-8 최대 4바이트)
    }
  }
  return byteLength;
}

export default sendMsg;