export const errorResponse = (errorCode: string, errorMessage: string) => {
  const response = {
    errorCode,
    errorMessage,
  };

  return response;
};

export const UserStatusCode = {
  OFFLINE: 0,
  ONLINE: 1,
  AWAY: 2,
  VACATION: 3,
  MEETING: 4,
  TRAINING: 5,
  BUSINESS_TRAVEL: 6,
};

// M-Messenger chatting history url
export const CHATTING_HISTORY_URL = 'http://lgucap.com:9098/uCapMsg/lgUcapChat.do';

export const PW_DEFAULT_DAYS: number = 90;
export const DATE_TO_MILLISEC: number = 24 * 60 * 60 * 1000;
export const UTC_9: number = 9 * 60 * 60 * 1000;
export const HR_WORKING_STATUS_COMPANIES: string[] = ['GUC021', 'GUC100']; // innotek working status

export const ALLOWED_EXTS = [
  'png', 'jpeg', 'jpg', 'webp', 'bmp', 'heic',
  'xlsx', 'xls', 'xlsb', 'ppt', 'pptx', 'doc', 'docx',
  'pdf', 'txt', 'zip',
  'mp4', 'avi', 'mov', 'm4v',
];

export const CHAT_ROOM_MAX_MEMBERS: number = 500;
export const ENCKEYFORPARAM = "S7E5R3KJTKTKDLXTBE1MK25AY3IRJTD9"; // TODO - 임시
export const ENCRYPT_APPVERSION = "0.5.94";

export const FTP_HOST: string = 'ftp.lgmtalk.com';
