import dotenv from 'dotenv';
dotenv.config();

// import server, {serverExtNet} from 'server';
import server from 'server';

server.listen(4000);
// serverExtNet.listen(5000);
