import {Types} from 'mongoose';
import userWorkingStatusModel from '../../models/account/user_working_status';
import {cleanupWorkingStatus} from './cleanupWorkingStatus';

interface UpdateWorkingStatusParams {
  companyCode: string;
  employeeData: {
    employeeId: string;
    workingStatus: string;
  }[];
  tenantFlag: string;
}

export const updateWorkingStatusService = async ({
  companyCode,
  employeeData,
  tenantFlag
}: UpdateWorkingStatusParams): Promise<void> => {
  await cleanupWorkingStatus(companyCode, tenantFlag);
  
  const documents = employeeData.map((employee) => ({
    _id: new Types.ObjectId(),
    company_code: companyCode,
    user_id: employee.employeeId,
    attend: employee.workingStatus,
    date: new Date().toISOString().split('T')[0],
    created_at: new Date(),
    updated_at: new Date()
  }));
  
  // 성능 및 전체 DB insert fail 대비해 1000개씩 DB Transaction 처리
  const BATCH_SIZE = 1000;
  const WorkingStatusModel = userWorkingStatusModel({ tenantFlag });

  // 컬렉션이 없는 경우 : 컬렉션 생성 
  try {
    if (documents.length > 0) {
      await WorkingStatusModel.create(documents[0]);
      await WorkingStatusModel.deleteOne({ _id: documents[0]._id });
    }
  } catch (error) {
    console.log('Initial document creation error (ignorable):', error);
  }
  
  for (let i = 0; i < documents.length; i += BATCH_SIZE) {
    const batch = documents.slice(i, i + BATCH_SIZE);
    
    const session = await WorkingStatusModel.startSession();
    try {
      const result = await WorkingStatusModel.insertMany(batch, {
        session,
        ordered: false
      });
      console.log('Successfully inserted:', result.length);
    } catch (error) {
      const err = error as any;
      if (err.writeErrors) {
        console.log('Failed to insert:', err.writeErrors.length);
        console.log('Successfully inserted:', err.result.nInserted);
      }
      console.log(`Batch processing failed (${i}~${i + batch.length}):`, error);
      throw error; 
    } finally {
      await session.endSession();
    }
  }
};
