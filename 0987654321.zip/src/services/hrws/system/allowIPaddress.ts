export const allowIPaddress = (whiteList: string, clientIp: string): boolean => {
  if (!whiteList || !clientIp) {
    return false;
  }

  const whiteListArray = whiteList.split(',').map(ip => ip.trim());
  
  return whiteListArray.some(allowedIp => {
    if (allowedIp.includes('*')) {
      const ipPattern = allowedIp.replace('*', '');
      return clientIp.startsWith(ipPattern);
    }
    return allowedIp === clientIp;
  });
}; 