import jwt from 'jsonwebtoken';

export const createToken = (key: string, apiKey: string, expiryTime: number): string => {
  try {
    const payload = {
      key,
      apiKey,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + expiryTime
    };

    return jwt.sign(payload, process.env.HRWS_SECRET_KEY || '');
  } catch (err) {
    console.log('Error creating token:', err);
    return '';
  }
};

export const checkJWT = async (
  secretKey: string,
  apiKey: string,
  token: string
): Promise<{isValid: boolean; status?: number; error?: string}> => {
  try {
    const decoded = jwt.verify(token, process.env.HRWS_SECRET_KEY || '') as { key: string; apiKey: string };
    
    if (decoded.key !== secretKey || decoded.apiKey !== apiKey) {
      return {
        isValid: false,
        status: 401,
        error: 'Invalid token credentials'
      };
    }

    return {
      isValid: true
    };
  } catch (err) {
    console.log('Error verifying token:', err);
    return {
      isValid: false,
      status: 401,
      error: 'Token verification failed'
    };
  }
}; 