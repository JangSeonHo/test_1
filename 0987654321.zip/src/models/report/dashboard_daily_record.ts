import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  COMPANY_COMPANY_INFO,
  DASHBOARD_DAILY_RECORD,
} from 'models/collection_names';

// userRecord 서브스키마
const userRecordSchema = new mongoose.Schema(
  {
    deviceType: {
      type: String,
      required: true,
      //TODO: 확정 후 체크
      enum: ["android", "iOS", "windows"],
    },
    versionInfo: {
      type: String,
      // TODO: 모바일의 경우 버전이 저장이 안 되는 문제가 있어서 임시로 주석처리
      // required: true,
    },
    activeUserCounts: {
      type: Number,
      required: true,
    },
  },
  { _id: false }
);

// pushCountRecord 서브스키마
const pushCountRecordSchema = new mongoose.Schema(
  {
    sendDivision: {
      type: String,
      required: true,
      enum: ["SMS", "LMS", "FCM"],
    },
    counts: {
      type: Number,
      required: true,
    },
  },
  { _id: false }
);

// dailyRecord 서브스키마
const dailyRecordSchema = new mongoose.Schema(
  {
    chatCounts: {
      type: Number,
      required: true,
    },
    alarmCounts: {
      type: Number,
      required: true,
    },
    pushCountRecord: [pushCountRecordSchema],
    noteCounts: {
      type: Number,
      required: true,
    },
  },
  { _id: false }
);

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema(
  {
    groupCode: {
      type: String,
      required: true,
    },
    parentCompany: {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`,
      required: true,
    },
    year: {
      type: String,
      required: true,
    },
    month: {
      type: String,
      required: true,
    },
    day: {
      type: String,
      required: true,
    },
    registeredUserCounts: {
      type: Number,
      required: true,
    },
    totalUserCounts: {
      type: Number,
      required: true,
    },
    userRecord: [userRecordSchema],
    dailyRecord: dailyRecordSchema,
    createdAt: {
      type: Date,
      default: Date.now,
    }
  }
);

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${DASHBOARD_DAILY_RECORD}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const companyModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${DASHBOARD_DAILY_RECORD}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
