import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  COMPANY_COMPANY_INFO,
  STATISTICS_DAILY_RECORD,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema(
  {
    parentCompany: {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`,
      required: true,
    },
    parentUser: {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${USER_INFO}`,
      required: true,
    },
    year: {
      type: String,
      required: true,
    },
    month: {
      type: String,
      required: true,
    },
    day: {
      type: String,
      required: true,
    },
    registeredYn: {
      type: String,
      required: true,
    },
    deletedYn: {
      type: String,
      required: true,
    },
    usePcYn: {
      type: String,
      required: true,
    },
    useMobileYn: {
      type: String,
      required: true,
    },
    chatCounts: {
      type: Number,
      required: true,
    },
    noteCounts: {
      type: Number,
      required: true,
    },
    createdAt: {
      type: Number,
      required: true,
    }
  }
);

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${STATISTICS_DAILY_RECORD}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const companyModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${STATISTICS_DAILY_RECORD}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
