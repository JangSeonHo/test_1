/* eslint-disable max-len */
import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  COMPANY_COMPANY_INFO,
  SYSTEM_ALARM_INFO,
  USER_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'parentCompany': {type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`},
  'companyCode': {type: String,default: ''},
  'title': {type: String, default: ''},
  'message': {type: String, default: ''},
  'budalMode': {type: Boolean, default: false},
  'sender': {type: String, default: ''},
  'senderMobile': {type: String, default: ''},
  'sendResultCode': {type: String, default: ''},
  'receiveInfo': [{
    'receiveUser': {type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${USER_INFO}`},
    'sendDivision' : {type: String, default: ''},
    'receiveResult' : {type: String, default: ''},
    'receiveResultCode' : {type: String, default: ''}
  }],
  'createdAt': {type: Number},
  'updatedAt': {type: Number},
  'attachedFiles':[{
        originalName: {type: String, default: ''},
        fileName: {type: String, default: ''},
        path: {type: String, default: ''},
        size: {type: Number, defalut: 0}
  }]
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYSTEM_ALARM_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const deptModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SYSTEM_ALARM_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};
export default getModel;
