import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  USER_ALARM,
  SYSTEM_ALARM_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  // eslint-disable-next-line max-len
  'type': {type: String}, // type: reminder, chatting_mention, chatting_notice, chatting_important, chatting_vote, system_alarm
  'parentUser': {type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${USER_INFO}`,},
  'actionUser': {type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${USER_INFO}`,},
  'chatRoomId': {type: String},
  'chatMessageId': {type: String},
  'detailId': {type: String}, // voteId
  'content': {type: String, default: ""},
  'voteAction': {type: String}, // vote_start, vote_end
  'isRead': {type: Boolean, default: false},
  'createdAt': {type: Number},
  'alertTime': {type: Number}, // for reminder
  'isAlreadyAlert': {type: Boolean, default: false},
  'systemAlarmDivision': {type: String}, //type이 system_alar인경우 문자(SMS,MMS), FCM, pushy.me 를 구분하기 위함.
  'systemAlarmDevice': {type: String}, //type이 system_alarm인 경우이면서, FCM인 경우 android, ios 구분
  'parentSystemAlarm': {type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${SYSTEM_ALARM_INFO}`,}, //시스템 알림 _id
  'title': {type: String, default: ""},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_ALARM}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_ALARM}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const alarmModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_ALARM}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
