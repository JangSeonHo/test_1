import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  SCHEDULER_LOCK,
} from 'models/collection_names';


const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  _id: {type: String, required: true,},
  createdAt: {type: Number, required: true,},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SCHEDULER_LOCK}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const schedulerLockModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${SCHEDULER_LOCK}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;