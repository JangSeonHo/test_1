import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  CHATTING_ROOM_INFO,
  CHATTING_ROOM_MESSAGE,
  CHATTING_ROOM_MESSAGE_EG,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  parentChattingRoom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_INFO}`,
  },
  parentChattingMessage: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_MESSAGE}`,
  },
  R1: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${USER_INFO}`,
    },
  ],
  R2: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${USER_INFO}`,
    },
  ],
  R3: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${USER_INFO}`,
    },
  ],
  R4: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${USER_INFO}`,
    },
  ],
  R5: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${USER_INFO}`,
    },
  ],
  R6: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${USER_INFO}`,
    },
  ],
  R7: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${USER_INFO}`,
    },
  ],
  R8: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${USER_INFO}`,
    },
  ],
  R9: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${USER_INFO}`,
    },
  ],
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE_EG}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE_EG}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const chatRoomMsgEgModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE_EG}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
