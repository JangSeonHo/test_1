import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  CHATTING_ROOM_INFO,
  CHATTING_ROOM_MESSAGE,
  CHATTING_ROOM_MESSAGE_VOTE,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  parentUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  },
  parentChattingRoom: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_INFO}`,
  },
  parentChattingMessage: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_MESSAGE}`,
  },
  // votes
  allowMultipleVote: {type: Boolean},
  allowTextReply: {type: Boolean},
  anonymousVote: {type: Boolean},
  createdAt: {type: Number},
  deadline: {type: Number},
  voteTitle: {type: String},
  voteRecords: {},
  voteType: {type: String, default: 'text'},
  voteItems: [
    {
      label: {type: String},
      image: {
        url: {type: String},
        fileName: {type: String},
        size: {type: Number},
        mimeType: {type: String},
      },
    },
  ],
  isEnded: {type: Boolean, default: false},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE_VOTE}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE_VOTE}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const chatRoomMsgVoteModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_MESSAGE_VOTE}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
