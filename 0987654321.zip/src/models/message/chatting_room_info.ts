import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  CHATTING_ROOM_INFO,
  CHATTING_ROOM_MESSAGE,
  CHATTING_COUNTER,
  CHATTING_ROOM_MESSAGE_NOTICE,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  roomName: {type: String},
  ucapRoomId: {type: String},
  totalRoomMembers: {type: Number},
  isGroupChat: {type: Boolean},
  isMyChat: {type: Boolean},
  isMyGptChat: {type: Boolean, default: false},
  childUsers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  }], // 그룹쳇에서는 아무 의미 없음
  // gropuChatChildUsers: [{
  //   type: mongoose.Schema.Types.ObjectId,
  //   ref: `${tenantFlag}_${USER_INFO}`,
  // }],
  childLastMessage: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_MESSAGE}`,
  },
  childNoticeMessage: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_ROOM_MESSAGE_NOTICE}`,
  },
  childChattingCounter: {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${CHATTING_COUNTER}`,
  },
  createdAt: {type: Number},
  reName: {type: Boolean, default: false},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_INFO}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const roomInfoModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${CHATTING_ROOM_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
