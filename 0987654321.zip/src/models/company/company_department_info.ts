/* eslint-disable max-len */
import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  COMPANY_GROUP_INFO,
  COMPANY_DEPARTMENT_INFO,
  COMPANY_COMPANY_INFO,
  USER_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'departmentName': {
    'ko': {type: String, default: ''},
    'en': {type: String, default: ''},
  },
  'parentGroup': {type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${COMPANY_GROUP_INFO}`},
  'parentCompany': {type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`},
  'parentDepartments': [{type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${COMPANY_DEPARTMENT_INFO}`}],
  'childDepartments': [{type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${COMPANY_DEPARTMENT_INFO}`, default: []}],
  'childUsers': [{type: mongoose.Schema.Types.ObjectId, ref: `${tenantFlag}_${USER_INFO}`}],
  'totalChildUsers': {type: Number},
  'lastModifiedAt': {type: Number},
  'originCode': {type: String},
  'isDeleted': {type: Boolean, default: false},
  'siblingOrders': {type: String, default: ''},
  'siblingDepth': {type: Number},
  'siblingLevel':{type: Number},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${COMPANY_DEPARTMENT_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const deptModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${COMPANY_DEPARTMENT_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};
export default getModel;
