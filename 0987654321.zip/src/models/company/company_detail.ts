import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
    COMPANY_COMPANY_INFO,
    COMPANY_DETAIL,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
    //부모 회사코드
    parentCompany: {
        type: mongoose.Schema.Types.ObjectId,
        ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`,
    },
    //라이센스(구매수량)
    license: {
        type: Number,
        required: false,
        default: 0,
    },
    //도메인
    companyDomain: {
        type: String,
        required: true,
    },
    //약관버전
    companyTerms: {
        type: String,
        required: true,
    },
    //비밀번호 변경주기
    passwordChangeCycle: {
        type: Number,
        required: false,
        default: 0,
    },
    //장기 미접속 계정잠금 - PC
    longNonAccessLockPcYn: {
        type: String,
        required: false,
        default: "N",
    },
    //장기 미접속 계정잠금 - PC - 기간
    longNonAccessLockPcPeriod: {
        type: Number,
        required: false,
        default: 0,
    },
    //장기 미접속 계정잠금 - Mobile
    longNonAccessLockMobileYn: {
        type: String,
        required: false,
        default: "N",
    },
    //장기 미접속 계정잠금 - Mobile - 기간
    longNonAccessLockMobilePeriod: {
        type: Number,
        required: false,
        default: 0,
    },
    //조직도 조회권한 - PC 조회범위 - [그룹사 전체(GROUP), 소속회사(COMPANY), 권한없음(NONE)]
    orgReadAuthorityPc: {
        type: String,
        required: false,
        default: "",
    },
    //조직도 조회권한 - Mobile 조회범위 - [그룹사 전체(GROUP), 소속회사(COMPANY), 권한없음(NONE)]
    orgReadAuthorityMobile: {
        type: String,
        required: false,
        default: "",
    },
    //내/외부망 체크유무 - [포트체크 진행, 무시]
    networkSeparationCheckYn: {
        type: String,
        required: false,
        default: "N",
    },
    //보안 강화(모바일) - Mobile단일인증 적용여부
    secuirtyEnforceMobileSingleAuthYn: {
        type: String,
        required: false,
        default: "N",
    },
    //보안 강화(모바일) - 암호잠금 강제 여부
    secuirtyEnforceMobilePasswordLockYn: {
        type: String,
        required: false,
        default: "N",
    },
    //메시지 저장 기간
    msgSavePeriod: {
        type: Number,
        required: false,
        default: 0,
    },
    //메신저 사용 권한
    messengerUseYn: {
        type: String,
        required: false,
        default: "N",
    },
    //번역사용
    translationYn: {
        type: String,
        required: false,
        default: "N",
    },
    //파일 발신 파일 용량 - PC (MB)
    sentFileSizePc: {
        type: Number,
        required: false,
        default: 0,
    },
    //파일 발신 파일 용량 - Mobile (MB)
    sentFileSizeMobile: {
        type: Number,
        required: false,
        default: 0,
    },
    //파일 서버저장기간 - 일수
    fileServerSavePeriod: {
        type: Number,
        required: false,
        default: 0,
    },
    //업로드/다운로드 권한 - PC - 업로드, 다운로드, 권한없음
    fileControlAuthorityPc: {
        type: String,
        required: false,
    },
    //업로드/다운로드 권한 - Mobile - 업로드, 다운로드, 권한없음
    fileControlAuthorityMobile: {
        type: String,
        required: false,
    },
    //파일 전송 가능 회사
    manageCompany: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: `${tenantFlag}_${COMPANY_COMPANY_INFO}`,
        }
    ],
    //사용여부(회사에 대한 사용여부. 개발중이어서 현재는 여기에다가 하고, 추후 본 회사컬렉션에 추가할 예정임. 2024.01.23)
    useYn: {
        type: String,
        required: false,
        default: "Y"
    },
    //생성자
    creator: {
        type: String,
        required: false,
        default: ""
    },
    //수정자
    updater:  {
        type: String,
        required: false,
        default: ""
    },
    // 개인정보 필터링 여부
    privacyFilterYn: {type: String, default: 'Y'},
    // 자사전용 사용 여부
    useCompanyOnlyYn: {type: String, default: 'N'},
    // 캡쳐방지 비활성화 여부
    isDisableNoCapturing: {type: Boolean, default: false},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${COMPANY_DETAIL}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const companyDetailModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${COMPANY_DETAIL}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
