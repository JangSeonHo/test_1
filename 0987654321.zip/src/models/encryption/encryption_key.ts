import mongoose from 'mongoose';

import {
  ENCRYPTION_KEY,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'encryptionKey': {type: String},
  'iv': {type: String},
  'tenantFlag': {type: String},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${ENCRYPTION_KEY}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
