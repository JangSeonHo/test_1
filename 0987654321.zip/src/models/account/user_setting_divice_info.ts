/* eslint-disable max-len */
import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  USER_SETTING_DIVICE_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'parentUser': {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  },
  'deviceType': {type: String},                          // deviceType
  'versionInfo': {type: String},                         // 버전 정보

  //알림 설정
  'usePushAlarm': {type: Boolean, default: true},        // 푸시알림 받기
  'useAlarmChatMessage': {type: Boolean, default: true}, // 일반 메세지
  'useAlarmChatMention': {type: Boolean, default: true}, // 나를 멘션
  'useAlarmChatNotice': {type: Boolean, default: true},  // 공지사항
  'useAlarmChatVote': {type: Boolean, default: true},    // 투표
  'useAlarmNote': {type: Boolean, default: true},        // 쪽지

  //알림 방식
  'notificationType': {type: Number, default: 3},        // PC 알림 방법 1 소리, 2 알림창, 3 소리, 알림창
  'notificationDuration': {type: Number, default: 5},    // PC 알림창 노출시간
  'useAlarmSound': {type: Boolean, default: true},       // 모바일 소리
  'useAlarmVibrate': {type: Boolean, default: true},     // 모바일 진동

  //모바일 방해금지 시간설정
  'useAlarmAllowedTime': {type: Boolean, default: false}, // 방해금지 시간설정
  'alarmAllowedTime': {                                   // 방해금지 시작/종료시간
    'start': {type: Number, default: 9},
    'end': {type: Number, default: 18},
  },
  'timezoneOffset': {type: Number, default: 0}, // 0 = GMT+9

  //[PC]모바일 알림, [모바일]PC에서 부재중일 때만 알림받기 (같은 필드를 다른 용어로 사용, 서로 같은 데이터일 수 없음)
  'onlyAlarmWhenPCIsAbsence': {type: Boolean, default: false},
  
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_SETTING_DIVICE_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_SETTING_DIVICE_INFO}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const userSettingDeviceInfoPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_SETTING_DIVICE_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
