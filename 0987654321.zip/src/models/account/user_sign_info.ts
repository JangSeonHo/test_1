import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_INFO,
  USER_SIGN_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'parentUser': {
    type: mongoose.Schema.Types.ObjectId,
    ref: `${tenantFlag}_${USER_INFO}`,
  },
  'sendStream': {type: Boolean, default: false}, // flag for steam
  'accessToken': {type: String},
  'refreshToken': {type: String},
  'deviceId': {type: String},
  'deviceType': {type: String}, // m(mobile), p(pc)
  'versionInfo': {type: String},
  'pushType': {type: String, default: 'fcm'},
  'pushToken': {type: String},
  'isChina': {type: Boolean},
  'initialSignedAt': {type: Number},
  'lastRefreshedAt': {type: Number},
  'alarmOffChattingRooms': {type: Array, default: []},
  'useEnUserInfo': {type: Boolean, default: false},
  'usePushAlarm': {type: Boolean, default: true},
  'useAlarmAllowedTime': {type: Boolean, default: false},
  'alarmAllowedTime': {
    'start': {type: Number, default: 9},
    'end': {type: Number, default: 18},
  },
  'timezoneOffset': {type: Number, default: 0}, // 0 = GMT+9
  'pcStatus': {type: mongoose.Schema.Types.Mixed, default: 0},
  'onlyAlarmWhenPCIsAbsence': {type: Boolean, default: false},
  'usePCLoginAlarm': {type: Boolean, default: false},
  'useAlarmChatMessage': {type: Boolean, default: true},
  'useAlarmNote': {type: Boolean, default: true},
  'useAlarmChatVote': {type: Boolean, default: true},
  'useAlarmChatNotice': {type: Boolean, default: true},
  'useAlarmImportantMessage': {type: Boolean, default: true},
  'useAlarmChatMention': {type: Boolean, default: true},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_SIGN_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_SIGN_INFO}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const userSignModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_SIGN_INFO}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
