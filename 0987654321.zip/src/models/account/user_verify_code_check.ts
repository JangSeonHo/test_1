import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  USER_VERIFY_CODE_CHECK,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  verifyId: { type: String, required: true },
  authType: { type: String, required: true }, // email or phone
  createdAt: { type: Date, default: Date.now, expires: 60 }, // 1분 뒤에 자동 삭제용 Date
  createdAtMs: { type: Number, default: () => Date.now() },  // 밀리초 기록용 Number
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_VERIFY_CODE_CHECK}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_VERIFY_CODE_CHECK}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export const userStatusModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${USER_VERIFY_CODE_CHECK}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
