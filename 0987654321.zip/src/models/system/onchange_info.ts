import mongoose from 'mongoose';
// import {dbPrimaryOnly} from '../../server';

import {
  ONCHANGE_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'collName': {type: String},
  'changeValue': {type: mongoose.Schema.Types.Mixed},
  'createdAt': {type: Number, default: 0},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${ONCHANGE_INFO}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

import streamMongoose from 'configs/streamMongoose';

export const streamModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${ONCHANGE_INFO}`;

  return streamMongoose.models[modelName] ||
    streamMongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
