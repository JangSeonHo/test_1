import mongoose from 'mongoose';
import {dbPrimaryOnly} from '../../server';

import {
  LOADBALANCER_IP,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'enable': {type: Boolean},
  'domain': {type: String},
  'ip1': {type: Number},
  'ip2': {type: Number},
  'isExt': {type: Boolean},
  'updatedAt': {type: Number},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${LOADBALANCER_IP}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export const lbipModelPrimaryOnly = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${LOADBALANCER_IP}`;

  return dbPrimaryOnly.models[modelName] ||
    dbPrimaryOnly.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
