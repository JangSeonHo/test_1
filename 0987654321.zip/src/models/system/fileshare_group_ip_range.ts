import mongoose from 'mongoose';

import {
  FILESHARE_GROUP_IP,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'groupName': {type: String},
  'ipRangeStart': {type: Number},
  'ipRangeEnd': {type: Number},
  'isEnable': {type: Boolean},
  'creator': {type: String},
  'description': {type: String},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${FILESHARE_GROUP_IP}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
