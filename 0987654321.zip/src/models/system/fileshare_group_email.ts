import mongoose from 'mongoose';

import {
  FILESHARE_GROUP_EMAIL,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema({
  'groupName': {type: String},
  'email': {type: String},
});

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${FILESHARE_GROUP_EMAIL}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
