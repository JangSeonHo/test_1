import mongoose from 'mongoose';

import {
  DISTRIBUTION_MANAGEMENT,
  COMPANY_GROUP_INFO,
} from 'models/collection_names';

const getSchema = ({tenantFlag}: {tenantFlag: string}) => new mongoose.Schema(
  {
    device: {
      type: String,
      required: false,
    },
    deploymentMode: {
      type: String,
      required: false,
    },
    version: {
      type: String,
      required: true,
    },
    distributionDate: {
      type: Date,
      required: false,
    },
    versionName: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: false,
    },
    status: {
      type: String,
      required: false,
    },
    companyGroup: {
      type: mongoose.Schema.Types.ObjectId,
      ref: `${tenantFlag}_${COMPANY_GROUP_INFO}`,
    },
    files: [
      {
        originalName: String,
        fileName: String,
        path: String,
        size: Number,
      },
    ],
  },
  {
    timestamps: true,
  },
);

const getModel = ({tenantFlag}: {tenantFlag: string}) => {
  const modelName = `${tenantFlag}_${DISTRIBUTION_MANAGEMENT}`;

  return mongoose.models[modelName] ||
    mongoose.model(modelName, getSchema({tenantFlag}));
};

export default getModel;
