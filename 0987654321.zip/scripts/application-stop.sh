#!/bin/bash
REPOSITORY=/svc/engn001/nmp/nmp-ap-server

cd $REPOSITORY

. /home/nmpapp/.nvm/nvm.sh && npm run stop && npm run delete
