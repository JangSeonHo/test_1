#!/bin/bash
REPOSITORY=/svc/engn001/nmp/nmp-ap-server

sudo chmod 777 $REPOSITORY

cd $REPOSITORY

cp $REPOSITORY/../.env ./

. /home/nmpapp/.nvm/nvm.sh && npm i && npm run build && npm run start