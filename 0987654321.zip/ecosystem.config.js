module.exports = {
  apps: [
    {
      name: 'nmp',
      // eslint-disable-next-line max-len
      script: './dist/src/prod.js',
      instances: 0,
      exec_mode: 'cluster',
      out_file: '/svc/logs001/nmp/out.log',
      error_file: '/svc/logs001/nmp/error.log',
    },
  ],
};
